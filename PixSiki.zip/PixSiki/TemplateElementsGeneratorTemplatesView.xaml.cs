﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TemplateElementsGenerator.TemplatesView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Questions;
using PixBlocks.TemplateElementsGenerator.Icons;
using PixBlocks.Views.CodeElements;
using PixBlocks.Views.DragDropController;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.TemplateElementsGenerator
{
  public partial class TemplatesView : UserControl, IComponentConnector
  {
    public CircleButton maximaliseButton;
    public CircleButton minimaliseButton;
    private CircleButton infoButton;
    private CircleButton infoCancelButton;
    private bool isPythonCode;
    private StackPanel AllCodeViews;
    private bool isFreez;
    private Point clickPoint = new Point(-100.0, -100.0);
    private double svVerticalOffset;
    private double svHorizontalOffset;
    internal RowDefinition BottonGrid;
    internal ScrollViewer scroll;
    internal Grid mainGrid;
    internal Grid freezGrid;
    internal Grid maximaliseButtonGrid;
    internal StackPanel bottonGrid;
    private bool _contentLoaded;

    public TemplatesView()
    {
      this.InitializeComponent();
      this.AllCodeViews = new TemplateModelsGenerator().GatAllCodeViews();
      this.mainGrid.Children.Add((UIElement) this.AllCodeViews);
      this.infoButton = new CircleButton((UserControl) new InfoIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.infoButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.InfoButton_buttonClickedEvent);
      this.infoCancelButton = new CircleButton((UserControl) new InfoIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.infoCancelButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.InfoButton_buttonClickedEvent1);
      this.bottonGrid.Children.Add((UIElement) this.infoButton);
      this.bottonGrid.Children.Add((UIElement) this.infoCancelButton);
      this.infoCancelButton.Visibility = Visibility.Collapsed;
      this.SetFreez(false);
      this.maximaliseButton = new CircleButton((UserControl) new MaximaliseIcon(), Color.FromRgb((byte) 40, (byte) 120, (byte) 245), CircleButton.VisualParam.circle);
      this.maximaliseButtonGrid.Children.Add((UIElement) this.maximaliseButton);
      this.minimaliseButton = new CircleButton((UserControl) new MinimaliseIcon(), Color.FromRgb((byte) 40, (byte) 120, (byte) 245), CircleButton.VisualParam.circle);
      this.maximaliseButtonGrid.Children.Add((UIElement) this.minimaliseButton);
      this.ShowMaximaliseButton(false);
    }

    public void ShowMaximaliseButton(bool show)
    {
      if (show)
      {
        this.maximaliseButton.Visibility = Visibility.Visible;
        this.minimaliseButton.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.maximaliseButton.Visibility = Visibility.Collapsed;
        this.minimaliseButton.Visibility = Visibility.Visible;
      }
    }

    private void InfoButton_buttonClickedEvent1()
    {
      this.ShowDescriptions(false);
      this.infoCancelButton.Visibility = Visibility.Collapsed;
      this.infoButton.Visibility = Visibility.Visible;
    }

    private void InfoButton_buttonClickedEvent()
    {
      this.ShowDescriptions(true);
      this.infoCancelButton.Visibility = Visibility.Visible;
      this.infoButton.Visibility = Visibility.Collapsed;
    }

    public void IsPythonCode(bool isPythonCode, Question question)
    {
      this.isPythonCode = isPythonCode;
      if (isPythonCode)
      {
        this.infoButton.Visibility = Visibility.Collapsed;
        this.infoCancelButton.Visibility = Visibility.Collapsed;
      }
      foreach (object child1 in this.AllCodeViews.Children)
      {
        if (child1 is WrapPanel)
        {
          foreach (TemplatAndDscription child2 in (child1 as WrapPanel).Children)
            child2.IsPythonCode(isPythonCode, question);
        }
        SmallLine smallLine = child1 as SmallLine;
      }
      this.scroll.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
    }

    public void ShowDescriptions(bool showDescription)
    {
      this.scroll.VerticalScrollBarVisibility = ScrollBarVisibility.Hidden;
      foreach (object child1 in this.AllCodeViews.Children)
      {
        if (child1 is WrapPanel)
        {
          foreach (TemplatAndDscription child2 in (child1 as WrapPanel).Children)
            child2.ShowDescription(showDescription);
        }
        SmallLine smallLine = child1 as SmallLine;
      }
      this.scroll.VerticalScrollBarVisibility = ScrollBarVisibility.Visible;
      this.scroll.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
    }

    public void SaveAllUniqueNames()
    {
      string contents = "";
      foreach (object child1 in this.AllCodeViews.Children)
      {
        if (child1 is WrapPanel)
        {
          foreach (TemplatAndDscription child2 in (child1 as WrapPanel).Children)
            contents = contents + child2.GetCodeElement().GetUniqueName() + "\r\n";
        }
        SmallLine smallLine = child1 as SmallLine;
      }
      File.WriteAllText("AllTemplatesIDs.txt", contents);
    }

    public void SetVisibleForAll()
    {
      foreach (object child1 in this.AllCodeViews.Children)
      {
        if (child1 is WrapPanel)
        {
          foreach (IUCWithICodeElement child2 in (child1 as WrapPanel).Children)
            (child2 as UserControl).Visibility = Visibility.Visible;
        }
        if (child1 is SmallLine)
          (child1 as SmallLine).Visibility = Visibility.Visible;
      }
    }

    public void SetVisibleOnlyElementsFromCode(RepeatNTimes root)
    {
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      List<ICodeElement> blockElements = root.GetBlockElements();
      for (int index = 0; index < blockElements.Count; ++index)
      {
        if (!(blockElements[index] is AssigmentInstruction) || (blockElements[index] as AssigmentInstruction).TypeOfAssigment != AssigmentInstructionType.BreakAll)
          codeElementList.AddRange((IEnumerable<ICodeElement>) blockElements[index].InnerCodeElements());
      }
      List<string> stringList = new List<string>();
      foreach (ICodeElement codeElement in codeElementList)
      {
        string uniqueName = codeElement.GetUniqueName();
        if (!stringList.Contains(uniqueName))
          stringList.Add(uniqueName);
      }
      bool flag = false;
      foreach (object child1 in this.AllCodeViews.Children)
      {
        if (child1 is WrapPanel)
        {
          flag = false;
          foreach (IUCWithICodeElement child2 in (child1 as WrapPanel).Children)
          {
            if (!stringList.Contains(child2.GetCodeElement().GetUniqueName()))
            {
              (child2 as UserControl).Visibility = Visibility.Collapsed;
            }
            else
            {
              (child2 as UserControl).Visibility = Visibility.Visible;
              flag = true;
            }
          }
        }
        if (child1 is SmallLine)
        {
          if (flag)
            (child1 as SmallLine).Visibility = Visibility.Visible;
          else
            (child1 as SmallLine).Visibility = Visibility.Collapsed;
          flag = false;
        }
      }
    }

    internal void HideAllElements()
    {
      foreach (object child1 in this.AllCodeViews.Children)
      {
        if (child1 is WrapPanel)
        {
          foreach (IUCWithICodeElement child2 in (child1 as WrapPanel).Children)
            (child2 as UserControl).Visibility = Visibility.Collapsed;
        }
        if (child1 is SmallLine)
          (child1 as SmallLine).Visibility = Visibility.Collapsed;
      }
    }

    private void UserControl_MouseEnter(object sender, MouseEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType == StaticDragController.DraggingType.None || ((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().GetIsTemplateElement())
        return;
      DragElementView.Instance.RemoveElement = true;
    }

    private void UserControl_MouseLeave(object sender, MouseEventArgs e) => DragElementView.Instance.RemoveElement = false;

    private void UserControl_MouseUp(object sender, MouseButtonEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None && !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().GetIsTemplateElement())
        ((IUCWitchCodeBlockParent) StaticDragController.Instance.UcToDrag).CodeBlockParent.RemoveChild(StaticDragController.Instance.UcToDrag);
      DragElementView.Instance.RemoveElement = false;
    }

    internal void SetFreez(bool isFreez)
    {
      this.isFreez = isFreez;
      if (isFreez)
      {
        this.freezGrid.Visibility = Visibility.Visible;
        this.ShowDescriptions(true);
        this.infoCancelButton.Visibility = Visibility.Visible;
        this.infoButton.Visibility = Visibility.Collapsed;
        if (!this.isPythonCode)
          return;
        this.infoButton.Visibility = Visibility.Collapsed;
        this.infoCancelButton.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.Visibility = Visibility.Visible;
        this.freezGrid.Visibility = Visibility.Hidden;
        this.ShowDescriptions(false);
        this.infoCancelButton.Visibility = Visibility.Collapsed;
        this.infoButton.Visibility = Visibility.Visible;
        if (!this.isPythonCode)
          return;
        this.infoButton.Visibility = Visibility.Collapsed;
        this.infoCancelButton.Visibility = Visibility.Collapsed;
      }
    }

    private void mainGrid_MouseMove(object sender, MouseEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      Point position = e.GetPosition((IInputElement) this);
      if (this.clickPoint.Y == -100.0)
        return;
      this.scroll.ScrollToVerticalOffset(this.svVerticalOffset - position.Y + this.clickPoint.Y);
      this.scroll.ScrollToHorizontalOffset(this.svHorizontalOffset - position.X + this.clickPoint.X);
    }

    private void mainGrid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.svVerticalOffset = this.scroll.VerticalOffset;
      this.svHorizontalOffset = this.scroll.HorizontalOffset;
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.clickPoint = e.GetPosition((IInputElement) this);
    }

    private void mainGrid_MouseUp(object sender, MouseButtonEventArgs e) => this.clickPoint = new Point(-100.0, -100.0);

    private void mainGrid_MouseLeave(object sender, MouseEventArgs e) => this.clickPoint = new Point(-100.0, -100.0);

    internal void DisposeAll()
    {
      foreach (object child1 in this.AllCodeViews.Children)
      {
        if (child1 is WrapPanel)
        {
          foreach (TemplatAndDscription child2 in (child1 as WrapPanel).Children)
            child2.DisposeAll();
        }
      }
      this.mainGrid.Children.Clear();
      this.AllCodeViews = (StackPanel) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/templateelementsgenerator/templatesview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.UserControl_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.UserControl_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.UserControl_MouseUp);
          break;
        case 2:
          this.BottonGrid = (RowDefinition) target;
          break;
        case 3:
          this.scroll = (ScrollViewer) target;
          break;
        case 4:
          this.mainGrid = (Grid) target;
          this.mainGrid.MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          this.mainGrid.MouseLeave += new MouseEventHandler(this.mainGrid_MouseLeave);
          this.mainGrid.MouseMove += new MouseEventHandler(this.mainGrid_MouseMove);
          this.mainGrid.MouseUp += new MouseButtonEventHandler(this.mainGrid_MouseUp);
          break;
        case 5:
          this.freezGrid = (Grid) target;
          this.freezGrid.MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          this.freezGrid.MouseLeave += new MouseEventHandler(this.mainGrid_MouseLeave);
          this.freezGrid.MouseMove += new MouseEventHandler(this.mainGrid_MouseMove);
          this.freezGrid.MouseUp += new MouseButtonEventHandler(this.mainGrid_MouseUp);
          break;
        case 6:
          this.maximaliseButtonGrid = (Grid) target;
          break;
        case 7:
          this.bottonGrid = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
