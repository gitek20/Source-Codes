﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonCode.Views.SampleWindow
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Questions;
using PixBlocks.Tools.CodeParser;
using PixBlocks.Tools.QuestionsParser;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.PythonCode.Views
{
  public partial class SampleWindow : Window, IComponentConnector
  {
    private RepeatNTimes rootCodeAsk;
    private TextEditor textEdit;
    internal Grid mainGrid;
    internal Button button;
    internal TextBlock textBlock;
    internal Grid droppigGrid;
    internal TextBox text;
    internal Grid resultGrid;
    private bool _contentLoaded;

    public SampleWindow()
    {
      this.InitializeComponent();
      Question question = QuestionCategoryLoaderAndSever.QuestionOfGuid(QuestionCategoryLoaderAndSever.LoadCategory(QuestionCategoryLoaderAndSever.LoadCategory(QuestionCategoryLoaderAndSever.GetMainCategory().SubcategoriesUniquePaths[10]).SubcategoriesUniquePaths[0]).SubQuestionsGuids[0]);
      this.rootCodeAsk = CodeStringParser.GenerateModelFromCode(question.Code);
      this.TextEdit = new TextEditor(this.rootCodeAsk, (RepeatNTimes) null, question);
      this.TextEdit.canCompileProgramEvent += new TextEditor.CanCompileProgram(this.TextEdit_canCompileProgramEvent);
      this.mainGrid.Children.Add((UIElement) this.TextEdit);
      this.TextEdit.textBox.TextChanged += new TextChangedEventHandler(this.TextBox_TextChanged);
    }

    private void TextEdit_canCompileProgramEvent(int canCompile)
    {
      if (canCompile == 1)
        this.text.Text = this.rootCodeAsk.GetPythonCode("");
      else
        this.text.Text = "BŁĄD";
    }

    private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
    }

    public TextEditor TextEdit
    {
      get => this.textEdit;
      set => this.textEdit = value;
    }

    public SampleWindow(RepeatNTimes rootCodeAsk)
    {
      this.InitializeComponent();
      this.TextEdit = new TextEditor();
      this.mainGrid.Children.Add((UIElement) this.TextEdit);
      this.TextEdit.SetText(rootCodeAsk);
    }

    public SampleWindow(string text)
    {
      this.InitializeComponent();
      this.TextEdit = new TextEditor();
      this.mainGrid.Children.Add((UIElement) this.TextEdit);
      this.TextEdit.SetText(text);
    }

    private void button_Click(object sender, RoutedEventArgs e)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoncode/views/samplewindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.button = (Button) target;
          this.button.Click += new RoutedEventHandler(this.button_Click);
          break;
        case 3:
          this.textBlock = (TextBlock) target;
          break;
        case 4:
          this.droppigGrid = (Grid) target;
          break;
        case 5:
          this.text = (TextBox) target;
          break;
        case 6:
          this.resultGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
