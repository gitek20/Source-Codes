﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonCode.Controllers.ModelToPythonConverter.PythonToModelParser
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.DataModels.Code.Variables;
using System.Collections.Generic;
using System.Linq;

namespace PixBlocks.PythonCode.Controllers.ModelToPythonConverter
{
  internal class PythonToModelParser
  {
    public ParsingResult TryToParse(string pythonText)
    {
      List<int> intList = new List<int>();
      pythonText = pythonText.Replace("\r\n", "\n");
      pythonText = pythonText.TrimEnd("\n"[0]);
      pythonText = pythonText.Replace("else :", "else");
      pythonText = pythonText.Replace("else:", "else");
      pythonText = pythonText.Replace("else", " else");
      pythonText = pythonText.Replace(")or ", ") or ");
      pythonText = pythonText.Replace(")and ", ") and ");
      pythonText = pythonText.Replace(" or(", " or (");
      pythonText = pythonText.Replace(" and(", " and (");
      pythonText = pythonText.Replace(")and(", ") and (");
      pythonText = pythonText.Replace(")or(", ") or (");
      List<string> stringList1 = new List<string>();
      stringList1.AddRange((IEnumerable<string>) pythonText.Split("\n"[0]));
      List<string> stringList2 = new List<string>();
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      for (int index = 0; index < stringList1.Count; ++index)
      {
        ParsingResult parseSingleLine = this.TryToParseSingleLine(stringList1[index].Replace("\r", ""));
        parseSingleLine.LineNumber = index;
        codeElementList.Add(parseSingleLine.ParsedCodeElement);
        if (parseSingleLine.IsOK)
          parseSingleLine.ParsedCodeElement.PutIsTemplateElement(false);
        else
          intList.Add(index);
      }
      RepeatNTimes repeatNtimes = new RepeatNTimes();
      repeatNtimes.InnerCodeElements().Clear();
      repeatNtimes.PutIsTemplateElement(false);
      List<ICodeElement> source = new List<ICodeElement>();
      source.Add((ICodeElement) repeatNtimes);
      for (int index = 0; index < stringList1.Count; ++index)
      {
        int num = stringList1[index].Length - stringList1[index].TrimStart(" "[0]).Length;
        ICodeElement newBlockElement = codeElementList[index];
        if (newBlockElement != null)
        {
          if (num <= source.Count - 1)
          {
            source.RemoveRange(num + 1, source.Count - 1 - num);
            if (!(source.Last<ICodeElement>() as ICodeInstructionBlock).TryToAddBlockElement(newBlockElement) && !intList.Contains(index))
              intList.Add(index);
            newBlockElement.SetParent(source.Last<ICodeElement>());
            if (newBlockElement is ICodeInstructionBlock)
              source.Add(newBlockElement);
          }
          else if (!intList.Contains(index))
            intList.Add(index);
        }
      }
      if (intList.Count == 0)
        return new ParsingResult((ICodeElement) repeatNtimes, pythonText)
        {
          BadLinesIndexes = intList
        };
      return new ParsingResult(ParsingErrorType.undefinedError, pythonText)
      {
        BadLinesIndexes = intList
      };
    }

    private ParsingResult TryToParseSingleLine(string text)
    {
      text = text.ToLower();
      text = text.TrimStart(" "[0]);
      if (text.Contains("loop ") && text.Substring(0, "loop ".Length) == "loop ")
      {
        string text1 = text.Substring("loop ".Length).TrimEnd(":"[0]);
        if (text1.Contains("#"))
        {
          string[] strArray = text1.Split("#"[0]);
          if (strArray.Length == 2)
          {
            ParsingResult parseProcedure1 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(strArray[0]);
            ParsingResult parseProcedure2 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(strArray[1]);
            if (parseProcedure1.IsOK && parseProcedure1.ParsedCodeElement.GetRetunType() != ValueType.Number)
              return new ParsingResult(ParsingErrorType.undefinedError, text);
            if (parseProcedure1.IsOK && parseProcedure2.IsOK && parseProcedure2.ParsedCodeElement is Variable)
            {
              Variable parsedCodeElement = parseProcedure2.ParsedCodeElement as Variable;
              if (parsedCodeElement.GetRetunType() == ValueType.Number && parsedCodeElement.VariableType == VariableType.variable)
              {
                RepeatNTimes repeatNtimes = new RepeatNTimes(RepeatNTimesType.loopAndStep);
                repeatNtimes.NumberOfIteration = parseProcedure1.ParsedCodeElement;
                repeatNtimes.NumberOfIteration.SetParent((ICodeElement) repeatNtimes);
                repeatNtimes.StepVariable = parseProcedure2.ParsedCodeElement;
                repeatNtimes.StepVariable.SetParent((ICodeElement) repeatNtimes);
                return new ParsingResult((ICodeElement) repeatNtimes, text);
              }
            }
          }
          return new ParsingResult(ParsingErrorType.undefinedError, text);
        }
        ParsingResult parseProcedure = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(text1);
        if (parseProcedure.IsOK && parseProcedure.ParsedCodeElement.GetRetunType() != ValueType.Number)
          return new ParsingResult(ParsingErrorType.undefinedError, text);
        if (!parseProcedure.IsOK)
          return parseProcedure;
        RepeatNTimes repeatNtimes1 = new RepeatNTimes();
        repeatNtimes1.NumberOfIteration = parseProcedure.ParsedCodeElement;
        repeatNtimes1.NumberOfIteration.SetParent((ICodeElement) repeatNtimes1);
        return new ParsingResult((ICodeElement) repeatNtimes1, text);
      }
      if (text.Contains("if ") && text.Substring(0, "if ".Length) == "if ")
      {
        string text1 = text.Substring("if ".Length).TrimEnd(":"[0]);
        if (text1.Contains(" and ") || text1.Contains(" or "))
        {
          ParsingResult parseProcedure = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(text1);
          if (!parseProcedure.IsOK)
            return new ParsingResult(ParsingErrorType.ifThenNotProper, text1);
          IfThenInstruction ifThenInstruction = new IfThenInstruction(IfThenInstructionType.BooleanInstruction);
          ifThenInstruction.Arguments.Clear();
          ifThenInstruction.Arguments.Add(parseProcedure.ParsedCodeElement);
          parseProcedure.ParsedCodeElement.SetParent((ICodeElement) ifThenInstruction);
          return new ParsingResult((ICodeElement) ifThenInstruction, text);
        }
        IfThenInstructionType ifThenInstructionType = IfThenInstructionType.TurtleSeeColor;
        if (text1.Contains("=="))
        {
          text1 = text1.Replace("==", "\r");
          ifThenInstructionType = IfThenInstructionType.EqualsNumbers;
        }
        if (text1.Contains("!="))
        {
          text1 = text1.Replace("!=", "\r");
          ifThenInstructionType = IfThenInstructionType.NotEqualsNumbers;
        }
        if (text1.Contains("<="))
        {
          text1 = text1.Replace("<=", "\r");
          ifThenInstructionType = IfThenInstructionType.LessEqals;
        }
        if (text1.Contains(">="))
        {
          text1 = text1.Replace(">=", "\r");
          ifThenInstructionType = IfThenInstructionType.GreaterEquals;
        }
        if (text1.Contains("<"))
        {
          text1 = text1.Replace("<", "\r");
          ifThenInstructionType = IfThenInstructionType.Less;
        }
        if (text1.Contains(">"))
        {
          text1 = text1.Replace(">", "\r");
          ifThenInstructionType = IfThenInstructionType.Greater;
        }
        string[] strArray = text1.Split("\r"[0]);
        if (strArray.Length != 2)
          return new ParsingResult(ParsingErrorType.ifThenNotProper, text1);
        ParsingResult parseProcedure1 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(strArray[0]);
        ParsingResult parseProcedure2 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(strArray[1]);
        if (parseProcedure1.IsOK && parseProcedure2.IsOK && (parseProcedure1.ParsedCodeElement.GetRetunType() != ValueType.NULL && parseProcedure1.ParsedCodeElement.GetRetunType() == parseProcedure2.ParsedCodeElement.GetRetunType()))
        {
          if (parseProcedure1.ParsedCodeElement.GetRetunType() == ValueType.Color)
          {
            if (ifThenInstructionType != IfThenInstructionType.EqualsNumbers && ifThenInstructionType != IfThenInstructionType.NotEqualsNumbers)
              return new ParsingResult(ParsingErrorType.ifThenNotProper, text1);
            if (ifThenInstructionType == IfThenInstructionType.EqualsNumbers)
              ifThenInstructionType = IfThenInstructionType.EqualsColors;
            if (ifThenInstructionType == IfThenInstructionType.NotEqualsNumbers)
              ifThenInstructionType = IfThenInstructionType.NotEqualsColors;
          }
          IfThenInstruction ifThenInstruction = new IfThenInstruction(ifThenInstructionType);
          ifThenInstruction.Arguments.Clear();
          ifThenInstruction.Arguments.Add(parseProcedure1.ParsedCodeElement);
          ifThenInstruction.Arguments.Add(parseProcedure2.ParsedCodeElement);
          parseProcedure1.ParsedCodeElement.SetParent((ICodeElement) ifThenInstruction);
          parseProcedure2.ParsedCodeElement.SetParent((ICodeElement) ifThenInstruction);
          return new ParsingResult((ICodeElement) ifThenInstruction, text);
        }
        if (!parseProcedure1.IsOK)
          return parseProcedure1;
        if (!parseProcedure2.IsOK)
          return parseProcedure2;
        if (parseProcedure1.ParsedCodeElement.GetRetunType() == ValueType.Color && parseProcedure2.ParsedCodeElement.GetRetunType() == ValueType.Number)
          return new ParsingResult(ParsingErrorType.ifThenColorCanNotBeAssignedToNumber, parseProcedure1.ParsedText);
        if (parseProcedure1.ParsedCodeElement.GetRetunType() == ValueType.Number && parseProcedure2.ParsedCodeElement.GetRetunType() == ValueType.Color)
          return new ParsingResult(ParsingErrorType.ifThenNumberanNotBeAssignedToColor, parseProcedure1.ParsedText);
      }
      if (text.Contains("="))
      {
        string[] strArray = text.Split("="[0]);
        if (strArray.Length != 2)
          return new ParsingResult(ParsingErrorType.SetTypeNotProper, text);
        ParsingResult parseProcedure1 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(strArray[0]);
        ParsingResult parseProcedure2 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(strArray[1]);
        if (parseProcedure1.IsOK && parseProcedure2.IsOK && (parseProcedure1.ParsedCodeElement.GetRetunType() != ValueType.NULL && parseProcedure1.ParsedCodeElement.GetRetunType() == parseProcedure2.ParsedCodeElement.GetRetunType()))
        {
          if ((parseProcedure2.ParsedCodeElement as Variable).VariableType == VariableType.procedure && (parseProcedure2.ParsedCodeElement as Variable).InnerProcedure.ProcedureType == ProceduresTypes.PutRectangleInColor)
            return new ParsingResult(ParsingErrorType.SetTypeNotProper, parseProcedure1.ParsedText);
          AssigmentInstruction assigmentInstruction1 = new AssigmentInstruction(AssigmentInstructionType.BreakAll);
          if ((parseProcedure1.ParsedCodeElement as Variable).VariableType == VariableType.procedure && (parseProcedure1.ParsedCodeElement as Variable).InnerProcedure.ProcedureType == ProceduresTypes.TurtleSee)
          {
            if (parseProcedure2.ParsedCodeElement.GetRetunType() != ValueType.Color)
              return new ParsingResult(ParsingErrorType.SetTypeNotProper, parseProcedure1.ParsedText);
            AssigmentInstruction assigmentInstruction2 = new AssigmentInstruction(AssigmentInstructionType.DrawTurtleColor);
            assigmentInstruction2.InputElement = parseProcedure2.ParsedCodeElement;
            parseProcedure2.ParsedCodeElement.SetParent((ICodeElement) assigmentInstruction2);
            return new ParsingResult((ICodeElement) assigmentInstruction2, text);
          }
          if (parseProcedure1.ParsedCodeElement.GetRetunType() == ValueType.Color)
            assigmentInstruction1 = new AssigmentInstruction(AssigmentInstructionType.ClassicAssigmentColor);
          if (parseProcedure1.ParsedCodeElement.GetRetunType() == ValueType.Number)
            assigmentInstruction1 = new AssigmentInstruction(AssigmentInstructionType.ClassicAssigmentNumber);
          assigmentInstruction1.InputElement = parseProcedure2.ParsedCodeElement;
          assigmentInstruction1.OutputElement = parseProcedure1.ParsedCodeElement;
          if ((assigmentInstruction1.OutputElement as Variable).VariableType != VariableType.variable && ((assigmentInstruction1.OutputElement as Variable).VariableType != VariableType.procedure || (assigmentInstruction1.OutputElement as Variable).InnerProcedure.GetSetType == GetSetType.Get))
            return new ParsingResult(ParsingErrorType.SetTypeNotProper, parseProcedure1.ParsedText);
          assigmentInstruction1.InputElement.SetParent((ICodeElement) assigmentInstruction1);
          assigmentInstruction1.OutputElement.SetParent((ICodeElement) assigmentInstruction1);
          return new ParsingResult((ICodeElement) assigmentInstruction1, text);
        }
        if (!parseProcedure1.IsOK)
          return parseProcedure1;
        if (!parseProcedure2.IsOK)
          return parseProcedure2;
        if (parseProcedure1.ParsedCodeElement.GetRetunType() == ValueType.Color && parseProcedure2.ParsedCodeElement.GetRetunType() == ValueType.Number)
          return new ParsingResult(ParsingErrorType.colorCanNotBeAssignedToNumber, parseProcedure1.ParsedText);
        if (parseProcedure1.ParsedCodeElement.GetRetunType() == ValueType.Number && parseProcedure2.ParsedCodeElement.GetRetunType() == ValueType.Color)
          return new ParsingResult(ParsingErrorType.numberanNotBeAssignedToColor, parseProcedure1.ParsedText);
      }
      if (text.Trim(" "[0]) == "return".ToLower())
        return new ParsingResult((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.BreakAll), text);
      if (text.Trim(" "[0]) == "else".ToLower())
        return new ParsingResult((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.ElseSign), text);
      if (text.Trim(" "[0]) == "rabbit.goLeft()".ToLower())
        return new ParsingResult((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.TurtleLeft), text);
      if (text.Trim(" "[0]) == "rabbit.goRight()".ToLower())
        return new ParsingResult((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.TurtleRight), text);
      if (text.Trim(" "[0]) == "rabbit.goUp()".ToLower())
        return new ParsingResult((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.TurtleTop), text);
      return text.Trim(" "[0]) == "rabbit.goDown()".ToLower() ? new ParsingResult((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.TurtleDown), text) : new ParsingResult(ParsingErrorType.undefinedError, text);
    }
  }
}
