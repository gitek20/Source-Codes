﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParsingResult
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Procedures;
using System.Collections.Generic;

namespace PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser
{
  public class MethodParsingResult
  {
    private List<string> innerParamsTexts;
    private ProceduresTypes typeOfProcedure;
    private GetSetType getSetType;
    private ValueType getSetValueType;
    private bool parssedOk;

    public MethodParsingResult(List<string> innerParamsTexts, ProceduresTypes typeOfProcedure)
    {
      this.innerParamsTexts = innerParamsTexts;
      this.typeOfProcedure = typeOfProcedure;
      if (typeOfProcedure == ProceduresTypes.BoolAND || typeOfProcedure == ProceduresTypes.BoolEqual || (typeOfProcedure == ProceduresTypes.BoolGreaterOrEqual || typeOfProcedure == ProceduresTypes.BoolGreaterThan) || (typeOfProcedure == ProceduresTypes.BoolLessOrEqual || typeOfProcedure == ProceduresTypes.BoolLessThan || (typeOfProcedure == ProceduresTypes.BoolNotEqual || typeOfProcedure == ProceduresTypes.BoolOR)))
      {
        this.getSetType = GetSetType.Get;
        this.getSetValueType = ValueType.Boolean;
      }
      if (typeOfProcedure == ProceduresTypes.GetR || typeOfProcedure == ProceduresTypes.GetG || (typeOfProcedure == ProceduresTypes.GetB || typeOfProcedure == ProceduresTypes.MathDiv) || (typeOfProcedure == ProceduresTypes.MathMinus || typeOfProcedure == ProceduresTypes.MathMod || (typeOfProcedure == ProceduresTypes.MathMulti || typeOfProcedure == ProceduresTypes.MathPlus)) || (typeOfProcedure == ProceduresTypes.GetNumberOfColorsInRectangle || typeOfProcedure == ProceduresTypes.GetNumberOfColorsInX || typeOfProcedure == ProceduresTypes.GetNumberOfColorsInY))
      {
        this.getSetType = GetSetType.Get;
        this.getSetValueType = ValueType.Number;
      }
      if (typeOfProcedure == ProceduresTypes.GetColorFromRGB)
      {
        this.getSetType = GetSetType.Get;
        this.getSetValueType = ValueType.Color;
      }
      if (typeOfProcedure == ProceduresTypes.TurtleX || typeOfProcedure == ProceduresTypes.TurtleY)
      {
        this.getSetType = GetSetType.GetSet;
        this.getSetValueType = ValueType.Number;
      }
      if (typeOfProcedure == ProceduresTypes.GetPutPixel)
      {
        this.getSetType = GetSetType.GetSet;
        this.getSetValueType = ValueType.Color;
      }
      if (typeOfProcedure == ProceduresTypes.PutRectangleInColor)
      {
        this.getSetType = GetSetType.Set;
        this.getSetValueType = ValueType.Color;
      }
      this.parssedOk = true;
    }

    public MethodParsingResult(bool isOK) => this.parssedOk = isOK;

    public List<string> InnerParamsTexts
    {
      get => this.innerParamsTexts;
      set => this.innerParamsTexts = value;
    }

    public ProceduresTypes TypeOfProcedure
    {
      get => this.typeOfProcedure;
      set => this.typeOfProcedure = value;
    }

    public GetSetType GetSetType
    {
      get => this.getSetType;
      set => this.getSetType = value;
    }

    public bool ParssedOk
    {
      get => this.parssedOk;
      set => this.parssedOk = value;
    }

    public ValueType GetSetValueType
    {
      get => this.getSetValueType;
      set => this.getSetValueType = value;
    }

    private enum errorMessage
    {
      badNumberOfParams,
    }
  }
}
