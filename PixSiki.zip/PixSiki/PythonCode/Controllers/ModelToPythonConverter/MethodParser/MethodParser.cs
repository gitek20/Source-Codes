﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.DataModels.Code.Variables;
using System.Collections.Generic;

namespace PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser
{
  internal class MethodParser
  {
    public static ParsingResult TryToParseProcedure(string text)
    {
      text = text.Trim(" "[0]);
      text = text.ToLower();
      int num = 0;
      for (int index = 0; index < text.Length; ++index)
      {
        if ((int) text[index] == (int) "("[0])
          ++num;
        if ((int) text[index] == (int) ")"[0])
          --num;
        if (num < 0)
          return new ParsingResult(ParsingErrorType.undefinedError, text);
      }
      for (int index = 0; index < 20000 && (text.Length >= 2 && (int) text[0] == (int) "("[0]) && ((int) text[text.Length - 1] == (int) ")"[0] && PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(text.Substring(1, text.Length - 2)).IsOK); ++index)
        text = text.Substring(1, text.Length - 2);
      if (text == "image.height")
        return new ParsingResult((ICodeElement) new Variable(VariableType.imageHeight, ValueType.Number), text);
      if (text == "image.width")
        return new ParsingResult((ICodeElement) new Variable(VariableType.imageWidth, ValueType.Number), text);
      if (text == "rabbit.color")
      {
        Variable variable = new Variable(VariableType.procedure, ValueType.Color);
        Procedure procedure = new Procedure(ProceduresTypes.TurtleSee);
        variable.InnerProcedure = procedure;
        procedure.SetParent((ICodeElement) variable);
        return new ParsingResult((ICodeElement) variable, text);
      }
      if (text == "rabbit.x")
      {
        Variable variable = new Variable(VariableType.procedure, ValueType.Number);
        Procedure procedure = new Procedure(ProceduresTypes.TurtleX);
        variable.InnerProcedure = procedure;
        procedure.SetParent((ICodeElement) variable);
        return new ParsingResult((ICodeElement) variable, text);
      }
      if (text == "rabbit.y")
      {
        Variable variable = new Variable(VariableType.procedure, ValueType.Number);
        Procedure procedure = new Procedure(ProceduresTypes.TurtleY);
        variable.InnerProcedure = procedure;
        procedure.SetParent((ICodeElement) variable);
        return new ParsingResult((ICodeElement) variable, text);
      }
      if (text == "colors.white")
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(10, 10, 10)), text);
      if (text == "colors.black")
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(0, 0, 0)), text);
      if (text == "colors.red")
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(10, 0, 0)), text);
      if (text == "colors.green")
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(0, 10, 0)), text);
      if (text == "colors.blue")
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(0, 0, 10)), text);
      if (text == "colors.cyan")
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(0, 10, 10)), text);
      if (text == "colors.magenta")
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(10, 0, 10)), text);
      if (text == "colors.yellow")
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(10, 10, 0)), text);
      long result = 0;
      if (long.TryParse(text, out result))
        return new ParsingResult((ICodeElement) new Variable(VariableType.constant, new Value(result)), text);
      if (text.Length == 1 && "qwertyuiopasdfghjklzxcvbnm".Contains(text) || text.Length == 2 && !text.Contains("_") && "x1_x2_x3_x4_x5_x6_x7_x8_x9_x0_y1_y2_y3_y4_y5_y6_y7_y8_y9_y0".Contains(text) || text == "out")
        return new ParsingResult((ICodeElement) new Variable(VariableType.variable, ValueType.Number, text), text);
      if (text.Length == 2 && !text.Contains("_") && "c1_c2_c3_c4_c5_c6_c7_c8_c9_c0".Contains(text))
        return new ParsingResult((ICodeElement) new Variable(VariableType.variable, ValueType.Color, text), text);
      MethodParsingResult method = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.ParseMethod(text);
      if (!method.ParssedOk)
        return new ParsingResult(ParsingErrorType.undefinedError, text);
      Variable variable1 = new Variable(VariableType.procedure, method.GetSetValueType);
      Procedure procedure1 = new Procedure(method.TypeOfProcedure);
      variable1.InnerProcedure = procedure1;
      procedure1.SetParent((ICodeElement) variable1);
      procedure1.ProcedureParams.Clear();
      foreach (string innerParamsText in method.InnerParamsTexts)
      {
        ParsingResult parseProcedure = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(innerParamsText);
        if (!parseProcedure.IsOK)
          return new ParsingResult(ParsingErrorType.undefinedError, innerParamsText);
        if (parseProcedure.ParsedCodeElement is Variable && (parseProcedure.ParsedCodeElement as Variable).InnerProcedure != null && (parseProcedure.ParsedCodeElement as Variable).InnerProcedure.GetSetType == GetSetType.Set)
          return new ParsingResult(ParsingErrorType.undefinedError, innerParamsText);
        procedure1.ProcedureParams.Add(parseProcedure.ParsedCodeElement);
        parseProcedure.ParsedCodeElement.SetParent((ICodeElement) procedure1);
      }
      if ((procedure1.ProcedureType == ProceduresTypes.GetR || procedure1.ProcedureType == ProceduresTypes.GetG || procedure1.ProcedureType == ProceduresTypes.GetB) && procedure1.ProcedureParams[0].GetRetunType() != ValueType.Color)
        return new ParsingResult(ParsingErrorType.undefinedError, text);
      if (procedure1.ProcedureType == ProceduresTypes.GetPutPixel || procedure1.ProcedureType == ProceduresTypes.MathDiv || (procedure1.ProcedureType == ProceduresTypes.MathMinus || procedure1.ProcedureType == ProceduresTypes.MathMod) || (procedure1.ProcedureType == ProceduresTypes.MathMulti || procedure1.ProcedureType == ProceduresTypes.MathPlus || (procedure1.ProcedureType == ProceduresTypes.GetColorFromRGB || procedure1.ProcedureType == ProceduresTypes.GetNumberOfColorsInRectangle)))
      {
        foreach (ICodeElement procedureParam in procedure1.ProcedureParams)
        {
          if (procedureParam.GetRetunType() != ValueType.Number)
            return new ParsingResult(ParsingErrorType.undefinedError, text);
        }
      }
      if (procedure1.ProcedureType == ProceduresTypes.BoolAND || procedure1.ProcedureType == ProceduresTypes.BoolOR)
      {
        foreach (ICodeElement procedureParam in procedure1.ProcedureParams)
        {
          if (procedureParam.GetRetunType() != ValueType.Boolean)
            return new ParsingResult(ParsingErrorType.undefinedError, text);
        }
      }
      if (procedure1.ProcedureType == ProceduresTypes.BoolGreaterOrEqual || procedure1.ProcedureType == ProceduresTypes.BoolGreaterThan || (procedure1.ProcedureType == ProceduresTypes.BoolLessOrEqual || procedure1.ProcedureType == ProceduresTypes.BoolLessThan))
      {
        foreach (ICodeElement procedureParam in procedure1.ProcedureParams)
        {
          if (procedureParam.GetRetunType() != ValueType.Number)
            return new ParsingResult(ParsingErrorType.undefinedError, text);
        }
      }
      if (procedure1.ProcedureType == ProceduresTypes.BoolEqual || procedure1.ProcedureType == ProceduresTypes.BoolNotEqual)
      {
        if (procedure1.ProcedureParams.Count != 2)
          return new ParsingResult(ParsingErrorType.undefinedError, text);
        if (procedure1.ProcedureParams[0].GetRetunType() != procedure1.ProcedureParams[1].GetRetunType())
          return new ParsingResult(ParsingErrorType.undefinedError, text);
        if (procedure1.ProcedureParams[0].GetRetunType() != ValueType.Color && procedure1.ProcedureParams[1].GetRetunType() != ValueType.Number)
          return new ParsingResult(ParsingErrorType.undefinedError, text);
      }
      if (procedure1.ProcedureType == ProceduresTypes.GetNumberOfColorsInX || procedure1.ProcedureType == ProceduresTypes.GetNumberOfColorsInY)
      {
        if (procedure1.ProcedureParams[0].GetRetunType() != ValueType.Number)
          return new ParsingResult(ParsingErrorType.undefinedError, text);
        if (procedure1.ProcedureParams[1].GetRetunType() != ValueType.Color)
          return new ParsingResult(ParsingErrorType.undefinedError, text);
      }
      return new ParsingResult((ICodeElement) variable1, text);
    }

    public static MethodParsingResult ParseMethod(string methodString)
    {
      MethodParsingResult methodParsingResult = new MethodParsingResult(false);
      MethodParsingResult parse1 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParse("image.pixelcolor", ProceduresTypes.GetPutPixel, 2, methodString);
      if (parse1.ParssedOk)
        return parse1;
      MethodParsingResult parse2 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParse("image.rectanglecolor", ProceduresTypes.PutRectangleInColor, 4, methodString);
      if (parse2.ParssedOk)
        return parse2;
      MethodParsingResult parse3 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParse("image.countcolorinrow", ProceduresTypes.GetNumberOfColorsInY, 2, methodString);
      if (parse3.ParssedOk)
        return parse3;
      MethodParsingResult parse4 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParse("image.countcolorincolumn", ProceduresTypes.GetNumberOfColorsInX, 2, methodString);
      if (parse4.ParssedOk)
        return parse4;
      MethodParsingResult parse5 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParse("colors.fromredgreenblue", ProceduresTypes.GetColorFromRGB, 3, methodString);
      if (parse5.ParssedOk)
        return parse5;
      MethodParsingResult parse6 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParse("colors.getred", ProceduresTypes.GetR, 1, methodString);
      if (parse6.ParssedOk)
        return parse6;
      MethodParsingResult parse7 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParse("colors.getgreen", ProceduresTypes.GetG, 1, methodString);
      if (parse7.ParssedOk)
        return parse7;
      MethodParsingResult parse8 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParse("colors.getblue", ProceduresTypes.GetB, 1, methodString);
      if (parse8.ParssedOk)
        return parse8;
      MethodParsingResult parseMath = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseMath(methodString);
      return parseMath.ParssedOk ? parseMath : new MethodParsingResult(false);
    }

    public static MethodParsingResult TryToParse(
      string methodName,
      ProceduresTypes typeOfProcedure,
      int numberOfParams,
      string methodString)
    {
      if (methodString.Contains(methodName) && methodString.Substring(0, methodName.Length) == methodName)
      {
        string str = methodString.Substring(methodName.Length);
        if (str.Length >= 2 && (int) str[0] == (int) "("[0] && (int) str[str.Length - 1] == (int) ")"[0])
        {
          string input = str.Substring(1, str.Length - 2);
          if (PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.IsBracketsPropper(input))
          {
            List<string> innerParamsTexts = new List<string>();
            if (numberOfParams == 1)
            {
              innerParamsTexts.Add(input);
              return new MethodParsingResult(innerParamsTexts, typeOfProcedure);
            }
            for (int index = 1; index < numberOfParams; ++index)
            {
              string[] strArray = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator(",", input, true);
              if (strArray == null)
                return new MethodParsingResult(false);
              innerParamsTexts.Add(strArray[0]);
              input = strArray[1];
              if (index == numberOfParams - 1)
              {
                innerParamsTexts.Add(strArray[1]);
                return new MethodParsingResult(innerParamsTexts, typeOfProcedure);
              }
            }
          }
        }
      }
      return new MethodParsingResult(false);
    }

    public static MethodParsingResult TryToParseMath(string methodString)
    {
      int num1 = 0;
      for (int index = 0; index < methodString.Length; ++index)
      {
        if ((int) methodString[index] == (int) "("[0])
          ++num1;
        if ((int) methodString[index] == (int) ")"[0])
          --num1;
        if (num1 < 0)
          return new MethodParsingResult(false);
      }
      if (methodString.Length >= 2 && (int) methodString[0] == (int) "("[0] && ((int) methodString[methodString.Length - 1] == (int) ")"[0] && PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.TryToParseProcedure(methodString.Substring(1, methodString.Length - 2)).IsOK))
        methodString = methodString.Substring(1, methodString.Length - 2);
      ProceduresTypes typeOfProcedure = ProceduresTypes.GetR;
      string[] strArray1 = (string[]) null;
      if (strArray1 == null)
      {
        string[] strArray2 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator(" and ", methodString, false);
        string[] strArray3 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator(" or ", methodString, false);
        int num2 = int.MinValue;
        int num3 = int.MinValue;
        if (strArray2 != null)
          num2 = strArray2[0].Length;
        if (strArray3 != null)
          num3 = strArray3[0].Length;
        if (num2 != int.MinValue && num2 > num3)
        {
          typeOfProcedure = ProceduresTypes.BoolAND;
          strArray1 = strArray2;
        }
        if (num3 != int.MinValue && num3 > num2)
        {
          typeOfProcedure = ProceduresTypes.BoolOR;
          strArray1 = strArray3;
        }
      }
      if (strArray1 == null)
      {
        string[] strArray2 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator(">", methodString, false);
        if (strArray2 != null)
        {
          strArray1 = strArray2;
          typeOfProcedure = ProceduresTypes.BoolGreaterThan;
        }
        string[] strArray3 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("<", methodString, false);
        if (strArray3 != null)
        {
          strArray1 = strArray3;
          typeOfProcedure = ProceduresTypes.BoolLessThan;
        }
        string[] strArray4 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator(">=", methodString, false);
        if (strArray4 != null)
        {
          strArray1 = strArray4;
          typeOfProcedure = ProceduresTypes.BoolGreaterOrEqual;
        }
        string[] strArray5 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("<=", methodString, false);
        if (strArray5 != null)
        {
          strArray1 = strArray5;
          typeOfProcedure = ProceduresTypes.BoolLessOrEqual;
        }
        string[] strArray6 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("==", methodString, false);
        if (strArray6 != null)
        {
          strArray1 = strArray6;
          typeOfProcedure = ProceduresTypes.BoolEqual;
        }
        string[] strArray7 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("!=", methodString, false);
        if (strArray7 != null)
        {
          strArray1 = strArray7;
          typeOfProcedure = ProceduresTypes.BoolNotEqual;
        }
      }
      if (strArray1 == null)
      {
        string[] strArray2 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("+", methodString, false);
        string[] strArray3 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("-", methodString, false);
        int num2 = int.MaxValue;
        int num3 = int.MaxValue;
        if (strArray2 != null)
          num2 = strArray2[0].Length;
        if (strArray3 != null)
          num3 = strArray3[0].Length;
        if (num2 != int.MaxValue && (num3 == int.MaxValue || num2 > num3))
        {
          typeOfProcedure = ProceduresTypes.MathPlus;
          strArray1 = strArray2;
        }
        if (num3 != int.MaxValue && (num2 == int.MaxValue || num3 > num2))
        {
          typeOfProcedure = ProceduresTypes.MathMinus;
          strArray1 = strArray3;
        }
      }
      if (strArray1 == null)
      {
        string[] strArray2 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("*", methodString, false);
        string[] strArray3 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("/", methodString, false);
        string[] strArray4 = PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.CutStringOnTwoUsingSeparator("%", methodString, false);
        int num2 = int.MinValue;
        int num3 = int.MinValue;
        int num4 = int.MinValue;
        if (strArray2 != null)
          num2 = strArray2[0].Length;
        if (strArray3 != null)
          num3 = strArray3[0].Length;
        if (strArray4 != null)
          num4 = strArray4[0].Length;
        if (num2 != int.MinValue && num2 > num3 && num2 > num4)
        {
          typeOfProcedure = ProceduresTypes.MathMulti;
          strArray1 = strArray2;
        }
        if (num3 != int.MinValue && num3 > num2 && num3 > num4)
        {
          typeOfProcedure = ProceduresTypes.MathDiv;
          strArray1 = strArray3;
        }
        if (num4 != int.MinValue && num4 > num2 && num4 > num3)
        {
          typeOfProcedure = ProceduresTypes.MathMod;
          strArray1 = strArray4;
        }
      }
      if (strArray1 == null)
        return new MethodParsingResult(false);
      return new MethodParsingResult(new List<string>()
      {
        strArray1[0],
        strArray1[1]
      }, typeOfProcedure);
    }

    public static string[] CutStringOnTwoUsingSeparator(
      string separator,
      string input,
      bool CutFirst)
    {
      string[] strArray = new string[2];
      if (!input.Contains(separator))
        return (string[]) null;
      if (CutFirst)
      {
        for (int index = 0; index <= input.Length - separator.Length; ++index)
        {
          if (input.Substring(index, separator.Length) == separator)
          {
            string input1 = input.Substring(0, index);
            string str = input.Substring(index + separator.Length);
            if (PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.IsBracketsPropper(input1) && PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.IsBracketsPropper(input1))
            {
              strArray[0] = input1;
              strArray[1] = str;
              return strArray;
            }
          }
        }
      }
      else
      {
        for (int index = input.Length - separator.Length; index >= 0; --index)
        {
          if (input.Substring(index, separator.Length) == separator)
          {
            string input1 = input.Substring(0, index);
            string str = input.Substring(index + separator.Length);
            if (PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.IsBracketsPropper(input1) && PixBlocks.PythonCode.Controllers.ModelToPythonConverter.MethodParser.MethodParser.IsBracketsPropper(input1))
            {
              strArray[0] = input1;
              strArray[1] = str;
              return strArray;
            }
          }
        }
      }
      return (string[]) null;
    }

    public static bool IsBracketsPropper(string input)
    {
      int num = 0;
      for (int index = 0; index < input.Length; ++index)
      {
        if ((int) input[index] == (int) "("[0])
          ++num;
        if ((int) input[index] == (int) ")"[0])
          --num;
        if (num < 0)
          return false;
      }
      return num == 0;
    }
  }
}
