﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonCode.Controllers.ModelToPythonConverter.ParsingResult
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using System.Collections.Generic;

namespace PixBlocks.PythonCode.Controllers.ModelToPythonConverter
{
  internal class ParsingResult
  {
    private List<int> badLinesIndexes;
    private ICodeElement codeElement;
    private ParsingErrorType parsingErrorType;
    private string parsedText;
    private bool isOK;

    public ParsingResult(ICodeElement codeElement, string text)
    {
      this.codeElement = codeElement;
      this.isOK = true;
      this.parsedText = text;
    }

    public ParsingResult(ParsingErrorType errorType, string text)
    {
      this.isOK = false;
      this.parsingErrorType = errorType;
      this.parsedText = text;
    }

    public ICodeElement ParsedCodeElement => this.codeElement;

    public bool IsOK
    {
      get => this.isOK;
      set => this.isOK = value;
    }

    internal ParsingErrorType ParsingErrorType
    {
      get => this.parsingErrorType;
      set => this.parsingErrorType = value;
    }

    public string ParsedText
    {
      get => this.parsedText;
      set => this.parsedText = value;
    }

    public int LineNumber { get; internal set; }

    public List<int> BadLinesIndexes
    {
      get => this.badLinesIndexes;
      set => this.badLinesIndexes = value;
    }
  }
}
