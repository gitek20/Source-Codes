﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonCode.Views.SingleLine
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.PythonCode.Views.Elements;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.PythonCode.Views
{
  public partial class SingleLine : UserControl, IComponentConnector
  {
    private string oldInput;
    private bool lineIsProperParsed = true;
    internal StackPanel stackPanel;
    internal TextBlock textBlockNormal;
    internal Grid gridLoop;
    internal TextBlock textBlockLoop;
    internal Grid gridAfretLoop;
    internal TextBlock textBlockAfterLoop;
    private bool _contentLoaded;

    public SingleLine() => this.InitializeComponent();

    public void RefreshView(string newInput)
    {
      if (!(this.oldInput != newInput))
        return;
      this.oldInput = newInput;
      this.stackPanel.Children.Clear();
      int length = newInput.Length;
      newInput = newInput.TrimStart(" "[0]);
      int num = length - newInput.Length;
      for (int index = 0; index < num; ++index)
        this.stackPanel.Children.Add((UIElement) new SingleLineSpace());
      bool flag = false;
      if (newInput.Length >= "loop ".Length && newInput.Substring(0, "loop ".Length) == "loop ")
      {
        this.textBlockLoop.Text = "loop ";
        this.gridLoop.Visibility = Visibility.Visible;
        this.textBlockNormal.Visibility = Visibility.Collapsed;
        newInput = newInput.Substring("loop ".Length);
        this.gridAfretLoop.Visibility = Visibility.Visible;
        this.textBlockAfterLoop.Text = newInput;
        flag = true;
      }
      if (!flag)
      {
        if (newInput.Length >= "if ".Length && newInput.Substring(0, "if ".Length) == "if ")
        {
          this.textBlockLoop.Text = "if ";
          this.gridLoop.Visibility = Visibility.Visible;
          this.textBlockNormal.Visibility = Visibility.Collapsed;
          newInput = newInput.Substring("if ".Length);
          this.gridAfretLoop.Visibility = Visibility.Visible;
          this.textBlockAfterLoop.Text = newInput;
          flag = true;
        }
        if (!flag && newInput.Length >= "else".Length && newInput.Substring(0, "else".Length) == "else")
        {
          this.textBlockLoop.Text = "else";
          this.gridLoop.Visibility = Visibility.Visible;
          this.textBlockNormal.Visibility = Visibility.Collapsed;
          newInput = newInput.Substring("else".Length);
          this.gridAfretLoop.Visibility = Visibility.Visible;
          this.textBlockAfterLoop.Text = newInput;
          flag = true;
        }
      }
      if (flag)
        return;
      this.textBlockNormal.Text = newInput;
      this.textBlockNormal.Visibility = Visibility.Visible;
      this.gridLoop.Visibility = Visibility.Collapsed;
      this.gridAfretLoop.Visibility = Visibility.Collapsed;
    }

    internal void SetInternalInstruction(ICodeElement element) => element.codeRunningStatusChanged += new CodeElementRunningStatus(this.Element_codeRunningStatusChanged);

    public void SetLineIsProperParses(bool proper)
    {
      if (proper == this.lineIsProperParsed)
        return;
      this.lineIsProperParsed = proper;
      if (this.lineIsProperParsed)
      {
        this.textBlockNormal.Background = (Brush) new SolidColorBrush(Colors.Transparent);
        this.textBlockAfterLoop.Background = (Brush) new SolidColorBrush(Colors.Transparent);
        this.textBlockLoop.Background = (Brush) new SolidColorBrush(Colors.Transparent);
      }
      else
      {
        if (this.textBlockNormal.Text.Length == 0)
          this.textBlockNormal.Text = " ";
        this.textBlockNormal.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 190, byte.MaxValue, (byte) 170, (byte) 170));
        this.textBlockAfterLoop.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 190, byte.MaxValue, (byte) 170, (byte) 170));
        this.textBlockLoop.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 190, byte.MaxValue, (byte) 170, (byte) 170));
      }
    }

    private void Element_codeRunningStatusChanged(RunningStatus runningStatus)
    {
      if (runningStatus == RunningStatus.StartRuning)
      {
        this.textBlockNormal.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, (byte) 0));
        this.textBlockAfterLoop.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, (byte) 0));
        this.textBlockLoop.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, (byte) 0));
      }
      if (runningStatus != RunningStatus.StopRuning)
        return;
      this.textBlockNormal.Background = (Brush) new SolidColorBrush(Colors.Transparent);
      this.textBlockAfterLoop.Background = (Brush) new SolidColorBrush(Colors.Transparent);
      this.textBlockLoop.Background = (Brush) new SolidColorBrush(Colors.Transparent);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoncode/views/singleline.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.stackPanel = (StackPanel) target;
          break;
        case 2:
          this.textBlockNormal = (TextBlock) target;
          break;
        case 3:
          this.gridLoop = (Grid) target;
          break;
        case 4:
          this.textBlockLoop = (TextBlock) target;
          break;
        case 5:
          this.gridAfretLoop = (Grid) target;
          break;
        case 6:
          this.textBlockAfterLoop = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
