﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonCode.Views.OptionsMenu.OptionsUC
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.PythonCode.Views.OptionsMenu
{
  public partial class OptionsUC : UserControl, IComponentConnector
  {
    public static List<string> rootCommands = new List<string>();
    public List<string> childCommands = new List<string>();
    internal ListBox listBox;
    private bool _contentLoaded;

    public OptionsUC()
    {
      this.InitializeComponent();
      OptionsUC.rootCommands.Clear();
      OptionsUC.rootCommands.Add("loop ");
      OptionsUC.rootCommands.Add("if ");
      OptionsUC.rootCommands.Add("rabbit");
      this.childCommands.Add("rabbit.color");
      this.childCommands.Add("rabbit.x");
      this.childCommands.Add("rabbit.y");
      this.childCommands.Add("rabbit.goLeft()");
      this.childCommands.Add("rabbit.goRight()");
      this.childCommands.Add("rabbit.goUp()");
      this.childCommands.Add("rabbit.goDown()");
      OptionsUC.rootCommands.Add("image");
      this.childCommands.Add("image.width");
      this.childCommands.Add("image.height");
      this.childCommands.Add("image.pixelColor(x,y)");
      this.childCommands.Add("image.rectangleColor(x1,y1,x2,y2)");
      this.childCommands.Add("image.countColorInRow(y,c1)");
      this.childCommands.Add("image.countColorInColumn(x,c1)");
      OptionsUC.rootCommands.Add("colors");
      this.childCommands.Add("colors.fromRedGreenBlue(r,g,b)");
      this.childCommands.Add("colors.getRed(c1)");
      this.childCommands.Add("colors.getGreen(c1)");
      this.childCommands.Add("colors.getBlue(c1)");
      this.childCommands.Add("colors.white");
      this.childCommands.Add("colors.black");
      this.childCommands.Add("colors.red");
      this.childCommands.Add("colors.green");
      this.childCommands.Add("colors.blue");
      this.childCommands.Add("colors.cyan");
      this.childCommands.Add("colors.magenta");
      this.childCommands.Add("colors.yellow");
    }

    public event OptionsUC.ItemWasSelected ItemSelectedEvet;

    internal void PerfromKey(KeyEventArgs e)
    {
      if (e.Key == Key.Down)
        this.listBox.SelectedIndex = Math.Min(this.listBox.Items.Count - 1, this.listBox.SelectedIndex + 1);
      if (e.Key == Key.Up)
        this.listBox.SelectedIndex = Math.Max(0, this.listBox.SelectedIndex - 1);
      if (e.Key != Key.Return)
        return;
      if (this.ItemSelectedEvet != null && this.listBox.SelectedItem != null)
      {
        if (this.listBox.SelectedItem is ListBoxItem)
          this.ItemSelectedEvet(((ContentControl) this.listBox.SelectedItem).Content.ToString());
        else
          this.ItemSelectedEvet(this.listBox.SelectedItem.ToString());
      }
      if (this.listBox.SelectedItem == null || e.Timestamp == int.MinValue)
      {
        this.listBox.SelectedIndex = 0;
      }
      else
      {
        string str = this.listBox.SelectedItem.ToString();
        if (OptionsUC.rootCommands.Contains(str) && !str.Contains(".") && (!str.Contains("(") && str != "loop ") && str != "if ")
          this.Visibility = Visibility.Visible;
        else
          this.Visibility = Visibility.Collapsed;
      }
    }

    private void listBox_MouseUp(object sender, MouseButtonEventArgs e)
    {
      string str = this.listBox.SelectedItem.ToString();
      if (this.listBox.SelectedItem is ListBoxItem)
        str = ((ContentControl) this.listBox.SelectedItem).Content.ToString();
      if (OptionsUC.rootCommands.Contains(str) && !str.Contains(".") && (!str.Contains("(") && str != "loop ") && str != "if ")
        this.Visibility = Visibility.Visible;
      else
        this.Visibility = Visibility.Collapsed;
      if (this.ItemSelectedEvet == null)
        return;
      if (this.listBox.SelectedItem is ListBoxItem)
        this.ItemSelectedEvet(((ContentControl) this.listBox.SelectedItem).Content.ToString());
      else
        this.ItemSelectedEvet(this.listBox.SelectedItem.ToString());
    }

    internal void SetPrevLine(string substring)
    {
      if (substring.Replace(" ", "") == "")
      {
        this.listBox.Items.Clear();
        ListBoxItem listBoxItem1 = new ListBoxItem();
        listBoxItem1.Content = (object) "loop ";
        listBoxItem1.FontWeight = FontWeights.Bold;
        listBoxItem1.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 0, (byte) 33, (byte) 184));
        this.listBox.Items.Add((object) listBoxItem1);
        ListBoxItem listBoxItem2 = new ListBoxItem();
        listBoxItem2.Content = (object) "if ";
        listBoxItem2.FontWeight = FontWeights.Bold;
        listBoxItem2.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 0, (byte) 33, (byte) 184));
        this.listBox.Items.Add((object) listBoxItem2);
        for (int index = 2; index < OptionsUC.rootCommands.Count; ++index)
          this.listBox.Items.Add((object) OptionsUC.rootCommands[index]);
        this.listBox.SelectedIndex = 0;
      }
      else if (" =<>+-/%*(,|&".Contains<char>(substring[substring.Length - 1]))
      {
        this.listBox.Items.Clear();
        for (int index = 2; index < OptionsUC.rootCommands.Count; ++index)
          this.listBox.Items.Add((object) OptionsUC.rootCommands[index]);
        this.listBox.SelectedIndex = 0;
      }
      else
      {
        if ((substring[substring.Length - 1].ToString() ?? "") == ".")
          substring = substring.Substring(0, substring.Length - 1);
        string str = "";
        substring = substring.ToLower();
        for (int index = substring.Length - 1; index >= 0 && "qwertyuiopasdfghjklzxcvbnm1234567890.".Contains<char>(substring[index]); --index)
          str = substring[index].ToString() + str;
        this.listBox.Items.Clear();
        foreach (string rootCommand in OptionsUC.rootCommands)
        {
          if (rootCommand.ToLower() == str)
          {
            foreach (string childCommand in this.childCommands)
            {
              if (childCommand.Contains(rootCommand) && childCommand.Substring(0, rootCommand.Length) == rootCommand)
                this.listBox.Items.Add((object) childCommand.Replace(rootCommand + ".", ""));
            }
          }
        }
        this.listBox.SelectedIndex = 0;
      }
    }

    private void listBox_MouseMove(object sender, MouseEventArgs e) => this.listBox.SelectionMode = SelectionMode.Single;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoncode/views/optionsmenu/optionsuc.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
      {
        this.listBox = (ListBox) target;
        this.listBox.MouseUp += new MouseButtonEventHandler(this.listBox_MouseUp);
        this.listBox.MouseMove += new MouseEventHandler(this.listBox_MouseMove);
      }
      else
        this._contentLoaded = true;
    }

    public delegate void ItemWasSelected(string text);
  }
}
