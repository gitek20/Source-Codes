﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonCode.Views.TextEditor
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner;
using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.DataModels.Questions;
using PixBlocks.PythonCode.Controllers.ModelToPythonConverter;
using PixBlocks.PythonCode.Views.OptionsMenu;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.CodeParser;
using PixBlocks.UserMenagment.StaticEditedCodeMenager;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.Views.CodeElements.BlockOfCode.images;
using PixBlocks.Views.CongratulationsView;
using PixBlocks.Views.HelpView;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace PixBlocks.PythonCode.Views
{
  public partial class TextEditor : UserControl, IComponentConnector
  {
    private List<SingleLine> lines = new List<SingleLine>();
    private MainWindowMessageBox messageBox;
    public bool reactOnTextChanged = true;
    private OptionsUC options = new OptionsUC();
    private ICodeElement rootElement;
    private RepeatNTimes rootCodeAsk;
    private RepeatNTimes rootCodePattern;
    private Question question;
    private int myScore;
    private int linesOfCodeInPattern;
    private bool clickMakeStop;
    internal Grid BottonGrid;
    internal TextBlock textBlock;
    internal TextBlock textBotton;
    internal Image image;
    internal Image blue1;
    internal Image gray1;
    internal Image redStar;
    internal StackPanel buttonLook;
    internal Grid BadPythonLines;
    internal Grid TooManyInstructionGrid;
    internal ScrollViewer scrollViewer;
    internal Grid mainGrid;
    internal StackPanel stackPanel;
    internal TextBox textBox;
    internal Border Caret;
    internal Storyboard CaretStoryBoard;
    private bool _contentLoaded;

    public TextEditor()
    {
      this.InitializeComponent();
      for (int index = 0; index < 60; ++index)
      {
        SingleLine singleLine = new SingleLine();
        this.lines.Add(singleLine);
        this.stackPanel.Children.Add((UIElement) singleLine);
        singleLine.Visibility = Visibility.Collapsed;
      }
      this.textBox_TextChanged((object) null, (TextChangedEventArgs) null);
      this.options.Visibility = Visibility.Collapsed;
      this.mainGrid.Children.Add((UIElement) this.options);
      this.options.ItemSelectedEvet += new OptionsUC.ItemWasSelected(this.Options_ItemSelectedEvet);
    }

    private void MoveCustomCaret()
    {
      Point location = this.textBox.GetRectFromCharacterIndex(this.textBox.CaretIndex).Location;
      if (!double.IsInfinity(location.X))
      {
        Canvas.SetLeft((UIElement) this.Caret, location.X);
        if (this.options.Visibility == Visibility.Visible)
        {
          Point point = new Point(this.options.Margin.Left + this.options.ActualWidth, this.options.Margin.Top + this.options.ActualHeight);
          if (point.Y > this.scrollViewer.VerticalOffset + this.ActualHeight - 40.0)
            this.scrollViewer.ScrollToVerticalOffset(point.Y - this.ActualHeight + 40.0);
          if (point.X > this.scrollViewer.HorizontalOffset + this.ActualWidth - 40.0)
            this.scrollViewer.ScrollToHorizontalOffset(point.X - this.ActualWidth + 40.0);
        }
        else
        {
          if (location.X < this.scrollViewer.HorizontalOffset + 40.0)
            this.scrollViewer.ScrollToHorizontalOffset(location.X - 40.0);
          if (location.X > this.scrollViewer.HorizontalOffset + this.ActualWidth - 100.0)
            this.scrollViewer.ScrollToHorizontalOffset(location.X - this.ActualWidth + 100.0);
        }
      }
      if (double.IsInfinity(location.Y))
        return;
      Canvas.SetTop((UIElement) this.Caret, location.Y);
    }

    public void SetFreez(bool freez)
    {
      this.textBox.IsReadOnly = freez;
      if (freez)
        this.buttonLook.Visibility = Visibility.Collapsed;
      else
        this.buttonLook.Visibility = Visibility.Visible;
      if (freez)
      {
        this.scrollViewer.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 251, (byte) 251, (byte) 251));
        this.TooManyInstructionGrid.Visibility = Visibility.Collapsed;
      }
      else if (this.textBlock.FontWeight == FontWeights.Bold)
      {
        this.scrollViewer.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 230, (byte) 200));
        this.TooManyInstructionGrid.Visibility = Visibility.Visible;
      }
      else
      {
        this.scrollViewer.Background = (Brush) new SolidColorBrush(Colors.White);
        this.TooManyInstructionGrid.Visibility = Visibility.Collapsed;
      }
    }

    public TextEditor(RepeatNTimes rootCodeAsk, RepeatNTimes rootCodePattern, Question question)
    {
      this.InitializeComponent();
      int num = -1;
      if (rootCodePattern != null)
      {
        foreach (ICodeElement innerCodeElement in rootCodePattern.InnerCodeElements())
        {
          if (innerCodeElement.IsInstruction())
            ++num;
        }
        this.textBotton.Text = "(" + num.ToString() + ")";
        this.linesOfCodeInPattern = num;
      }
      this.textBox.SelectionChanged += (RoutedEventHandler) ((sender, e) => this.MoveCustomCaret());
      this.textBox.LostFocus += (RoutedEventHandler) ((sender, e) => this.Caret.Visibility = Visibility.Collapsed);
      this.textBox.GotFocus += (RoutedEventHandler) ((sender, e) => this.Caret.Visibility = Visibility.Visible);
      if (question.QuestionType == QuestionType.ClassicQuestionType)
      {
        this.textBox.Focus();
        this.textBox.Select(0, 0);
      }
      this.reactOnTextChanged = false;
      for (int index = 0; index < 60; ++index)
      {
        SingleLine singleLine = new SingleLine();
        this.lines.Add(singleLine);
        this.stackPanel.Children.Add((UIElement) singleLine);
        singleLine.Visibility = Visibility.Collapsed;
      }
      this.textBox_TextChanged((object) null, (TextChangedEventArgs) null);
      this.options.Visibility = Visibility.Collapsed;
      this.mainGrid.Children.Add((UIElement) this.options);
      this.options.ItemSelectedEvet += new OptionsUC.ItemWasSelected(this.Options_ItemSelectedEvet);
      this.rootCodeAsk = rootCodeAsk;
      this.rootCodePattern = rootCodePattern;
      this.question = question;
      this.SetText(rootCodeAsk);
      this.reactOnTextChanged = true;
      if (question.QuestionType != QuestionType.ClassicQuestionType)
        this.BottonGrid.Children.Clear();
      if (question.QuestionType == QuestionType.ClassicQuestionType)
        this.ShowNumberOfCodeLines();
      if (question.ExamID.HasValue || !UserMenager.UserCanSeeSolutions() || (question == null || question.QuestionType != QuestionType.ClassicQuestionType))
        return;
      CircleButton circleButton1 = new CircleButton((UserControl) new ShowSolutionIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.buttonLook.Children.Add((UIElement) circleButton1);
      circleButton1.buttonClickedEvent += new CircleButton.ButtonClicker(this.LookButton_buttonClickedEvent);
      if (UserMenager.IsOffLineUser || !CurrentUserInfo.CurrentUser.Teacher_isTeacher)
        return;
      CircleButton circleButton2 = new CircleButton((UserControl) new TrashIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.buttonLook.Children.Add((UIElement) circleButton2);
      circleButton2.buttonClickedEvent += new CircleButton.ButtonClicker(this.DeleteCode_buttonClickedEvent);
    }

    private void DeleteCode_buttonClickedEvent()
    {
      this.textBox.Text = "";
      this.ShowNumberOfCodeLines();
      this.reactOnTextChanged = true;
      this.RebulidStructure();
      this.CanCompileProgramThrowEvent();
    }

    private void LookButton_buttonClickedEvent()
    {
      if (!UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Teacher_isTeacher)
        this.Accept_buttonClickedEvent();
      else if (QuestionsPointsCounter.GetQuestionPoints(this.question) == 0)
      {
        this.messageBox = new MainWindowMessageBox();
        MainWindowStaticController.mainWindow.mainGrid.Children.Add((UIElement) this.messageBox);
        this.messageBox.accept.buttonClickedEvent += new CircleButton.ButtonClicker(this.Accept_buttonClickedEvent);
        this.messageBox.close.buttonClickedEvent += new CircleButton.ButtonClicker(this.Close_buttonClickedEvent);
      }
      else
        this.Accept_buttonClickedEvent();
    }

    private void Close_buttonClickedEvent() => MainWindowStaticController.mainWindow.mainGrid.Children.Remove((UIElement) this.messageBox);

    private void Accept_buttonClickedEvent()
    {
      if (MainWindowStaticController.mainWindow.mainGrid.Children.Contains((UIElement) this.messageBox))
        MainWindowStaticController.mainWindow.mainGrid.Children.Remove((UIElement) this.messageBox);
      if (!UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Teacher_isTeacher)
      {
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) <= 0)
        {
          QuestionsPointsCounter.SetQuestionPoints(this.question, 1);
          this.blue1.Visibility = Visibility.Visible;
          this.gray1.Visibility = Visibility.Collapsed;
          this.redStar.Visibility = Visibility.Collapsed;
        }
      }
      else
      {
        CongratulationsStaticManager.GreesStarShow = false;
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) <= 0)
        {
          QuestionsPointsCounter.SetQuestionPoints(this.question, -1);
          this.blue1.Visibility = Visibility.Collapsed;
          this.gray1.Visibility = Visibility.Collapsed;
          this.redStar.Visibility = Visibility.Visible;
        }
      }
      CongratulationsStaticManager.ShowCongratulations();
      this.reactOnTextChanged = false;
      List<ICodeElement> blockElements = CodeStringParser.GenerateModelFromCode(this.question.Code).GetBlockElements();
      this.textBox.Text = "";
      foreach (ICodeElement codeElement in blockElements)
      {
        if (codeElement is AssigmentInstruction)
        {
          if ((codeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.BreakAll)
            break;
        }
        this.textBox.Text += codeElement.GetPythonCode("");
      }
      this.ShowNumberOfCodeLines();
      this.reactOnTextChanged = true;
      this.RebulidStructure();
      this.CanCompileProgramThrowEvent();
    }

    public event TextEditor.CanCompileProgram canCompileProgramEvent;

    public void CanCompileProgramThrowEvent()
    {
      if (this.canCompileProgramEvent == null)
        return;
      if (this.rootCodeAsk != null && this.rootCodeAsk.GetBlockElements().Count > 0 && this.textBlock.FontWeight != FontWeights.Bold)
        this.canCompileProgramEvent(1);
      else
        this.canCompileProgramEvent(0);
    }

    public void ShowBadLines(List<int> badLinesIndexes)
    {
      this.BadPythonLines.Children.Clear();
      if (badLinesIndexes.Count > 0)
      {
        if (this.textBox.Text.Replace(" ", "").Replace("\r\n", "") == "")
          this.BadPythonLines.Children.Add((UIElement) new BadPythonLinesView(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("typeCode")));
        else
          this.BadPythonLines.Children.Add((UIElement) new BadPythonLinesView(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("errorInLine") + " " + (badLinesIndexes[0] + 1).ToString()));
      }
      for (int index = 0; index < this.lines.Count; ++index)
      {
        if (badLinesIndexes.Contains(index))
          this.lines[index].SetLineIsProperParses(false);
        else
          this.lines[index].SetLineIsProperParses(true);
      }
    }

    internal void SetText(RepeatNTimes rootCodeAsk)
    {
      List<ICodeElement> codeElementList = rootCodeAsk.InnerCodeElements();
      int index = 0;
      foreach (ICodeElement element in codeElementList)
      {
        if (element.IsInstruction() && element != rootCodeAsk)
        {
          if (index < this.lines.Count)
            this.lines[index].SetInternalInstruction(element);
          ++index;
        }
      }
      List<ICodeElement> blockElements = rootCodeAsk.GetBlockElements();
      this.textBox.Text = "";
      foreach (ICodeElement codeElement in blockElements)
        this.textBox.Text += codeElement.GetPythonCode("");
    }

    public void SetText(string text)
    {
      int questionPoints = QuestionsPointsCounter.GetQuestionPoints(this.question);
      this.reactOnTextChanged = false;
      this.textBox.Text = text;
      this.reactOnTextChanged = true;
      this.RebulidStructure();
      if (QuestionsPointsCounter.GetQuestionPoints(this.question) >= 0)
        this.ShowScore(questionPoints);
      if (this.question.QuestionType == QuestionType.ClassicQuestionType)
        this.ShowNumberOfCodeLines();
      this.CanCompileProgramThrowEvent();
    }

    public string GetText() => this.textBox.Text;

    private void Options_ItemSelectedEvet(string text)
    {
      string str1 = text;
      int selectionStart = this.textBox.SelectionStart;
      if (text != "loop " && text != "if " && (!text.Contains(".") && !text.Contains("(")) && OptionsUC.rootCommands.Contains(text))
      {
        string str2 = str1 + ".";
        this.textBox.Text = this.textBox.Text.Insert(selectionStart, str2);
        this.textBox.SelectionStart = selectionStart + str2.Length;
        this.textBox.Focus();
        this.textBox_PreviewKeyDown((object) null, new KeyEventArgs((KeyboardDevice) null, PresentationSource.FromVisual((Visual) this), int.MinValue, Key.OemPeriod));
        this.options.Visibility = Visibility.Visible;
      }
      else
      {
        this.textBox.Text = this.textBox.Text.Insert(selectionStart, str1);
        this.textBox.SelectionStart = selectionStart + str1.Length;
        this.textBox.Focus();
      }
    }

    private void textBox_TextChanged(object sender, TextChangedEventArgs e)
    {
      string[] strArray = this.textBox.Text.Replace("\r", "").Split("\n"[0]);
      if (strArray.Length > this.lines.Count)
      {
        string str = "";
        for (int index = 0; index < this.lines.Count; ++index)
        {
          str += strArray[index];
          if (index < this.lines.Count - 1)
            str += "\r\n";
        }
        int caretIndex = this.textBox.CaretIndex;
        this.textBox.Text = str;
        this.textBox.CaretIndex = Math.Min(this.textBox.Text.Length, caretIndex);
      }
      else
      {
        for (int index = 0; index < this.lines.Count; ++index)
        {
          if (index < strArray.Length)
          {
            this.lines[index].RefreshView(strArray[index]);
            this.lines[index].Visibility = Visibility.Visible;
          }
          else
            this.lines[index].Visibility = Visibility.Collapsed;
        }
        if (this.question != null && this.question.QuestionType == QuestionType.ClassicQuestionType)
          this.ShowNumberOfCodeLines();
        if (this.reactOnTextChanged)
        {
          this.RebulidStructure();
          QuestionsPointsCounter.GetQuestionPoints(this.question);
        }
        this.CanCompileProgramThrowEvent();
      }
    }

    private void RebulidStructure()
    {
      PythonToModelParser pythonToModelParser = new PythonToModelParser();
      ParsingResult parse = pythonToModelParser.TryToParse(this.GetText());
      List<int> badLinesIndexes = parse.BadLinesIndexes;
      this.rootElement = pythonToModelParser.TryToParse(this.GetText()).ParsedCodeElement;
      if (badLinesIndexes.Count == 0)
      {
        RepeatNTimes parsedCodeElement = parse.ParsedCodeElement as RepeatNTimes;
        parsedCodeElement.NumberOfIteration = !this.question.IsGame ? (ICodeElement) new Variable(VariableType.constant, new Value(1L)) : (ICodeElement) new Variable(VariableType.constant, new Value((long) int.MaxValue));
        this.rootCodeAsk.NumberOfIteration = parsedCodeElement.NumberOfIteration;
        this.rootCodeAsk.GetBlockElements().Clear();
        foreach (ICodeElement blockElement in parsedCodeElement.GetBlockElements())
        {
          this.rootCodeAsk.GetBlockElements().Add(blockElement);
          blockElement.SetParent((ICodeElement) this.rootCodeAsk);
        }
        List<ICodeElement> codeElementList = this.rootCodeAsk.InnerCodeElements();
        int index = 0;
        foreach (ICodeElement element in codeElementList)
        {
          if (element.IsInstruction() && element != this.rootCodeAsk)
          {
            if (index < this.lines.Count)
              this.lines[index].SetInternalInstruction(element);
            ++index;
          }
        }
      }
      else
      {
        this.rootCodeAsk.NumberOfIteration = !this.question.IsGame ? (ICodeElement) new Variable(VariableType.constant, new Value(1L)) : (ICodeElement) new Variable(VariableType.constant, new Value((long) int.MaxValue));
        this.rootCodeAsk.GetBlockElements().Clear();
      }
      this.ShowBadLines(badLinesIndexes);
    }

    public void ShowScore(int score)
    {
      this.myScore = score;
      if (this.question != null && this.question.QuestionType == QuestionType.FreeCodeType)
        return;
      if (score == 0)
      {
        if (this.textBlock.FontWeight == FontWeights.Bold)
        {
          this.scrollViewer.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 230, (byte) 200));
          this.TooManyInstructionGrid.Visibility = Visibility.Visible;
        }
        else
        {
          this.scrollViewer.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));
          this.TooManyInstructionGrid.Visibility = Visibility.Collapsed;
        }
        this.blue1.Visibility = Visibility.Collapsed;
        this.redStar.Visibility = Visibility.Collapsed;
        this.gray1.Visibility = Visibility.Visible;
      }
      if (score >= 1)
      {
        this.scrollViewer.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));
        this.TooManyInstructionGrid.Visibility = Visibility.Collapsed;
        this.blue1.Visibility = Visibility.Visible;
        this.redStar.Visibility = Visibility.Collapsed;
        this.gray1.Visibility = Visibility.Collapsed;
      }
      if (score >= 0)
        return;
      this.blue1.Visibility = Visibility.Collapsed;
      this.redStar.Visibility = Visibility.Visible;
      this.gray1.Visibility = Visibility.Collapsed;
    }

    internal void ShowMatchStatus(CodeRunningResult matchStatus)
    {
      if (!matchStatus.CodesMatch)
      {
        this.SetFreez(true);
        if (this.question == null)
          return;
        int questionType = (int) this.question.QuestionType;
      }
      else
      {
        int num = 1;
        CongratulationsStaticManager.GreesStarShow = true;
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) < 0)
        {
          CongratulationsStaticManager.GreesStarShow = false;
          num = -1;
        }
        this.ShowScore(num);
        if (this.question != null && this.question.QuestionType == QuestionType.ClassicQuestionType)
          QuestionsPointsCounter.SetQuestionPoints(this.question, num);
        CongratulationsStaticManager.ShowCongratulations();
        this.SetFreez(true);
      }
    }

    public bool ClickMakeStop
    {
      get => this.clickMakeStop;
      set => this.clickMakeStop = value;
    }

    public event TextEditor.MakeStopByClick makeStopByClickEvent;

    private void ShowNumberOfCodeLines()
    {
      int length = this.textBox.Text.Replace("\r", "").TrimEnd("\n"[0]).Split("\n"[0]).Length;
      this.textBlock.Text = length.ToString() ?? "";
      if (length > this.linesOfCodeInPattern)
      {
        if (this.linesOfCodeInPattern < 0)
          return;
        this.scrollViewer.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 230, (byte) 200));
        this.TooManyInstructionGrid.Visibility = Visibility.Visible;
        this.textBlock.FontWeight = FontWeights.Bold;
        this.textBlock.Foreground = (Brush) new SolidColorBrush(Colors.OrangeRed);
      }
      else
      {
        this.scrollViewer.Background = (Brush) new SolidColorBrush(Colors.White);
        this.TooManyInstructionGrid.Visibility = Visibility.Collapsed;
        this.textBlock.FontWeight = FontWeights.Normal;
        this.textBlock.Foreground = (Brush) new SolidColorBrush(Colors.Black);
      }
    }

    private void textBox_KeyDown(object sender, KeyEventArgs e)
    {
    }

    public Point LocalizeCaret()
    {
      string[] strArray = this.textBox.Text.Substring(0, this.textBox.CaretIndex).Split("\n"[0]);
      return new Point((double) strArray[strArray.Length - 1].Length * 16.5, (double) strArray.Length * 35.15);
    }

    private void textBox_PreviewKeyDown(object sender, KeyEventArgs e)
    {
      if (!this.textBox.IsReadOnly && (e.Key == Key.OemPeriod || e.Key == Key.Tab) && (!Keyboard.IsKeyDown(Key.LeftShift) && !Keyboard.IsKeyDown(Key.RightShift)))
      {
        string str1 = this.textBox.Text.Substring(0, this.textBox.CaretIndex);
        int num = str1.LastIndexOf("\n");
        string substring = str1.Substring(num + 1, str1.Length - (num + 1));
        string str2 = "";
        if (substring.Length > 0)
          str2 = substring[substring.Length - 1].ToString() ?? "";
        if (str2 == "" || str2 == " ")
        {
          if (e.Timestamp != int.MinValue && e.Key == Key.OemPeriod)
            e.Handled = true;
        }
        else if (!"qwertyuiopasdfghjklzxcvbnm1234567890".Contains(str2.ToLower()) && e.Timestamp != int.MinValue && e.Key == Key.OemPeriod)
          e.Handled = true;
        this.options.SetPrevLine(substring);
        if (this.options.listBox.Items.Count == 0)
        {
          this.options.Visibility = Visibility.Collapsed;
        }
        else
        {
          this.options.Visibility = Visibility.Visible;
          Point point1 = this.LocalizeCaret();
          this.options.Margin = new Thickness(point1.X + 10.0, point1.Y - 3.0, 0.0, 0.0);
          this.options.Visibility = Visibility.Visible;
          Point point2;
          ref Point local = ref point2;
          Thickness margin = this.options.Margin;
          double x = margin.Left + this.options.ActualWidth;
          margin = this.options.Margin;
          double y = margin.Top + this.options.ActualHeight;
          local = new Point(x, y);
          if (point2.Y > this.scrollViewer.VerticalOffset + this.ActualHeight - 40.0)
            this.scrollViewer.ScrollToVerticalOffset(point2.Y - this.ActualHeight + 40.0);
          if (point2.X <= this.scrollViewer.HorizontalOffset + this.ActualWidth - 40.0)
            return;
          this.scrollViewer.ScrollToHorizontalOffset(point2.X - this.ActualWidth + 40.0);
        }
      }
      else
      {
        if (this.options.Visibility == Visibility.Visible)
        {
          Point point = new Point(this.options.Margin.Left + this.options.ActualWidth, this.options.Margin.Top + this.options.ActualHeight);
          if (point.Y > this.scrollViewer.VerticalOffset + this.ActualHeight - 40.0)
            this.scrollViewer.ScrollToVerticalOffset(point.Y - this.ActualHeight + 40.0);
          if (point.X > this.scrollViewer.HorizontalOffset + this.ActualWidth - 40.0)
            this.scrollViewer.ScrollToHorizontalOffset(point.X - this.ActualWidth + 40.0);
          if (e.Key == Key.Down || e.Key == Key.Up || e.Key == Key.Return)
          {
            e.Handled = true;
            this.options.PerfromKey(e);
          }
          else if (e.Key != Key.OemPeriod && e.Key != Key.Space && e.Key != Key.Return)
            this.options.Visibility = Visibility.Collapsed;
        }
        if (e.Key != Key.Escape)
          return;
        this.options.Visibility = Visibility.Collapsed;
      }
    }

    private void UserControl_MouseDown(object sender, MouseButtonEventArgs e) => this.options.Visibility = Visibility.Collapsed;

    private void textBox_MouseDown(object sender, MouseButtonEventArgs e) => this.options.Visibility = Visibility.Collapsed;

    private void textBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.clickMakeStop && this.makeStopByClickEvent != null)
        this.makeStopByClickEvent();
      this.options.Visibility = Visibility.Collapsed;
    }

    internal void DisposeAllElements()
    {
      if (this.question != null && this.question.QuestionType != QuestionType.InfoType)
        QuestionsCodesManager.AddPythonCode(this.question, this.textBox.Text);
      if (this.question != null)
      {
        int num = this.question.CanEditBitmap ? 1 : 0;
      }
      this.rootCodeAsk = (RepeatNTimes) null;
      this.rootCodePattern = (RepeatNTimes) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoncode/views/texteditor.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          break;
        case 2:
          this.BottonGrid = (Grid) target;
          break;
        case 3:
          this.textBlock = (TextBlock) target;
          break;
        case 4:
          this.textBotton = (TextBlock) target;
          break;
        case 5:
          this.image = (Image) target;
          break;
        case 6:
          this.blue1 = (Image) target;
          break;
        case 7:
          this.gray1 = (Image) target;
          break;
        case 8:
          this.redStar = (Image) target;
          break;
        case 9:
          this.buttonLook = (StackPanel) target;
          break;
        case 10:
          this.BadPythonLines = (Grid) target;
          break;
        case 11:
          this.TooManyInstructionGrid = (Grid) target;
          break;
        case 12:
          this.scrollViewer = (ScrollViewer) target;
          break;
        case 13:
          this.mainGrid = (Grid) target;
          break;
        case 14:
          this.stackPanel = (StackPanel) target;
          break;
        case 15:
          this.textBox = (TextBox) target;
          this.textBox.TextChanged += new TextChangedEventHandler(this.textBox_TextChanged);
          this.textBox.KeyDown += new KeyEventHandler(this.textBox_KeyDown);
          this.textBox.PreviewKeyDown += new KeyEventHandler(this.textBox_PreviewKeyDown);
          this.textBox.MouseDown += new MouseButtonEventHandler(this.textBox_MouseDown);
          this.textBox.PreviewMouseDown += new MouseButtonEventHandler(this.textBox_PreviewMouseDown);
          break;
        case 16:
          this.Caret = (Border) target;
          break;
        case 17:
          this.CaretStoryBoard = (Storyboard) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void CanCompileProgram(int canCompile);

    public delegate void MakeStopByClick();
  }
}
