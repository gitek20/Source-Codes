﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Properties.Resources
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace PixBlocks.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (PixBlocks.Properties.Resources.resourceMan == null)
          PixBlocks.Properties.Resources.resourceMan = new ResourceManager("PixBlocks.Properties.Resources", typeof (PixBlocks.Properties.Resources).Assembly);
        return PixBlocks.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => PixBlocks.Properties.Resources.resourceCulture;
      set => PixBlocks.Properties.Resources.resourceCulture = value;
    }

    internal static Bitmap item_aparat_40 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_aparat_40), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_auto1_12 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_auto1_12), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_auto2_7 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_auto2_7), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_auto3_5 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_auto3_5), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_books_8 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_books_8), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_buteleczka_14 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_buteleczka_14), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_ciastko_5 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_ciastko_5), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_ciastko2_5 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_ciastko2_5), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_ciastko3_5 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_ciastko3_5), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_dlugopisy_7 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_dlugopisy_7), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_fotel_36 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_fotel_36), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_globus_14 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_globus_14), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_hamburger_4 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_hamburger_4), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_klocek1_2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_klocek1_2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_klocek2_2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_klocek2_2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_klocek3_2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_klocek3_2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_klocek4_2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_klocek4_2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_kubek1_6 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_kubek1_6), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_kubek2_5 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_kubek2_5), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_kubek3_4 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_kubek3_4), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_kubek4_4 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_kubek4_4), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_kwiatek1_5 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_kwiatek1_5), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_kwiatek2_7 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_kwiatek2_7), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_kwiatek3_4 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_kwiatek3_4), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_lampa1_14 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_lampa1_14), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_lampa2_14 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_lampa2_14), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_lampa3_30 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_lampa3_30), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_latawiec_20 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_latawiec_20), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_milk_2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_milk_2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_napoj_12 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_napoj_12), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_okulary_8 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_okulary_8), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_owoc1_2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_owoc1_2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_owoc2_3 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_owoc2_3), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_owoc3_1 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_owoc3_1), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_pilka1_16 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_pilka1_16), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_pilka2_13 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_pilka2_13), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_plecak1_24 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_plecak1_24), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_plecak2_24 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_plecak2_24), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_polka_1 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_polka_1), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_prezent1_19 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_prezent1_19), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_prezent2_19 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_prezent2_19), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_rakieta_15 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_rakieta_15), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_robot_40 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_robot_40), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_szafka_23 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_szafka_23), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_torba1_4 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_torba1_4), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_torba2_4 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_torba2_4), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_torba3_12 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_torba3_12), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zdjecie_5 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zdjecie_5), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zegar_11 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zegar_11), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zegar2_11 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zegar2_11), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zwierze1_25 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zwierze1_25), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zwierze2_25 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zwierze2_25), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zzbaranek_35 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zzbaranek_35), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zzdiament_100 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zzdiament_100), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zzgwiazda_10 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zzgwiazda_10), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zzkonik_60 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zzkonik_60), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zzkorczak_10 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zzkorczak_10), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap item_zzser_10 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (item_zzser_10), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_boy => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_boy), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_boy1 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_boy1), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_boy2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_boy2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_boy3 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_boy3), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_girl => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_girl), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_girl1 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_girl1), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_girl2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_girl2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_girl3 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_girl3), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_man => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_man), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_man1 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_man1), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_man2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_man2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_man3 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_man3), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_woman => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_woman), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_woman1 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_woman1), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_woman2 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_woman2), PixBlocks.Properties.Resources.resourceCulture);

    internal static Bitmap table_woman3 => (Bitmap) PixBlocks.Properties.Resources.ResourceManager.GetObject(nameof (table_woman3), PixBlocks.Properties.Resources.resourceCulture);
  }
}
