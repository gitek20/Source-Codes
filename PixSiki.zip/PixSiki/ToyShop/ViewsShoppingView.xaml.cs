﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.ShoppingView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.Properties;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.ToyShop.Views.Images;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.ToyShop.Views
{
  public partial class ShoppingView : UserControl, IComponentConnector
  {
    private ToyShopView toyShopView;
    private int boughtProducts;
    private int maxProductsWithoutUserEmail = 8;
    private List<SingleProduct> products = new List<SingleProduct>();
    private CircleButton buttonCircle;
    private System.Windows.Point clickPoint = new System.Windows.Point(-100.0, -100.0);
    private double svVerticalOffset;
    private double svHorizontalOffset;
    internal ScrollViewer scroll;
    internal WrapPanel mainStack;
    internal Grid topButton;
    internal Grid topStars;
    internal Label NumberOfPoints2;
    private bool _contentLoaded;

    public ShoppingView()
    {
    }

    public ShoppingView(ToyShopView toyShopView)
    {
      this.toyShopView = toyShopView;
      this.InitializeComponent();
      QuestionsPointsCounter.questionPointsModifyEvent += new QuestionsPointsCounter.QuestionPointsModify(this.QuestionsPointsCounter_questionPointsModifyEvent);
      this.NumberOfPoints2.Content = (object) QuestionsPointsCounter.GetPointsForCurrentUser();
      foreach (var data in ((IEnumerable<PropertyInfo>) typeof (Resources).GetProperties(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)).Where<PropertyInfo>((Func<PropertyInfo, bool>) (p => p.PropertyType == typeof (Bitmap))).Select(x => new
      {
        Name = x.Name,
        Image = x.GetValue((object) null, (object[]) null)
      }).ToList())
      {
        if (!data.Name.Contains("table_"))
        {
          SingleProduct singleProduct = new SingleProduct(data.Name, data.Image as Bitmap);
          this.products.Add(singleProduct);
          singleProduct.buttonClickedEvet += new SingleProduct.ButtonClicked(this.Product_buttonClickedEvet);
          this.mainStack.Children.Add((UIElement) singleProduct);
        }
      }
      this.buttonCircle = new CircleButton((UserControl) new BackFromShop(), System.Windows.Media.Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.veryBig);
      this.buttonCircle.buttonClickedEvent += new CircleButton.ButtonClicker(this.ButtonCircle_buttonClickedEvent);
      this.topButton.Children.Add((UIElement) this.buttonCircle);
      int pointsForCurrentUser = QuestionsPointsCounter.GetPointsForCurrentUser();
      QuestionsPointsCounter.questionPointsModifyEvent += new QuestionsPointsCounter.QuestionPointsModify(this.QuestionsPointsCounter_questionPointsModifyEvent);
      foreach (SingleProduct product in this.products)
        product.RefreshCanBuy(pointsForCurrentUser);
    }

    private void QuestionsPointsCounter_questionPointsModifyEvent(QuestionPoint questionPoint) => this.RefreshView();

    public void RefreshView()
    {
      this.NumberOfPoints2.Content = (object) QuestionsPointsCounter.GetPointsForCurrentUser();
      int pointsForCurrentUser = QuestionsPointsCounter.GetPointsForCurrentUser();
      foreach (SingleProduct product in this.products)
        product.RefreshCanBuy(pointsForCurrentUser);
    }

    private void Product_buttonClickedEvet(string name, bool delete)
    {
      if (delete)
      {
        this.toyShopView.DeleteElement(name);
        this.toyShopView.shoppingItems.Children.Clear();
      }
      else
      {
        foreach (SingleProduct product in this.products)
        {
          if (product.NameOfBitmap == name)
            this.toyShopView.AddElement(product.NameOfBitmap, product.Bitmap);
        }
        this.toyShopView.shoppingItems.Children.Clear();
      }
    }

    internal void ShowDeleteButtons()
    {
      this.boughtProducts = 0;
      foreach (SingleProduct product in this.products)
      {
        bool canDelete = false;
        foreach (DropableElement element in this.toyShopView.Elements)
        {
          if (element.UniqueName == product.NameOfBitmap)
          {
            canDelete = true;
            ++this.boughtProducts;
          }
        }
        product.SetCanDelete(canDelete);
      }
      if (!string.IsNullOrEmpty(CurrentUserInfo.CurrentUser.Email) || this.boughtProducts < this.maxProductsWithoutUserEmail)
        return;
      this.toyShopView.ShowLimitProductsWithoutEmail();
    }

    private void ButtonCircle_buttonClickedEvent() => this.toyShopView.shoppingItems.Children.Clear();

    private void button_Click(object sender, RoutedEventArgs e)
    {
    }

    private void Grid_MouseMove(object sender, MouseEventArgs e)
    {
      System.Windows.Point position = e.GetPosition((IInputElement) this);
      if (this.clickPoint.Y == -100.0)
        return;
      this.scroll.ScrollToVerticalOffset(this.svVerticalOffset - position.Y + this.clickPoint.Y);
      this.scroll.ScrollToHorizontalOffset(this.svHorizontalOffset - position.X + this.clickPoint.X);
    }

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.svVerticalOffset = this.scroll.VerticalOffset;
      this.svHorizontalOffset = this.scroll.HorizontalOffset;
      this.clickPoint = e.GetPosition((IInputElement) this);
    }

    private void Grid_MouseUp(object sender, MouseButtonEventArgs e) => this.clickPoint = new System.Windows.Point(-100.0, -100.0);

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.clickPoint = new System.Windows.Point(-100.0, -100.0);

    internal void DisposeAll()
    {
      this.buttonCircle.buttonClickedEvent -= new CircleButton.ButtonClicker(this.ButtonCircle_buttonClickedEvent);
      QuestionsPointsCounter.questionPointsModifyEvent -= new QuestionsPointsCounter.QuestionPointsModify(this.QuestionsPointsCounter_questionPointsModifyEvent);
      this.mainStack.Children.Clear();
      foreach (SingleProduct product in this.products)
      {
        product.buttonClickedEvet -= new SingleProduct.ButtonClicked(this.Product_buttonClickedEvet);
        product.DisposeAll();
      }
      this.products.Clear();
      this.products = (List<SingleProduct>) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toyshop/views/shoppingview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.scroll = (ScrollViewer) target;
          break;
        case 2:
          ((UIElement) target).MouseMove += new MouseEventHandler(this.Grid_MouseMove);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.Grid_MouseUp);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 3:
          this.mainStack = (WrapPanel) target;
          break;
        case 4:
          this.topButton = (Grid) target;
          break;
        case 5:
          this.topStars = (Grid) target;
          break;
        case 6:
          this.NumberOfPoints2 = (Label) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
