﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.ProductsLimitView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using PixBlocks.TopPanel.PreferencesPanel.Views;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.ToyShop.Views
{
  public partial class ProductsLimitView : UserControl, IPreferencePanelController, IComponentConnector
  {
    private ToyShopView toyShopView;
    private GenericPopUp popUp;
    internal Grid mainGrid;
    private bool _contentLoaded;

    public ProductsLimitView(ToyShopView toyShopView)
    {
      this.InitializeComponent();
      this.toyShopView = toyShopView;
      this.SetPopUpView((UserControl) new ProductsLimitInformationView(this));
    }

    private void SetPopUpView(UserControl userControl)
    {
      this.mainGrid.Children.Clear();
      this.popUp = new GenericPopUp();
      this.popUp.IsCloseButton(false);
      this.popUp.AddComponent(userControl);
      this.mainGrid.Children.Add((UIElement) this.popUp);
    }

    public void CloseButton_clickEvent()
    {
      this.toyShopView.mainGrid.Children.Remove((UIElement) this);
      this.toyShopView.shoppingItems.Children.Clear();
    }

    public void ShowProfileEditPanel() => throw new NotImplementedException();

    public void ShowStartPreferencePanel()
    {
      if (string.IsNullOrEmpty(CurrentUserInfo.CurrentUser.Email))
        this.SetPopUpView((UserControl) new ProductsLimitInformationView(this));
      else
        this.toyShopView.mainGrid.Children.Remove((UIElement) this);
    }

    public void ShowPasswordEditPanel() => throw new NotImplementedException();

    public void ShowAssignToClassPanel() => throw new NotImplementedException();

    public void ShowUnassignFromClassPanel() => throw new NotImplementedException();

    public void ShowSetEmailPanel() => this.SetPopUpView((UserControl) new SetEmailPanel((IPreferencePanelController) this));

    public void ShowEnterPinPanel(string email) => this.SetPopUpView((UserControl) new EnterSetEmailPinPanel(email, (IPreferencePanelController) this));

    public void ShowRemoveAccountPanel() => throw new NotImplementedException();

    public void ShowRemoveAccountInfo() => throw new NotImplementedException();

    public void ShowBecomeTeacherPanel() => throw new NotImplementedException();

    public void ShowPasswordChangedInfo() => throw new NotImplementedException();

    public void ShowBecomeTeacherInfo() => throw new NotImplementedException();

    public void ShowImportFromOfflineProfile() => throw new NotImplementedException();

    public void ShowUnassignFromClassInfo() => throw new NotImplementedException();

    public void ShowEditSchool(School school) => throw new NotImplementedException();

    public void ShowEnterLicenseKeyPanel() => throw new NotImplementedException();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toyshop/views/productslimitview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.mainGrid = (Grid) target;
      else
        this._contentLoaded = true;
    }
  }
}
