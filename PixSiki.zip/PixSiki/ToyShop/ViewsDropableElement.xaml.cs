﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.DropableElement
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PixBlocks.ToyShop.Views
{
  public partial class DropableElement : UserControl, IComparable, IComponentConnector
  {
    private Bitmap bmp;
    private string uniqueName;
    private int myZIndex;
    private bool isDragged;
    public static int zindex;
    private System.Windows.Point currentMargin = new System.Windows.Point(0.0, 0.0);
    private System.Windows.Point currentpoint = new System.Windows.Point(0.0, 0.0);
    internal System.Windows.Controls.Image imgSrc;
    private bool _contentLoaded;

    public DropableElement(string name, Bitmap bmp)
    {
      this.uniqueName = name;
      this.bmp = bmp;
      this.InitializeComponent();
      MemoryStream memoryStream = new MemoryStream();
      bmp.Save((Stream) memoryStream, ImageFormat.Png);
      memoryStream.Position = 0L;
      BitmapImage bitmapImage = new BitmapImage();
      bitmapImage.BeginInit();
      bitmapImage.StreamSource = (Stream) memoryStream;
      bitmapImage.EndInit();
      this.imgSrc.Source = (ImageSource) bitmapImage;
      this.imgSrc.Width = (double) bmp.Width;
      this.imgSrc.Height = (double) bmp.Height;
      this.Width = (double) bmp.Width;
      this.Height = (double) bmp.Height;
      this.VerticalAlignment = VerticalAlignment.Top;
      this.HorizontalAlignment = HorizontalAlignment.Left;
      this.Margin = new Thickness(1000.0 - this.Width / 2.0, 800.0 - this.Height / 2.0, 0.0, 0.0);
      ++DropableElement.zindex;
      this.MyZIndex = DropableElement.zindex;
      Panel.SetZIndex((UIElement) this, DropableElement.zindex);
      this.IsHitTestVisible = false;
    }

    public BitmapImage Convert(Bitmap src)
    {
      MemoryStream memoryStream = new MemoryStream();
      src.Save((Stream) memoryStream, ImageFormat.Bmp);
      BitmapImage bitmapImage = new BitmapImage();
      bitmapImage.BeginInit();
      memoryStream.Seek(0L, SeekOrigin.Begin);
      bitmapImage.StreamSource = (Stream) memoryStream;
      bitmapImage.EndInit();
      return bitmapImage;
    }

    public DropableElement()
    {
    }

    public bool IsDragged => this.isDragged;

    public int MyZIndex
    {
      get => this.myZIndex;
      set
      {
        this.myZIndex = value;
        Panel.SetZIndex((UIElement) this, DropableElement.zindex);
      }
    }

    public string UniqueName => this.uniqueName;

    private void imgSrc_MouseDown(object sender, MouseButtonEventArgs e)
    {
    }

    public bool IsVisibleToClickToClick(MouseButtonEventArgs e)
    {
      Thickness margin = this.Margin;
      double left = margin.Left;
      margin = this.Margin;
      double top = margin.Top;
      this.currentMargin = new System.Windows.Point(left, top);
      System.Windows.Point position1 = e.GetPosition((IInputElement) this);
      if (position1.X >= 0.0 && position1.X < this.Width && (position1.Y >= 0.0 && position1.Y < this.Height))
      {
        System.Windows.Point position2 = e.GetPosition((IInputElement) this);
        System.Drawing.Color pixel = this.bmp.GetPixel((int) position2.X, (int) position2.Y);
        pixel.ToArgb();
        if (pixel.A != (byte) 0)
          return true;
      }
      return false;
    }

    private void imgSrc_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
      Thickness margin = this.Margin;
      double left = margin.Left;
      margin = this.Margin;
      double top = margin.Top;
      this.currentMargin = new System.Windows.Point(left, top);
      e.GetPosition((IInputElement) (this.Parent as Grid));
      System.Windows.Point position = e.GetPosition((IInputElement) this);
      System.Drawing.Color pixel = this.bmp.GetPixel((int) position.X, (int) position.Y);
      pixel.ToArgb();
      if (pixel.A != (byte) 0)
      {
        this.isDragged = true;
        ++DropableElement.zindex;
        Panel.SetZIndex((UIElement) this, DropableElement.zindex);
      }
      else
        this.IsHitTestVisible = false;
    }

    private void imgSrc_MouseLeave(object sender, MouseEventArgs e) => this.isDragged = false;

    private void imgSrc_MouseUp(object sender, MouseButtonEventArgs e) => this.isDragged = false;

    private void imgSrc_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.isDragged)
        return;
      System.Windows.Point position = e.GetPosition((IInputElement) (this.Parent as Grid));
      this.Margin = new Thickness(Math.Min((this.Parent as Grid).ActualWidth - this.Width, Math.Max(0.0, -this.Width / 2.0 + (position.X - this.currentpoint.X))), Math.Min((this.Parent as Grid).ActualHeight - this.Height, Math.Max(0.0, -this.Height / 2.0 + (position.Y - this.currentpoint.Y))), 0.0, 0.0);
    }

    public int CompareTo(object obj) => -this.myZIndex.CompareTo((obj as DropableElement).MyZIndex);

    internal void DisposeAll()
    {
      this.bmp.Dispose();
      this.bmp = (Bitmap) null;
      this.uniqueName = (string) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toyshop/views/dropableelement.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
      {
        this.imgSrc = (System.Windows.Controls.Image) target;
        this.imgSrc.MouseDown += new MouseButtonEventHandler(this.imgSrc_MouseDown);
        this.imgSrc.PreviewMouseDown += new MouseButtonEventHandler(this.imgSrc_PreviewMouseDown);
        this.imgSrc.MouseLeave += new MouseEventHandler(this.imgSrc_MouseLeave);
        this.imgSrc.MouseUp += new MouseButtonEventHandler(this.imgSrc_MouseUp);
        this.imgSrc.MouseMove += new MouseEventHandler(this.imgSrc_MouseMove);
      }
      else
        this._contentLoaded = true;
    }
  }
}
