﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.MessageNotifications.NotificationControl
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PixBlocks.ToyShop.Views.MessageNotifications
{
  public partial class NotificationControl : UserControl, IComponentConnector
  {
    public bool showNotifications = true;
    private CircleButton maximaliseButton;
    private CircleButton minimaliseButton;
    private int maxSize = 450;
    private DispatcherTimer dispatcherTimer = new DispatcherTimer();
    private bool minimalising = true;
    private string currentLang = "";
    private string AbsoluteUri = "www.pixblocks.com";
    internal Grid insideGrid;
    internal Rectangle shadow2;
    internal Rectangle shadow1;
    internal Image infoIcon;
    internal Grid mainGrid;
    internal Image image;
    internal TextBlock text;
    internal Hyperlink hyperlink;
    internal TextBlock hyperText;
    internal Rectangle rec;
    internal Grid minimaliseButtonGrid;
    private bool _contentLoaded;

    private static BitmapImage LoadImage(byte[] imageData)
    {
      if (imageData == null || imageData.Length == 0)
        return (BitmapImage) null;
      BitmapImage bitmapImage = new BitmapImage();
      using (MemoryStream memoryStream = new MemoryStream(imageData))
      {
        memoryStream.Position = 0L;
        bitmapImage.BeginInit();
        bitmapImage.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
        bitmapImage.UriSource = (Uri) null;
        bitmapImage.StreamSource = (Stream) memoryStream;
        bitmapImage.EndInit();
      }
      bitmapImage.Freeze();
      return bitmapImage;
    }

    public NotificationControl()
    {
      this.InitializeComponent();
      this.maximaliseButton = new CircleButton((UserControl) new MaximaliseIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.minimaliseButtonGrid.Children.Add((UIElement) this.maximaliseButton);
      this.maximaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.MaximaliseButton_buttonClickedEvent);
      this.minimaliseButton = new CircleButton((UserControl) new MinimaliseIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.minimaliseButtonGrid.Children.Add((UIElement) this.minimaliseButton);
      this.minimaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.MinimaliseButton_buttonClickedEvent);
      this.maximaliseButton.Visibility = Visibility.Collapsed;
      this.infoIcon.Visibility = Visibility.Collapsed;
      int num = this.showNotifications ? 1 : 0;
      this.dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 7);
      this.dispatcherTimer.Tick += new EventHandler(this.DispatcherTimer_Tick);
    }

    private void DispatcherTimer_Tick(object sender, EventArgs e)
    {
      if (this.minimalising)
      {
        this.maxSize -= 25;
        this.maxSize = Math.Max(0, this.maxSize);
        this.mainGrid.MaxWidth = (double) this.maxSize;
        this.mainGrid.MaxHeight = (double) this.maxSize;
        if (this.maxSize != 0)
          return;
        this.dispatcherTimer.Stop();
        this.maximaliseButton.Visibility = Visibility.Visible;
        this.infoIcon.Visibility = Visibility.Visible;
      }
      else
      {
        this.maxSize += 25;
        this.mainGrid.MaxWidth = (double) this.maxSize;
        this.mainGrid.MaxHeight = (double) this.maxSize;
        if (this.maxSize < 450)
          return;
        this.mainGrid.MaxHeight = (double) (100 * this.maxSize);
        this.dispatcherTimer.Stop();
        this.minimaliseButton.Visibility = Visibility.Visible;
      }
    }

    private void MinimaliseButton_buttonClickedEvent()
    {
      this.dispatcherTimer.Start();
      this.minimalising = true;
      this.minimaliseButton.Visibility = Visibility.Collapsed;
    }

    private void MaximaliseButton_buttonClickedEvent()
    {
      this.dispatcherTimer.Start();
      this.minimalising = false;
      this.maximaliseButton.Visibility = Visibility.Collapsed;
      this.infoIcon.Visibility = Visibility.Collapsed;
    }

    internal void Refresh()
    {
      this.currentLang = UserMenager.LanguageKey;
      try
      {
        ServerApi serverApi = new ServerApi();
        List<PixBlocks.Server.DataModels.DataModels.Notification> notificationList = new List<PixBlocks.Server.DataModels.DataModels.Notification>();
        if (!UserMenager.IsOffLineUser)
          notificationList = serverApi.GetNotificationForUser(UserMenager.LanguageKey, new AuthorizeData(CurrentUserInfo.CurrentUser));
        if (notificationList.Count != 0)
        {
          int index = new Random().Next(0, notificationList.Count);
          this.text.Text = notificationList[index].NotyficationText;
          this.hyperText.Text = notificationList[index].Url;
          this.AbsoluteUri = notificationList[index].HiddenURL;
          this.image.Source = (ImageSource) NotificationControl.LoadImage(Convert.FromBase64String(notificationList[index].ImageInBase64));
          this.Visibility = Visibility.Visible;
        }
        else
          this.Visibility = Visibility.Collapsed;
      }
      catch (Exception ex)
      {
        this.Visibility = Visibility.Collapsed;
      }
    }

    private void OpenHyperlinkInBrowser(RequestNavigateEventArgs e = null)
    {
      try
      {
        Process.Start(new ProcessStartInfo(this.AbsoluteUri));
        if (e == null)
          return;
        e.Handled = true;
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show("Error serwer www : " + ex?.ToString());
      }
    }

    private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e) => this.OpenHyperlinkInBrowser(e);

    private void PopupImage_MouseDown(object sender, MouseButtonEventArgs e) => this.OpenHyperlinkInBrowser();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toyshop/views/messagenotifications/notificationcontrol.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.insideGrid = (Grid) target;
          break;
        case 2:
          this.shadow2 = (Rectangle) target;
          break;
        case 3:
          this.shadow1 = (Rectangle) target;
          break;
        case 4:
          this.infoIcon = (Image) target;
          break;
        case 5:
          this.mainGrid = (Grid) target;
          break;
        case 6:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.PopupImage_MouseDown);
          break;
        case 7:
          this.image = (Image) target;
          break;
        case 8:
          this.text = (TextBlock) target;
          break;
        case 9:
          this.hyperlink = (Hyperlink) target;
          this.hyperlink.RequestNavigate += new RequestNavigateEventHandler(this.Hyperlink_RequestNavigate);
          break;
        case 10:
          this.hyperText = (TextBlock) target;
          break;
        case 11:
          this.rec = (Rectangle) target;
          break;
        case 12:
          this.minimaliseButtonGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
