﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.MessageNotifications.Notification
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.ToyShop.Views.MessageNotifications
{
  internal class Notification
  {
    private string imageURL;
    private string notificationText;
    private string linkURL;
  }
}
