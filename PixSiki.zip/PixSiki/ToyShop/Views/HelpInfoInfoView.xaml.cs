﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.HelpInfo.InfoView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using PixBlocks.TopPanel.PreferencesPanel.Views;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.ToyShop.Views.HelpInfo
{
  public partial class InfoView : UserControl, IPreferencePanelController, IComponentConnector
  {
    internal Action logoutEvent;
    internal Grid BecomingTeacherPanel;
    internal Grid AreYouTeacherPanel;
    internal TextBlock Caption;
    internal ActionButtons actionButtons;
    internal TextBlock Sublitle;
    private bool _contentLoaded;

    public InfoView()
    {
      this.InitializeComponent();
      this.Caption.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("areYouTeacher");
      this.Sublitle.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("teacherProfitsDescription");
      this.actionButtons.abort.buttonText.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("iAmNotTeacher");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.Abort_clickEvent);
      this.actionButtons.confirm.buttonText.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("iAmTeacher");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.Confirm_clickEvent);
      this.ViewReloaded();
    }

    private void Abort_clickEvent() => this.Visibility = Visibility.Collapsed;

    internal void ViewReloaded()
    {
      if (CurrentUserInfo.CurrentUser != null)
      {
        bool? acceptedToStudentsClass = CurrentUserInfo.CurrentUser.Student_isAcceptedToStudentsClass;
        bool flag = false;
        if (acceptedToStudentsClass.GetValueOrDefault() == flag & acceptedToStudentsClass.HasValue && !CurrentUserInfo.CurrentUser.Teacher_isTeacher && (!CurrentUserInfo.CurrentUser.Student_isAssignedToStudentsClass && CurrentUserInfo.CurrentUser.Student_login == null) && CurrentUserInfo.CurrentUser.LoginsCounter <= 1)
        {
          this.Visibility = Visibility.Visible;
          return;
        }
      }
      this.Visibility = Visibility.Collapsed;
    }

    private void Confirm_clickEvent()
    {
      BecomeTeacherPanel becomeTeacherPanel = new BecomeTeacherPanel((IPreferencePanelController) this);
      this.AreYouTeacherPanel.Visibility = Visibility.Collapsed;
      this.BecomingTeacherPanel.Children.Add((UIElement) becomeTeacherPanel);
    }

    public void ShowAssignToClassPanel() => throw new NotImplementedException();

    public void ShowBecomeTeacherInfo()
    {
      this.BecomingTeacherPanel.Children.Clear();
      BecomeTeacherInfo becomeTeacherInfo = new BecomeTeacherInfo((IPreferencePanelController) this);
      becomeTeacherInfo.LogoutEvent += new BecomeTeacherInfo.LogoutAction(this.BecomeTeacherInfo_LogoutEvent);
      this.BecomingTeacherPanel.Children.Add((UIElement) becomeTeacherInfo);
    }

    private void BecomeTeacherInfo_LogoutEvent()
    {
      Action logoutEvent = this.logoutEvent;
      if (logoutEvent == null)
        return;
      logoutEvent();
    }

    public void ShowBecomeTeacherPanel() => throw new NotImplementedException();

    public void ShowEditSchool(School school) => throw new NotImplementedException();

    public void ShowEnterLicenseKeyPanel() => throw new NotImplementedException();

    public void ShowEnterPinPanel(string email) => throw new NotImplementedException();

    public void ShowImportFromOfflineProfile() => throw new NotImplementedException();

    public void ShowPasswordChangedInfo() => throw new NotImplementedException();

    public void ShowPasswordEditPanel() => throw new NotImplementedException();

    public void ShowProfileEditPanel()
    {
    }

    public void ShowRemoveAccountInfo() => throw new NotImplementedException();

    public void ShowRemoveAccountPanel() => throw new NotImplementedException();

    public void ShowSetEmailPanel() => throw new NotImplementedException();

    public void ShowStartPreferencePanel()
    {
      this.AreYouTeacherPanel.Visibility = Visibility.Visible;
      this.BecomingTeacherPanel.Children.Clear();
    }

    public void ShowUnassignFromClassInfo() => throw new NotImplementedException();

    public void ShowUnassignFromClassPanel() => throw new NotImplementedException();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toyshop/views/helpinfo/infoview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.BecomingTeacherPanel = (Grid) target;
          break;
        case 2:
          this.AreYouTeacherPanel = (Grid) target;
          break;
        case 3:
          this.Caption = (TextBlock) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        case 5:
          this.Sublitle = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
