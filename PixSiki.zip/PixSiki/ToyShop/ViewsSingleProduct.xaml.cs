﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.SingleProduct
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.ToyShop.Views.Images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PixBlocks.ToyShop.Views
{
  public partial class SingleProduct : UserControl, IComponentConnector
  {
    private string name;
    private Bitmap bitmap;
    private int price;
    private CircleButton buttonBuy;
    private CircleButton buttonDelete;
    internal System.Windows.Controls.Image imgSrc;
    internal StackPanel buyIconGrid;
    internal Label label;
    private bool _contentLoaded;

    public Bitmap Bitmap => this.bitmap;

    public string NameOfBitmap => this.name;

    public int GetPriceOfName(string name)
    {
      if (!name.Contains("_"))
        return 0;
      string s = name.Substring(name.LastIndexOf("_") + 1);
      int num = 0;
      ref int local = ref num;
      return int.TryParse(s, out local) ? num : 0;
    }

    public SingleProduct(string name, Bitmap bmp)
    {
      this.bitmap = bmp;
      this.name = name;
      this.InitializeComponent();
      MemoryStream memoryStream = new MemoryStream();
      bmp.Save((Stream) memoryStream, ImageFormat.Png);
      memoryStream.Position = 0L;
      BitmapImage bitmapImage = new BitmapImage();
      bitmapImage.BeginInit();
      bitmapImage.StreamSource = (Stream) memoryStream;
      bitmapImage.EndInit();
      this.imgSrc.Source = (ImageSource) bitmapImage;
      this.price = this.GetPriceOfName(name);
      this.label.Content = (object) this.price;
      this.buttonBuy = new CircleButton((UserControl) new GetProductIcon(), System.Windows.Media.Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.CircleBig);
      this.buttonDelete = new CircleButton((UserControl) new TrashIcon(), System.Windows.Media.Color.FromRgb((byte) 225, (byte) 100, (byte) 88), CircleButton.VisualParam.CircleBig);
      this.buttonDelete.Margin = new Thickness(2.0, 0.0, 0.0, 0.0);
      this.buttonDelete.buttonClickedEvent += new CircleButton.ButtonClicker(this.ButtonDelete_buttonClickedEvent);
      int price = this.price;
      this.buttonBuy.buttonClickedEvent += new CircleButton.ButtonClicker(this.ButtonCircle_buttonClickedEvent);
      this.buyIconGrid.Children.Add((UIElement) this.buttonBuy);
      this.buyIconGrid.Children.Add((UIElement) this.buttonDelete);
    }

    internal void RefreshCanBuy(int totalPoints)
    {
      if (this.price > totalPoints)
        this.buttonBuy.SetIsEnabled(false);
      else
        this.buttonBuy.SetIsEnabled(true);
    }

    private void ButtonDelete_buttonClickedEvent()
    {
      if (this.buttonClickedEvet == null)
        return;
      this.buttonClickedEvet(this.NameOfBitmap, true);
    }

    internal void SetCanDelete(bool canDelete)
    {
      if (canDelete)
        this.buttonDelete.Visibility = Visibility.Visible;
      else
        this.buttonDelete.Visibility = Visibility.Collapsed;
    }

    public event SingleProduct.ButtonClicked buttonClickedEvet;

    private void ButtonCircle_buttonClickedEvent()
    {
      if (this.buttonClickedEvet == null)
        return;
      this.buttonClickedEvet(this.NameOfBitmap, false);
    }

    internal void DisposeAll()
    {
      this.bitmap.Dispose();
      this.buttonDelete.buttonClickedEvent -= new CircleButton.ButtonClicker(this.ButtonDelete_buttonClickedEvent);
      this.buttonBuy.buttonClickedEvent -= new CircleButton.ButtonClicker(this.ButtonCircle_buttonClickedEvent);
      this.buttonBuy = (CircleButton) null;
      this.buttonDelete = (CircleButton) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toyshop/views/singleproduct.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.imgSrc = (System.Windows.Controls.Image) target;
          break;
        case 2:
          this.buyIconGrid = (StackPanel) target;
          break;
        case 3:
          this.label = (Label) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ButtonClicked(string name, bool delete);
  }
}
