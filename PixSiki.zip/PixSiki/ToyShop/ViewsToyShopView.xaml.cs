﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.ToyShopView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.Properties;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.ToyShop.Views.HelpInfo;
using PixBlocks.ToyShop.Views.Images;
using PixBlocks.ToyShop.Views.MessageNotifications;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.UserMenagment.ToyShopMenager;
using PixBlocks.Views.AdditionalBrandingView;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.ToyShop.Views
{
  public partial class ToyShopView : UserControl, IComponentConnector
  {
    private List<DropableElement> elements = new List<DropableElement>();
    private NotificationControl notification = new NotificationControl();
    private InfoView infoView = new InfoView();
    private CircleButton buttonCircle;
    private ShoppingView shooppingView;
    private DropableElement dropElement;
    private System.Windows.Point clickPoint;
    private UserAgeType userFaceType;
    public List<PropertyInfo> images;
    private GenericPopUp popUp;
    internal Grid mainGrid;
    internal Viewbox viewBoxx;
    internal Grid gridinViewBox;
    internal System.Windows.Shapes.Rectangle TopOfRoom;
    internal Grid testStack;
    internal Grid topButton;
    internal Grid NotificationGrid;
    internal Grid InfoGrid;
    internal Grid AdditionalLogoGrid;
    internal Grid shoppingItems;
    private bool _contentLoaded;

    public List<DropableElement> Elements => this.elements;

    public ToyShopView()
    {
      this.InitializeComponent();
      this.AdditionalLogoGrid.Children.Add((UIElement) AdditionalBrandingManager.GetBranding());
      this.InfoGrid.Children.Add((UIElement) this.infoView);
      if (!UserMenager.IsTeacherLogin)
        this.NotificationGrid.Children.Add((UIElement) this.notification);
      this.RefreshUserInfo();
      this.buttonCircle = new CircleButton((UserControl) new ShopIcon(), System.Windows.Media.Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.veryBig);
      this.buttonCircle.buttonClickedEvent += new CircleButton.ButtonClicker(this.ButtonCircle_buttonClickedEvent);
      this.topButton.Children.Add((UIElement) this.buttonCircle);
      UserMenager.userDataChangedEvent += new UserMenager.UserDataChangedEvent(this.UserMenager_userDataChangedEvent);
    }

    private void UserMenager_userDataChangedEvent()
    {
      if (this.userFaceType != UserMenager.UserAgeType)
        this.RefreshUserInfo();
      this.infoView.ViewReloaded();
    }

    public void ShowLimitProductsWithoutEmail() => this.mainGrid.Children.Add((UIElement) new ProductsLimitView(this));

    private void ButtonCircle_buttonClickedEvent()
    {
      if (this.shooppingView == null)
        this.shooppingView = new ShoppingView(this);
      this.shoppingItems.Visibility = Visibility.Visible;
      this.shoppingItems.Children.Clear();
      this.shoppingItems.Children.Add((UIElement) this.shooppingView);
      this.shooppingView.ShowDeleteButtons();
    }

    public void ClearShoppingItemsGrid() => this.shoppingItems.Children.Clear();

    internal void DeleteElement(string name)
    {
      DropableElement dropableElement = (DropableElement) null;
      foreach (DropableElement element in this.elements)
      {
        if (element.UniqueName == name)
        {
          dropableElement = element;
          break;
        }
      }
      if (dropableElement == null)
        return;
      this.elements.Remove(dropableElement);
      this.testStack.Children.Remove((UIElement) dropableElement);
      StaticToyManager.ToysInfos.AddToDeletedToy(name);
      StaticToyManager.ToysInfos.RefreshActiveToys(this.elements);
      QuestionsPointsCounter.PointsWasChangedInShop();
    }

    private void Grid_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      double num1 = this.mainGrid.ActualWidth / this.mainGrid.ActualHeight;
      double num2 = this.gridinViewBox.ActualWidth / this.gridinViewBox.ActualHeight;
      if (num1 > num2)
      {
        double num3 = (this.gridinViewBox.ActualWidth * (num1 / num2) - this.gridinViewBox.ActualWidth) / 2.0;
        this.TopOfRoom.Margin = new Thickness(-num3, 0.0, -num3, 500.0);
      }
      if (num1 >= num2)
        return;
      this.TopOfRoom.Margin = new Thickness(0.0, -((this.gridinViewBox.ActualHeight * (num2 / num1) - this.gridinViewBox.ActualHeight) / 2.0), 0.0, 500.0);
    }

    internal void AddElement(string name, Bitmap bitmap)
    {
      DropableElement dropableElement = new DropableElement(name, bitmap);
      this.elements.Add(dropableElement);
      this.testStack.Children.Add((UIElement) dropableElement);
      StaticToyManager.ToysInfos.RefreshActiveToys(this.elements);
      QuestionsPointsCounter.PointsWasChangedInShop();
    }

    private void AddElement(string name, Bitmap bitmap, System.Windows.Point position)
    {
      DropableElement dropableElement = new DropableElement(name, bitmap);
      this.elements.Add(dropableElement);
      this.testStack.Children.Add((UIElement) dropableElement);
      dropableElement.Margin = new Thickness(position.X, position.Y, 0.0, 0.0);
    }

    private void testStack_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.elements.Sort();
      foreach (DropableElement element in this.elements)
      {
        if (element.IsVisibleToClickToClick(e))
        {
          this.dropElement = element;
          ++DropableElement.zindex;
          element.MyZIndex = DropableElement.zindex;
          this.clickPoint = e.GetPosition((IInputElement) this.testStack);
          return;
        }
      }
      this.dropElement = (DropableElement) null;
    }

    private void testStack_MouseUp(object sender, MouseButtonEventArgs e)
    {
      if (this.dropElement != null)
      {
        StaticToyManager.ToysInfos.RefreshActiveToys(this.elements);
        QuestionsPointsCounter.PointsWasChangedInShop();
      }
      this.dropElement = (DropableElement) null;
    }

    private void testStack_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
    }

    private void testStack_MouseMove(object sender, MouseEventArgs e)
    {
      if (this.dropElement == null)
        return;
      System.Windows.Point position = e.GetPosition((IInputElement) this.testStack);
      this.dropElement.Margin = new Thickness(Math.Min(this.testStack.ActualWidth - this.dropElement.Width, Math.Max(0.0, this.dropElement.Margin.Left + (position.X - this.clickPoint.X))), Math.Min(this.testStack.ActualHeight - this.dropElement.Height, Math.Max(0.0, this.dropElement.Margin.Top + (position.Y - this.clickPoint.Y))), 0.0, 0.0);
      this.clickPoint = position;
    }

    internal void RefreshUserInfo()
    {
      if (this.notification != null)
        this.notification.Refresh();
      this.userFaceType = UserMenager.UserAgeType;
      this.testStack.Children.Clear();
      this.elements.Clear();
      if (this.images == null)
        this.images = ((IEnumerable<PropertyInfo>) typeof (Resources).GetProperties(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)).Where<PropertyInfo>((Func<PropertyInfo, bool>) (p => p.PropertyType == typeof (Bitmap))).ToList<PropertyInfo>();
      foreach (ToyInfo activeToy in StaticToyManager.ToysInfos.ActiveToys)
      {
        foreach (PropertyInfo image in this.images)
        {
          if (image.Name == activeToy.UniqueName)
            this.AddElement(image.Name, image.GetValue((object) null, (object[]) null) as Bitmap, activeToy.Position);
        }
      }
      if (this.shooppingView == null)
        return;
      this.shooppingView.RefreshView();
    }

    private void testStack_MouseLeave(object sender, MouseEventArgs e)
    {
      if (this.dropElement != null)
      {
        StaticToyManager.ToysInfos.RefreshActiveToys(this.elements);
        QuestionsPointsCounter.PointsWasChangedInShop();
      }
      this.dropElement = (DropableElement) null;
    }

    private void UserControl_MouseLeave(object sender, MouseEventArgs e)
    {
    }

    internal void DisposeAll()
    {
      this.NotificationGrid.Children.Clear();
      this.notification = (NotificationControl) null;
      if (this.buttonCircle != null)
        this.buttonCircle.buttonClickedEvent -= new CircleButton.ButtonClicker(this.ButtonCircle_buttonClickedEvent);
      if (this.shooppingView != null)
        this.shooppingView.DisposeAll();
      foreach (DropableElement element in this.elements)
        element.DisposeAll();
      this.testStack.Children.Clear();
      this.elements = (List<DropableElement>) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toyshop/views/toyshopview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.UserControl_MouseLeave);
          break;
        case 2:
          this.mainGrid = (Grid) target;
          this.mainGrid.SizeChanged += new SizeChangedEventHandler(this.Grid_SizeChanged);
          break;
        case 3:
          this.viewBoxx = (Viewbox) target;
          break;
        case 4:
          this.gridinViewBox = (Grid) target;
          break;
        case 5:
          this.TopOfRoom = (System.Windows.Shapes.Rectangle) target;
          break;
        case 6:
          this.testStack = (Grid) target;
          this.testStack.MouseDown += new MouseButtonEventHandler(this.testStack_MouseDown);
          this.testStack.MouseUp += new MouseButtonEventHandler(this.testStack_MouseUp);
          this.testStack.PreviewMouseDown += new MouseButtonEventHandler(this.testStack_PreviewMouseDown);
          this.testStack.MouseMove += new MouseEventHandler(this.testStack_MouseMove);
          this.testStack.MouseLeave += new MouseEventHandler(this.testStack_MouseLeave);
          break;
        case 7:
          this.topButton = (Grid) target;
          break;
        case 8:
          this.NotificationGrid = (Grid) target;
          break;
        case 9:
          this.InfoGrid = (Grid) target;
          break;
        case 10:
          this.AdditionalLogoGrid = (Grid) target;
          break;
        case 11:
          this.shoppingItems = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
