﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.ToyShop.Views.ProductsLimitInformationView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.ToyShop.Views
{
  public partial class ProductsLimitInformationView : UserControl, IComponentConnector
  {
    private ProductsLimitView productsLimitWhithoutEmail;
    internal BigCaption bigCaption;
    internal SmallInfoText information;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public ProductsLimitInformationView(ProductsLimitView productsLimitWhithoutEmail)
    {
      this.InitializeComponent();
      this.productsLimitWhithoutEmail = productsLimitWhithoutEmail;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterEmailWarn");
      this.information.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("ifBuyProductSetEmail");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.CloseButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("setEmail");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.Confirm_clickEvent);
    }

    private void Confirm_clickEvent() => this.productsLimitWhithoutEmail.ShowSetEmailPanel();

    private void CloseButton_clickEvent() => this.productsLimitWhithoutEmail.CloseButton_clickEvent();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toyshop/views/productslimitinformationview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.information = (SmallInfoText) target;
          break;
        case 3:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
