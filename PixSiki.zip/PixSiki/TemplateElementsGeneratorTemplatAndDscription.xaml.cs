﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TemplateElementsGenerator.TemplatAndDscription
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Views.CodeElements;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.TemplateElementsGenerator
{
  public partial class TemplatAndDscription : UserControl, IUCWithICodeElement, IComponentConnector
  {
    private UserControl template;
    private string UniqueID;
    private bool showDescription;
    private bool isPythonCode;
    private bool isPythonVisible = true;
    internal Grid mainGrid;
    internal Grid gridInside;
    internal Rectangle rectangle;
    internal WrapPanel TemplateElement;
    internal TextBlock PythonDescription;
    internal TextBlock description;
    private bool _contentLoaded;

    public TemplatAndDscription(UserControl template)
    {
      this.InitializeComponent();
      this.PythonDescription.Visibility = Visibility.Collapsed;
      this.template = template;
      this.TemplateElement.Children.Add((UIElement) template);
      this.UniqueID = (template as IUCWithICodeElement).GetCodeElement().GetUniqueName();
      UserMenager.languageKeyChangedEvet += new UserMenager.LanguageKeyChangedEvet(this.UserMenager_languageKeyChangedEvet);
      this.description.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateTemplatesID(this.UniqueID);
      this.ShowDescription(false);
    }

    private void UserMenager_languageKeyChangedEvet() => this.description.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateTemplatesID(this.UniqueID);

    public ICodeElement GetCodeElement() => (this.template as IUCWithICodeElement).GetCodeElement();

    public void ShowDescription(bool show)
    {
      this.showDescription = show;
      if (this.isPythonCode)
        return;
      if (show)
      {
        this.mainGrid.MaxWidth = 408.0;
        this.mainGrid.MinWidth = 408.0;
        this.description.Visibility = Visibility.Visible;
        this.rectangle.Visibility = Visibility.Visible;
      }
      else
      {
        string str = this.template.ActualWidth.ToString() + "__" + (this.template as IUCWithICodeElement).GetCodeElement().GetUniqueName();
        this.description.Visibility = Visibility.Collapsed;
        this.rectangle.Visibility = Visibility.Collapsed;
        if ((this.template as IUCWithICodeElement).GetCodeElement() is Procedure)
        {
          ProceduresTypes procedureType = ((this.template as IUCWithICodeElement).GetCodeElement() as Procedure).ProcedureType;
          if (procedureType == ProceduresTypes.TurtleSee)
          {
            this.mainGrid.MaxWidth = 116.0;
            this.mainGrid.MinWidth = 116.0;
          }
          if (procedureType == ProceduresTypes.TurtleX || procedureType == ProceduresTypes.TurtleY)
          {
            this.mainGrid.MaxWidth = 86.0;
            this.mainGrid.MinWidth = 86.0;
          }
          if (procedureType == ProceduresTypes.GetR || procedureType == ProceduresTypes.GetG || procedureType == ProceduresTypes.GetB)
          {
            this.mainGrid.MaxWidth = 130.0;
            this.mainGrid.MinWidth = 130.0;
          }
          if (procedureType == ProceduresTypes.GetColorFromRGB)
          {
            this.mainGrid.MaxWidth = 352.0;
            this.mainGrid.MinWidth = 352.0;
          }
          if (procedureType == ProceduresTypes.GetPutPixel || procedureType == ProceduresTypes.GetPutImage)
          {
            this.mainGrid.MaxWidth = 212.0;
            this.mainGrid.MinWidth = 212.0;
          }
          if (procedureType == ProceduresTypes.PutRectangleInColor)
          {
            this.mainGrid.MaxWidth = 361.0;
            this.mainGrid.MinWidth = 361.0;
          }
          if (procedureType == ProceduresTypes.GetNumberOfColorsInX || procedureType == ProceduresTypes.GetNumberOfColorsInY)
          {
            this.mainGrid.MaxWidth = 235.0;
            this.mainGrid.MinWidth = 235.0;
          }
          if (procedureType != ProceduresTypes.MathDiv && procedureType != ProceduresTypes.MathMinus && (procedureType != ProceduresTypes.MathMod && procedureType != ProceduresTypes.MathMulti) && procedureType != ProceduresTypes.MathPlus)
            return;
          this.mainGrid.MaxWidth = 200.0;
          this.mainGrid.MinWidth = 200.0;
        }
        else if ((this.template as IUCWithICodeElement).GetCodeElement() is AssigmentInstruction)
        {
          AssigmentInstructionType typeOfAssigment = ((this.template as IUCWithICodeElement).GetCodeElement() as AssigmentInstruction).TypeOfAssigment;
          if (typeOfAssigment == AssigmentInstructionType.ClassicAssigmentColor || typeOfAssigment == AssigmentInstructionType.ClassicAssigmentNumber || (typeOfAssigment == AssigmentInstructionType.DrawTurtleColor || typeOfAssigment == AssigmentInstructionType.DrawTurtleImage) || typeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage2Image)
          {
            this.mainGrid.MaxWidth = 203.0;
            this.mainGrid.MinWidth = 203.0;
          }
          if (typeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage)
          {
            this.mainGrid.MaxWidth = 233.0;
            this.mainGrid.MinWidth = 233.0;
          }
          if (typeOfAssigment == AssigmentInstructionType.TurtleDown || typeOfAssigment == AssigmentInstructionType.TurtleLeft || (typeOfAssigment == AssigmentInstructionType.TurtleRight || typeOfAssigment == AssigmentInstructionType.TurtleTop))
          {
            this.mainGrid.MaxWidth = 167.0;
            this.mainGrid.MinWidth = 167.0;
          }
          if (typeOfAssigment != AssigmentInstructionType.BreakAll)
            return;
          this.mainGrid.MaxWidth = 190.0;
          this.mainGrid.MinWidth = 190.0;
        }
        else if ((this.template as IUCWithICodeElement).GetCodeElement() is Variable)
        {
          this.mainGrid.MaxWidth = 75.0;
          this.mainGrid.MinWidth = 75.0;
        }
        else if ((this.template as IUCWithICodeElement).GetCodeElement() is IfThenInstruction)
        {
          this.mainGrid.MaxWidth = 203.0;
          this.mainGrid.MinWidth = 203.0;
        }
        else if ((this.template as IUCWithICodeElement).GetCodeElement() is RepeatNTimes)
        {
          if (((this.template as IUCWithICodeElement).GetCodeElement() as RepeatNTimes).RepeatNTimesType == RepeatNTimesType.classicLoop)
          {
            this.mainGrid.MaxWidth = 173.0;
            this.mainGrid.MinWidth = 173.0;
          }
          else
          {
            this.mainGrid.MaxWidth = 288.0;
            this.mainGrid.MinWidth = 288.0;
          }
        }
        else if (this.template.ActualHeight != 0.0)
        {
          this.mainGrid.MaxWidth = this.template.ActualWidth;
          this.mainGrid.MinWidth = this.template.ActualWidth;
        }
        else
        {
          this.template.UpdateLayout();
          this.UpdateLayout();
          this.template.Margin = new Thickness(1.0);
          this.template.Margin = new Thickness(0.0);
          this.mainGrid.Visibility = Visibility.Collapsed;
          this.mainGrid.Visibility = Visibility.Visible;
          if (this.template.ActualHeight == 0.0)
            return;
          this.mainGrid.MaxWidth = this.template.ActualWidth;
          this.mainGrid.MinWidth = this.template.ActualWidth;
        }
      }
    }

    internal void IsPythonCode(bool isPythonCode, Question question)
    {
      this.isPythonCode = isPythonCode;
      if (isPythonCode)
      {
        ICodeElement codeElement = (this.template as IUCWithICodeElement).GetCodeElement();
        if (codeElement is Variable && (codeElement as Variable).VariableType == VariableType.constant && (codeElement as Variable).GetRetunType() == PixBlocks.DataModels.Code.ValueType.Number)
        {
          this.isPythonVisible = false;
          this.TemplateElement.Visibility = Visibility.Collapsed;
          this.Visibility = Visibility.Collapsed;
          this.PythonDescription.Visibility = Visibility.Collapsed;
          this.TemplateElement.Visibility = Visibility.Collapsed;
          this.description.Visibility = Visibility.Collapsed;
          this.rectangle.Visibility = Visibility.Collapsed;
        }
        else
        {
          this.isPythonVisible = true;
          this.mainGrid.MaxWidth = 408.0;
          this.mainGrid.MinWidth = 408.0;
          this.PythonDescription.Text = (this.template as IUCWithICodeElement).GetCodeElement().GetPythonCode("").Replace("\r\n", "");
          this.PythonDescription.Visibility = Visibility.Visible;
          this.TemplateElement.Visibility = Visibility.Collapsed;
          this.description.Visibility = Visibility.Visible;
          this.rectangle.Visibility = Visibility.Visible;
        }
      }
      else
      {
        this.isPythonVisible = true;
        this.PythonDescription.Visibility = Visibility.Collapsed;
        this.TemplateElement.Visibility = Visibility.Visible;
        this.ShowDescription(this.showDescription);
      }
    }

    public void DisposeAll()
    {
      UserMenager.languageKeyChangedEvet -= new UserMenager.LanguageKeyChangedEvet(this.UserMenager_languageKeyChangedEvet);
      (this.template as IUCWithICodeElement).DisposeAll();
      this.mainGrid.Children.Clear();
      this.template = (UserControl) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/templateelementsgenerator/templatanddscription.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.gridInside = (Grid) target;
          break;
        case 3:
          this.rectangle = (Rectangle) target;
          break;
        case 4:
          this.TemplateElement = (WrapPanel) target;
          break;
        case 5:
          this.PythonDescription = (TextBlock) target;
          break;
        case 6:
          this.description = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
