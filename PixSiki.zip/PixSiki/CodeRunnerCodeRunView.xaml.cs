﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.CodeRunner.CodeRunView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.CodeRunner.CodeRunnerViewElements.Images;
using PixBlocks.CodeRunner.CodeRunnerViewElements.SliderView;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Questions;
using PixBlocks.Tools.TurtleMoveStatic;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;

namespace PixBlocks.CodeRunner
{
  public partial class CodeRunView : System.Windows.Controls.UserControl, IComponentConnector
  {
    private PixBlocks.CodeRunner.CodeRunner codeRunner;
    private PixBlocks.CodeRunner.CodeRunner codePatter;
    private Question question;
    private long gameIterationCouter;
    private Timer timer;
    private FastSlider slider;
    private long maxNumberOfIteration;
    private bool isPatternStarted;
    private PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus statusPattern;
    private FastIcon fastIconMy;
    private FastIcon fastIconPattern;
    private long maxTime = 10000000;
    private long minTime = 100;
    private CircleButton OneStepMy;
    private CircleButton FastMy;
    private CircleButton RunFullMy;
    private CircleButton FastPattern;
    private CircleButton RunFullPattern;
    private CircleButton StopButton;
    private DispatcherTimer dispatcherTimer;
    private PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status;
    internal StackPanel IconsStackPanel;
    internal Grid GameIcon;
    private bool _contentLoaded;

    public CodeRunView(PixBlocks.CodeRunner.CodeRunner codeRunner, PixBlocks.CodeRunner.CodeRunner codePatter, Question question)
    {
      this.question = question;
      this.InitializeComponent();
      this.codeRunner = codeRunner;
      this.codeRunner.RootElement.iteratorChangedEvent += new RepeatNTimes.IteratorChanged(this.RootElement_iteratorChangedEvent);
      if (question == null || !question.IsGame)
        this.GameIcon.Visibility = Visibility.Collapsed;
      this.codePatter = codePatter;
      codeRunner.codeeRunnerStatusChangedEvent += new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodeRunner_codeeRunnerStatusChangedEvent);
      codeRunner.ResetRunning();
      if (codePatter != null)
      {
        codePatter.codeeRunnerStatusChangedEvent += new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodePatter_codeeRunnerStatusChangedEvent);
        codePatter.ResetRunning();
      }
      this.OneStepMy = new CircleButton((System.Windows.Controls.UserControl) new OneStepIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.big);
      this.OneStepMy.buttonClickedEvent += new CircleButton.ButtonClicker(this.OneStepMy_buttonClickedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.OneStepMy);
      this.fastIconMy = new FastIcon();
      this.FastMy = new CircleButton((System.Windows.Controls.UserControl) this.fastIconMy, Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.big);
      this.FastMy.buttonClickedEvent += new CircleButton.ButtonClicker(this.FastMy_buttonClickedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.FastMy);
      this.RunFullMy = new CircleButton((System.Windows.Controls.UserControl) new RunFullFastIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.big);
      this.RunFullMy.buttonClickedEvent += new CircleButton.ButtonClicker(this.RunFullMy_buttonClickedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.RunFullMy);
      this.fastIconPattern = new FastIcon();
      this.FastPattern = new CircleButton((System.Windows.Controls.UserControl) this.fastIconPattern, Color.FromRgb((byte) 150, (byte) 50, byte.MaxValue), CircleButton.VisualParam.big);
      if (question != null && question.IsGame)
      {
        this.OneStepMy.MaxWidth = 0.0;
        this.RunFullMy.MaxWidth = 0.0;
        this.OneStepMy.MinWidth = 0.0;
        this.RunFullMy.MinWidth = 0.0;
      }
      this.FastPattern.buttonClickedEvent += new CircleButton.ButtonClicker(this.FastPattern_buttonClickedEvent);
      this.RunFullPattern = new CircleButton((System.Windows.Controls.UserControl) new RunPatternIcon(), Color.FromRgb((byte) 0, (byte) 190, (byte) 0), CircleButton.VisualParam.big);
      this.IconsStackPanel.Children.Add((UIElement) this.RunFullPattern);
      this.RunFullPattern.buttonClickedEvent += new CircleButton.ButtonClicker(this.RunFullPattern_buttonClickedEvent);
      this.StopButton = new CircleButton((System.Windows.Controls.UserControl) new StopIcon(), Color.FromRgb((byte) 120, (byte) 120, (byte) 155), CircleButton.VisualParam.big);
      this.StopButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.StopButton_buttonClickedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.StopButton);
      this.slider = new FastSlider(true);
      this.slider.valueChangedEvent += new FastSlider.SliderValueChanged(this.Slider_valueChangedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.slider);
      this.StopButton.SetIsEnabled(false);
      if (codePatter == null)
      {
        this.FastPattern.Visibility = Visibility.Collapsed;
        this.RunFullPattern.Visibility = Visibility.Collapsed;
      }
      this.dispatcherTimer = new DispatcherTimer();
      this.dispatcherTimer.Tick += new EventHandler(this.DispatcherTimer_Tick);
      this.timer = new Timer();
      this.Slider_valueChangedEvent(FastSlider.prevVal);
      this.maxNumberOfIteration = (long) (codeRunner.CodeInOut.Image.GetWidth() * codeRunner.CodeInOut.Image.GetHeight() * 100);
      if (question != null)
      {
        int questionType = (int) question.QuestionType;
      }
      this.gameIterationCouter = 0L;
      TurtleMoveStaticManager.pressedIterationCounter = 0L;
    }

    private void RootElement_iteratorChangedEvent()
    {
      if (this.question == null || !this.question.IsGame)
        return;
      if (TurtleMoveStaticManager.pressedIterationCounter == this.gameIterationCouter - 1L && !TurtleMoveStaticManager.KeyIsPressed)
      {
        TurtleMoveStaticManager.DeltaX = 0;
        TurtleMoveStaticManager.DeltaY = 0;
      }
      this.codeRunner.CodeInOut.TurtleX += TurtleMoveStaticManager.DeltaX;
      this.codeRunner.CodeInOut.TurtleY += TurtleMoveStaticManager.DeltaY;
      if (TurtleMoveStaticManager.KeyIsPressed)
        TurtleMoveStaticManager.pressedIterationCounter = this.gameIterationCouter;
      ++this.gameIterationCouter;
      if (TurtleMoveStaticManager.KeyIsPressed)
        return;
      TurtleMoveStaticManager.DeltaX = 0;
      TurtleMoveStaticManager.DeltaY = 0;
    }

    private void RunFullPattern_buttonClickedEvent()
    {
      this.isPatternStarted = true;
      this.gameIterationCouter = 0L;
      TurtleMoveStaticManager.pressedIterationCounter = 0L;
      if (this.dispatcherTimer != null)
        this.dispatcherTimer.Stop();
      this.codeRunner.ResetRunning();
      this.FastMy.SetIsEnabled(false);
      this.RunFullMy.SetIsEnabled(false);
      this.OneStepMy.SetIsEnabled(false);
      this.StopButton.SetIsEnabled(true);
      if (this.statusPattern != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
      {
        if (this.dispatcherTimer != null)
        {
          for (int index = 0; index < int.MaxValue; ++index)
          {
            this.codePatter.RunNextInstruction();
            if (this.statusPattern != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
              break;
          }
        }
      }
      else
        this.codePatter.SendEndedEvent();
      if (this.statusPattern == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
        return;
      this.OneStepMy.SetIsEnabled(true);
      this.FastMy.SetIsEnabled(true);
      this.RunFullMy.SetIsEnabled(true);
      this.FastPattern.SetIsEnabled(false);
      this.RunFullPattern.SetIsEnabled(false);
      this.StopButton.SetIsEnabled(true);
    }

    private void FastPattern_buttonClickedEvent()
    {
      if (this.statusPattern == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
        this.codePatter.ResetRunning();
      this.isPatternStarted = true;
      if (this.dispatcherTimer != null)
        this.dispatcherTimer.Start();
      this.OneStepMy.SetIsEnabled(false);
      this.RunFullMy.SetIsEnabled(false);
      this.FastMy.SetIsEnabled(false);
      this.StopButton.SetIsEnabled(true);
    }

    private void CodePatter_codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status)
    {
      this.statusPattern = status;
      if (this.statusPattern == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
      {
        this.OneStepMy.SetIsEnabled(true);
        this.FastMy.SetIsEnabled(true);
        this.RunFullMy.SetIsEnabled(true);
        this.FastPattern.SetIsEnabled(false);
        this.RunFullPattern.SetIsEnabled(false);
        this.StopButton.SetIsEnabled(true);
        if (this.dispatcherTimer != null)
          this.dispatcherTimer.Stop();
      }
      if (this.statusPattern == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
      {
        this.FastMy.SetIsEnabled(false);
        this.RunFullMy.SetIsEnabled(false);
        this.OneStepMy.SetIsEnabled(false);
      }
      if (this.statusPattern != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped)
        return;
      if (this.OneStepMy != null)
      {
        this.OneStepMy.SetIsEnabled(true);
        this.FastMy.SetIsEnabled(true);
        this.RunFullMy.SetIsEnabled(true);
        this.FastPattern.SetIsEnabled(true);
        this.RunFullPattern.SetIsEnabled(true);
        this.StopButton.SetIsEnabled(false);
      }
      if (this.dispatcherTimer == null)
        return;
      this.dispatcherTimer.Stop();
    }

    private void Slider_valueChangedEvent(double value)
    {
      this.dispatcherTimer.Interval = new TimeSpan((long) ((double) this.maxTime * ((1.0 - value) * (1.0 - value) * Math.Sqrt(1.0 - value)) + (double) this.minTime));
      this.fastIconMy.ScaleImage(value);
      this.fastIconPattern.ScaleImage(value);
    }

    private void FastMy_buttonClickedEvent()
    {
      this.isPatternStarted = false;
      if (this.status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped && this.question != null && this.question.IsGame)
      {
        this.codeRunner.CodeInOut.TurtleX = 1;
        this.codeRunner.CodeInOut.TurtleY = 1;
      }
      if (this.status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
        this.codeRunner.ResetRunning();
      if (this.dispatcherTimer != null)
        this.dispatcherTimer.Start();
      this.FastPattern.SetIsEnabled(false);
      this.FastMy.SetIsEnabled(false);
      this.RunFullPattern.SetIsEnabled(true);
      this.StopButton.SetIsEnabled(true);
    }

    internal void DisposeAllElements()
    {
      this.dispatcherTimer.Stop();
      if (this.codeRunner != null)
      {
        this.codeRunner.RootElement.iteratorChangedEvent -= new RepeatNTimes.IteratorChanged(this.RootElement_iteratorChangedEvent);
        this.codeRunner.codeeRunnerStatusChangedEvent -= new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodeRunner_codeeRunnerStatusChangedEvent);
      }
      if (this.codePatter != null)
        this.codePatter.codeeRunnerStatusChangedEvent -= new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodePatter_codeeRunnerStatusChangedEvent);
      this.OneStepMy.buttonClickedEvent -= new CircleButton.ButtonClicker(this.OneStepMy_buttonClickedEvent);
      this.FastMy.buttonClickedEvent -= new CircleButton.ButtonClicker(this.FastMy_buttonClickedEvent);
      this.RunFullMy.buttonClickedEvent -= new CircleButton.ButtonClicker(this.RunFullMy_buttonClickedEvent);
      this.FastPattern.buttonClickedEvent -= new CircleButton.ButtonClicker(this.FastPattern_buttonClickedEvent);
      this.RunFullPattern.buttonClickedEvent -= new CircleButton.ButtonClicker(this.RunFullPattern_buttonClickedEvent);
      this.StopButton.buttonClickedEvent -= new CircleButton.ButtonClicker(this.StopButton_buttonClickedEvent);
      this.slider.valueChangedEvent -= new FastSlider.SliderValueChanged(this.Slider_valueChangedEvent);
      this.dispatcherTimer.Tick -= new EventHandler(this.DispatcherTimer_Tick);
      this.codeRunner = (PixBlocks.CodeRunner.CodeRunner) null;
      this.codePatter = (PixBlocks.CodeRunner.CodeRunner) null;
      this.question = (Question) null;
    }

    private void RunFullMy_buttonClickedEvent()
    {
      this.isPatternStarted = false;
      if (this.status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
        this.codeRunner.ResetRunning();
      this.FastPattern.SetIsEnabled(false);
      this.RunFullPattern.SetIsEnabled(false);
      this.StopButton.SetIsEnabled(true);
      if (this.dispatcherTimer != null)
      {
        DateTime now = DateTime.Now;
        long ticks = now.Ticks;
        for (int index1 = 0; index1 < int.MaxValue; ++index1)
        {
          for (int index2 = 0; index2 < 100; ++index2)
          {
            this.codeRunner.RunNextInstruction();
            if (this.status != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
              break;
          }
          if (this.status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
          {
            now = DateTime.Now;
            if (now.Ticks - ticks > 20000000L)
              break;
          }
          else
            break;
        }
      }
      if (this.status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
        return;
      this.OneStepMy.SetIsEnabled(false);
      this.FastMy.SetIsEnabled(false);
      this.RunFullMy.SetIsEnabled(false);
      this.FastPattern.SetIsEnabled(true);
      this.RunFullPattern.SetIsEnabled(true);
    }

    private void StopButton_buttonClickedEvent()
    {
      this.gameIterationCouter = 0L;
      TurtleMoveStaticManager.pressedIterationCounter = 0L;
      this.isPatternStarted = false;
      if (this.dispatcherTimer != null)
        this.dispatcherTimer.Stop();
      this.codeRunner.ResetRunning();
      if (this.codePatter != null)
        this.codePatter.SendResetEvent();
      this.OneStepMy.SetIsEnabled(true);
      this.FastMy.SetIsEnabled(true);
      this.RunFullMy.SetIsEnabled(true);
      this.FastPattern.SetIsEnabled(true);
      this.RunFullPattern.SetIsEnabled(true);
    }

    internal void ActForNumberOfCodeLines(int numberOfCodeLines)
    {
      if (numberOfCodeLines == 0)
      {
        this.OneStepMy.Visibility = Visibility.Collapsed;
        this.FastMy.Visibility = Visibility.Collapsed;
        this.RunFullMy.Visibility = Visibility.Collapsed;
        this.slider.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.OneStepMy.Visibility = Visibility.Visible;
        this.FastMy.Visibility = Visibility.Visible;
        this.RunFullMy.Visibility = Visibility.Visible;
        this.slider.Visibility = Visibility.Visible;
      }
    }

    private void OneStepMy_buttonClickedEvent()
    {
      this.isPatternStarted = false;
      if (this.status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
        this.codeRunner.ResetRunning();
      if (this.dispatcherTimer != null)
        this.dispatcherTimer.Stop();
      this.codeRunner.RunNextInstruction();
      this.FastMy.SetIsEnabled(true);
      this.FastPattern.SetIsEnabled(false);
      this.RunFullPattern.SetIsEnabled(true);
      this.StopButton.SetIsEnabled(true);
      if (this.status != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
        return;
      this.FastMy.SetIsEnabled(false);
    }

    private void DispatcherTimer_Tick(object sender, EventArgs e)
    {
      if (this.isPatternStarted)
        this.codePatter.RunNextInstruction();
      else
        this.codeRunner.RunNextInstruction();
    }

    public event CodeRunView.SolutionsMatchingResult solutionMatchResultEvent;

    private void CheckIfSolutionsAreMatch()
    {
      this.codePatter.InvokeEvents = false;
      if (this.statusPattern != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
      {
        for (int index = 0; (long) index < this.maxNumberOfIteration; ++index)
        {
          this.codePatter.RunNextInstruction();
          if (this.codePatter.CurrentInstruction == null)
            break;
        }
      }
      if (this.solutionMatchResultEvent != null)
        this.solutionMatchResultEvent(new CodeRunningResult(this.codeRunner, this.codePatter));
      this.codePatter.InvokeEvents = true;
    }

    private void CodeRunner_codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status)
    {
      this.isPatternStarted = false;
      this.status = status;
      if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
      {
        this.OneStepMy.SetIsEnabled(false);
        this.FastMy.SetIsEnabled(false);
        this.RunFullMy.SetIsEnabled(false);
        this.FastPattern.SetIsEnabled(true);
        this.RunFullPattern.SetIsEnabled(true);
        this.StopButton.SetIsEnabled(true);
        if (this.dispatcherTimer != null)
          this.dispatcherTimer.Stop();
        if (this.codePatter != null)
          this.CheckIfSolutionsAreMatch();
      }
      if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
      {
        this.FastPattern.SetIsEnabled(true);
        this.RunFullPattern.SetIsEnabled(true);
      }
      if (status != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped)
        return;
      if (this.OneStepMy != null)
      {
        this.RunFullMy.SetIsEnabled(true);
        this.FastPattern.SetIsEnabled(true);
        this.RunFullPattern.SetIsEnabled(true);
        this.FastPattern.SetIsEnabled(true);
        this.RunFullPattern.SetIsEnabled(true);
        this.StopButton.SetIsEnabled(false);
      }
      if (this.dispatcherTimer == null)
        return;
      this.dispatcherTimer.Stop();
    }

    internal void ProgramaticlyClickStopButton() => this.StopButton.ProgramaticlyClick();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      System.Windows.Application.LoadComponent((object) this, new Uri("/PixBlocks;component/coderunner/coderunview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.GameIcon = (Grid) target;
        else
          this._contentLoaded = true;
      }
      else
        this.IconsStackPanel = (StackPanel) target;
    }

    public delegate void SolutionsMatchingResult(CodeRunningResult matchStatus);
  }
}
