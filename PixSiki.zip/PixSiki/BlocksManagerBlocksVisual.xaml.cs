﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.BlocksManager.BlocksVisual
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.CodeInputOutput;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.BlocksManager
{
  public partial class BlocksVisual : UserControl, IComponentConnector
  {
    private Grid[,] grids;
    private IOImage image;
    internal Grid backGrid;
    internal Grid mainGrid;
    private bool _contentLoaded;

    public BlocksVisual(PixBlocks.CodeRunner.CodeRunner runner)
    {
      this.InitializeComponent();
      this.image = runner.CodeInOut.Image;
      runner.codeeRunnerStatusChangedEvent += new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.Runner_codeeRunnerStatusChangedEvent);
      this.Width = (double) this.image.GetWidth();
      this.Height = (double) this.image.GetHeight();
      this.grids = new Grid[this.image.GetWidth(), this.image.GetHeight()];
      this.image.rectModificationEvent += new IOImage.RectWasModified(this.Image_rectModificationEvent);
      this.image.imageLoaded += new IOImage.ImageLoadedFromFile(this.RefreshImage);
      this.image.InvokeEvents = false;
      double num = 0.015 * ((double) Math.Max(this.image.GetWidth(), this.image.GetHeight()) / 20.0);
      for (int x = 0; x < this.image.GetWidth(); ++x)
      {
        for (int y = 0; y < this.image.GetHeight(); ++y)
        {
          Grid grid = new Grid();
          grid.Width = 1.0 + 2.0 * num;
          grid.Height = 1.0 + 2.0 * num;
          grid.VerticalAlignment = VerticalAlignment.Bottom;
          grid.HorizontalAlignment = HorizontalAlignment.Left;
          grid.Margin = new Thickness((double) x - num, 0.0, 0.0, (double) y - num);
          this.grids[x, y] = grid;
          this.mainGrid.Children.Add((UIElement) grid);
          this.RefreshAtPoint(x, y);
        }
      }
      this.image.InvokeEvents = true;
    }

    private void Runner_codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status)
    {
      if (status != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped)
        return;
      this.RefreshImage();
    }

    public void RefreshImage()
    {
      this.image.InvokeEvents = false;
      if (this.image.GetWidth() != this.grids.GetLength(0) || this.image.GetHeight() != this.grids.GetLength(1))
      {
        Grid[,] grids = this.grids;
        int upperBound1 = grids.GetUpperBound(0);
        int upperBound2 = grids.GetUpperBound(1);
        for (int lowerBound1 = grids.GetLowerBound(0); lowerBound1 <= upperBound1; ++lowerBound1)
        {
          for (int lowerBound2 = grids.GetLowerBound(1); lowerBound2 <= upperBound2; ++lowerBound2)
            grids[lowerBound1, lowerBound2]?.Children.Clear();
        }
        this.grids = new Grid[this.image.GetWidth(), this.image.GetHeight()];
        this.Width = (double) this.image.GetWidth();
        this.Height = (double) this.image.GetHeight();
        this.mainGrid.Children.Clear();
        double num = 0.015 * ((double) Math.Max(this.image.GetWidth(), this.image.GetHeight()) / 20.0);
        for (int index1 = 0; index1 < this.image.GetWidth(); ++index1)
        {
          for (int index2 = 0; index2 < this.image.GetHeight(); ++index2)
          {
            Grid grid = new Grid();
            grid.Width = 1.0 + 2.0 * num;
            grid.Height = 1.0 + 2.0 * num;
            grid.VerticalAlignment = VerticalAlignment.Bottom;
            grid.HorizontalAlignment = HorizontalAlignment.Left;
            grid.Margin = new Thickness((double) index1 - num, 0.0, 0.0, (double) index2 - num);
            this.grids[index1, index2] = grid;
            this.mainGrid.Children.Add((UIElement) grid);
          }
        }
      }
      for (int x = 0; x < this.image.GetWidth(); ++x)
      {
        for (int y = 0; y < this.image.GetHeight(); ++y)
          this.RefreshAtPoint(x, y);
      }
      this.image.InvokeEvents = true;
    }

    private void RefreshAtPoint(int x, int y)
    {
      this.grids[x, y].Children.Clear();
      this.image.InvokeEvents = false;
      Value pixelColor = this.image.GetPixelColor(x + 1, y + 1);
      this.image.InvokeEvents = true;
      UserControl ucOfBlock = PixBlocks.BlocksManager.BlocksManager.GetUCOfBlock(PixBlocks.BlocksManager.BlocksManager.NameFromColor(pixelColor));
      this.grids[x, y].Children.Add((UIElement) ucOfBlock);
    }

    private void Image_rectModificationEvent(IOImage.ModificationRectangle modRect)
    {
      if (!modRect.IsWriting)
        return;
      this.RefreshAtPoint(modRect.XLeft, modRect.YBotton);
    }

    public void SetTransparency(bool transparent)
    {
      if (transparent)
      {
        this.Opacity = 0.22;
        this.backGrid.Opacity = 0.0;
      }
      else
      {
        this.Opacity = 1.0;
        this.backGrid.Opacity = 1.0;
      }
    }

    internal void DisposeAll()
    {
      Grid[,] grids = this.grids;
      int upperBound1 = grids.GetUpperBound(0);
      int upperBound2 = grids.GetUpperBound(1);
      for (int lowerBound1 = grids.GetLowerBound(0); lowerBound1 <= upperBound1; ++lowerBound1)
      {
        for (int lowerBound2 = grids.GetLowerBound(1); lowerBound2 <= upperBound2; ++lowerBound2)
          grids[lowerBound1, lowerBound2]?.Children.Clear();
      }
      this.grids = (Grid[,]) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/blocksmanager/blocksvisual.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.mainGrid = (Grid) target;
        else
          this._contentLoaded = true;
      }
      else
        this.backGrid = (Grid) target;
    }
  }
}
