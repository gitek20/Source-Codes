﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.MainWindow
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using Microsoft.Win32;
using PixBlocks.CodeRunner;
using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.CodeRunner.CodeRunnerViewElements.Images;
using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.DataModels.Questions;
using PixBlocks.PythonCode.Views;
using PixBlocks.PythonIron.Tools;
using PixBlocks.PythonIron.Views;
using PixBlocks.Server.DataModels.DataModels.DBModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.Woocommerce;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TemplateElementsGenerator;
using PixBlocks.Tools.CodeParser;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.LoginPanel;
using PixBlocks.TopPanel.PreferencesPanel;
using PixBlocks.TopPanel.PreferencesPanel.Views;
using PixBlocks.TopPanel.TeacherPanel;
using PixBlocks.ToyShop.Views;
using PixBlocks.ToyShop.Views.HelpInfo;
using PixBlocks.UserMenagment.StaticEditedCodeMenager;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.UserMenagment.ToyShopMenager;
using PixBlocks.UserMenagment.UserProfileSaverAndLoader;
using PixBlocks.Views.AdditionalBrandingView;
using PixBlocks.Views.CodeElements;
using PixBlocks.Views.CodeElements.BlockOfCode;
using PixBlocks.Views.CongratulationsView;
using PixBlocks.Views.DragDropController;
using PixBlocks.Views.GameControllerView;
using PixBlocks.Views.HelpView;
using PixBlocks.Views.ImageProcessingView;
using PixBlocks.Views.QuestionsView;
using PixBlocks.Views.QuestionsView.CategoryViewer;
using PixBlocks.Views.QuestionsView.SelectionComboBox;
using PixBlocks.Views.StaticVariables;
using PixBlocks.Views.ViewTools;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PixBlocks
{
  public partial class MainWindow : Window, IComponentConnector
  {
    private bool showMouseHighLight;
    private int bringToFrontCounter;
    private DispatcherTimer bringToFronTimer = new DispatcherTimer();
    private MainPreferencePanel mainPreferences;
    private MainLoginPanel mainLoginPanel;
    private SimpleComboBoxItem.ActionType actionType;
    private MainTeacherPanel mainTeacherPanel;
    private CircleButton zoomInButton;
    private CircleButton zoomOutButton;
    private QuestionTopView questionTopView;
    private ToyShopView toyShop;
    private CategoriesHelpView categoriesHelpView = new CategoriesHelpView();
    private bool minimaliseQuestionView = true;
    private int QuestionColumWidth = 250;
    private int CategoriesColumWidth = 600;
    private int QuestionColumSize = 250;
    private DispatcherTimer dispatcherMouseHighlight = new DispatcherTimer();
    private DispatcherTimer dispatcherMinimalise = new DispatcherTimer();
    private MainWindowHelpView helpView;
    private PixBlocks.Views.CongratulationsView.CongratulationsView congratulationsView = new PixBlocks.Views.CongratulationsView.CongratulationsView();
    private QuestionVerticalView questionVerticalV;
    private PixBlocks.CodeRunner.CodeRunner codeRunner;
    private PixBlocks.CodeRunner.CodeRunner codeRunnerPattern;
    private ImageProcView imageProcess;
    private DroppingGridView droppingGridView;
    private StaticVariablesView staticVariablesView;
    private TemplatesView templatesViewField;
    private QuestionCategory CurrentCategory;
    private Question currentQuestion;
    private PythonCodeRunner pythonCodeRunner;
    private CodeView ironPythonCodeView;
    private RightPanel ironPythonRightPanel;
    private MeassageBoxAnswer meassageBoxAnswer = new MeassageBoxAnswer();
    private TextEditor pythonEditor;
    private double sizeMultiplication = 1.5;
    private bool firstTimeClosing = true;
    private double sizeMultiplication2 = 1.0;
    private GameController gameController;
    private bool stateCahngedActive = true;
    internal Grid topGrid;
    internal Grid mainGrid;
    internal Grid questionView;
    internal ColumnDefinition QuestionsColumn;
    internal Grid questionVerticalView;
    internal Grid codeGrid;
    internal ColumnDefinition templatesColumnDeinition;
    internal Grid TemplatesGrid;
    internal Grid StaticVariablesGrid;
    internal ColumnDefinition leftColumn;
    internal ColumnDefinition rightColumn;
    internal Grid droppingGrid;
    internal Grid rightColumnInside;
    internal RowDefinition DebugVievRow;
    internal Grid imageDebug;
    internal Grid DebugView;
    internal Button button;
    internal Button button4;
    internal Button button5;
    internal Button buttonNewSizle;
    internal CheckBox checkBox;
    internal Button button6;
    internal Grid hiddenGrid;
    internal Grid ToysShopGrid;
    internal StackPanel zoomIcons;
    internal Grid lockGrid;
    internal Grid preferencePanel;
    internal Ellipse mouseHighLight;
    internal Grid shadowBack;
    internal Grid extendedComboBoxGrid;
    internal ExtendedComboBox extendedComboBox;
    private bool _contentLoaded;

    public MainWindow()
    {
      this.InitializeComponent();
      MainWindowStaticController.mainWindow = this;
      CustomMessageBox.StartWatching(this.mainGrid);
      if (!this.showMouseHighLight)
        this.mouseHighLight.Visibility = Visibility.Collapsed;
      this.gameController = new GameController(this);
      this.Topmost = false;
      this.hiddenGrid.Children.Add((UIElement) this.categoriesHelpView);
      this.questionVerticalV = new QuestionVerticalView();
      this.questionVerticalV.minimaliseButtonEventClicked += new QuestionVerticalView.MinimaliseButtonClicked(this.QuestionVerticalV_minimaliseButtonEventClicked);
      this.questionVerticalV.CategoriesViewer.questioinSelectedEvent += new CategoriesListView.QuestionSelected(this.CategoriesViewer_questioinSelectedEvent);
      this.questionVerticalView.Children.Add((UIElement) this.questionVerticalV);
      this.questionVerticalV.categoryWasSelectedEvent += new QuestionVerticalView.CategoryWasSelected(this.Qv_categoryWasSelectedEvent);
      this.questionTopView = new QuestionTopView(this.questionVerticalV);
      this.questionTopView.navigationButtonEvent += new QuestionTopView.NavigationButtonPressed(this.QuestionTopView_closingButtonEvent);
      this.questionView.Children.Add((UIElement) this.questionTopView);
      this.questionTopView.categoryWasSelectedEvent += new QuestionTopView.CategoryWasSelected(this.QuestionTopView_categoryWasSelectedEvent);
      this.questionTopView.questionWasSelectedEvent += new QuestionTopView.QuestionSelected(this.QuestionTopView_questionWasSelectedEvent);
      this.questionTopView.CategoryTopViewer.InfoButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.InfoButton_buttonClickedEvent);
      if (!UserMenager.UserIsSuperAdmin())
      {
        this.questionVerticalV.SelectCategory(this.questionVerticalV.MainCategory);
        if (!(UserMenager.GetCurrentUserName() == "Ajstkbajsts"))
        {
          this.DebugView.Visibility = Visibility.Collapsed;
          this.DebugVievRow.MaxHeight = 0.0;
        }
      }
      else
      {
        this.hiddenGrid.Visibility = Visibility.Hidden;
        this.templatesColumnDeinition.MaxWidth = 620.0;
        this.templatesColumnDeinition.MinWidth = 620.0;
        this.templatesColumnDeinition.Width = new GridLength(620.0);
      }
      this.zoomInButton = new CircleButton((UserControl) new PlusZoom(), System.Windows.Media.Color.FromRgb((byte) 40, (byte) 120, (byte) 245), CircleButton.VisualParam.circle);
      this.zoomOutButton = new CircleButton((UserControl) new minusZoom(), System.Windows.Media.Color.FromRgb((byte) 40, (byte) 120, (byte) 245), CircleButton.VisualParam.circle);
      this.zoomIcons.Children.Add((UIElement) this.zoomOutButton);
      this.zoomIcons.Children.Add((UIElement) this.zoomInButton);
      this.zoomInButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.ZoomInButton_buttonClickedEvent);
      this.zoomOutButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.ZoomOutButton_buttonClickedEvent);
      this.mainGrid.Children.Add((UIElement) this.gameController);
      this.gameController.SetCodeRunner(this.codeRunner);
      this.gameController.Visibility = Visibility.Collapsed;
      this.mainGrid.Children.Add((UIElement) DragElementView.Instance);
      CongratulationsStaticManager.congratilationViewStatusChangedEvent += new CongratulationsStaticManager.CongratilationViewStatusChanged(this.CongratulationsStaticManager_congratilationViewStatusChangedEvent);
      this.helpView = new MainWindowHelpView(this);
      this.mainGrid.Children.Add((UIElement) this.helpView);
      this.helpView.HideHelpView();
      this.dispatcherMinimalise.Interval = new TimeSpan(0, 0, 0, 0, 10);
      this.dispatcherMinimalise.Tick += new EventHandler(this.DispatcherMinimalise_Tick);
      DragElementView.Instance.dragChangedEvent += new DragElementView.DragingChanged(this.Instance_dragChangedEvent);
      this.StaticVariablesGrid.Visibility = Visibility.Hidden;
      this.extendedComboBox.selectedItemeEvent += new SimpleComboBoxItem.SelectedItem(this.SelectionComboBox_selectedItemeEvent);
      MainLoginPanel mainLoginPanel = new MainLoginPanel();
      this.preferencePanel.Children.Clear();
      this.preferencePanel.Children.Add((UIElement) mainLoginPanel);
      this.questionTopView.CategoryTopViewer.Visibility = Visibility.Collapsed;
      mainLoginPanel.loginSucesfullEvent += new MainLoginPanel.LoginSucessfull(this.MainLoginPanel_loginSucesfullEvent);
      this.extendedComboBox.Visibility = Visibility.Collapsed;
      this.questionTopView.ShowNavigatonsButtons(false);
      this.extendedComboBox.Margin = new Thickness(0.0, 8.0, 20.0, 0.0);
      this.extendedComboBox.comboBoxClickedEvent += new ExtendedComboBox.ComboBoxClicked(this.ExtendedComboBox_comboBoxClickedEvent);
      GlobalProgressBarManager.SetMainGrid(this.mainGrid);
      this.WindowState = WindowState.Maximized;
      this.Window_StateChanged((object) null, (EventArgs) null);
      this.questionVerticalV.backButtonClickedEvent += new QuestionVerticalView.BackButtonClicked(this.QuestionVerticalV_backButtonClickedEvent);
      this.Topmost = true;
      this.Focus();
      this.Topmost = false;
      string[] commandLineArgs = Environment.GetCommandLineArgs();
      try
      {
        if (commandLineArgs.Length <= 1)
          return;
        if (commandLineArgs[0].Length > 0)
        {
          UserAuthorizeResult result = new ServerApi().AuthorizeUser(commandLineArgs[1], commandLineArgs[2], false, new LicenseData());
          AdditionalBrandingManager.SetNewPartnerImage(result.SchoolLogoInBase64);
          string str = result.User.Name + " " + result.User.Surname + " - " + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("teacherAccess");
          this.Title = str;
          this.ProceedLogin(result, true);
          this.QuestionTopView_closingButtonEvent(QuestionTopView.NavigationType.normalWindow);
          this.extendedComboBox.IsEnabled = false;
          this.extendedComboBox.Opacity = 0.7;
          this.extendedComboBox.UserNameLabel.Text = str;
          this.toyShop.IsEnabled = false;
          this.toyShop.Opacity = 0.7;
        }
        this.bringToFronTimer.Tick += new EventHandler(this.BringToFronTimer_Tick);
        this.bringToFronTimer.Interval = new TimeSpan(0, 0, 0, 1);
        this.bringToFronTimer.Start();
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.ToString());
      }
    }

    private void BringToFronTimer_Tick(object sender, EventArgs e)
    {
      this.Topmost = true;
      this.Focus();
      this.BringIntoView();
      this.Topmost = false;
    }

    private void QuestionVerticalV_backButtonClickedEvent() => this.questionTopView.CategoryTopViewer.GoBackButton_buttonClickedEvent();

    private void ExtendedComboBox_comboBoxClickedEvent()
    {
      if (this.imageProcess == null)
        return;
      this.imageProcess.ProgramaticlyClickStopButton();
    }

    private void ProceedLogin(UserAuthorizeResult result, bool isTeacherLogin)
    {
      CurrentUserInfo.CurrentUser = result.User;
      UserMenager.IsOffLineUser = false;
      UserMenager.IsTeacherLogin = isTeacherLogin;
      CurrentUserInfo.pixBlocksLicense = result.PixBlocksLicense;
      this.MainLoginPanel_loginSucesfullEvent();
      this.actionType = SimpleComboBoxItem.ActionType.lessonsView;
      this.RefreshSelectedComboBox();
    }

    public void LoadProfile()
    {
      ProfileSaverAndLoader.LoadProfileForCurrentUser();
      if (this.toyShop == null)
      {
        this.toyShop = new ToyShopView();
        (this.toyShop.InfoGrid.Children[0] as InfoView).logoutEvent += new Action(this.MainPreferences_LogoutEvent);
        this.ToysShopGrid.Children.Clear();
        this.ToysShopGrid.Children.Add((UIElement) this.toyShop);
      }
      else
        this.toyShop.RefreshUserInfo();
      this.extendedComboBox.UserName = UserMenager.GetCurrentUserName();
      this.extendedComboBox.RefreshItemsVisibilities();
      this.extendedComboBox.NumberOfPoints = QuestionsPointsCounter.GetPointsForCurrentUser() + StaticToyManager.ToysInfos.GetTotalMoneyInRoom() - 6;
      this.questionTopView.RefreshUserInfo();
      if (UserMenager.UserIsSuperAdmin())
      {
        if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + "\\questions_data\\main\\"))
          Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "\\questions_data\\main\\");
        QuestionCategoryLoaderAndSever.BuildCategoriesAndQuestions();
        this.DebugView.Visibility = Visibility.Visible;
        this.DebugVievRow.MaxHeight = 50.0;
        this.DebugView.Height = 50.0;
      }
      if (!UserMenager.UserIsSuperAdmin())
      {
        this.questionVerticalV.SelectCategory(this.questionVerticalV.MainCategory);
        if (!(UserMenager.GetCurrentUserName() == "Ajstkbajsts"))
        {
          this.DebugView.Visibility = Visibility.Collapsed;
          this.DebugVievRow.MaxHeight = 0.0;
        }
      }
      else
      {
        this.hiddenGrid.Visibility = Visibility.Hidden;
        this.templatesColumnDeinition.MaxWidth = 620.0;
        this.templatesColumnDeinition.MinWidth = 620.0;
        this.templatesColumnDeinition.Width = new GridLength(620.0);
      }
      if (UserMenager.UserIsSuperAdmin())
      {
        this.templatesView.SaveAllUniqueNames();
        this.CategoriesViewer_questioinSelectedEvent(QuestionCategoryLoaderAndSever.LoadQuestionFromPath("template.question"));
        this.ResetVievToAdminView((object) null, (RoutedEventArgs) null);
      }
      this.extendedComboBox.UserMenager_userDataChangedEvent();
    }

    private void RefreshSelectedComboBox()
    {
      if (this.actionType == SimpleComboBoxItem.ActionType.logout)
      {
        if (UserMenager.UserIsSuperAdmin())
          QuestionCategoryLoaderAndSever.BuildCategoriesAndQuestions();
        if (this.codeRunner != null)
          this.codeRunner.ResetRunning();
        if (this.ironPythonRightPanel != null)
          this.ironPythonRightPanel.DisposeAllElements();
        if (this.pythonEditor != null)
          this.pythonEditor.DisposeAllElements();
        if (this.droppingGridView != null)
          this.droppingGridView.DisposeAllElements();
        ProfileSaverAndLoader.SaveProfileForCurrentUser();
        if (this.mainTeacherPanel != null)
          this.mainTeacherPanel.DisposeAllElements();
        this.mainTeacherPanel = (MainTeacherPanel) null;
        this.DisposeAllElements();
        AdditionalBrandingManager.SetNewPartnerImage((string) null);
        this.mainLoginPanel = new MainLoginPanel();
        this.preferencePanel.Children.Clear();
        this.preferencePanel.Children.Add((UIElement) this.mainLoginPanel);
        this.questionTopView.CategoryTopViewer.Visibility = Visibility.Collapsed;
        this.mainLoginPanel.loginSucesfullEvent += new MainLoginPanel.LoginSucessfull(this.MainLoginPanel_loginSucesfullEvent);
        this.extendedComboBox.Visibility = Visibility.Collapsed;
      }
      if (this.actionType == SimpleComboBoxItem.ActionType.preferences)
      {
        if (this.mainPreferences == null)
        {
          this.mainPreferences = new MainPreferencePanel();
          this.mainPreferences.LogoutEvent += new RemoveAccountInfo.LogoutAction(this.MainPreferences_LogoutEvent);
        }
        this.preferencePanel.Children.Clear();
        this.preferencePanel.Children.Add((UIElement) this.mainPreferences);
        this.questionTopView.CategoryTopViewer.Visibility = Visibility.Collapsed;
      }
      if (this.actionType == SimpleComboBoxItem.ActionType.teacherPanel)
      {
        if (this.mainTeacherPanel == null)
          this.mainTeacherPanel = new MainTeacherPanel();
        this.preferencePanel.Children.Clear();
        this.preferencePanel.Children.Add((UIElement) this.mainTeacherPanel);
        this.questionTopView.CategoryTopViewer.Visibility = Visibility.Collapsed;
      }
      if (this.actionType != SimpleComboBoxItem.ActionType.lessonsView)
        return;
      this.preferencePanel.Children.Clear();
      this.questionTopView.CategoryTopViewer.Visibility = Visibility.Visible;
    }

    private TemplatesView templatesView
    {
      get
      {
        if (this.templatesViewField == null)
        {
          this.templatesViewField = new TemplatesView();
          this.TemplatesGrid.Children.Add((UIElement) this.templatesViewField);
          this.templatesViewField.maximaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.MaximaliseButton_buttonClickedEvent);
          this.templatesViewField.minimaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.QuestionVerticalV_minimaliseButtonEventClicked);
        }
        return this.templatesViewField;
      }
    }

    private void SelectionComboBox_selectedItemeEvent(SimpleComboBoxItem.ActionType actionType)
    {
      this.actionType = actionType;
      GlobalProgressBarManager.RunFuncionAndProgressBar(new Action(this.RefreshSelectedComboBox));
    }

    private void MainPreferences_LogoutEvent() => this.SelectionComboBox_selectedItemeEvent(SimpleComboBoxItem.ActionType.logout);

    private void MainLoginPanel_loginSucesfullEvent()
    {
      this.questionVerticalV.SelectCategory(this.questionVerticalV.MainCategory);
      this.questionTopView.SelectMainCategory();
      this.LoadProfile();
      this.extendedComboBox.Visibility = Visibility.Visible;
      this.extendedComboBox.SelectFirstItem();
      this.extendedComboBox.HighlightRect_MouseDown((object) null, (MouseButtonEventArgs) null);
    }

    private void MaximaliseButton_buttonClickedEvent()
    {
      this.leftColumn.Width = new GridLength(400.0, GridUnitType.Star);
      this.rightColumn.Width = new GridLength(450.0, GridUnitType.Star);
      this.minimaliseQuestionView = false;
      this.dispatcherMinimalise.Start();
    }

    private void DispatcherMouseHighlight_Tick(object sender, EventArgs e)
    {
      try
      {
        if (this.mouseHighLight != this.mainGrid.Children[this.mainGrid.Children.Count - 1])
        {
          this.mainGrid.Children.Remove((UIElement) this.mouseHighLight);
          this.mainGrid.Children.Add((UIElement) this.mouseHighLight);
        }
      }
      catch
      {
      }
      if (Mouse.LeftButton == MouseButtonState.Pressed)
        this.mouseHighLight.Opacity = 0.6;
      else
        this.mouseHighLight.Opacity = Math.Max(0.0, this.mouseHighLight.Opacity - 0.2);
    }

    private void InfoButton_buttonClickedEvent()
    {
      if (this.helpView == null)
        return;
      this.helpView.ShowDescription(this.currentQuestion, this.CurrentCategory, this.imageProcess);
      if (this.currentQuestion == null || this.currentQuestion.Description.Length <= 0)
        return;
      this.questionTopView.CategoryTopViewer.InfoButton.SetIsEnabled(false);
    }

    private void QuestionTopView_questionWasSelectedEvent(Question question)
    {
      if (this.helpView == null)
        return;
      this.helpView.ShowDescription(this.currentQuestion, this.CurrentCategory, this.imageProcess);
      if (this.currentQuestion == null || this.currentQuestion.Description.Length <= 0)
        return;
      this.questionTopView.CategoryTopViewer.InfoButton.SetIsEnabled(false);
    }

    private void Instance_dragChangedEvent() => this.Window_MouseMove((object) null, (MouseEventArgs) null);

    private void DispatcherMinimalise_Tick(object sender, EventArgs e)
    {
      if (this.minimaliseQuestionView)
      {
        this.QuestionColumSize = Math.Max(this.QuestionColumSize - 40, 0);
        this.QuestionsColumn.MinWidth = (double) this.QuestionColumSize;
        this.QuestionsColumn.MaxWidth = (double) this.QuestionColumSize;
        if (this.QuestionColumSize != 0)
          return;
        this.dispatcherMinimalise.Stop();
        this.templatesView.ShowMaximaliseButton(true);
        if (this.staticVariablesView == null)
          return;
        this.staticVariablesView.ShowMaximaliseButton(true);
      }
      else
      {
        this.templatesView.ShowMaximaliseButton(false);
        if (this.staticVariablesView != null)
          this.staticVariablesView.ShowMaximaliseButton(false);
        this.QuestionColumSize = Math.Min(this.QuestionColumSize + 50, this.QuestionColumWidth);
        this.QuestionsColumn.MinWidth = (double) this.QuestionColumSize;
        this.QuestionsColumn.MaxWidth = (double) this.QuestionColumSize;
        if (this.QuestionColumSize != this.QuestionColumWidth)
          return;
        this.dispatcherMinimalise.Stop();
      }
    }

    private void QuestionVerticalV_minimaliseButtonEventClicked()
    {
      this.leftColumn.Width = new GridLength(400.0, GridUnitType.Star);
      this.rightColumn.Width = new GridLength(450.0, GridUnitType.Star);
      this.minimaliseQuestionView = true;
      this.dispatcherMinimalise.Start();
    }

    private void QuestionTopView_closingButtonEvent(QuestionTopView.NavigationType navigationType)
    {
      if (navigationType == QuestionTopView.NavigationType.normalWindow)
        this.extendedComboBox.Margin = new Thickness(0.0, 8.0, 20.0, 0.0);
      if (navigationType == QuestionTopView.NavigationType.close)
        this.Close();
      if (navigationType == QuestionTopView.NavigationType.minimalise)
        this.WindowState = WindowState.Minimized;
      if (navigationType != QuestionTopView.NavigationType.normalWindow)
        return;
      this.Topmost = false;
      this.WindowStyle = WindowStyle.ThreeDBorderWindow;
      this.WindowState = WindowState.Normal;
      this.questionTopView.ShowNavigatonsButtons(false);
    }

    private void CongratulationsStaticManager_congratilationViewStatusChangedEvent(
      CongratulationsStaticManager.CongratulationsStatus statuc)
    {
      if (statuc == CongratulationsStaticManager.CongratulationsStatus.started)
      {
        if (this.mainGrid.Children.Contains((UIElement) this.congratulationsView))
          return;
        this.mainGrid.Children.Add((UIElement) this.congratulationsView);
      }
      else
        this.mainGrid.Children.Remove((UIElement) this.congratulationsView);
    }

    private void QuestionTopView_categoryWasSelectedEvent(QuestionCategory category)
    {
      if (this.toyShop != null)
        this.toyShop.ClearShoppingItemsGrid();
      this.minimaliseQuestionView = false;
      if (category != null && category.SubQuestionsGuids.Count == 0)
      {
        this.QuestionsColumn.MinWidth = (double) this.CategoriesColumWidth;
        this.QuestionsColumn.MaxWidth = (double) this.CategoriesColumWidth;
        this.QuestionColumSize = this.QuestionColumWidth;
      }
      else
      {
        if (category != null)
        {
          this.QuestionsColumn.MinWidth = (double) this.QuestionColumWidth;
          this.QuestionsColumn.MaxWidth = (double) this.QuestionColumWidth;
        }
        if (this.CurrentCategory != null && this.CurrentCategory.SubQuestionsGuids.Count > 0)
          this.dispatcherMinimalise.Start();
      }
      if (category == null)
        return;
      this.CurrentCategory = category;
      this.questionVerticalV.SelectCategory(category);
    }

    private void ImageProcess_solutionMatchResultEvent(CodeRunningResult matchStatus)
    {
      if (!this.currentQuestion.PtyhonCode)
        this.droppingGridView.ShowMatchStatus(matchStatus);
      else
        this.pythonEditor.ShowMatchStatus(matchStatus);
    }

    private void Qv_categoryWasSelectedEvent(QuestionCategory category)
    {
      if (!category.IsListOfAllHomeworks && !category.IsListOfExams && (!category.IsExam && !category.IsChampionship))
      {
        PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.StopWatching();
        PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.onExamChange -= new Action<int, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState>(this.Instance_examChangeEvent);
      }
      if (this.toyShop != null)
        this.toyShop.ClearShoppingItemsGrid();
      this.minimaliseQuestionView = false;
      if (category.SubQuestionsGuids.Count == 0 && !category.IsExam)
      {
        this.QuestionsColumn.MinWidth = (double) this.CategoriesColumWidth;
        this.QuestionsColumn.MaxWidth = (double) this.CategoriesColumWidth;
        this.QuestionColumSize = this.QuestionColumWidth;
      }
      else
      {
        this.QuestionsColumn.MinWidth = (double) this.QuestionColumWidth;
        this.QuestionsColumn.MaxWidth = (double) this.QuestionColumWidth;
        this.dispatcherMinimalise.Start();
      }
      this.gameController.Visibility = Visibility.Collapsed;
      this.CurrentCategory = category;
      this.hiddenGrid.Visibility = Visibility.Visible;
      this.lockGrid.Visibility = Visibility.Collapsed;
      this.droppingGrid.Children.Clear();
      this.imageDebug.Children.Clear();
      this.DisposeAllElements();
    }

    private void DisposeAllElements()
    {
      if (this.ironPythonCodeView != null)
        this.ironPythonCodeView.DisposeAllElements();
      if (this.ironPythonRightPanel != null)
        this.ironPythonRightPanel.DisposeAllElements();
      if (this.pythonCodeRunner != null)
      {
        this.pythonCodeRunner.Stop();
        this.pythonCodeRunner = (PythonCodeRunner) null;
      }
      if (this.imageProcess != null)
      {
        this.imageProcess.DisposeAllElements();
        this.imageProcess = (ImageProcView) null;
      }
      if (this.droppingGridView != null)
      {
        this.droppingGridView.numberOfCodeLinesChangedEvent -= new DroppingGridView.NumberOfCodeLinesChanged(this.DroppingGridView_numberOfCodeLinesChangedEvent);
        this.droppingGridView.makeStopByClickEvent -= new DroppingGridView.MakeStopByClick(this.DroppingGridView_makeStopByClickEvent);
        this.droppingGridView.DisposeAllElements();
        this.droppingGridView = (DroppingGridView) null;
      }
      if (this.pythonEditor != null)
      {
        this.pythonEditor.makeStopByClickEvent -= new TextEditor.MakeStopByClick(this.DroppingGridView_makeStopByClickEvent);
        this.pythonEditor.canCompileProgramEvent -= new TextEditor.CanCompileProgram(this.DroppingGridView_numberOfCodeLinesChangedEvent);
        this.pythonEditor.DisposeAllElements();
        this.pythonEditor = (TextEditor) null;
      }
      if (this.staticVariablesView != null)
      {
        this.staticVariablesView.maximaliseButton.buttonClickedEvent -= new CircleButton.ButtonClicker(this.MaximaliseButton_buttonClickedEvent);
        this.staticVariablesView.minimaliseButton.buttonClickedEvent -= new CircleButton.ButtonClicker(this.QuestionVerticalV_minimaliseButtonEventClicked);
        this.staticVariablesView.DisposeAllElements();
        this.staticVariablesView = (StaticVariablesView) null;
      }
      this.codeRunner = (PixBlocks.CodeRunner.CodeRunner) null;
      this.codeRunnerPattern = (PixBlocks.CodeRunner.CodeRunner) null;
      if (this.mainLoginPanel != null)
      {
        this.mainLoginPanel.loginSucesfullEvent -= new MainLoginPanel.LoginSucessfull(this.MainLoginPanel_loginSucesfullEvent);
        this.mainLoginPanel = (MainLoginPanel) null;
      }
      if (this.mainPreferences == null)
        return;
      this.mainPreferences.LogoutEvent -= new RemoveAccountInfo.LogoutAction(this.MainPreferences_LogoutEvent);
      this.mainPreferences = (MainPreferencePanel) null;
    }

    private void Instance_examChangeEvent(int examID, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState examState)
    {
      if (!this.currentQuestion.ExamID.HasValue || (examID != this.currentQuestion.ExamID.Value || examState != PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState.Deleted))
        return;
      PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.StopWatching();
      PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.onExamChange -= new Action<int, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState>(this.Instance_examChangeEvent);
      CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("examTimeHasEnded"));
      this.questionTopView.CategoryTopViewer.GoBackButton_buttonClickedEvent();
      this.questionTopView.CategoryTopViewer.GoBackButton_buttonClickedEvent();
    }

    private void LoadIronPython(Question question)
    {
      this.DisposeAllElements();
      this.hiddenGrid.Visibility = Visibility.Collapsed;
      this.imageDebug.Children.Clear();
      this.droppingGrid.Children.Clear();
      this.pythonCodeRunner = new PythonCodeRunner();
      if (question.QuestionType == QuestionType.InfoType)
      {
        this.pythonCodeRunner.SetCode(question.Code);
      }
      else
      {
        this.pythonCodeRunner.SetCode(QuestionsCodesManager.GetPythonCodeFormQuestion(question));
        if (question.QuestionType == QuestionType.FreeCodeType)
          this.pythonCodeRunner.SetInputText(QuestionsCodesManager.GetImageBase64FormQuestion(question));
      }
      this.ironPythonCodeView = new CodeView(this.pythonCodeRunner, question);
      this.ironPythonCodeView.minimaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.QuestionVerticalV_minimaliseButtonEventClicked);
      this.ironPythonCodeView.maximaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.MaximaliseButton_buttonClickedEvent);
      this.ironPythonCodeView.Margin = new Thickness(-(this.TemplatesGrid.ActualWidth + 8.0), 0.0, 0.0, 0.0);
      this.droppingGrid.Children.Add((UIElement) this.ironPythonCodeView);
      this.ironPythonRightPanel = new RightPanel(this.pythonCodeRunner, question);
      this.imageDebug.Children.Add((UIElement) this.ironPythonRightPanel);
      this.pythonCodeRunner.readLineEvent += new PythonCodeRunner.ReadLineDelegate(this.PythonCodeRunner_readLineEvent);
      if (question.Description == null || question.Description.Count<char>() <= 1)
        return;
      this.helpView.ShowDescription(question, this.CurrentCategory, this.imageProcess);
    }

    private string PythonCodeRunner_readLineEvent(string message)
    {
      if (!this.mainGrid.Children.Contains((UIElement) this.meassageBoxAnswer))
        this.mainGrid.Children.Add((UIElement) this.meassageBoxAnswer);
      return this.meassageBoxAnswer.ShowMessage(message, this.pythonCodeRunner);
    }

    private void CategoriesViewer_questioinSelectedEvent(Question question)
    {
      try
      {
        this.leftColumn.Width = new GridLength(400.0, GridUnitType.Star);
        this.rightColumn.Width = new GridLength(450.0, GridUnitType.Star);
        this.currentQuestion = question;
        if (question.IsExamQuestion)
        {
          if (!PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.IsStarted)
            PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.StartWatching((List<Exam>) null);
          PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.onExamChange -= new Action<int, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState>(this.Instance_examChangeEvent);
          PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.onExamChange += new Action<int, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState>(this.Instance_examChangeEvent);
        }
        else
        {
          PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.StopWatching();
          PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.onExamChange -= new Action<int, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState>(this.Instance_examChangeEvent);
        }
        if (question.IsPremiumQuestion && (!UserMenager.IsCurrentUserPremiumPython() && question.IsIronPython || !UserMenager.IsCurrentUserPremiumBlocks() && !question.IsIronPython))
          this.lockGrid.Visibility = Visibility.Visible;
        else
          this.lockGrid.Visibility = Visibility.Collapsed;
        if (question.IsIronPython)
        {
          this.LoadIronPython(question);
        }
        else
        {
          this.questionTopView.CategoryTopViewer.InfoButton.SetIsEnabled(false);
          this.templatesView.IsPythonCode(question.PtyhonCode, question);
          this.hiddenGrid.Visibility = Visibility.Collapsed;
          this.DisposeAllElements();
          RepeatNTimes repeatNtimes1 = (RepeatNTimes) null;
          RepeatNTimes root = (RepeatNTimes) null;
          string base64 = (string) null;
          RepeatNTimes repeatNtimes2;
          if (question.QuestionType == QuestionType.InfoType || UserMenager.UserIsSuperAdmin())
          {
            repeatNtimes2 = CodeStringParser.GenerateModelFromCode(question.Code);
          }
          else
          {
            repeatNtimes2 = !question.IsGame ? new RepeatNTimes(1) : new RepeatNTimes(int.MaxValue);
            if (question != null && question.QuestionType != QuestionType.InfoType)
            {
              RepeatNTimes repeatNtimes3 = (RepeatNTimes) null;
              if (!question.PtyhonCode)
                repeatNtimes3 = QuestionsCodesManager.GetCodeFormQuestion(question);
              if (repeatNtimes3 != null)
                repeatNtimes2 = repeatNtimes3;
            }
            if (question != null && question.CanEditBitmap)
              base64 = QuestionsCodesManager.GetImageBase64FormQuestion(question);
          }
          this.codeRunnerPattern = (PixBlocks.CodeRunner.CodeRunner) null;
          if (question.QuestionType == QuestionType.ClassicQuestionType)
          {
            repeatNtimes1 = CodeStringParser.GenerateModelFromCode(question.Code);
            this.codeRunnerPattern = new PixBlocks.CodeRunner.CodeRunner(new CodeInOut(), repeatNtimes1);
            this.codeRunnerPattern.codeeRunnerStatusChangedEvent += new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodeRunnerPattern_codeeRunnerStatusChangedEvent);
          }
          this.imageDebug.Children.Clear();
          this.codeRunner = new PixBlocks.CodeRunner.CodeRunner(new CodeInOut(), repeatNtimes2);
          this.staticVariablesView = new StaticVariablesView(this.codeRunner);
          this.staticVariablesView.maximaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.MaximaliseButton_buttonClickedEvent);
          this.staticVariablesView.minimaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.QuestionVerticalV_minimaliseButtonEventClicked);
          this.codeRunner.codeeRunnerStatusChangedEvent += new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodeRunner_codeeRunnerStatusChangedEvent);
          if (question.QuestionType == QuestionType.ClassicQuestionType)
            root = repeatNtimes1;
          if (question.QuestionType == QuestionType.FreeCodeType)
            root = CodeStringParser.GenerateModelFromCode(question.Code);
          if (question.QuestionType == QuestionType.InfoType)
            root = repeatNtimes2;
          this.templatesView.Visibility = Visibility.Visible;
          this.StaticVariablesGrid.Visibility = Visibility.Hidden;
          if (question != null && question.QuestionType == QuestionType.InfoType)
            this.templatesView.SetFreez(true);
          else
            this.templatesView.SetFreez(false);
          this.templatesView.SetVisibleOnlyElementsFromCode(root);
          if (question.ImageInBase64 != null)
          {
            if (this.codeRunner != null)
            {
              if (base64 != null)
                this.codeRunner.CodeInOut.Image.LoadFromBase64(base64, question.ImageWidth, question.ImageHeight);
              else
                this.codeRunner.CodeInOut.Image.LoadFromBase64(question.ImageInBase64, question.ImageWidth, question.ImageHeight);
            }
            if (this.codeRunnerPattern != null)
            {
              if (base64 != null)
                this.codeRunnerPattern.CodeInOut.Image.LoadFromBase64(base64, question.ImageWidth, question.ImageHeight);
              else
                this.codeRunnerPattern.CodeInOut.Image.LoadFromBase64(question.ImageInBase64, question.ImageWidth, question.ImageHeight);
            }
          }
          this.imageProcess = new ImageProcView(this.codeRunner, this.codeRunnerPattern, question);
          this.imageDebug.Children.Clear();
          this.imageDebug.Children.Add((UIElement) this.imageProcess);
          this.imageProcess.ZoomInButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.ZoomInButton_buttonClickedEvent);
          this.imageProcess.ZoomOutButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.ZoomOutButton_buttonClickedEvent);
          this.imageProcess.solutionMatchResultEvent += new ImageProcView.SolutionsMatchingResult(this.ImageProcess_solutionMatchResultEvent);
          if (!question.PtyhonCode)
          {
            this.droppingGridView = new DroppingGridView(repeatNtimes2, repeatNtimes1, question);
            this.droppingGrid.Children.Clear();
            this.droppingGrid.Children.Add((UIElement) this.droppingGridView);
            this.droppingGridView.numberOfCodeLinesChangedEvent += new DroppingGridView.NumberOfCodeLinesChanged(this.DroppingGridView_numberOfCodeLinesChangedEvent);
            this.droppingGridView.ShowNumberOfCodesLines();
            this.droppingGridView.makeStopByClickEvent += new DroppingGridView.MakeStopByClick(this.DroppingGridView_makeStopByClickEvent);
          }
          else
          {
            this.pythonEditor = new TextEditor(repeatNtimes2, repeatNtimes1, question);
            this.pythonEditor.makeStopByClickEvent += new TextEditor.MakeStopByClick(this.DroppingGridView_makeStopByClickEvent);
            this.pythonEditor.canCompileProgramEvent += new TextEditor.CanCompileProgram(this.DroppingGridView_numberOfCodeLinesChangedEvent);
            if (question != null && question.QuestionType != QuestionType.InfoType)
            {
              string codeFormQuestion = QuestionsCodesManager.GetPythonCodeFormQuestion(question);
              if (codeFormQuestion != null || !UserMenager.UserIsSuperAdmin())
                this.pythonEditor.SetText(codeFormQuestion);
            }
            if (question != null)
            {
              int num = question.CanEditBitmap ? 1 : 0;
            }
            this.droppingGrid.Children.Clear();
            this.droppingGrid.Children.Add((UIElement) this.pythonEditor);
          }
          if (question != null && question.QuestionType == QuestionType.InfoType)
          {
            if (!UserMenager.UserIsSuperAdmin())
            {
              if (!question.PtyhonCode)
                this.droppingGridView.SetFreez(true);
              else
                this.pythonEditor.SetFreez(true);
            }
            this.templatesView.SetFreez(true);
          }
          else
          {
            this.templatesView.SetFreez(false);
            if (!question.PtyhonCode)
              this.droppingGridView.SetFreez(false);
            else
              this.pythonEditor.SetFreez(false);
          }
          this.gameController.Visibility = Visibility.Collapsed;
          this.gameController.SetCodeRunner(this.codeRunner);
          if (this.helpView != null)
          {
            this.helpView.ShowDescription(this.currentQuestion, this.CurrentCategory, this.imageProcess);
            this.questionTopView.CategoryTopViewer.InfoButton.SetIsEnabled(false);
          }
          if (!UserMenager.UserIsSuperAdmin())
            return;
          this.ResetVievToAdminView((object) null, (RoutedEventArgs) null);
          this.checkBox.IsChecked = new bool?(this.currentQuestion.IsGame);
        }
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message + "  " + ex.StackTrace);
      }
    }

    private void DroppingGridView_makeStopByClickEvent() => this.imageProcess.ProgramaticlyClickStopButton();

    private void DroppingGridView_numberOfCodeLinesChangedEvent(int numberOfCodeLines) => this.imageProcess.ActForNumberOfCodeLines(numberOfCodeLines);

    private void CodeRunner_codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status)
    {
      if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped)
      {
        this.gameController.Visibility = Visibility.Collapsed;
        this.StaticVariablesGrid.Visibility = Visibility.Hidden;
        if (this.currentQuestion == null || this.currentQuestion.QuestionType != QuestionType.InfoType)
        {
          if (!this.currentQuestion.PtyhonCode)
          {
            if (this.droppingGridView != null)
              this.droppingGridView.SetFreez(false);
          }
          else if (this.pythonEditor != null)
            this.pythonEditor.SetFreez(false);
        }
      }
      if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
      {
        if (this.currentQuestion != null && this.currentQuestion.IsGame)
          this.gameController.Visibility = Visibility.Visible;
        this.StaticVariablesGrid.Visibility = Visibility.Visible;
        this.StaticVariablesGrid.Children.Clear();
        this.StaticVariablesGrid.Children.Add((UIElement) this.staticVariablesView);
        if (!UserMenager.UserIsSuperAdmin())
        {
          if (!this.currentQuestion.PtyhonCode)
          {
            if (this.droppingGridView != null)
              this.droppingGridView.SetFreez(true);
          }
          else if (this.pythonEditor != null)
            this.pythonEditor.SetFreez(true);
        }
      }
      if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
      {
        if (this.droppingGridView != null)
          this.droppingGridView.ClickMakeStop = true;
        if (this.pythonEditor == null)
          return;
        this.pythonEditor.ClickMakeStop = true;
      }
      else
      {
        if (this.droppingGridView != null)
          this.droppingGridView.ClickMakeStop = false;
        if (this.pythonEditor == null)
          return;
        this.pythonEditor.ClickMakeStop = false;
      }
    }

    private void Window_MouseMove(object sender, MouseEventArgs e)
    {
      Point position;
      if (this.showMouseHighLight && Mouse.LeftButton == MouseButtonState.Pressed)
      {
        Ellipse mouseHighLight = this.mouseHighLight;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double left = position.X - this.mouseHighLight.Width / 2.0;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double top = position.Y - this.mouseHighLight.Height / 2.0;
        Thickness thickness = new Thickness(left, top, -100.0, -100.0);
        mouseHighLight.Margin = thickness;
      }
      if (StaticDragController.Instance.UcToDrag == null)
      {
        DragElementView instance = DragElementView.Instance;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double left = position.X - 60.0;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double top = position.Y - 30.0;
        Thickness thickness = new Thickness(left, top, 0.0, 0.0);
        instance.Margin = thickness;
      }
      else if (StaticDragController.Instance.UcToDrag is VariableView || StaticDragController.Instance.UcToDrag is ProcedureView)
      {
        DragElementView instance = DragElementView.Instance;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double left = position.X - 40.0;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double top = position.Y - 25.0;
        Thickness thickness = new Thickness(left, top, 0.0, 0.0);
        instance.Margin = thickness;
      }
      else
      {
        DragElementView instance = DragElementView.Instance;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double left = position.X - 60.0;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double top = position.Y - 30.0;
        Thickness thickness = new Thickness(left, top, 0.0, 0.0);
        instance.Margin = thickness;
      }
    }

    private void Window_MouseUp(object sender, MouseButtonEventArgs e) => StaticDragController.Instance.StopDragging();

    private void Window_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
    }

    private void topGrid_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      this.mainGrid.Height = e.NewSize.Height * this.sizeMultiplication;
      this.mainGrid.Width = e.NewSize.Width * this.sizeMultiplication;
    }

    private void CodeRunnerPattern_codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status)
    {
      if (this.currentQuestion == null || this.currentQuestion.QuestionType != QuestionType.InfoType)
      {
        if (!this.currentQuestion.PtyhonCode)
        {
          if (this.droppingGridView != null)
            this.droppingGridView.SetFreez(false);
        }
        else if (this.pythonEditor != null)
          this.pythonEditor.SetFreez(false);
      }
      this.StaticVariablesGrid.Visibility = Visibility.Hidden;
    }

    private void ZoomOutButton_buttonClickedEvent()
    {
      this.leftColumn.Width = new GridLength(400.0, GridUnitType.Star);
      this.rightColumn.Width = new GridLength(450.0, GridUnitType.Star);
      this.sizeMultiplication = Math.Min(2.5, this.sizeMultiplication + 0.1);
      this.mainGrid.Height = this.topGrid.ActualHeight * this.sizeMultiplication * this.sizeMultiplication2;
      this.mainGrid.Width = this.topGrid.ActualWidth * this.sizeMultiplication * this.sizeMultiplication2;
    }

    private void ZoomInButton_buttonClickedEvent()
    {
      this.leftColumn.Width = new GridLength(400.0, GridUnitType.Star);
      this.rightColumn.Width = new GridLength(450.0, GridUnitType.Star);
      this.sizeMultiplication = Math.Max(1.0, this.sizeMultiplication - 0.1);
      if (this.topGrid.ActualWidth * this.sizeMultiplication * this.sizeMultiplication2 > 1900.0)
      {
        this.mainGrid.Height = this.topGrid.ActualHeight * this.sizeMultiplication * this.sizeMultiplication2;
        this.mainGrid.Width = this.topGrid.ActualWidth * this.sizeMultiplication * this.sizeMultiplication2;
      }
      else
        this.sizeMultiplication = Math.Min(2.5, this.sizeMultiplication + 0.1);
    }

    private void DropImageEvent(object sender, DragEventArgs e)
    {
      if (!e.Data.GetDataPresent(DataFormats.FileDrop))
        return;
      string[] data = (string[]) e.Data.GetData(DataFormats.FileDrop);
      if (data.Length != 1)
        return;
      this.codeRunner.CodeInOut.Image.LoadFromFile(data[0]);
      if (this.currentQuestion != null)
      {
        this.currentQuestion.ImageInBase64 = this.codeRunner.CodeInOut.Image.ConvertToBase64();
        this.currentQuestion.ImageHeight = this.codeRunner.CodeInOut.Image.GetHeight();
        this.currentQuestion.ImageWidth = this.codeRunner.CodeInOut.Image.GetWidth();
      }
      if (this.codeRunnerPattern != null)
        this.codeRunnerPattern.CodeInOut.Image.LoadFromFile(data[0]);
      if (this.currentQuestion == null)
        return;
      QuestionsCodesManager.AddEditedImageInBase64(this.currentQuestion, (string) null);
    }

    private void button4_Click(object sender, RoutedEventArgs e)
    {
      if (!this.currentQuestion.IsIronPython)
      {
        this.codeRunner.ResetRunning();
        PixBlocks.Views.QuestionsView.QuestionSaveWindow.QuestionSaveWindow questionSaveWindow = new PixBlocks.Views.QuestionsView.QuestionSaveWindow.QuestionSaveWindow(this.codeRunner, this.currentQuestion);
        questionSaveWindow.Topmost = true;
        questionSaveWindow.Show();
      }
      else
      {
        PixBlocks.Views.QuestionsView.QuestionSaveWindow.QuestionSaveWindow questionSaveWindow = new PixBlocks.Views.QuestionsView.QuestionSaveWindow.QuestionSaveWindow(this.currentQuestion, this.pythonCodeRunner.GetCode());
        questionSaveWindow.Topmost = true;
        questionSaveWindow.Show();
      }
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      if (!this.firstTimeClosing)
        return;
      this.firstTimeClosing = false;
      e.Cancel = true;
      GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
      {
        if (this.codeRunner != null)
          this.codeRunner.ResetRunning();
        if (this.codeRunner != null)
          this.codeRunner.ResetRunning();
        if (this.ironPythonRightPanel != null)
          this.ironPythonRightPanel.DisposeAllElements();
        if (this.pythonEditor != null)
          this.pythonEditor.DisposeAllElements();
        if (this.droppingGridView != null)
          this.droppingGridView.DisposeAllElements();
        if (!UserMenager.UserIsSuperAdmin())
          ProfileSaverAndLoader.SaveProfileForCurrentUser();
        if (this.mainTeacherPanel != null)
          this.mainTeacherPanel.DisposeAllElements();
        this.DisposeAllElements();
        Thread.Sleep(200);
        this.Close();
      }));
    }

    private void button5_Drop(object sender, DragEventArgs e)
    {
      if (!e.Data.GetDataPresent(DataFormats.FileDrop))
        return;
      string[] data = (string[]) e.Data.GetData(DataFormats.FileDrop);
      if (data.Length != 1)
        return;
      Question question = QuestionCategoryLoaderAndSever.LoadQuestionFromPath(data[0]);
      question.QuestionType = QuestionType.InfoType;
      this.CategoriesViewer_questioinSelectedEvent(question);
      this.templatesView.SetVisibleForAll();
      this.templatesView.ShowDescriptions(false);
      this.ResetVievToAdminView((object) null, (RoutedEventArgs) null);
      question.QuestionType = QuestionType.ClassicQuestionType;
    }

    private void ResetVievToAdminView(object sender, RoutedEventArgs e)
    {
      this.templatesView.SetVisibleForAll();
      this.templatesView.ShowDescriptions(false);
      this.templatesView.Visibility = Visibility.Visible;
      this.lockGrid.Visibility = Visibility.Collapsed;
      this.templatesView.SetFreez(false);
      if (!this.currentQuestion.PtyhonCode)
        this.droppingGridView.SetFreez(false);
      else
        this.pythonEditor.SetFreez(false);
      this.StaticVariablesGrid.Visibility = Visibility.Hidden;
    }

    private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      this.leftColumn.Width = new GridLength(400.0, GridUnitType.Star);
      this.rightColumn.Width = new GridLength(450.0, GridUnitType.Star);
      this.sizeMultiplication = Math.Min(2.5, Math.Max(1.0, 1.5 - (this.topGrid.ActualWidth - 1620.0) / 1620.0));
      this.mainGrid.Height = this.topGrid.ActualHeight * this.sizeMultiplication;
      this.mainGrid.Width = this.topGrid.ActualWidth * this.sizeMultiplication;
    }

    private void mainGrid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (!this.showMouseHighLight)
        return;
      this.mouseHighLight.Opacity = 0.6;
      this.mouseHighLight.Margin = new Thickness(Mouse.GetPosition((IInputElement) this.mainGrid).X - this.mouseHighLight.Width / 2.0, Mouse.GetPosition((IInputElement) this.mainGrid).Y - this.mouseHighLight.Height / 2.0, -100.0, -100.0);
    }

    private void mainGrid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
      this.extendedComboBox.CollapseComboBox();
      if (this.showMouseHighLight)
      {
        this.mouseHighLight.Opacity = 0.6;
        Ellipse mouseHighLight = this.mouseHighLight;
        Point position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double left = position.X - this.mouseHighLight.Width / 2.0;
        position = Mouse.GetPosition((IInputElement) this.mainGrid);
        double top = position.Y - this.mouseHighLight.Height / 2.0;
        Thickness thickness = new Thickness(left, top, -100.0, -100.0);
        mouseHighLight.Margin = thickness;
      }
      if (this.helpView.Visibility == Visibility.Collapsed)
        return;
      this.helpView.HideHelpView();
      if (this.currentQuestion != null && this.currentQuestion.Description.Length > 0)
        this.questionTopView.CategoryTopViewer.InfoButton.SetIsEnabled(true);
      else
        this.questionTopView.CategoryTopViewer.InfoButton.SetIsEnabled(false);
    }

    private void checkBox_Checked(object sender, RoutedEventArgs e)
    {
      if (this.currentQuestion == null)
        return;
      this.currentQuestion.IsGame = true;
      this.codeRunner.RootElement.NumberOfIteration = (ICodeElement) new Variable(VariableType.constant, new Value((long) int.MaxValue));
    }

    private void checkBox_Unchecked(object sender, RoutedEventArgs e)
    {
      if (this.currentQuestion == null)
        return;
      this.currentQuestion.IsGame = false;
      this.codeRunner.RootElement.NumberOfIteration = (ICodeElement) new Variable(VariableType.constant, new Value(1L));
    }

    private void Window_MouseDown(object sender, MouseButtonEventArgs e) => this.Window_MouseMove(sender, (MouseEventArgs) e);

    private void Window_Closed(object sender, EventArgs e)
    {
    }

    private void button6_Click(object sender, RoutedEventArgs e)
    {
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.Filter = "PNG(*.png)|*.png";
      SaveFileDialog saveFileDialog2 = saveFileDialog1;
      bool? nullable = saveFileDialog2.ShowDialog();
      bool flag = true;
      if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
        return;
      using (FileStream fileStream = new FileStream(saveFileDialog2.FileName, FileMode.OpenOrCreate))
      {
        PngBitmapEncoder pngBitmapEncoder = new PngBitmapEncoder();
        pngBitmapEncoder.Frames.Add(BitmapFrame.Create((BitmapSource) this.codeRunner.CodeInOut.Image.BitmapIO));
        pngBitmapEncoder.Save((Stream) fileStream);
      }
    }

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
      if (Keyboard.IsKeyDown(Key.LeftCtrl) && Keyboard.IsKeyDown(Key.LeftAlt) && (Keyboard.IsKeyDown(Key.LeftShift) && e.Key == Key.C))
      {
        this.showMouseHighLight = !this.showMouseHighLight;
        if (this.showMouseHighLight)
        {
          this.mouseHighLight.Visibility = Visibility.Visible;
          this.dispatcherMouseHighlight.Interval = new TimeSpan(0, 0, 0, 0, 100);
          this.dispatcherMouseHighlight.Tick += new EventHandler(this.DispatcherMouseHighlight_Tick);
          this.dispatcherMouseHighlight.Dispatcher.Thread.Priority = ThreadPriority.Lowest;
          this.dispatcherMouseHighlight.Start();
        }
      }
      if (!UserMenager.UserIsSuperAdmin())
        return;
      if (Keyboard.IsKeyDown(Key.LeftCtrl) && e.Key == Key.N && (this.currentQuestion != null && this.currentQuestion.UserFriendlyName != null) && this.codeRunner != null)
      {
        WriteableBitmap bitmapIo = this.codeRunner.CodeInOut.Image.BitmapIO;
        for (int x = 0; (double) x < bitmapIo.Width; ++x)
        {
          for (int y = 0; (double) y < bitmapIo.Height; ++y)
          {
            System.Windows.Media.Color pixel = bitmapIo.GetPixel(x, y);
            int num = (int) Math.Max(Math.Max(pixel.R, pixel.G), pixel.B);
            bitmapIo.SetPixel(x, y, System.Windows.Media.Color.FromRgb((byte) ((int) byte.MaxValue + (int) pixel.R - num), (byte) ((int) byte.MaxValue + (int) pixel.G - num), (byte) ((int) byte.MaxValue + (int) pixel.B - num)));
          }
        }
        this.codeRunner.CodeInOut.Image.TransformBitmapColors();
      }
      if (!Keyboard.IsKeyDown(Key.LeftCtrl) || e.Key != Key.S)
        return;
      e.Handled = true;
      if (this.currentQuestion == null || this.currentQuestion.UserFriendlyName == null)
        return;
      if (!this.currentQuestion.IsIronPython)
      {
        this.currentQuestion.Code = this.codeRunner.RootElement.GetInternalCode("");
        this.currentQuestion.ImageInBase64 = this.codeRunner.CodeInOut.Image.ConvertToBase64();
        this.currentQuestion.ImageWidth = (int) (this.codeRunner.CodeInOut.Image.BitmapIO.Width + 0.5);
        this.currentQuestion.ImageHeight = (int) (this.codeRunner.CodeInOut.Image.BitmapIO.Height + 0.5);
        QuestionCategoryLoaderAndSever.SaveQuestion(this.currentQuestion, AppDomain.CurrentDomain.BaseDirectory + this.currentQuestion.UserFriendlyName);
        CustomMessageBox.Show("zapisano bez zmiany GUID");
      }
      else
      {
        this.currentQuestion.Code = this.pythonCodeRunner.GetCode();
        this.currentQuestion.InputIronPythonCode = this.ironPythonCodeView.inputIronPythonCode.Text;
        this.currentQuestion.ImageInBase64 = (string) null;
        this.currentQuestion.ImageWidth = 0;
        this.currentQuestion.ImageHeight = 0;
        QuestionCategoryLoaderAndSever.SaveQuestion(this.currentQuestion, AppDomain.CurrentDomain.BaseDirectory + this.currentQuestion.UserFriendlyName);
        CustomMessageBox.Show("zapisano bez zmiany GUID");
      }
    }

    private void buttonNewSizle_Click(object sender, RoutedEventArgs e)
    {
      SizePicker sizePicker = new SizePicker();
      sizePicker.ShowDialog();
      if (sizePicker.NewHeight == 0)
        return;
      string base64 = new IOImage(sizePicker.NewWidth, sizePicker.NewHeight, sizePicker.fillColor).ConvertToBase64();
      this.codeRunner.CodeInOut.Image.LoadFromBase64(base64, sizePicker.NewWidth, sizePicker.NewHeight);
      if (this.currentQuestion != null)
      {
        this.currentQuestion.ImageInBase64 = base64;
        this.currentQuestion.ImageHeight = this.codeRunner.CodeInOut.Image.GetHeight();
        this.currentQuestion.ImageWidth = this.codeRunner.CodeInOut.Image.GetWidth();
      }
      if (this.codeRunnerPattern != null)
        this.codeRunnerPattern.CodeInOut.Image.LoadFromBase64(base64, sizePicker.NewWidth, sizePicker.NewHeight);
      if (this.currentQuestion == null)
        return;
      QuestionsCodesManager.AddEditedImageInBase64(this.currentQuestion, (string) null);
    }

    private void Window_StateChanged(object sender, EventArgs e)
    {
      if (!this.stateCahngedActive || this.WindowState != WindowState.Maximized)
        return;
      this.stateCahngedActive = false;
      this.questionTopView.ShowNavigatonsButtons(true);
      this.WindowStyle = WindowStyle.None;
      this.WindowState = WindowState.Normal;
      this.WindowState = WindowState.Maximized;
      this.stateCahngedActive = true;
      this.extendedComboBox.Margin = new Thickness(0.0, 8.0, 240.0, 0.0);
      this.Topmost = true;
      this.Focus();
      this.Topmost = false;
    }

    private void droppingGrid_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      if (this.leftColumn.ActualWidth < this.leftColumn.MinWidth + 5.0)
        this.leftColumn.MinWidth = this.leftColumn.MinWidth;
      if (this.rightColumn.ActualWidth >= this.rightColumn.MinWidth + 5.0)
        return;
      this.rightColumn.MinWidth = this.rightColumn.MinWidth;
    }

    private void imageDebug_SizeChanged(object sender, SizeChangedEventArgs e)
    {
    }

    private void rightColumnInside_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      if (this.leftColumn.ActualWidth < this.leftColumn.MinWidth + 5.0)
        this.leftColumn.MinWidth = this.leftColumn.MinWidth;
      if (this.rightColumn.ActualWidth >= this.rightColumn.MinWidth + 5.0)
        return;
      this.rightColumn.MinWidth = this.rightColumn.MinWidth;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/mainwindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseMove += new MouseEventHandler(this.Window_MouseMove);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.Window_MouseUp);
          ((UIElement) target).PreviewMouseUp += new MouseButtonEventHandler(this.Window_PreviewMouseUp);
          ((Window) target).Closing += new CancelEventHandler(this.Window_Closing);
          ((FrameworkElement) target).SizeChanged += new SizeChangedEventHandler(this.Window_SizeChanged);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Window_MouseDown);
          ((Window) target).Closed += new EventHandler(this.Window_Closed);
          ((UIElement) target).PreviewKeyDown += new KeyEventHandler(this.Window_PreviewKeyDown);
          ((Window) target).StateChanged += new EventHandler(this.Window_StateChanged);
          break;
        case 2:
          this.topGrid = (Grid) target;
          this.topGrid.SizeChanged += new SizeChangedEventHandler(this.topGrid_SizeChanged);
          break;
        case 3:
          this.mainGrid = (Grid) target;
          this.mainGrid.MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          this.mainGrid.PreviewMouseDown += new MouseButtonEventHandler(this.mainGrid_PreviewMouseDown);
          break;
        case 4:
          this.questionView = (Grid) target;
          break;
        case 5:
          this.QuestionsColumn = (ColumnDefinition) target;
          break;
        case 6:
          this.questionVerticalView = (Grid) target;
          break;
        case 7:
          this.codeGrid = (Grid) target;
          break;
        case 8:
          this.templatesColumnDeinition = (ColumnDefinition) target;
          break;
        case 9:
          this.TemplatesGrid = (Grid) target;
          break;
        case 10:
          this.StaticVariablesGrid = (Grid) target;
          break;
        case 11:
          this.leftColumn = (ColumnDefinition) target;
          break;
        case 12:
          this.rightColumn = (ColumnDefinition) target;
          break;
        case 13:
          this.droppingGrid = (Grid) target;
          this.droppingGrid.SizeChanged += new SizeChangedEventHandler(this.droppingGrid_SizeChanged);
          break;
        case 14:
          this.rightColumnInside = (Grid) target;
          this.rightColumnInside.SizeChanged += new SizeChangedEventHandler(this.rightColumnInside_SizeChanged);
          break;
        case 15:
          this.DebugVievRow = (RowDefinition) target;
          break;
        case 16:
          this.imageDebug = (Grid) target;
          break;
        case 17:
          this.DebugView = (Grid) target;
          break;
        case 18:
          this.button = (Button) target;
          this.button.Drop += new DragEventHandler(this.DropImageEvent);
          break;
        case 19:
          this.button4 = (Button) target;
          this.button4.Click += new RoutedEventHandler(this.button4_Click);
          break;
        case 20:
          this.button5 = (Button) target;
          this.button5.Drop += new DragEventHandler(this.button5_Drop);
          break;
        case 21:
          this.buttonNewSizle = (Button) target;
          this.buttonNewSizle.Click += new RoutedEventHandler(this.buttonNewSizle_Click);
          break;
        case 22:
          this.checkBox = (CheckBox) target;
          this.checkBox.Checked += new RoutedEventHandler(this.checkBox_Checked);
          this.checkBox.Unchecked += new RoutedEventHandler(this.checkBox_Unchecked);
          break;
        case 23:
          this.button6 = (Button) target;
          this.button6.Click += new RoutedEventHandler(this.button6_Click);
          break;
        case 24:
          this.hiddenGrid = (Grid) target;
          break;
        case 25:
          this.ToysShopGrid = (Grid) target;
          break;
        case 26:
          this.zoomIcons = (StackPanel) target;
          break;
        case 27:
          this.lockGrid = (Grid) target;
          break;
        case 28:
          this.preferencePanel = (Grid) target;
          break;
        case 29:
          this.mouseHighLight = (Ellipse) target;
          break;
        case 30:
          this.shadowBack = (Grid) target;
          break;
        case 31:
          this.extendedComboBoxGrid = (Grid) target;
          break;
        case 32:
          this.extendedComboBox = (ExtendedComboBox) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
