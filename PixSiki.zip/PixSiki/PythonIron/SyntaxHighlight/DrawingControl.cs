﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.SyntaxHighlight.DrawingControl
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.Windows;
using System.Windows.Media;

namespace PixBlocks.PythonIron.SyntaxHighlight
{
  public class DrawingControl : FrameworkElement
  {
    private VisualCollection visuals;
    private DrawingVisual visual;
    private int a;

    public DrawingControl()
    {
      this.visual = new DrawingVisual();
      this.visuals = new VisualCollection((Visual) this);
      this.visuals.Add((Visual) this.visual);
    }

    public DrawingContext GetContext() => this.visual.RenderOpen();

    protected override int VisualChildrenCount => this.visuals.Count;

    protected override Visual GetVisualChild(int index)
    {
      if (index < 0 || index >= this.visuals.Count)
        throw new ArgumentOutOfRangeException();
      return this.visuals[index];
    }
  }
}
