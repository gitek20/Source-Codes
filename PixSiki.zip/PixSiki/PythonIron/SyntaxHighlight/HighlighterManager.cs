﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.SyntaxHighlight.HighlighterManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace PixBlocks.PythonIron.SyntaxHighlight
{
  public class HighlighterManager
  {
    private static HighlighterManager instance = new HighlighterManager();

    public static HighlighterManager Instance => HighlighterManager.instance;

    public IDictionary<string, IHighlighter> Highlighters { get; private set; }

    private HighlighterManager()
    {
      this.Highlighters = (IDictionary<string, IHighlighter>) new Dictionary<string, IHighlighter>();
      XmlSchema schema = XmlSchema.Read(Application.GetResourceStream(new Uri("pack://application:,,,/PythonIron/SyntaxHighlight/resources/syntax.xsd")).Stream, (ValidationEventHandler) ((s, e) => {}));
      XmlReaderSettings settings = new XmlReaderSettings();
      settings.Schemas.Add(schema);
      settings.ValidationType = ValidationType.Schema;
      foreach (KeyValuePair<string, UnmanagedMemoryStream> resource in (IEnumerable<KeyValuePair<string, UnmanagedMemoryStream>>) this.GetResources("resources/(.+?)[.]xml"))
      {
        XDocument xdocument;
        try
        {
          xdocument = XDocument.Load(XmlReader.Create((Stream) resource.Value, settings));
        }
        catch (XmlSchemaValidationException ex)
        {
          break;
        }
        catch (Exception ex)
        {
          break;
        }
        XElement root = xdocument.Root;
        this.Highlighters.Add(root.Attribute((XName) "name").Value.Trim(), (IHighlighter) new HighlighterManager.XmlHighlighter(root));
      }
    }

    private IDictionary<string, UnmanagedMemoryStream> GetResources(
      string filter)
    {
      Assembly callingAssembly = Assembly.GetCallingAssembly();
      ResourceReader resourceReader = new ResourceReader(callingAssembly.GetManifestResourceStream(callingAssembly.GetName().Name + ".g.resources"));
      IDictionary<string, UnmanagedMemoryStream> dictionary = (IDictionary<string, UnmanagedMemoryStream>) new Dictionary<string, UnmanagedMemoryStream>();
      foreach (DictionaryEntry dictionaryEntry in resourceReader)
      {
        string key = (string) dictionaryEntry.Key;
        UnmanagedMemoryStream unmanagedMemoryStream = (UnmanagedMemoryStream) dictionaryEntry.Value;
        if (Regex.IsMatch(key, filter))
          dictionary.Add(key, unmanagedMemoryStream);
      }
      return dictionary;
    }

    private class XmlHighlighter : IHighlighter
    {
      private List<HighlighterManager.HighlightWordsRule> wordsRules;
      private List<HighlighterManager.HighlightLineRule> lineRules;
      private List<HighlighterManager.AdvancedHighlightRule> regexRules;

      public XmlHighlighter(XElement root)
      {
        this.wordsRules = new List<HighlighterManager.HighlightWordsRule>();
        this.lineRules = new List<HighlighterManager.HighlightLineRule>();
        this.regexRules = new List<HighlighterManager.AdvancedHighlightRule>();
        foreach (XElement element in root.Elements())
        {
          string str = element.Name.ToString();
          if (!(str == "HighlightWordsRule"))
          {
            if (!(str == "HighlightLineRule"))
            {
              if (str == "AdvancedHighlightRule")
                this.regexRules.Add(new HighlighterManager.AdvancedHighlightRule(element));
            }
            else
              this.lineRules.Add(new HighlighterManager.HighlightLineRule(element));
          }
          else
            this.wordsRules.Add(new HighlighterManager.HighlightWordsRule(element));
        }
      }

      public int Highlight(FormattedText text, int previousBlockCode)
      {
        foreach (Match match in new Regex("[a-zA-Z_][a-zA-Z0-9_]*").Matches(text.Text))
        {
          foreach (HighlighterManager.HighlightWordsRule wordsRule in this.wordsRules)
          {
            foreach (string word in wordsRule.Words)
            {
              if (wordsRule.Options.IgnoreCase)
              {
                if (match.Value.Equals(word, StringComparison.InvariantCultureIgnoreCase))
                {
                  text.SetForegroundBrush(wordsRule.Options.Foreground, match.Index, match.Length);
                  text.SetFontWeight(wordsRule.Options.FontWeight, match.Index, match.Length);
                  text.SetFontStyle(wordsRule.Options.FontStyle, match.Index, match.Length);
                }
              }
              else if (match.Value == word)
              {
                text.SetForegroundBrush(wordsRule.Options.Foreground, match.Index, match.Length);
                text.SetFontWeight(wordsRule.Options.FontWeight, match.Index, match.Length);
                text.SetFontStyle(wordsRule.Options.FontStyle, match.Index, match.Length);
              }
            }
          }
        }
        foreach (HighlighterManager.AdvancedHighlightRule regexRule in this.regexRules)
        {
          foreach (Match match in new Regex(regexRule.Expression).Matches(text.Text))
          {
            text.SetForegroundBrush(regexRule.Options.Foreground, match.Index, match.Length);
            text.SetFontWeight(regexRule.Options.FontWeight, match.Index, match.Length);
            text.SetFontStyle(regexRule.Options.FontStyle, match.Index, match.Length);
          }
        }
        foreach (HighlighterManager.HighlightLineRule lineRule in this.lineRules)
        {
          foreach (Match match in new Regex(Regex.Escape(lineRule.LineStart) + ".*").Matches(text.Text))
          {
            text.SetForegroundBrush(lineRule.Options.Foreground, match.Index, match.Length);
            text.SetFontWeight(lineRule.Options.FontWeight, match.Index, match.Length);
            text.SetFontStyle(lineRule.Options.FontStyle, match.Index, match.Length);
          }
        }
        return -1;
      }
    }

    private class HighlightWordsRule
    {
      public List<string> Words { get; private set; }

      public HighlighterManager.RuleOptions Options { get; private set; }

      public HighlightWordsRule(XElement rule)
      {
        this.Words = new List<string>();
        this.Options = new HighlighterManager.RuleOptions(rule);
        foreach (string str in Regex.Split(rule.Element((XName) nameof (Words)).Value, "\\s+"))
        {
          if (!string.IsNullOrWhiteSpace(str))
            this.Words.Add(str.Trim());
        }
      }
    }

    private class HighlightLineRule
    {
      public string LineStart { get; private set; }

      public HighlighterManager.RuleOptions Options { get; private set; }

      public HighlightLineRule(XElement rule)
      {
        this.LineStart = rule.Element((XName) nameof (LineStart)).Value.Trim();
        this.Options = new HighlighterManager.RuleOptions(rule);
      }
    }

    private class AdvancedHighlightRule
    {
      public string Expression { get; private set; }

      public HighlighterManager.RuleOptions Options { get; private set; }

      public AdvancedHighlightRule(XElement rule)
      {
        this.Expression = rule.Element((XName) nameof (Expression)).Value.Trim();
        this.Options = new HighlighterManager.RuleOptions(rule);
      }
    }

    private class RuleOptions
    {
      public bool IgnoreCase { get; private set; }

      public Brush Foreground { get; private set; }

      public FontWeight FontWeight { get; private set; }

      public FontStyle FontStyle { get; private set; }

      public RuleOptions(XElement rule)
      {
        string str1 = rule.Element((XName) nameof (IgnoreCase)).Value.Trim();
        string str2 = rule.Element((XName) nameof (Foreground)).Value.Trim();
        string str3 = rule.Element((XName) nameof (FontWeight)).Value.Trim();
        string str4 = rule.Element((XName) nameof (FontStyle)).Value.Trim();
        this.IgnoreCase = bool.Parse(str1);
        this.Foreground = (Brush) new BrushConverter().ConvertFrom((object) str2);
        this.FontWeight = (FontWeight) new FontWeightConverter().ConvertFrom((object) str3);
        this.FontStyle = (FontStyle) new FontStyleConverter().ConvertFrom((object) str4);
      }
    }
  }
}
