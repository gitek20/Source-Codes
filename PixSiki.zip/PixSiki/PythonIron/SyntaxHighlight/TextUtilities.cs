﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.SyntaxHighlight.TextUtilities
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;

namespace PixBlocks.PythonIron.SyntaxHighlight
{
  public class TextUtilities
  {
    public static int GetLineCount(string text)
    {
      int num = 1;
      for (int index = 0; index < text.Length; ++index)
      {
        if (text[index] == '\n')
          ++num;
      }
      return num;
    }

    public static int GetFirstCharIndexFromLineIndex(string text, int lineIndex)
    {
      if (text == null)
        throw new ArgumentNullException(nameof (text));
      if (lineIndex <= 0)
        return 0;
      int num = 0;
      for (int index = 0; index < text.Length - 1; ++index)
      {
        if (text[index] == '\n')
        {
          ++num;
          if (num == lineIndex)
            return Math.Min(index + 1, text.Length - 1);
        }
      }
      return Math.Max(text.Length - 1, 0);
    }

    public static int GetLastCharIndexFromLineIndex(string text, int lineIndex)
    {
      if (text == null)
        throw new ArgumentNullException(nameof (text));
      if (lineIndex < 0)
        return 0;
      int num = 0;
      for (int index = 0; index < text.Length - 1; ++index)
      {
        if (text[index] == '\n')
        {
          if (num == lineIndex)
            return index;
          ++num;
        }
      }
      return Math.Max(text.Length - 1, 0);
    }
  }
}
