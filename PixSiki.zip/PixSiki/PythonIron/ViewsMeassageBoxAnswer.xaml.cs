﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.MeassageBoxAnswer
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.PythonIron.Tools;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.Views.AdditionalBrandingView;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;

namespace PixBlocks.PythonIron.Views
{
  public partial class MeassageBoxAnswer : UserControl, IComponentConnector
  {
    private bool enterWasPressed;
    private DispatcherTimer dispatcherTimer;
    private EventWaitHandle eventWaitHandle = new EventWaitHandle(false, EventResetMode.ManualReset);
    internal Grid additionalLogoGrid;
    internal TextBlock textBlock;
    internal RoundedTextBox textBox;
    private bool _contentLoaded;

    public MeassageBoxAnswer()
    {
      this.InitializeComponent();
      this.additionalLogoGrid.Children.Add((UIElement) AdditionalBrandingManager.GetBranding());
      this.Visibility = Visibility.Collapsed;
      this.textBox.textBox.KeyDown += new KeyEventHandler(this.textBox_KeyDown);
      this.dispatcherTimer = new DispatcherTimer();
      this.dispatcherTimer.Tick += new EventHandler(this.DispatcherTimer_Tick);
    }

    private void DispatcherTimer_Tick(object sender, EventArgs e)
    {
      this.textBox.textBox.Focusable = true;
      this.textBox.textBox.Focus();
    }

    public string ShowMessage(string message, PythonCodeRunner pythonCodeRunner)
    {
      this.Visibility = Visibility.Visible;
      pythonCodeRunner.currentStateChangedEvent += new PythonCodeRunner.CurrentStateChanged(this.PythonCodeRunner_currentStateChangedEvent);
      this.eventWaitHandle.Reset();
      this.textBlock.Text = message;
      this.textBox.textBox.Focusable = true;
      this.textBox.textBox.Focus();
      this.textBox.textBox.SelectAll();
      this.textBox.textBox.Text = "";
      this.dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 2);
      this.dispatcherTimer.Start();
      this.WaitForEvent(this.eventWaitHandle, new TimeSpan(1, 0, 0));
      this.dispatcherTimer.Stop();
      this.Visibility = Visibility.Collapsed;
      return this.textBox.textBox.Text;
    }

    private void PythonCodeRunner_currentStateChangedEvent(PythonCodeRunner.RunnerState runnerState)
    {
      if (runnerState == PythonCodeRunner.RunnerState.running)
        return;
      this.eventWaitHandle.Set();
    }

    private bool WaitForEvent(EventWaitHandle eventHandle, TimeSpan timeout)
    {
      bool didWait = false;
      DispatcherFrame frame = new DispatcherFrame();
      new Thread((ThreadStart) (() =>
      {
        didWait = eventHandle.WaitOne(timeout);
        frame.Continue = false;
      })).Start();
      Dispatcher.PushFrame(frame);
      return didWait;
    }

    private void textBox_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key != Key.Return)
        return;
      this.eventWaitHandle.Set();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/meassageboxanswer.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.additionalLogoGrid = (Grid) target;
          break;
        case 2:
          this.textBlock = (TextBlock) target;
          break;
        case 3:
          this.textBox = (RoundedTextBox) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
