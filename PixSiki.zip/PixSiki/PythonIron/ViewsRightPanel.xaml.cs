﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.RightPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.PythonIron.Tools;
using PixBlocks.PythonIron.Tools.Game;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.UserMenagment.StaticEditedCodeMenager;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.Views.CongratulationsView;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PixBlocks.PythonIron.Views
{
  public partial class RightPanel : UserControl, IComponentConnector
  {
    private PythonCodeRunner pythonCodeRunner;
    private Question question;
    private GameUC gameView;
    private TopCodeRunner topCodRun;
    private bool firstPause = true;
    private bool isFreezGrid;
    private GameUC gamePatternUC;
    internal RowDefinition firstRow;
    internal RowDefinition secondRow;
    internal Grid topCodeRunner;
    internal Grid inputGrid;
    internal TextBox input;
    internal Grid gameUCPattern;
    internal Grid gameUC;
    internal RowDefinition thirdRow;
    internal RowDefinition fourRow;
    internal Grid ErrorPanel;
    internal Label yoursText;
    internal Label requestedValue;
    internal Label orginalText;
    internal TextBox output;
    internal TextBox variables;
    internal Grid freezGrid;
    internal TextBlock displayDisabledMessage;
    private bool _contentLoaded;

    public RightPanel(PythonCodeRunner pythonCodeRunner, Question question)
    {
      this.InitializeComponent();
      this.ErrorPanel.Visibility = Visibility.Collapsed;
      if (question.QuestionType == QuestionType.FreeCodeType)
        this.input.Text = pythonCodeRunner.InputText;
      if (question.QuestionType == QuestionType.FreeCodeType || question.CanEditBitmap || UserMenager.UserIsSuperAdmin())
        this.input.IsReadOnly = false;
      else
        this.input.IsReadOnly = true;
      if (pythonCodeRunner != null)
      {
        pythonCodeRunner.refreshOutputAndVariablesEvent += new PythonCodeRunner.RefreshOutputAndVariables(this.PythonCodeRunner_refreshOutputAndVariablesEvent);
        pythonCodeRunner.currentStateChangedEvent += new PythonCodeRunner.CurrentStateChanged(this.PythonCodePattern_currentStateChangedEvent);
        pythonCodeRunner.refreshInputViewEvent += new PythonCodeRunner.RefreshInputView(this.PythonCodeRunner_refreshInputViewEvent);
      }
      this.pythonCodeRunner = pythonCodeRunner;
      pythonCodeRunner.currentStateChangedEvent += new PythonCodeRunner.CurrentStateChanged(this.PythonCodeRunner_currentStateChangedEvent);
      this.question = question;
      this.topCodRun = new TopCodeRunner(pythonCodeRunner, question, this);
      this.topCodRun.showProperSolutionEvent += new TopCodeRunner.ShowProperSolution(this.TopCodRun_showProperSolutionEvent);
      this.topCodeRunner.Children.Add((UIElement) this.topCodRun);
      this.input.TextChanged += new TextChangedEventHandler(this.Input_TextChanged);
      this.Input_TextChanged((object) null, (TextChangedEventArgs) null);
      pythonCodeRunner.codesMatchEvent += new PythonCodeRunner.CodesMatch(this.PythonCodeRunner_codesMatchEvent);
      pythonCodeRunner.showGameScene += new PythonCodeRunner.ShowGameScene(this.PythonCodeRunner_showGameScene);
      if (question.Code.Contains("game.") || question.Code.Contains("arrow."))
        this.PythonCodeRunner_showGameScene((GameScene) null);
      this.displayDisabledMessage.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("displayDisabled");
      this.requestedValue.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (requestedValue));
    }

    private void PythonCodeRunner_showGameScene(GameScene gameScene)
    {
      this.gameUCPattern.Visibility = Visibility.Visible;
      this.gameUC.Visibility = Visibility.Visible;
      if (this.gameUC.Children.Count == 0)
        this.secondRow.Height = new GridLength(this.secondRow.MinHeight * 2.0);
      this.gameUC.Children.Clear();
      this.gameView = new GameUC(gameScene);
      if (this.GamePatternUC == null)
      {
        this.gameView.backgroundGrid.Background = (Brush) new SolidColorBrush(Colors.White);
        this.gameView.startOnWhite = true;
      }
      else
        this.gameView.startOnWhite = false;
      this.gameUC.Children.Add((UIElement) this.gameView);
    }

    private void TopCodRun_showProperSolutionEvent(string okOutput) => this.output.Text = okOutput;

    private void PythonCodeRunner_currentStateChangedEvent(PythonCodeRunner.RunnerState runnerState)
    {
      if (runnerState != PythonCodeRunner.RunnerState.finished)
        this.firstPause = true;
      this.output.SelectionBrush = (Brush) new SolidColorBrush(Color.FromRgb((byte) 45, (byte) 185, byte.MaxValue));
      if (runnerState != PythonCodeRunner.RunnerState.stopped && runnerState != PythonCodeRunner.RunnerState.errored)
        return;
      this.ErrorPanel.Visibility = Visibility.Collapsed;
    }

    public bool FreezView
    {
      set
      {
        if (value == this.isFreezGrid)
          return;
        this.isFreezGrid = value;
        if (this.isFreezGrid)
          this.freezGrid.Visibility = Visibility.Visible;
        else
          this.freezGrid.Visibility = Visibility.Collapsed;
      }
    }

    internal GameUC GamePatternUC
    {
      get => this.gamePatternUC;
      set
      {
        this.gamePatternUC = value;
        this.gamePatternUC.SetOpacity = 0.15;
        this.gameUCPattern.Children.Add((UIElement) this.gamePatternUC);
      }
    }

    public bool IsGraphicksEquals(WriteableBitmap one, WriteableBitmap second)
    {
      if (one == null || second == null)
        return false;
      byte[,] numArray = new byte[one.PixelWidth, one.PixelHeight];
      int num1 = 0;
      for (int x = 2; x < one.PixelWidth - 2; ++x)
      {
        for (int y = 2; y < one.PixelHeight - 2; ++y)
        {
          Color pixel1 = one.GetPixel(x, y);
          Color pixel2 = second.GetPixel(x, y);
          if (pixel2.R != byte.MaxValue || pixel2.G != byte.MaxValue || pixel2.B != byte.MaxValue)
            ++num1;
          if ((int) pixel1.R != (int) pixel2.R || (int) pixel1.G != (int) pixel2.G || (int) pixel1.B != (int) pixel2.B)
          {
            int num2 = Math.Max(Math.Max(Math.Abs((int) pixel1.R - (int) pixel2.R), Math.Abs((int) pixel1.G - (int) pixel2.G)), Math.Abs((int) pixel1.B - (int) pixel2.B));
            numArray[x, y] = (byte) num2;
          }
        }
      }
      bool flag = true;
      int num3 = 1;
      for (int index1 = num3; index1 < one.PixelWidth - num3; ++index1)
      {
        for (int index2 = num3; index2 < one.PixelHeight - num3; ++index2)
        {
          byte val2 = byte.MaxValue;
          for (int index3 = -num3; index3 <= num3; ++index3)
          {
            for (int index4 = -num3; index4 <= num3; ++index4)
              val2 = Math.Min(numArray[index1 + index3, index2 + index4], val2);
          }
          if (val2 > (byte) 10)
          {
            flag = false;
            break;
          }
        }
      }
      one = (WriteableBitmap) null;
      second = (WriteableBitmap) null;
      return flag;
    }

    private void PythonCodeRunner_codesMatchEvent(
      bool isMatch,
      string properOutput,
      string runnerOutput)
    {
      if (isMatch)
      {
        if (this.topCodRun.gameDescription != null && (this.topCodRun.gameDescription == null || this.gameUC.Children.Count != 1 || !this.IsGraphicksEquals((this.gameUC.Children[0] as GameUC).GetUniqueDescriptionOfAllRenderedScene(), GameUC.pattern.GetUniqueDescriptionOfAllRenderedScene())))
          return;
        this.ErrorPanel.Visibility = Visibility.Collapsed;
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) == 0)
          QuestionsPointsCounter.SetQuestionPoints(this.question, 1);
        CongratulationsStaticManager.ShowCongratulations();
      }
      else
      {
        this.output.ScrollToEnd();
        string[] array1 = ((IEnumerable<string>) properOutput.Split("\n"[0])).Select<string, string>((Func<string, string>) (a => a.TrimEnd('\r'))).ToArray<string>();
        string[] array2 = ((IEnumerable<string>) runnerOutput.Split("\n"[0])).Select<string, string>((Func<string, string>) (a => a.TrimEnd('\r'))).ToArray<string>();
        string str1 = "";
        string str2 = "";
        int num = 0;
        for (int index = 0; index < Math.Min(array1.Length, array2.Length); ++index)
        {
          num = index;
          if (array1[index] != array2[index])
          {
            str1 = array1[index];
            str2 = array2[index];
            break;
          }
        }
        if (str1 == str2)
        {
          if (array1.Length > array2.Length)
            str1 = array1[array2.Length];
          if (array1.Length < array2.Length)
          {
            ++num;
            str2 = array2[array1.Length];
          }
        }
        int start = 0;
        for (int index = 0; index < num; ++index)
          start += array2[index].Length + 2;
        if (this.firstPause)
        {
          this.topCodRun.PauseRunning();
          this.firstPause = false;
        }
        if (PythonCodeRunner.gameScene == null)
          this.output.Focus();
        this.output.SelectionBrush = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 0, (byte) 0));
        this.output.Select(start, str2.Length);
        if (PythonCodeRunner.gameScene == null)
          this.output.Focus();
        this.ErrorPanel.Visibility = Visibility.Visible;
        this.yoursText.Content = (object) str2;
        this.orginalText.Content = (object) str1;
      }
    }

    private void PythonCodeRunner_refreshInputViewEvent()
    {
      this.input.TextChanged -= new TextChangedEventHandler(this.Input_TextChanged);
      this.input.Text = this.pythonCodeRunner.InputText;
      this.input.TextChanged += new TextChangedEventHandler(this.Input_TextChanged);
    }

    private void PythonCodePattern_currentStateChangedEvent(PythonCodeRunner.RunnerState runnerState)
    {
      if (runnerState != PythonCodeRunner.RunnerState.stopped)
        return;
      this.output.Text = "";
      this.variables.Text = "";
    }

    private void PythonCodeRunner_refreshOutputAndVariablesEvent(string output, string variables)
    {
      this.output.Text = output;
      this.variables.Text = variables;
      if (PythonCodeRunner.gameScene == null)
        this.variables.Focus();
      this.output.ScrollToEnd();
    }

    private void Input_TextChanged(object sender, TextChangedEventArgs e)
    {
      if (this.pythonCodeRunner == null)
        return;
      this.pythonCodeRunner.SetInputText(this.input.Text);
    }

    internal void DisposeAllElements()
    {
      if (this.question.QuestionType == QuestionType.FreeCodeType)
        QuestionsCodesManager.AddEditedImageInBase64(this.question, this.pythonCodeRunner.InputText);
      QuestionsCodesManager.AddPythonCode(this.question, this.pythonCodeRunner.GetCode());
      this.topCodRun.StopButton_buttonClickedEvent();
      this.pythonCodeRunner.Stop();
      if (this.pythonCodeRunner != null)
      {
        this.pythonCodeRunner.refreshOutputAndVariablesEvent -= new PythonCodeRunner.RefreshOutputAndVariables(this.PythonCodeRunner_refreshOutputAndVariablesEvent);
        this.pythonCodeRunner.currentStateChangedEvent -= new PythonCodeRunner.CurrentStateChanged(this.PythonCodePattern_currentStateChangedEvent);
        this.pythonCodeRunner.refreshInputViewEvent -= new PythonCodeRunner.RefreshInputView(this.PythonCodeRunner_refreshInputViewEvent);
      }
      this.pythonCodeRunner.currentStateChangedEvent -= new PythonCodeRunner.CurrentStateChanged(this.PythonCodeRunner_currentStateChangedEvent);
      this.topCodRun.showProperSolutionEvent -= new TopCodeRunner.ShowProperSolution(this.TopCodRun_showProperSolutionEvent);
      this.input.TextChanged -= new TextChangedEventHandler(this.Input_TextChanged);
      this.pythonCodeRunner.codesMatchEvent -= new PythonCodeRunner.CodesMatch(this.PythonCodeRunner_codesMatchEvent);
      this.pythonCodeRunner.showGameScene -= new PythonCodeRunner.ShowGameScene(this.PythonCodeRunner_showGameScene);
      if (this.gamePatternUC != null)
        this.gamePatternUC.DisposeAllElements();
      PythonCodeRunner.gameScene = (GameScene) null;
      this.pythonCodeRunner = new PythonCodeRunner();
    }

    private void UserControl_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
      if (PythonCodeRunner.gameScene == null || this.gameView == null)
        return;
      Keyboard.Focus((IInputElement) this.gameView.textBox);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/rightpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).PreviewMouseDown += new MouseButtonEventHandler(this.UserControl_PreviewMouseDown);
          break;
        case 2:
          this.firstRow = (RowDefinition) target;
          break;
        case 3:
          this.secondRow = (RowDefinition) target;
          break;
        case 4:
          this.topCodeRunner = (Grid) target;
          break;
        case 5:
          this.inputGrid = (Grid) target;
          break;
        case 6:
          this.input = (TextBox) target;
          break;
        case 7:
          this.gameUCPattern = (Grid) target;
          break;
        case 8:
          this.gameUC = (Grid) target;
          break;
        case 9:
          this.thirdRow = (RowDefinition) target;
          break;
        case 10:
          this.fourRow = (RowDefinition) target;
          break;
        case 11:
          this.ErrorPanel = (Grid) target;
          break;
        case 12:
          this.yoursText = (Label) target;
          break;
        case 13:
          this.requestedValue = (Label) target;
          break;
        case 14:
          this.orginalText = (Label) target;
          break;
        case 15:
          this.output = (TextBox) target;
          break;
        case 16:
          this.variables = (TextBox) target;
          break;
        case 17:
          this.freezGrid = (Grid) target;
          break;
        case 18:
          this.displayDisabledMessage = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
