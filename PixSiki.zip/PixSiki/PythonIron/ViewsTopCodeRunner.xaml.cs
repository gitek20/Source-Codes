﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.TopCodeRunner
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.CodeRunner.CodeRunnerViewElements.Images;
using PixBlocks.CodeRunner.CodeRunnerViewElements.SliderView;
using PixBlocks.DataModels.Questions;
using PixBlocks.PythonIron.Tools;
using PixBlocks.PythonIron.Tools.Game;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;

namespace PixBlocks.PythonIron.Views
{
  public partial class TopCodeRunner : UserControl, IComponentConnector
  {
    private CircleButton OneStepMy;
    private FastIcon fastIconMy;
    private CircleButton FastMy;
    private CircleButton RunFullMy;
    private CircleButton RunFullPattern;
    private CircleButton StopButton;
    private FastSlider slider;
    private PythonCodeRunner pyhonCodeRunner;
    private Question question;
    private RightPanel rightPanel;
    private long maxTime = 10000000;
    private long minTime;
    private DispatcherTimer dispatcherTimer;
    private double sliderValue;
    private string inp = "";
    private string properOutput;
    public string gameDescription;
    private GameUC gamePatternUC;
    internal StackPanel IconsStackPanel;
    private bool _contentLoaded;

    public TopCodeRunner(
      PythonCodeRunner pyhonCodeRunner,
      Question question,
      RightPanel rightPanel)
    {
      this.rightPanel = rightPanel;
      this.rightPanel.FreezView = false;
      this.InitializeComponent();
      pyhonCodeRunner.codeWasModifyEvent += new PythonCodeRunner.CodeWasModify(this.PyhonCodeRunner_codeWasModifyEvent);
      pyhonCodeRunner.stopPressedExternal += new PythonCodeRunner.StopPressedExternal(this.PyhonCodeRunner_stopPressedExternal);
      this.pyhonCodeRunner = pyhonCodeRunner;
      this.question = question;
      this.pyhonCodeRunner.IsPaused = false;
      this.OneStepMy = new CircleButton((UserControl) new OneStepIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.big);
      this.OneStepMy.buttonClickedEvent += new CircleButton.ButtonClicker(this.OneStepMy_buttonClickedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.OneStepMy);
      this.fastIconMy = new FastIcon();
      this.FastMy = new CircleButton((UserControl) this.fastIconMy, Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.big);
      this.FastMy.buttonClickedEvent += new CircleButton.ButtonClicker(this.FastMy_buttonClickedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.FastMy);
      if (question.QuestionType == QuestionType.ClassicQuestionType)
      {
        this.RunFullPattern = new CircleButton((UserControl) new RunPatternIcon(), Color.FromRgb((byte) 0, (byte) 190, (byte) 0), CircleButton.VisualParam.big);
        this.IconsStackPanel.Children.Add((UIElement) this.RunFullPattern);
        this.RunFullPattern.buttonClickedEvent += new CircleButton.ButtonClicker(this.RunFullPattern_buttonClickedEvent);
      }
      this.StopButton = new CircleButton((UserControl) new StopIcon(), Color.FromRgb((byte) 120, (byte) 120, (byte) 155), CircleButton.VisualParam.big);
      this.StopButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.StopButton_buttonClickedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.StopButton);
      this.slider = new FastSlider(true);
      this.slider.valueChangedEvent += new FastSlider.SliderValueChanged(this.Slider_valueChangedEvent);
      this.IconsStackPanel.Children.Add((UIElement) this.slider);
      this.dispatcherTimer = new DispatcherTimer();
      this.dispatcherTimer.Tick += new EventHandler(this.DispatcherTimer_Tick);
      this.Slider_valueChangedEvent(FastSlider.prevVal);
      if (pyhonCodeRunner != null)
        pyhonCodeRunner.currentStateChangedEvent += new PythonCodeRunner.CurrentStateChanged(this.PyhonCodeRunner_currentStateChangedEvent);
      this.inp = "";
      if (pyhonCodeRunner.CurrentState != PythonCodeRunner.RunnerState.running && question.InputIronPythonCode != null && question.InputIronPythonCode.Length > 0)
      {
        this.inp = pyhonCodeRunner.RunFullCode(question.InputIronPythonCode, "");
        pyhonCodeRunner.SetInputText(this.inp);
        pyhonCodeRunner.RefreshInput();
      }
      this.SetInputAndOutput();
    }

    private void PyhonCodeRunner_stopPressedExternal() => this.StopButton_buttonClickedEvent();

    private void PyhonCodeRunner_codeWasModifyEvent()
    {
      if (!this.dispatcherTimer.IsEnabled)
        return;
      this.dispatcherTimer.Stop();
      this.pyhonCodeRunner.SetShowHighLines = true;
      this.rightPanel.FreezView = false;
      this.pyhonCodeRunner.RefreshAllVariablesAndOutput();
    }

    internal void PauseRunning()
    {
      if (!this.dispatcherTimer.IsEnabled)
        return;
      this.dispatcherTimer.Stop();
      this.pyhonCodeRunner.SetShowHighLines = true;
      this.rightPanel.FreezView = false;
      this.pyhonCodeRunner.RefreshAllVariablesAndOutput();
    }

    private void PyhonCodeRunner_currentStateChangedEvent(PythonCodeRunner.RunnerState runnerState)
    {
      if (runnerState == PythonCodeRunner.RunnerState.finished || runnerState == PythonCodeRunner.RunnerState.errored)
      {
        this.OneStepMy.SetIsEnabled(false);
        this.FastMy.SetIsEnabled(false);
        this.StopButton.SetIsEnabled(true);
        if (this.RunFullPattern != null)
          this.RunFullPattern.SetIsEnabled(true);
      }
      if (runnerState == PythonCodeRunner.RunnerState.stopped)
      {
        this.OneStepMy.SetIsEnabled(true);
        this.FastMy.SetIsEnabled(true);
        this.StopButton.SetIsEnabled(false);
        if (this.RunFullPattern != null)
          this.RunFullPattern.SetIsEnabled(true);
      }
      if (runnerState != PythonCodeRunner.RunnerState.running)
        return;
      this.OneStepMy.SetIsEnabled(true);
      this.FastMy.SetIsEnabled(true);
      this.StopButton.SetIsEnabled(true);
      if (this.RunFullPattern == null)
        return;
      this.RunFullPattern.SetIsEnabled(true);
    }

    private void DispatcherTimer_Tick(object sender, EventArgs e)
    {
      if (this.sliderValue > 0.95)
      {
        this.pyhonCodeRunner.SetShowHighLines = false;
        this.rightPanel.FreezView = true;
      }
      else
      {
        this.pyhonCodeRunner.SetShowHighLines = true;
        this.rightPanel.FreezView = false;
      }
      if (this.pyhonCodeRunner.CurrentState == PythonCodeRunner.RunnerState.stopped || this.pyhonCodeRunner.CurrentState == PythonCodeRunner.RunnerState.running)
      {
        this.pyhonCodeRunner.RunNextInstruction();
      }
      else
      {
        this.dispatcherTimer.Stop();
        this.pyhonCodeRunner.SetShowHighLines = true;
        this.rightPanel.FreezView = false;
        this.pyhonCodeRunner.RefreshAllVariablesAndOutput();
      }
      if (this.pyhonCodeRunner.CurrentState == PythonCodeRunner.RunnerState.running)
        return;
      this.dispatcherTimer.Stop();
      this.pyhonCodeRunner.SetShowHighLines = true;
      this.rightPanel.FreezView = false;
      this.pyhonCodeRunner.RefreshAllVariablesAndOutput();
    }

    private void Slider_valueChangedEvent(double value)
    {
      this.sliderValue = value;
      if (this.sliderValue < 0.95 && PythonCodeRunner.gameScene != null)
        this.rightPanel.FreezView = false;
      this.dispatcherTimer.Interval = new TimeSpan((long) ((double) this.maxTime * ((1.0 - value) * (1.0 - value) * Math.Sqrt(1.0 - value)) + (double) this.minTime));
      this.fastIconMy.ScaleImage(value);
    }

    public void StopButton_buttonClickedEvent()
    {
      if (this.rightPanel.GamePatternUC != null)
        this.rightPanel.GamePatternUC.SetOpacity = 0.15;
      this.pyhonCodeRunner.SetShowHighLines = true;
      this.rightPanel.FreezView = false;
      this.dispatcherTimer.Stop();
      this.pyhonCodeRunner.Stop();
      this.pyhonCodeRunner.IsPaused = false;
    }

    public event TopCodeRunner.ShowProperSolution showProperSolutionEvent;

    private void RunFullPattern_buttonClickedEvent()
    {
      this.pyhonCodeRunner.SetShowHighLines = true;
      this.rightPanel.FreezView = false;
      this.dispatcherTimer.Stop();
      this.pyhonCodeRunner.Stop();
      this.pyhonCodeRunner.IsPaused = false;
      this.RunFullPattern.SetIsEnabled(false);
      this.FastMy.SetIsEnabled(false);
      this.OneStepMy.SetIsEnabled(false);
      if (this.pyhonCodeRunner.CurrentState != PythonCodeRunner.RunnerState.running && this.question.QuestionType == QuestionType.ClassicQuestionType)
      {
        if (!this.question.Code.Contains("game.") && !this.question.Code.Contains("arrow."))
        {
          PythonCodeRunner pythonCodeRunner = new PythonCodeRunner();
          pythonCodeRunner.showGameScene += new PythonCodeRunner.ShowGameScene(this.PatternRunner_showGameScene);
          this.properOutput = pythonCodeRunner.RunFullCode(this.question.Code, this.inp);
          this.pyhonCodeRunner.SetProperOutput(this.properOutput);
        }
        else
          this.rightPanel.GamePatternUC.SetOpacity = 1.0;
      }
      if (this.showProperSolutionEvent != null && !this.question.Code.Contains("game.") && !this.question.Code.Contains("arrow."))
      {
        this.properOutput = this.pyhonCodeRunner.RunFullCode(this.question.Code, this.inp);
        this.pyhonCodeRunner.SetProperOutput(this.properOutput);
        this.showProperSolutionEvent(this.properOutput);
      }
      this.StopButton.SetIsEnabled(true);
      this.FastMy.SetIsEnabled(true);
      this.OneStepMy.SetIsEnabled(true);
    }

    private void FastMy_buttonClickedEvent()
    {
      if (this.rightPanel.GamePatternUC != null)
        this.rightPanel.GamePatternUC.SetOpacity = 0.15;
      this.SetInputAndOutput();
      this.pyhonCodeRunner.IsPaused = false;
      this.dispatcherTimer.Start();
    }

    public void SetInputAndOutput()
    {
      if (this.gameDescription != null)
        return;
      if (this.question.InputIronPythonCode == null || this.question.InputIronPythonCode.Length == 0)
        this.inp = "";
      if (this.pyhonCodeRunner.CurrentState != PythonCodeRunner.RunnerState.running && this.question.InputIronPythonCode != null && this.question.InputIronPythonCode.Length > 0)
      {
        this.inp = this.pyhonCodeRunner.RunFullCode(this.question.InputIronPythonCode, "");
        this.pyhonCodeRunner.SetInputText(this.inp);
        this.pyhonCodeRunner.RefreshInput();
      }
      if (this.pyhonCodeRunner.CurrentState == PythonCodeRunner.RunnerState.running || this.question.QuestionType != QuestionType.ClassicQuestionType)
        return;
      PythonCodeRunner pythonCodeRunner = new PythonCodeRunner();
      pythonCodeRunner.showGameScene += new PythonCodeRunner.ShowGameScene(this.PatternRunner_showGameScene);
      this.properOutput = pythonCodeRunner.RunFullCode(this.question.Code, this.inp);
      if (this.gamePatternUC != null)
      {
        this.gameDescription = "isOK";
        this.rightPanel.GamePatternUC = this.gamePatternUC;
      }
      this.pyhonCodeRunner.SetProperOutput(this.properOutput);
    }

    private void PatternRunner_showGameScene(GameScene gameScene)
    {
      this.gamePatternUC = new GameUC(gameScene);
      this.gamePatternUC.IsFrozen = true;
    }

    private void OneStepMy_buttonClickedEvent()
    {
      if (this.rightPanel.GamePatternUC != null)
        this.rightPanel.GamePatternUC.SetOpacity = 0.15;
      this.pyhonCodeRunner.SetShowHighLines = true;
      this.rightPanel.FreezView = false;
      this.SetInputAndOutput();
      this.dispatcherTimer.Stop();
      if (this.pyhonCodeRunner.CurrentState == PythonCodeRunner.RunnerState.finished)
        return;
      this.pyhonCodeRunner.RunNextInstruction();
      this.pyhonCodeRunner.IsPaused = true;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/topcoderunner.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.IconsStackPanel = (StackPanel) target;
      else
        this._contentLoaded = true;
    }

    public delegate void ShowProperSolution(string okOutput);
  }
}
