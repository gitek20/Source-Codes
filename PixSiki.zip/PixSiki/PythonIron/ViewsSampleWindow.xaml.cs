﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.SampleWindow
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.PythonIron.Tools;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.PythonIron.Views
{
  public partial class SampleWindow : Window, IComponentConnector
  {
    private PythonCodeRunner pythonCodeRunner;
    internal Grid left;
    internal Grid right;
    internal Grid topGrid;
    private bool _contentLoaded;

    public SampleWindow()
    {
      this.InitializeComponent();
      this.pythonCodeRunner = new PythonCodeRunner();
      this.left.Children.Add((UIElement) new CodeView(this.pythonCodeRunner, (Question) null));
      this.right.Children.Add((UIElement) new RightPanel(this.pythonCodeRunner, (Question) null));
      this.pythonCodeRunner.readLineEvent += new PythonCodeRunner.ReadLineDelegate(this.PythonCodeRunner_readLineEvent);
    }

    private string PythonCodeRunner_readLineEvent(string message)
    {
      this.topGrid.Children.Clear();
      MeassageBoxAnswer meassageBoxAnswer = new MeassageBoxAnswer();
      this.topGrid.Children.Add((UIElement) meassageBoxAnswer);
      string str = meassageBoxAnswer.ShowMessage(message, this.pythonCodeRunner);
      this.topGrid.Children.Clear();
      return str;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/samplewindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.left = (Grid) target;
          break;
        case 2:
          this.right = (Grid) target;
          break;
        case 3:
          this.topGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
