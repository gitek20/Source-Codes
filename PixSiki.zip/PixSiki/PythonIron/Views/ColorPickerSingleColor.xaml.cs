﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.ColorPicker.SingleColor
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.PythonIron.Views.ColorPicker
{
  public partial class SingleColor : UserControl, IComponentConnector
  {
    private PixBlocks.PythonIron.Tools.Integration.Color color;
    internal Rectangle coloredRectangle;
    internal Rectangle highlight;
    private bool _contentLoaded;

    public event SingleColor.ColorWasClicked colorWasClicked;

    public SingleColor(PixBlocks.PythonIron.Tools.Integration.Color color)
    {
      this.InitializeComponent();
      this.color = color;
      this.coloredRectangle.Fill = (Brush) new SolidColorBrush(System.Windows.Media.Color.FromRgb((byte) color.r, (byte) color.g, (byte) color.b));
    }

    private void Grid_MouseEnter(object sender, MouseEventArgs e) => this.highlight.Visibility = Visibility.Visible;

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.highlight.Visibility = Visibility.Collapsed;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.colorWasClicked == null)
        return;
      this.colorWasClicked(this.color);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/colorpicker/singlecolor.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 2:
          this.coloredRectangle = (Rectangle) target;
          break;
        case 3:
          this.highlight = (Rectangle) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ColorWasClicked(PixBlocks.PythonIron.Tools.Integration.Color color);
  }
}
