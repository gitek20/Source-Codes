﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.SoundsSelector.SoundSelector
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.PythonIron.Views.SoundsSelector
{
  public partial class SoundSelector : UserControl, IComponentConnector
  {
    internal TextBox result;
    internal WrapPanel wrapPanel;
    private bool _contentLoaded;

    public SoundSelector()
    {
      this.InitializeComponent();
      int num;
      for (int index = 0; index < 21; ++index)
      {
        num = index + 1;
        SoundPlayButton soundPlayButton = new SoundPlayButton("e" + num.ToString());
        soundPlayButton.soundWasClicked += new SoundPlayButton.SoundWasClicked(this.SoundPlayButton_soundWasClicked);
        this.wrapPanel.Children.Add((UIElement) soundPlayButton);
      }
      Grid grid1 = new Grid();
      grid1.Width = 550.0;
      grid1.Height = 30.0;
      this.wrapPanel.Children.Add((UIElement) grid1);
      for (int index = 0; index < 37; ++index)
      {
        num = index + 1;
        SoundPlayButton soundPlayButton = new SoundPlayButton("n" + num.ToString());
        soundPlayButton.soundWasClicked += new SoundPlayButton.SoundWasClicked(this.SoundPlayButton_soundWasClicked);
        this.wrapPanel.Children.Add((UIElement) soundPlayButton);
      }
      Grid grid2 = new Grid();
      grid2.Width = 550.0;
      grid2.Height = 30.0;
      this.wrapPanel.Children.Add((UIElement) grid2);
      for (int index = 0; index < 4; ++index)
      {
        num = index + 1;
        SoundPlayButton soundPlayButton = new SoundPlayButton("m" + num.ToString());
        soundPlayButton.soundWasClicked += new SoundPlayButton.SoundWasClicked(this.SoundPlayButton_soundWasClicked);
        this.wrapPanel.Children.Add((UIElement) soundPlayButton);
      }
      SoundPlayButton soundPlayButton1 = new SoundPlayButton("stop");
      soundPlayButton1.soundWasClicked += new SoundPlayButton.SoundWasClicked(this.SoundPlayButton_soundWasClicked);
      this.wrapPanel.Children.Add((UIElement) soundPlayButton1);
    }

    private void SoundPlayButton_soundWasClicked(string soundPath)
    {
      if (soundPath == "stop")
        this.result.Text = "sound.stop()";
      else
        this.result.Text = "sound.play('" + soundPath + "')";
    }

    private void result_MouseDown(object sender, MouseButtonEventArgs e) => this.result.SelectAll();

    private void result_TextChanged(object sender, TextChangedEventArgs e)
    {
      e.Handled = true;
      this.result.SelectAll();
    }

    private void result_PreviewKeyDown(object sender, KeyEventArgs e) => this.result.SelectAll();

    private void result_PreviewKeyUp(object sender, KeyEventArgs e) => this.result.SelectAll();

    private void result_MouseMove(object sender, MouseEventArgs e) => this.result.SelectAll();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/soundsselector/soundselector.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.wrapPanel = (WrapPanel) target;
        else
          this._contentLoaded = true;
      }
      else
      {
        this.result = (TextBox) target;
        this.result.MouseDown += new MouseButtonEventHandler(this.result_MouseDown);
        this.result.TextChanged += new TextChangedEventHandler(this.result_TextChanged);
        this.result.PreviewKeyDown += new KeyEventHandler(this.result_PreviewKeyDown);
        this.result.PreviewKeyUp += new KeyEventHandler(this.result_PreviewKeyUp);
        this.result.MouseMove += new MouseEventHandler(this.result_MouseMove);
      }
    }
  }
}
