﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.HelpView.HelpUC
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.PythonIron.Views.HelpView
{
  public partial class HelpUC : UserControl, IComponentConnector
  {
    internal ScrollViewer scrollView;
    internal StackPanel stackPanel;
    private bool _contentLoaded;

    public HelpUC()
    {
      this.InitializeComponent();
      foreach (string pythonFunction in PixBlocks.Tools.TranslationsManager.TranslationsManager.GetPythonFunctions())
      {
        List<string> stringList = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslatePythonTemplate(pythonFunction);
        this.stackPanel.Children.Add((UIElement) new SingleHelp(new OneHelp(stringList[0], stringList[1], Regex.Unescape(stringList[2]))));
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/helpview/helpuc.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.stackPanel = (StackPanel) target;
        else
          this._contentLoaded = true;
      }
      else
        this.scrollView = (ScrollViewer) target;
    }
  }
}
