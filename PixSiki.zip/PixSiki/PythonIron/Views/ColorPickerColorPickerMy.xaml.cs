﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.ColorPicker.ColorPickerMy
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements.SliderView;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.PythonIron.Views.ColorPicker
{
  public partial class ColorPickerMy : UserControl, IComponentConnector
  {
    internal FastSlider rSlider;
    internal FastSlider gSlider;
    internal FastSlider bSlider;
    internal TextBlock rTextBlock;
    internal TextBlock gTextBlock;
    internal TextBlock bTextBlock;
    internal Rectangle rect;
    internal TextBox result;
    internal Rectangle rect_CopyR;
    internal Rectangle rect_CopyG;
    internal Rectangle rect_CopyB;
    internal WrapPanel wrapPanel;
    private bool _contentLoaded;

    public ColorPickerMy()
    {
      this.InitializeComponent();
      this.rSlider.valueChangedEvent += new FastSlider.SliderValueChanged(this.RSlider_valueChangedEvent);
      this.gSlider.valueChangedEvent += new FastSlider.SliderValueChanged(this.GSlider_valueChangedEvent);
      this.bSlider.valueChangedEvent += new FastSlider.SliderValueChanged(this.BSlider_valueChangedEvent);
      this.RSlider_valueChangedEvent(0.3);
      this.GSlider_valueChangedEvent(0.3);
      this.BSlider_valueChangedEvent(0.3);
      this.result.SelectAll();
      for (int r = 0; r <= (int) byte.MaxValue; r += 51)
      {
        for (int g = 0; g <= (int) byte.MaxValue; g += 51)
        {
          for (int b = 0; b <= (int) byte.MaxValue; b += 51)
          {
            SingleColor singleColor = new SingleColor(new PixBlocks.PythonIron.Tools.Integration.Color(r, g, b));
            singleColor.colorWasClicked += new SingleColor.ColorWasClicked(this.SingleColor_colorWasClicked);
            this.wrapPanel.Children.Add((UIElement) singleColor);
          }
        }
      }
    }

    private void SingleColor_colorWasClicked(PixBlocks.PythonIron.Tools.Integration.Color color)
    {
      this.rSlider.SetVal((double) color.r / (double) byte.MaxValue);
      this.gSlider.SetVal((double) color.g / (double) byte.MaxValue);
      this.bSlider.SetVal((double) color.b / (double) byte.MaxValue);
    }

    public void RefreshTest()
    {
      this.result.Text = "Color(" + this.rTextBlock.Text + "," + this.gTextBlock.Text + "," + this.bTextBlock.Text + ")";
      this.rect.Fill = (Brush) new SolidColorBrush(System.Windows.Media.Color.FromRgb(byte.Parse(this.rTextBlock.Text), byte.Parse(this.gTextBlock.Text), byte.Parse(this.bTextBlock.Text)));
    }

    private void BSlider_valueChangedEvent(double value)
    {
      this.bTextBlock.Text = ((int) (value * (double) byte.MaxValue)).ToString() ?? "";
      this.rect_CopyB.Opacity = value;
      this.RefreshTest();
    }

    private void GSlider_valueChangedEvent(double value)
    {
      this.gTextBlock.Text = ((int) (value * (double) byte.MaxValue)).ToString() ?? "";
      this.rect_CopyG.Opacity = value;
      this.RefreshTest();
    }

    private void RSlider_valueChangedEvent(double value)
    {
      this.rTextBlock.Text = ((int) (value * (double) byte.MaxValue)).ToString() ?? "";
      this.rect_CopyR.Opacity = value;
      this.RefreshTest();
    }

    private void result_MouseDown(object sender, MouseButtonEventArgs e) => this.result.SelectAll();

    private void result_TextChanged(object sender, TextChangedEventArgs e)
    {
      this.RefreshTest();
      e.Handled = true;
      this.result.SelectAll();
    }

    private void result_PreviewKeyDown(object sender, KeyEventArgs e)
    {
      this.RefreshTest();
      this.result.SelectAll();
    }

    private void result_PreviewKeyUp(object sender, KeyEventArgs e)
    {
      this.RefreshTest();
      this.result.SelectAll();
    }

    private void result_MouseMove(object sender, MouseEventArgs e)
    {
      this.RefreshTest();
      this.result.SelectAll();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/colorpicker/colorpickermy.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.rSlider = (FastSlider) target;
          break;
        case 2:
          this.gSlider = (FastSlider) target;
          break;
        case 3:
          this.bSlider = (FastSlider) target;
          break;
        case 4:
          this.rTextBlock = (TextBlock) target;
          break;
        case 5:
          this.gTextBlock = (TextBlock) target;
          break;
        case 6:
          this.bTextBlock = (TextBlock) target;
          break;
        case 7:
          this.rect = (Rectangle) target;
          break;
        case 8:
          this.result = (TextBox) target;
          this.result.MouseDown += new MouseButtonEventHandler(this.result_MouseDown);
          this.result.TextChanged += new TextChangedEventHandler(this.result_TextChanged);
          this.result.PreviewKeyDown += new KeyEventHandler(this.result_PreviewKeyDown);
          this.result.PreviewKeyUp += new KeyEventHandler(this.result_PreviewKeyUp);
          this.result.MouseMove += new MouseEventHandler(this.result_MouseMove);
          break;
        case 9:
          this.rect_CopyR = (Rectangle) target;
          break;
        case 10:
          this.rect_CopyG = (Rectangle) target;
          break;
        case 11:
          this.rect_CopyB = (Rectangle) target;
          break;
        case 12:
          this.wrapPanel = (WrapPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
