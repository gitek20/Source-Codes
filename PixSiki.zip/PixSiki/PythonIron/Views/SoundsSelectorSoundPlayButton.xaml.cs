﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.SoundsSelector.SoundPlayButton
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.SoundPlayer.SoundPlayer.Effects;
using PixBlocks.SoundPlayer.SoundPlayer.Music;
using PixBlocks.SoundPlayer.SoundPlayer.SoundEngine;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PixBlocks.PythonIron.Views.SoundsSelector
{
  public partial class SoundPlayButton : UserControl, IComponentConnector
  {
    private string soundPath;
    internal Rectangle mainRec;
    internal TextBlock soundNam;
    internal Rectangle image;
    private bool _contentLoaded;

    public SoundPlayButton(string soundPath)
    {
      this.soundPath = soundPath;
      this.InitializeComponent();
      this.soundNam.Text = soundPath;
      if (!(soundPath == "stop"))
        return;
      this.image.Visibility = Visibility.Collapsed;
      this.soundNam.Width = 50.0;
      this.soundNam.Text = "stop";
    }

    private void Rectangle_MouseEnter(object sender, MouseEventArgs e) => this.mainRec.Stroke = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 145, byte.MaxValue));

    private void Rectangle_MouseLeave(object sender, MouseEventArgs e) => this.mainRec.Stroke = (Brush) new SolidColorBrush(Color.FromRgb((byte) 226, (byte) 226, (byte) 226));

    public event SoundPlayButton.SoundWasClicked soundWasClicked;

    private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.soundWasClicked != null)
        this.soundWasClicked(this.soundPath);
      if (this.soundPath == "stop")
      {
        Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() => AudioPlaybackEngine.Instance.Stop()));
      }
      else
      {
        if (this.soundPath.Contains("m"))
        {
          AudioPlaybackEngine.Instance.Stop();
          MusicPlayer.Instance.Play(int.Parse(this.soundPath.Replace("m", "")));
        }
        if (this.soundPath.Contains(nameof (e)))
          Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
          {
            AudioPlaybackEngine.Instance.Stop();
            EffectsPlayer.Instance.PlayEffect(int.Parse(this.soundPath.Replace(nameof (e), "")));
          }));
        if (!this.soundPath.Contains("n"))
          return;
        Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
        {
          AudioPlaybackEngine.Instance.Stop();
          EffectsPlayer.Instance.PlayNote(int.Parse(this.soundPath.Replace("n", "")));
        }));
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/soundsselector/soundplaybutton.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainRec = (Rectangle) target;
          this.mainRec.MouseEnter += new MouseEventHandler(this.Rectangle_MouseEnter);
          this.mainRec.MouseLeave += new MouseEventHandler(this.Rectangle_MouseLeave);
          this.mainRec.MouseDown += new MouseButtonEventHandler(this.Rectangle_MouseDown);
          break;
        case 2:
          this.soundNam = (TextBlock) target;
          break;
        case 3:
          this.image = (Rectangle) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void SoundWasClicked(string soundPath);
  }
}
