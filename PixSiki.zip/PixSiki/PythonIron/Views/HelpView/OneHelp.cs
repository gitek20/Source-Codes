﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.HelpView.OneHelp
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.PythonIron.Views.HelpView
{
  public class OneHelp
  {
    private string sectionName;
    private bool isSection;
    private string name;
    private string description;
    private string example;

    public OneHelp(string sectionName)
    {
      this.SectionName = sectionName;
      this.IsSection = true;
    }

    public OneHelp(string name, string description, string example)
    {
      this.Name = name;
      this.Description = description;
      this.Example = example;
    }

    public string Name
    {
      get => this.name;
      set => this.name = value;
    }

    public string Description
    {
      get => this.description;
      set => this.description = value;
    }

    public string Example
    {
      get => this.example;
      set => this.example = value;
    }

    public bool IsSection
    {
      get => this.isSection;
      set => this.isSection = value;
    }

    public string SectionName
    {
      get => this.sectionName;
      set => this.sectionName = value;
    }
  }
}
