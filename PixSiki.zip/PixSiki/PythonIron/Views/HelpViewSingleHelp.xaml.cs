﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.HelpView.SingleHelp
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.PythonIron.SyntaxHighlight;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.PythonIron.Views.HelpView
{
  public partial class SingleHelp : UserControl, IComponentConnector
  {
    internal StackPanel stackPanel;
    internal TextBlock instruction;
    internal TextBlock description;
    internal Grid syntaxGrid;
    private bool _contentLoaded;

    public SingleHelp(OneHelp oneHelp)
    {
      this.InitializeComponent();
      this.instruction.Text = oneHelp.Name.Replace("\n", "");
      this.description.Text = oneHelp.Description;
      SyntaxHighlightBox syntaxHighlightBox = new SyntaxHighlightBox();
      syntaxHighlightBox.CurrentHighlighter = HighlighterManager.Instance.Highlighters["VHDL"];
      syntaxHighlightBox.IsReadOnly = true;
      syntaxHighlightBox.FontSize = 20.0;
      syntaxHighlightBox.Background = (Brush) new SolidColorBrush(Colors.Transparent);
      this.syntaxGrid.Children.Add((UIElement) syntaxHighlightBox);
      syntaxHighlightBox.Text = oneHelp.Example + "\r\n";
      syntaxHighlightBox.IsLineNumbersMarginVisible = false;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/helpview/singlehelp.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.stackPanel = (StackPanel) target;
          break;
        case 2:
          this.instruction = (TextBlock) target;
          break;
        case 3:
          this.description = (TextBlock) target;
          break;
        case 4:
          this.syntaxGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
