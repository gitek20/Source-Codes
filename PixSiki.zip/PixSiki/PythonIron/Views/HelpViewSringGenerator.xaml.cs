﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.HelpView.SringGenerator
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.PythonIron.Views.HelpView
{
  public partial class SringGenerator : Window, IComponentConnector
  {
    internal TextBox textBox;
    internal Button transform;
    internal TextBox textBox1;
    private bool _contentLoaded;

    public SringGenerator() => this.InitializeComponent();

    private void transform_Click(object sender, RoutedEventArgs e)
    {
      string[] strArray = this.textBox.Text.Split("\r"[0]);
      strArray[0].Replace("\n", "");
      strArray[1].Replace("\n", "");
      string str = "";
      for (int index = 2; index < strArray.Length; ++index)
        str = str + strArray[index] + "\r";
      this.textBox1.Text = str.Substring(1, str.Length - 2).Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t").Replace("‘", "'").Replace("’", "'").Replace("\"", "'");
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/helpview/sringgenerator.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.textBox = (TextBox) target;
          break;
        case 2:
          this.transform = (Button) target;
          this.transform.Click += new RoutedEventHandler(this.transform_Click);
          break;
        case 3:
          this.textBox1 = (TextBox) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
