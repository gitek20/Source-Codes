﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.SyntaxHighlight.SyntaxHighlightBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.PythonIron.SyntaxHighlight
{
  public partial class SyntaxHighlightBox : TextBox, IComponentConnector
  {
    private List<char> printableChars = new List<char>();
    private DrawingControl renderCanvas;
    private DrawingControl lineNumbersCanvas;
    private ScrollViewer scrollViewer;
    private double lineHeight;
    private int totalLineCount;
    private List<SyntaxHighlightBox.InnerTextBlock> blocks;
    private double blockHeight;
    private int maxLineCountInBlock;
    private int lastHightline = -1;
    public static readonly DependencyProperty IsLineNumbersMarginVisibleProperty = DependencyProperty.Register(nameof (IsLineNumbersMarginVisible), typeof (bool), typeof (SyntaxHighlightBox), new PropertyMetadata((object) true));
    private bool _contentLoaded;

    public double LineHeight
    {
      get => this.lineHeight;
      set
      {
        if (value == this.lineHeight)
          return;
        this.lineHeight = value;
        this.blockHeight = (double) this.MaxLineCountInBlock * value;
        TextBlock.SetLineStackingStrategy((DependencyObject) this, LineStackingStrategy.BlockLineHeight);
        TextBlock.SetLineHeight((DependencyObject) this, this.lineHeight);
      }
    }

    public int MaxLineCountInBlock
    {
      get => this.maxLineCountInBlock;
      set
      {
        this.maxLineCountInBlock = value > 0 ? value : 0;
        this.blockHeight = (double) value * this.LineHeight;
      }
    }

    public IHighlighter CurrentHighlighter { get; set; }

    private void TextBox_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key == Key.Return)
      {
        e.Handled = true;
        TextBox textBox = sender as TextBox;
        int selectionStart = textBox.SelectionStart;
        string str1 = textBox.Text;
        if (selectionStart < textBox.Text.Length)
          str1 = textBox.Text.Remove(selectionStart);
        string source = str1.Substring(str1.LastIndexOf('\n') < 0 ? 0 : str1.LastIndexOf('\n'));
        if (source.IndexOfAny(this.printableChars.ToArray()) > 0)
          source = source.Remove(source.IndexOfAny(this.printableChars.ToArray()));
        int num = source.Count<char>((Func<char, bool>) (c => c == '\t'));
        string str2 = "\n";
        for (int index = 0; index < num; ++index)
          str2 += "\t";
        string str3 = textBox.Text;
        if (selectionStart < textBox.Text.Length)
          str3 = textBox.Text.Remove(selectionStart);
        string str4 = textBox.Text.Substring(selectionStart);
        string str5 = str3 + str2;
        textBox.Text = str5 + str4;
        textBox.SelectionStart = selectionStart + str2.Length;
      }
      if (e.Key == Key.Tab && !Keyboard.IsKeyDown(Key.RightShift) && !Keyboard.IsKeyDown(Key.LeftShift))
      {
        TextBox textBox = sender as TextBox;
        if (textBox.SelectionLength > 0)
        {
          e.Handled = true;
          int selectionStart = textBox.SelectionStart;
          int selectionLength = textBox.SelectionLength;
          string selectedText = textBox.SelectedText;
          string restOfTheFirstLine = this.GetRestOfTheFirstLine(textBox);
          string restOfTheLastLine = this.GetRestOfTheLastLine(textBox);
          string str1 = selectedText;
          string str2 = restOfTheLastLine;
          string source = (restOfTheFirstLine + str1 + str2).Replace("\n", "\n\t");
          textBox.Text = this.GetTextBeforeCompleteText(textBox) + "\t" + source + this.GetTextAfterCompleteText(textBox);
          textBox.SelectionStart = selectionStart + 1;
          textBox.SelectionLength = selectionLength + source.Count<char>((Func<char, bool>) (s => s == '\n'));
        }
      }
      if (e.Key != Key.Tab || !Keyboard.IsKeyDown(Key.RightShift) && !Keyboard.IsKeyDown(Key.LeftShift))
        return;
      TextBox textBox1 = sender as TextBox;
      if (textBox1.SelectionLength > 0)
      {
        e.Handled = true;
        int selectionStart = textBox1.SelectionStart;
        int selectionLength = textBox1.SelectionLength;
        string selectedText = textBox1.SelectedText;
        string restOfTheFirstLine = this.GetRestOfTheFirstLine(textBox1);
        string restOfTheLastLine = this.GetRestOfTheLastLine(textBox1);
        string input = restOfTheFirstLine + selectedText + restOfTheLastLine;
        int count = Regex.Matches(input, "\n\t").Count;
        string str = input.Replace("\n\t", "\n");
        if (str[0] == '\t')
        {
          if (restOfTheFirstLine != "")
            --selectionStart;
          else
            ++count;
          str = str.Substring(1);
        }
        textBox1.Text = this.GetTextBeforeCompleteText(textBox1) + str + this.GetTextAfterCompleteText(textBox1);
        textBox1.SelectionStart = selectionStart;
        textBox1.SelectionLength = selectionLength - count;
      }
      else
      {
        e.Handled = true;
        int selectionStart = textBox1.SelectionStart;
        if (selectionStart <= 0 || textBox1.Text[selectionStart - 1] != '\t')
          return;
        textBox1.Text = textBox1.Text.Remove(selectionStart - 1, 1);
        textBox1.SelectionStart = selectionStart - 1;
      }
    }

    private string GetTextBeforeCompleteText(TextBox textBox)
    {
      string str1 = textBox.Text.Remove(textBox.SelectionStart);
      string str2 = "";
      if (str1.LastIndexOf('\n') >= 0)
        str2 = str1.LastIndexOf('\n') + 1 >= str1.Length ? str1 : str1.Remove(str1.LastIndexOf('\n') + 1);
      return str2;
    }

    private string GetTextAfterCompleteText(TextBox textBox)
    {
      int startIndex = textBox.SelectionStart + textBox.SelectionLength;
      string str1 = textBox.Text.Substring(startIndex);
      string str2 = str1;
      if (str1.IndexOf('\n') >= 0)
        str2 = str1.Substring(str1.IndexOf('\n'));
      return str2;
    }

    private string GetRestOfTheFirstLine(TextBox textBox)
    {
      string str1 = textBox.Text.Remove(textBox.SelectionStart);
      string str2 = str1;
      if (str1.LastIndexOf('\n') >= 0)
        str2 = str1.Substring(str1.LastIndexOf('\n') + 1);
      return str2;
    }

    private string GetRestOfTheLastLine(TextBox textBox)
    {
      int startIndex = textBox.SelectionStart + textBox.SelectionLength;
      string str1 = textBox.Text.Substring(startIndex);
      string str2 = "";
      if (str1.IndexOf('\n') >= 0)
        str2 = str1.Remove(str1.IndexOf('\n'));
      return str2;
    }

    public void HighlightLine(int? line, int startindex, bool isError)
    {
      Grid name = (Grid) this.Template.FindName("rectangle", (FrameworkElement) this);
      if (line.HasValue)
        this.lastHightline = line.Value;
      int? nullable = line;
      int num = -1;
      if (nullable.GetValueOrDefault() == num & nullable.HasValue)
        name.Visibility = Visibility.Collapsed;
      else
        name.Visibility = Visibility.Visible;
      name.VerticalAlignment = VerticalAlignment.Top;
      name.HorizontalAlignment = HorizontalAlignment.Stretch;
      if (isError)
        name.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 230, (byte) 230));
      else
        name.Background = (Brush) new SolidColorBrush(Colors.LightBlue);
      this.RefreshHighlightLine();
    }

    public void RefreshHighlightLine()
    {
      Grid name = (Grid) this.Template.FindName("rectangle", (FrameworkElement) this);
      double val1 = this.lineHeight * (double) this.lastHightline - this.scrollViewer.VerticalOffset;
      double top = Math.Max(val1, 0.0);
      name.Margin = new Thickness(0.0, top, 0.0, 0.0);
      name.Height = this.lineHeight - Math.Min(this.lineHeight, top - val1);
    }

    public SyntaxHighlightBox()
    {
      this.InitializeComponent();
      for (int index = 0; index <= (int) ushort.MaxValue; ++index)
      {
        char c = Convert.ToChar(index);
        if (!char.IsControl(c))
          this.printableChars.Add(c);
      }
      this.MaxLineCountInBlock = 100;
      this.LineHeight = this.FontSize * 1.3;
      this.totalLineCount = 1;
      this.blocks = new List<SyntaxHighlightBox.InnerTextBlock>();
      this.Loaded += (RoutedEventHandler) ((s, e) =>
      {
        this.renderCanvas = (DrawingControl) this.Template.FindName("PART_RenderCanvas", (FrameworkElement) this);
        this.lineNumbersCanvas = (DrawingControl) this.Template.FindName("PART_LineNumbersCanvas", (FrameworkElement) this);
        this.scrollViewer = (ScrollViewer) this.Template.FindName("PART_ContentHost", (FrameworkElement) this);
        this.lineNumbersCanvas.Width = this.GetFormattedTextWidth(string.Format("{0:00}", (object) this.totalLineCount)) + 5.0;
        this.scrollViewer.ScrollChanged += new ScrollChangedEventHandler(this.OnScrollChanged);
        this.InvalidateBlocks(0);
        this.InvalidateVisual();
      });
      this.SizeChanged += (SizeChangedEventHandler) ((s, e) =>
      {
        if (!e.HeightChanged)
          return;
        this.UpdateBlocks();
        this.InvalidateVisual();
      });
      this.TextChanged += (TextChangedEventHandler) ((s, e) =>
      {
        this.UpdateTotalLineCount();
        this.InvalidateBlocks(e.Changes.First<TextChange>().Offset);
        this.InvalidateVisual();
      });
    }

    protected override void OnRender(DrawingContext drawingContext)
    {
      this.DrawBlocks();
      base.OnRender(drawingContext);
    }

    private new void OnScrollChanged(object sender, ScrollChangedEventArgs e)
    {
      if (e.VerticalChange != 0.0)
        this.UpdateBlocks();
      this.RefreshHighlightLine();
      this.InvalidateVisual();
    }

    private void UpdateTotalLineCount() => this.totalLineCount = TextUtilities.GetLineCount(this.Text);

    private void UpdateBlocks()
    {
      if (this.blocks.Count == 0)
        return;
      while (!this.blocks.Last<SyntaxHighlightBox.InnerTextBlock>().IsLast && this.blocks.Last<SyntaxHighlightBox.InnerTextBlock>().Position.Y + this.blockHeight - this.VerticalOffset < this.ActualHeight)
      {
        int num1 = this.blocks.Last<SyntaxHighlightBox.InnerTextBlock>().LineEndIndex + 1 + this.maxLineCountInBlock - 1;
        int num2 = num1 <= this.totalLineCount - 1 ? num1 : this.totalLineCount - 1;
        int charStart = this.blocks.Last<SyntaxHighlightBox.InnerTextBlock>().CharEndIndex + 1;
        int indexFromLineIndex = TextUtilities.GetLastCharIndexFromLineIndex(this.Text, num2);
        if (indexFromLineIndex <= charStart)
        {
          this.blocks.Last<SyntaxHighlightBox.InnerTextBlock>().IsLast = true;
          break;
        }
        SyntaxHighlightBox.InnerTextBlock currentBlock = new SyntaxHighlightBox.InnerTextBlock(charStart, indexFromLineIndex, this.blocks.Last<SyntaxHighlightBox.InnerTextBlock>().LineEndIndex + 1, num2, this.LineHeight);
        currentBlock.RawText = currentBlock.GetSubString(this.Text);
        currentBlock.LineNumbers = this.GetFormattedLineNumbers(currentBlock.LineStartIndex, currentBlock.LineEndIndex);
        this.blocks.Add(currentBlock);
        this.FormatBlock(currentBlock, this.blocks.Count > 1 ? this.blocks[this.blocks.Count - 2] : (SyntaxHighlightBox.InnerTextBlock) null);
      }
    }

    private void InvalidateBlocks(int changeOffset)
    {
      SyntaxHighlightBox.InnerTextBlock innerTextBlock = (SyntaxHighlightBox.InnerTextBlock) null;
      for (int index = 0; index < this.blocks.Count; ++index)
      {
        if (this.blocks[index].CharStartIndex <= changeOffset && changeOffset <= this.blocks[index].CharEndIndex + 1)
        {
          innerTextBlock = this.blocks[index];
          break;
        }
      }
      if (innerTextBlock == null && changeOffset > 0)
        innerTextBlock = this.blocks.Last<SyntaxHighlightBox.InnerTextBlock>();
      int num1 = innerTextBlock != null ? innerTextBlock.LineStartIndex : 0;
      int ofLastVisibleLine = this.GetIndexOfLastVisibleLine();
      int num2 = innerTextBlock != null ? innerTextBlock.CharStartIndex : 0;
      int indexFromLineIndex = TextUtilities.GetLastCharIndexFromLineIndex(this.Text, ofLastVisibleLine);
      if (innerTextBlock != null)
        this.blocks.RemoveRange(this.blocks.IndexOf(innerTextBlock), this.blocks.Count - this.blocks.IndexOf(innerTextBlock));
      int num3 = 1;
      int num4 = num2;
      int lineStart = num1;
      for (int index = num2; index < this.Text.Length; ++index)
      {
        if (this.Text[index] == '\n')
          ++num3;
        if (index == this.Text.Length - 1)
        {
          string text = this.Text.Substring(num4);
          SyntaxHighlightBox.InnerTextBlock currentBlock = new SyntaxHighlightBox.InnerTextBlock(num4, index, lineStart, lineStart + TextUtilities.GetLineCount(text) - 1, this.LineHeight);
          currentBlock.RawText = currentBlock.GetSubString(this.Text);
          currentBlock.LineNumbers = this.GetFormattedLineNumbers(currentBlock.LineStartIndex, currentBlock.LineEndIndex);
          currentBlock.IsLast = true;
          foreach (SyntaxHighlightBox.InnerTextBlock block in this.blocks)
          {
            if (block.LineStartIndex == currentBlock.LineStartIndex)
              throw new Exception();
          }
          this.blocks.Add(currentBlock);
          this.FormatBlock(currentBlock, this.blocks.Count > 1 ? this.blocks[this.blocks.Count - 2] : (SyntaxHighlightBox.InnerTextBlock) null);
          break;
        }
        if (num3 > this.maxLineCountInBlock)
        {
          SyntaxHighlightBox.InnerTextBlock currentBlock = new SyntaxHighlightBox.InnerTextBlock(num4, index, lineStart, lineStart + this.maxLineCountInBlock - 1, this.LineHeight);
          currentBlock.RawText = currentBlock.GetSubString(this.Text);
          currentBlock.LineNumbers = this.GetFormattedLineNumbers(currentBlock.LineStartIndex, currentBlock.LineEndIndex);
          foreach (SyntaxHighlightBox.InnerTextBlock block in this.blocks)
          {
            if (block.LineStartIndex == currentBlock.LineStartIndex)
              throw new Exception();
          }
          this.blocks.Add(currentBlock);
          this.FormatBlock(currentBlock, this.blocks.Count > 1 ? this.blocks[this.blocks.Count - 2] : (SyntaxHighlightBox.InnerTextBlock) null);
          num4 = index + 1;
          lineStart += this.maxLineCountInBlock;
          num3 = 1;
          if (index > indexFromLineIndex)
            break;
        }
      }
    }

    private void DrawBlocks()
    {
      if (!this.IsLoaded || this.renderCanvas == null || this.lineNumbersCanvas == null)
        return;
      DrawingContext context1 = this.renderCanvas.GetContext();
      DrawingContext context2 = this.lineNumbersCanvas.GetContext();
      for (int index = 0; index < this.blocks.Count; ++index)
      {
        SyntaxHighlightBox.InnerTextBlock block = this.blocks[index];
        double num1 = block.Position.Y - this.VerticalOffset;
        double num2 = num1 + this.blockHeight;
        if (num1 < this.ActualHeight)
        {
          if (num2 > 0.0)
          {
            try
            {
              context1.DrawText(block.FormattedText, new Point(2.0 - this.HorizontalOffset, block.Position.Y - this.VerticalOffset));
              if (this.IsLineNumbersMarginVisible)
              {
                this.lineNumbersCanvas.Width = this.GetFormattedTextWidth(string.Format("{0:0000}", (object) this.totalLineCount)) + 5.0;
                context2.DrawText(block.LineNumbers, new Point(this.lineNumbersCanvas.ActualWidth, 1.0 + block.Position.Y - this.VerticalOffset));
              }
            }
            catch
            {
            }
          }
        }
      }
      context1.Close();
      context2.Close();
    }

    public int GetIndexOfFirstVisibleLine()
    {
      int num = (int) (this.VerticalOffset / this.lineHeight);
      return num <= this.totalLineCount ? num : this.totalLineCount;
    }

    public int GetIndexOfLastVisibleLine()
    {
      int num = (int) ((this.VerticalOffset + this.ViewportHeight) / this.lineHeight);
      return num <= this.totalLineCount - 1 ? num : this.totalLineCount - 1;
    }

    private void FormatBlock(
      SyntaxHighlightBox.InnerTextBlock currentBlock,
      SyntaxHighlightBox.InnerTextBlock previousBlock)
    {
      currentBlock.FormattedText = this.GetFormattedText(currentBlock.RawText);
      if (this.CurrentHighlighter == null)
        return;
      int previousBlockCode = previousBlock != null ? previousBlock.Code : -1;
      currentBlock.Code = this.CurrentHighlighter.Highlight(currentBlock.FormattedText, previousBlockCode);
    }

    private FormattedText GetFormattedText(string text) => new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight, new Typeface(this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch), this.FontSize, (Brush) Brushes.Black)
    {
      Trimming = TextTrimming.None,
      LineHeight = this.lineHeight
    };

    private FormattedText GetFormattedLineNumbers(int firstIndex, int lastIndex)
    {
      string str = "";
      for (int index = firstIndex + 1; index <= lastIndex + 1; ++index)
        str = str + index.ToString() + "\n";
      return new FormattedText(str.Trim(), CultureInfo.InvariantCulture, FlowDirection.LeftToRight, new Typeface(this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch), this.FontSize, (Brush) new SolidColorBrush(Color.FromRgb((byte) 33, (byte) 161, (byte) 216)))
      {
        Trimming = TextTrimming.None,
        LineHeight = this.lineHeight,
        TextAlignment = TextAlignment.Right
      };
    }

    private double GetFormattedTextWidth(string text) => new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight, new Typeface(this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch), this.FontSize, (Brush) Brushes.Black)
    {
      Trimming = TextTrimming.None,
      LineHeight = this.lineHeight
    }.Width;

    public bool IsLineNumbersMarginVisible
    {
      get => (bool) this.GetValue(SyntaxHighlightBox.IsLineNumbersMarginVisibleProperty);
      set => this.SetValue(SyntaxHighlightBox.IsLineNumbersMarginVisibleProperty, (object) value);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/syntaxhighlight/syntaxhighlightbox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        ((UIElement) target).PreviewKeyDown += new KeyEventHandler(this.TextBox_KeyDown);
      else
        this._contentLoaded = true;
    }

    private class InnerTextBlock
    {
      private double lineHeight;

      public string RawText { get; set; }

      public FormattedText FormattedText { get; set; }

      public FormattedText LineNumbers { get; set; }

      public int CharStartIndex { get; private set; }

      public int CharEndIndex { get; private set; }

      public int LineStartIndex { get; private set; }

      public int LineEndIndex { get; private set; }

      public Point Position => new Point(0.0, (double) this.LineStartIndex * this.lineHeight);

      public bool IsLast { get; set; }

      public int Code { get; set; }

      public InnerTextBlock(
        int charStart,
        int charEnd,
        int lineStart,
        int lineEnd,
        double lineHeight)
      {
        this.CharStartIndex = charStart;
        this.CharEndIndex = charEnd;
        this.LineStartIndex = lineStart;
        this.LineEndIndex = lineEnd;
        this.lineHeight = lineHeight;
        this.IsLast = false;
      }

      public string GetSubString(string text) => text.Substring(this.CharStartIndex, this.CharEndIndex - this.CharStartIndex + 1);

      public override string ToString() => string.Format("L:{0}/{1} C:{2}/{3} {4}", (object) this.LineStartIndex, (object) this.LineEndIndex, (object) this.CharStartIndex, (object) this.CharEndIndex, (object) this.FormattedText.Text);
    }
  }
}
