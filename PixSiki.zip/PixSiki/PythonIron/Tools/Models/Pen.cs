﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Models.Pen
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.PythonIron.Tools.Integration;
using System;

namespace PixBlocks.PythonIron.Tools.Models
{
  public class Pen
  {
    private Sprite sprite;

    public Pen(Sprite sprite) => this.sprite = sprite;

    public bool on
    {
      get => this.sprite.pen_onPrivate;
      set => this.sprite.pen_onPrivate = value;
    }

    public Color color
    {
      get => this.sprite.pen_colorPrivate;
      set => this.sprite.pen_colorPrivate = value;
    }

    public double size
    {
      get => this.sprite.pen_sizePrivate;
      set => this.sprite.pen_sizePrivate = Math.Min(Math.Max(0.0, value), 400.0);
    }
  }
}
