﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Game.AllSpritesView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.PythonIron.Tools.Game
{
  public partial class AllSpritesView : UserControl, IComponentConnector
  {
    internal WrapPanel wrapPanel;
    internal TextBox unicodes;
    private bool _contentLoaded;

    public AllSpritesView()
    {
      this.InitializeComponent();
      for (int number = 0; number < 104; ++number)
        this.wrapPanel.Children.Add((UIElement) new SpriteAndNumber(number));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/tools/game/allspritesview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.unicodes = (TextBox) target;
        else
          this._contentLoaded = true;
      }
      else
        this.wrapPanel = (WrapPanel) target;
    }
  }
}
