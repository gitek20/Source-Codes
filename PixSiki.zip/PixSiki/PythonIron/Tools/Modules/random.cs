﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Modules.random
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;

namespace PixBlocks.PythonIron.Tools.Modules
{
  public class random
  {
    private static Random random1 = new Random();

    public static int randint(int start, int end) => random.random1.Next(Math.Max(end + 1 - start, 0)) + start;
  }
}
