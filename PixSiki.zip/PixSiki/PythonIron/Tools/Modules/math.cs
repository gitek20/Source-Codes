﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Modules.math
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;

namespace PixBlocks.PythonIron.Tools.Modules
{
  public class math
  {
    public static double max(double a, double b) => Math.Max(a, b);

    public static double min(double a, double b) => Math.Min(a, b);

    public static double sin(double a) => Math.Sin(a);

    public static double cos(double a) => Math.Cos(a);

    public static double pow(double a, double b) => Math.Pow(a, b);

    public static double sqrt(double a) => a >= 0.0 ? Math.Sqrt(a) : throw new Exception("sqrt " + a.ToString() + " is NaN");

    public static double pi => Math.PI;
  }
}
