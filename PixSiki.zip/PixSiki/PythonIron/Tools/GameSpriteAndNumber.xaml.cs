﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Game.SpriteAndNumber
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.PythonIron.Tools.Integration;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.PythonIron.Tools.Game
{
  public partial class SpriteAndNumber : UserControl, IComponentConnector
  {
    internal Grid gridToSprite;
    internal TextBlock numberTex;
    private bool _contentLoaded;

    public SpriteAndNumber(int number)
    {
      this.InitializeComponent();
      Sprite sprite = (Sprite) new Arrow();
      sprite.image = number;
      sprite.color = new Color(14, 145, (int) byte.MaxValue);
      sprite.IsVisible = true;
      sprite.size = 38.0;
      SpriteView spriteView = new SpriteView(sprite, (GameScene) null, (Canvas) null);
      spriteView.Margin = new Thickness(10.0, 10.0, 0.0, 0.0);
      this.gridToSprite.Children.Add((UIElement) spriteView);
      this.numberTex.Text = sprite.image.ToString() ?? "";
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/tools/game/spriteandnumber.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.numberTex = (TextBlock) target;
        else
          this._contentLoaded = true;
      }
      else
        this.gridToSprite = (Grid) target;
    }
  }
}
