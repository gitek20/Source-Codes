﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.PythonCodeRunner
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using IronPython.Hosting;
using IronPython.Runtime;
using Microsoft.CSharp.RuntimeBinder;
using Microsoft.Scripting;
using Microsoft.Scripting.Hosting;
using PixBlocks.PythonIron.Tools.Game;
using PixBlocks.PythonIron.Tools.ImportFinder;
using PixBlocks.PythonIron.Tools.Integration;
using PixBlocks.PythonIron.Tools.Modules;
using PixBlocks.SoundPlayer.SoundPlayer.SoundEngine;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace PixBlocks.PythonIron.Tools
{
  public class PythonCodeRunner
  {
    private List inputValue;
    private bool showHighLines = true;
    internal bool RefreshObjectsOnUpdate = true;
    private Sound _sound;
    private string code;
    private string codeAndBreakpoints;
    private PythonCodeRunner.RunnerState currentState = PythonCodeRunner.RunnerState.stopped;
    private string inputText;
    internal bool RefreshObjectsNoThread;
    private int timeCounter;
    internal static ScriptEngine engine;
    internal ScriptSource source;
    private static ScriptScope scope = (ScriptScope) null;
    private MemoryStream streamOut = new MemoryStream();
    private string properOutput;
    private Thread thread;
    private static int instructionsCounter = 0;
    private static int runNextInstructionsCounter = 0;
    private int lastLineNumber;
    private string prevVariables;
    private string prevOutput;
    private long prevStreamLength;
    private bool lockNextInstruction;
    private bool breakAll;
    private DispatcherTimer timerCheckIsAbortedThread = new DispatcherTimer();
    internal bool isStopped;
    private math math = new math();
    private EventWaitHandle eventWaitHandle = new EventWaitHandle(false, EventResetMode.ManualReset);
    public static random ipRandom = new random();
    public static GameScene gameScene = (GameScene) null;
    private Sprite _pen;
    internal bool IsPaused;

    public PythonCodeRunner()
    {
      this.timerCheckIsAbortedThread = new DispatcherTimer();
      this.timerCheckIsAbortedThread.Tick += new EventHandler(this.TimerCheckIsAbortedThread_Tick);
    }

    public List input => this.inputValue;

    internal PythonCodeRunner.RunnerState CurrentState => this.currentState;

    internal string InputText => this.inputText;

    internal string ProperOutput => this.properOutput;

    internal int LastLineNumber => this.lastLineNumber;

    internal bool ShowHighLines => this.showHighLines;

    internal bool SetShowHighLines
    {
      set
      {
        if (!value && this.showHighLines && this.hightLightEvent != null)
          this.hightLightEvent(new int?(-1), 0, false, "");
        this.showHighLines = value;
      }
    }

    public Sound sound
    {
      get
      {
        if (this._sound == null)
          this._sound = new Sound();
        return this._sound;
      }
    }

    public Sprite pen
    {
      get
      {
        if (this._pen == null)
        {
          this._pen = (Sprite) new Arrow();
          this._pen._privIsArrow = true;
          this._pen.image = 66;
          this._pen.size = 10.0;
          this._pen.pen_sizePrivate = 1.5;
          this._pen.pen_onPrivate = true;
          this._pen.color = new Color(150, 150, 150);
          if (PythonCodeRunner.gameScene != null)
            PythonCodeRunner.gameScene.add(this._pen);
        }
        return this._pen;
      }
    }

    internal event PythonCodeRunner.CurrentStateChanged currentStateChangedEvent;

    internal void SetInputText(string inputText)
    {
      this.inputText = inputText;
      if (this.currentState == PythonCodeRunner.RunnerState.stopped)
        return;
      this.Stop();
    }

    internal event PythonCodeRunner.CodeWasModify codeWasModifyEvent;

    internal void SetCode(string code)
    {
      if (this.codeWasModifyEvent != null)
        this.codeWasModifyEvent();
      if (code == null)
        code = "";
      this.code = code;
      if (this.currentState == PythonCodeRunner.RunnerState.stopped)
        return;
      this.Stop();
    }

    internal string RunFullCode(string newCode, string newInput)
    {
      this.isStopped = false;
      List<string> list1 = ((IEnumerable<string>) newInput.Split("\n"[0])).Select<string, string>((Func<string, string>) (s => s.Replace("\r", ""))).ToList<string>();
      newCode = "import clr;clr.AddReference('PixBlocks');from PixBlocks.PythonIron.Tools.Integration import * \r\n" + newCode;
      List list2 = new List();
      foreach (string str in list1)
      {
        char[] chArray = new char[1]{ " "[0] };
        string s = str.TrimStart(chArray).TrimEnd(" "[0]);
        int result1 = 0;
        if (int.TryParse(s, out result1))
        {
          list2.Add((object) result1);
        }
        else
        {
          double result2 = 0.0;
          if (double.TryParse(s.Replace(",", "."), NumberStyles.Any, (IFormatProvider) CultureInfo.InvariantCulture, out result2))
            list2.Add((object) result2);
          else
            list2.Add((object) s);
        }
      }
      ScriptEngine engine = Python.CreateEngine();
      ScriptScope scope = engine.CreateScope();
      scope.SetVariable("input", (object) list2);
      scope.SetVariable("random", (object) PythonCodeRunner.ipRandom);
      if (newCode.Contains("game.") || newCode.Contains("arrow."))
      {
        if (PythonCodeRunner.gameScene != null)
          PythonCodeRunner.gameScene.Reset();
        PythonCodeRunner.gameScene = new GameScene(this);
        if (this.showGameScene != null)
          this.showGameScene(PythonCodeRunner.gameScene);
      }
      else
        PythonCodeRunner.gameScene = (GameScene) null;
      scope.SetVariable("math", (object) this.math);
      scope.SetVariable("sound", (object) this.sound);
      if (PythonCodeRunner.gameScene != null)
      {
        scope.SetVariable("game", (object) PythonCodeRunner.gameScene);
        this._pen = (Sprite) null;
        if (newCode.Contains("arrow."))
        {
          scope.SetVariable("arrow", (object) this.pen);
          this.pen.size = 0.0;
        }
      }
      MemoryStream stream = new MemoryStream();
      engine.Runtime.IO.SetOutput((Stream) stream, Encoding.Default);
      ScriptSource sourceFromString = engine.CreateScriptSourceFromString(newCode);
      this.RefreshObjectsNoThread = true;
      try
      {
        sourceFromString.Execute(scope);
      }
      catch
      {
        int num = (int) MessageBox.Show("error");
      }
      this.RefreshObjectsNoThread = false;
      return PythonCodeRunner.StreamToString(stream).TrimEnd("\n"[0]).TrimEnd("\r"[0]);
    }

    internal event PythonCodeRunner.ShowGameScene showGameScene;

    internal event PythonCodeRunner.StopPressedExternal stopPressedExternal;

    internal void PressStop()
    {
      if (this.stopPressedExternal == null)
        return;
      this.stopPressedExternal();
    }

    private void TryToRun()
    {
      this.isStopped = false;
      this.timeCounter = 0;
      this.currentState = PythonCodeRunner.RunnerState.running;
      if (this.currentStateChangedEvent != null)
        this.currentStateChangedEvent(this.currentState);
      PythonCodeRunner.instructionsCounter = 0;
      this.code = this.code;
      List<string> list = ((IEnumerable<string>) this.InputText.Split("\n"[0])).Select<string, string>((Func<string, string>) (s => s.Replace("\r", ""))).ToList<string>();
      this.inputValue = new List();
      foreach (string str in list)
      {
        char[] chArray = new char[1]{ " "[0] };
        string s = str.TrimStart(chArray).TrimEnd(" "[0]);
        int result1 = 0;
        if (int.TryParse(s, out result1))
        {
          this.inputValue.Add((object) result1);
        }
        else
        {
          double result2 = 0.0;
          if (double.TryParse(s.Replace(",", "."), NumberStyles.Any, (IFormatProvider) CultureInfo.InvariantCulture, out result2))
            this.inputValue.Add((object) result2);
          else
            this.inputValue.Add((object) s);
        }
      }
      PythonCodeRunner.runNextInstructionsCounter = 0;
      try
      {
        ScriptEngine engine = Python.CreateEngine();
        BadImportFinder.FindImports(this.code);
        string code = this.code;
        engine.CreateScriptSourceFromString(code).Compile();
        if (this.code.Contains("game.") || this.code.Contains("arrow."))
        {
          if (PythonCodeRunner.gameScene != null)
            PythonCodeRunner.gameScene.Reset();
          PythonCodeRunner.gameScene = new GameScene(this);
          if (this.showGameScene != null)
            this.showGameScene(PythonCodeRunner.gameScene);
        }
        else
          PythonCodeRunner.gameScene = (GameScene) null;
        this.codeAndBreakpoints = BreakPointsCreator.CreateInlineBreakPoints(this.code);
        this.RunAsync();
      }
      catch (Exception ex)
      {
        this.currentState = PythonCodeRunner.RunnerState.errored;
        if (this.currentStateChangedEvent != null)
          this.currentStateChangedEvent(this.currentState);
        Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
        {
          if (ex is SyntaxErrorException)
          {
            if (this.hightLightEvent == null)
              return;
            this.hightLightEvent(new int?((ex as SyntaxErrorException).Line - 1), 0, true, ex.Message);
          }
          else
          {
            if (!ex.Message.Contains("No module named") || this.hightLightEvent == null)
              return;
            this.hightLightEvent(new int?(-1), 0, true, ex.Message);
          }
        }));
      }
    }

    internal void RunAsync()
    {
      this.isStopped = false;
      this.thread = new Thread(new ThreadStart(this.DoWork));
      this.thread.Start();
    }

    internal void RefreshInput()
    {
      if (this.refreshInputViewEvent == null)
        return;
      this.refreshInputViewEvent();
    }

    internal void SetProperOutput(string properOutput) => this.properOutput = properOutput;

    private void DoWork()
    {
      Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
      Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
      try
      {
        this.prevVariables = (string) null;
        this.prevOutput = (string) null;
        this.prevStreamLength = -200L;
        PythonCodeRunner.engine = Python.CreateEngine();
        PythonCodeRunner.scope = PythonCodeRunner.engine.CreateScope();
        PythonCodeRunner.scope.SetVariable("pix", (object) this);
        PythonCodeRunner.scope.SetVariable("message", (object) this);
        PythonCodeRunner.scope.SetVariable("random", (object) PythonCodeRunner.ipRandom);
        PythonCodeRunner.scope.SetVariable("math", (object) this.math);
        PythonCodeRunner.scope.SetVariable("sound", (object) this.sound);
        if (PythonCodeRunner.gameScene != null)
        {
          PythonCodeRunner.scope.SetVariable("game", (object) PythonCodeRunner.gameScene);
          this._pen = (Sprite) null;
          if (this.code.Contains("arrow."))
            PythonCodeRunner.scope.SetVariable("arrow", (object) this.pen);
        }
        PythonCodeRunner.scope.SetVariable("input", (object) this.input);
        this.streamOut = new MemoryStream();
        PythonCodeRunner.engine.Runtime.IO.SetOutput((Stream) this.streamOut, Encoding.Default);
        PythonCodeRunner.engine.Runtime.IO.SetInput((Stream) this.streamOut, Encoding.Default);
        string expression = Encoding.UTF8.GetString(Encoding.UTF8.GetBytes(this.codeAndBreakpoints));
        this.source = PythonCodeRunner.engine.CreateScriptSourceFromString(expression);
        this.source.Execute(PythonCodeRunner.scope);
        Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
        {
          string outString = PythonCodeRunner.StreamToString(this.streamOut);
          this.currentState = PythonCodeRunner.RunnerState.finished;
          this.hightLightEvent(new int?(-1), 0, false, "");
          if (this.currentStateChangedEvent != null)
            this.currentStateChangedEvent(this.currentState);
          if (this.properOutput == null)
            return;
          this.CheckIsSubstring(outString, this.properOutput, true);
        }));
      }
      catch (Exception ex)
      {
        if (Application.Current == null)
          return;
        Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
        {
          if (ex is ThreadInterruptedException)
          {
            this.hightLightEvent(new int?(-1), 0, false, "");
          }
          else
          {
            this.currentState = PythonCodeRunner.RunnerState.errored;
            if (this.currentStateChangedEvent != null)
              this.currentStateChangedEvent(this.currentState);
            if (this.hightLightEvent == null)
              return;
            if (ex is SyntaxErrorException)
              this.hightLightEvent(new int?((ex as SyntaxErrorException).Line - 1), 0, true, ex.Message);
            else
              this.hightLightEvent(new int?(this.lastLineNumber), 0, true, ex.Message);
          }
        }));
      }
    }

    internal void RunNextInstruction()
    {
      if (this.currentState == PythonCodeRunner.RunnerState.running && !this.lockNextInstruction)
        ++PythonCodeRunner.runNextInstructionsCounter;
      int currentState = (int) this.currentState;
      if (this.currentState != PythonCodeRunner.RunnerState.stopped && this.currentState != PythonCodeRunner.RunnerState.errored)
        return;
      this.TryToRun();
    }

    internal event PythonCodeRunner.HighlihtLine hightLightEvent;

    public bool breakpoint(int lineNumber)
    {
      this.lastLineNumber = lineNumber;
      ++this.timeCounter;
      if (this.showHighLines)
      {
        if (Application.Current != null)
          Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
          {
            try
            {
              if (this.showHighLines && this.hightLightEvent != null)
                this.hightLightEvent(new int?(lineNumber), 0, false, "");
              string variables = "";
              if (this.showHighLines)
                variables = "\xD83D\xDD52=" + this.timeCounter.ToString() + "\r\n";
              if (!this.showHighLines)
                return;
              foreach (string name in PythonCodeRunner.scope.GetVariableNames().ToList<string>())
              {
                if (!(name == "__builtins__") && !(name == "__file__") && (!(name == "__name__") && !(name == "__doc__")) && (!(name == "pix") && !(name == "input")))
                {
                  object variable = PythonCodeRunner.scope.GetVariable(name);
                  // ISSUE: reference to a compiler-generated field
                  if (PythonCodeRunner.\u003C\u003Eo__72.\u003C\u003Ep__1 == null)
                  {
                    // ISSUE: reference to a compiler-generated field
                    PythonCodeRunner.\u003C\u003Eo__72.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (string), typeof (PythonCodeRunner)));
                  }
                  // ISSUE: reference to a compiler-generated field
                  Func<CallSite, object, string> target = PythonCodeRunner.\u003C\u003Eo__72.\u003C\u003Ep__1.Target;
                  // ISSUE: reference to a compiler-generated field
                  CallSite<Func<CallSite, object, string>> p1 = PythonCodeRunner.\u003C\u003Eo__72.\u003C\u003Ep__1;
                  // ISSUE: reference to a compiler-generated field
                  if (PythonCodeRunner.\u003C\u003Eo__72.\u003C\u003Ep__0 == null)
                  {
                    // ISSUE: reference to a compiler-generated field
                    PythonCodeRunner.\u003C\u003Eo__72.\u003C\u003Ep__0 = CallSite<Func<CallSite, PythonCodeRunner, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.InvokeSimpleName, "ConvertDynamicToString", (IEnumerable<Type>) null, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                    {
                      CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
                      CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
                    }));
                  }
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated field
                  object obj = PythonCodeRunner.\u003C\u003Eo__72.\u003C\u003Ep__0.Target((CallSite) PythonCodeRunner.\u003C\u003Eo__72.\u003C\u003Ep__0, this, variable);
                  string str = target((CallSite) p1, obj);
                  if (str != null)
                    variables = variables + name + "=" + str + "\r\n";
                }
              }
              if (this.refreshOutputAndVariablesEvent == null)
                return;
              string str1 = this.streamOut.Length == this.prevStreamLength ? this.prevOutput : PythonCodeRunner.StreamToString(this.streamOut);
              if (this.prevOutput != str1 || this.prevVariables != variables)
              {
                this.refreshOutputAndVariablesEvent(str1, variables);
                if (this.properOutput != null)
                  this.CheckIsSubstring(str1, this.properOutput, false);
              }
              this.prevOutput = str1;
              this.prevVariables = variables;
              this.prevStreamLength = this.streamOut.Length;
            }
            catch
            {
            }
          }));
        bool flag = false;
        while (PythonCodeRunner.instructionsCounter >= PythonCodeRunner.runNextInstructionsCounter)
        {
          if (this.breakAll)
          {
            flag = true;
            break;
          }
          try
          {
            Thread.Sleep(1);
          }
          catch
          {
            flag = true;
            break;
          }
        }
        PythonCodeRunner.instructionsCounter = PythonCodeRunner.runNextInstructionsCounter - 1;
        if (flag)
        {
          this.breakAll = false;
          throw new NotImplementedException();
        }
        ++PythonCodeRunner.instructionsCounter;
      }
      return true;
    }

    internal void RefreshAllVariablesAndOutput()
    {
      if (Application.Current == null)
        return;
      Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
      {
        try
        {
          string variables = "\xD83D\xDD52=" + this.timeCounter.ToString() + "\r\n";
          foreach (string name in PythonCodeRunner.scope.GetVariableNames().ToList<string>())
          {
            if (!(name == "__builtins__") && !(name == "__file__") && (!(name == "__name__") && !(name == "__doc__")) && (!(name == "pix") && !(name == "input")))
            {
              object variable = PythonCodeRunner.scope.GetVariable(name);
              // ISSUE: reference to a compiler-generated field
              if (PythonCodeRunner.\u003C\u003Eo__73.\u003C\u003Ep__1 == null)
              {
                // ISSUE: reference to a compiler-generated field
                PythonCodeRunner.\u003C\u003Eo__73.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (string), typeof (PythonCodeRunner)));
              }
              // ISSUE: reference to a compiler-generated field
              Func<CallSite, object, string> target = PythonCodeRunner.\u003C\u003Eo__73.\u003C\u003Ep__1.Target;
              // ISSUE: reference to a compiler-generated field
              CallSite<Func<CallSite, object, string>> p1 = PythonCodeRunner.\u003C\u003Eo__73.\u003C\u003Ep__1;
              // ISSUE: reference to a compiler-generated field
              if (PythonCodeRunner.\u003C\u003Eo__73.\u003C\u003Ep__0 == null)
              {
                // ISSUE: reference to a compiler-generated field
                PythonCodeRunner.\u003C\u003Eo__73.\u003C\u003Ep__0 = CallSite<Func<CallSite, PythonCodeRunner, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.InvokeSimpleName, "ConvertDynamicToString", (IEnumerable<Type>) null, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                {
                  CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
                  CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
                }));
              }
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              object obj = PythonCodeRunner.\u003C\u003Eo__73.\u003C\u003Ep__0.Target((CallSite) PythonCodeRunner.\u003C\u003Eo__73.\u003C\u003Ep__0, this, variable);
              string str = target((CallSite) p1, obj);
              if (str != null)
                variables = variables + name + "=" + str + "\r\n";
            }
          }
          if (this.refreshOutputAndVariablesEvent == null)
            return;
          string str1 = PythonCodeRunner.StreamToString(this.streamOut);
          this.refreshOutputAndVariablesEvent(str1, variables);
          if (this.properOutput != null)
            this.CheckIsSubstring(str1, this.properOutput, false);
          this.prevOutput = str1;
          this.prevVariables = variables;
          this.prevStreamLength = this.streamOut.Length;
        }
        catch
        {
        }
      }));
    }

    internal event PythonCodeRunner.CodesMatch codesMatchEvent;

    private string NormaliseString(string inp)
    {
      inp = inp.Replace("\r", "");
      for (int index = 0; index < int.MaxValue; ++index)
      {
        string str = inp.TrimEnd(" "[0]).TrimEnd("\n"[0]).TrimEnd(" "[0]);
        if (str != inp)
          inp = str;
        else
          break;
      }
      string[] strArray = inp.Split("\n"[0]);
      for (int index = 0; index < strArray.Length; ++index)
        strArray[index] = strArray[index].TrimEnd(" "[0]);
      string str1 = "";
      for (int index = 0; index < strArray.Length; ++index)
        str1 = str1 + strArray[index] + "\r\n";
      return str1.TrimEnd("\n"[0]).TrimEnd("\r"[0]);
    }

    private void CheckIsSubstring(string outString, string properOutput, bool shoulBeTheSame)
    {
      if (this.codesMatchEvent == null)
        return;
      outString = this.NormaliseString(outString);
      properOutput = this.NormaliseString(properOutput);
      if (shoulBeTheSame)
      {
        if (outString == properOutput)
          this.codesMatchEvent(true, properOutput, outString);
        else
          this.codesMatchEvent(false, properOutput, outString);
      }
      else if (properOutput.Length >= outString.Length && properOutput.Substring(0, outString.Length) == outString)
      {
        if (outString.Length <= 0 || properOutput.Length <= outString.Length || (int) properOutput[outString.Length] == (int) "\r"[0])
          return;
        this.codesMatchEvent(false, properOutput, outString);
      }
      else
        this.codesMatchEvent(false, properOutput, outString);
    }

    internal event PythonCodeRunner.ReadLineDelegate readLineEvent;

    public string show(string message)
    {
      string value = "NULL!!!";
      Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
      {
        this.lockNextInstruction = true;
        if (this.readLineEvent != null)
          value = this.readLineEvent(message);
        this.lockNextInstruction = false;
      }));
      return value;
    }

    internal event PythonCodeRunner.RefreshOutputAndVariables refreshOutputAndVariablesEvent;

    internal event PythonCodeRunner.RefreshInputView refreshInputViewEvent;

    private string ConvertDynamicToString(object d)
    {
      switch (d)
      {
        case double _:
        case int _:
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__2 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (string), typeof (PythonCodeRunner)));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, string> target1 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__2.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, string>> p2 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__2;
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__1 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, string, string, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "Replace", (IEnumerable<Type>) null, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, string, string, object> target2 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__1.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, string, string, object>> p1 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__1;
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__0 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__0 = CallSite<Func<CallSite, Type, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ToString", (IEnumerable<Type>) null, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj1 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__0.Target((CallSite) PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__0, typeof (Convert), d);
          object obj2 = target2((CallSite) p1, obj1, ",", ".");
          return target1((CallSite) p2, obj2);
        case string _:
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__6 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (string), typeof (PythonCodeRunner)));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, string> target3 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__6.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, string>> p6 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__6;
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__5 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, string, object> target4 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__5.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, string, object>> p5 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__5;
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__4 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__4 = CallSite<Func<CallSite, string, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, string, object, object> target5 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__4.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, string, object, object>> p4 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__4;
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__3 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__3 = CallSite<Func<CallSite, Type, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ToString", (IEnumerable<Type>) null, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj3 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__3.Target((CallSite) PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__3, typeof (Convert), d);
          object obj4 = target5((CallSite) p4, "'", obj3);
          object obj5 = target4((CallSite) p5, obj4, "'");
          return target3((CallSite) p6, obj5);
        case bool _:
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__8 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, bool> target6 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__8.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, bool>> p8 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__8;
          // ISSUE: reference to a compiler-generated field
          if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__7 == null)
          {
            // ISSUE: reference to a compiler-generated field
            PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj6 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__7.Target((CallSite) PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__7, d, true);
          return target6((CallSite) p8, obj6) ? "True" : "False";
        case List _:
          if ((d as List).__len__() >= 1000)
            return (string) null;
          string source = "[";
          foreach (object obj7 in d as List)
          {
            // ISSUE: reference to a compiler-generated field
            if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__10 == null)
            {
              // ISSUE: reference to a compiler-generated field
              PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__10 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (string), typeof (PythonCodeRunner)));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, string> target7 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__10.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, string>> p10 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__10;
            // ISSUE: reference to a compiler-generated field
            if (PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__9 == null)
            {
              // ISSUE: reference to a compiler-generated field
              PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__9 = CallSite<Func<CallSite, PythonCodeRunner, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.InvokeSimpleName, nameof (ConvertDynamicToString), (IEnumerable<Type>) null, typeof (PythonCodeRunner), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj8 = PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__9.Target((CallSite) PythonCodeRunner.\u003C\u003Eo__94.\u003C\u003Ep__9, this, obj7);
            string str = target7((CallSite) p10, obj8);
            if (str == null)
              return (string) null;
            source = source + str + ", ";
          }
          if (source.Length > 2)
            source = source.Remove(source.Count<char>() - 2, 2);
          return source + "]";
        default:
          return (string) null;
      }
    }

    internal static string StreamToString(MemoryStream stream) => Encoding.Default.GetString(stream.GetBuffer(), 0, stream.GetBuffer().Length).TrimEnd("\0"[0]);

    internal void Stop()
    {
      Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() => AudioPlaybackEngine.Instance.Stop()));
      this.isStopped = true;
      try
      {
        this.RefreshObjectsOnUpdate = true;
        this.RefreshObjectsNoThread = false;
        this.lockNextInstruction = false;
        this.breakAll = false;
        if (PythonCodeRunner.gameScene != null)
          PythonCodeRunner.gameScene.Reset();
        if (this.thread != null)
        {
          this.thread.Interrupt();
          this.timerCheckIsAbortedThread.Interval = new TimeSpan(0, 0, 0, 0, 10);
          this.timerCheckIsAbortedThread.Start();
          this.eventWaitHandle.Reset();
          this.WaitForEvent(this.eventWaitHandle, new TimeSpan(1, 0, 0));
          this.thread.Abort();
          this.eventWaitHandle.Reset();
          this.timerCheckIsAbortedThread.Start();
          this.WaitForEvent(this.eventWaitHandle, new TimeSpan(1, 0, 0));
        }
      }
      catch
      {
      }
      if (this.hightLightEvent != null)
        this.hightLightEvent(new int?(-1), 0, false, "");
      this.currentState = PythonCodeRunner.RunnerState.stopped;
      if (this.currentStateChangedEvent == null)
        return;
      this.currentStateChangedEvent(this.currentState);
    }

    private bool WaitForEvent(EventWaitHandle eventHandle, TimeSpan timeout)
    {
      bool didWait = false;
      DispatcherFrame frame = new DispatcherFrame();
      new Thread((ThreadStart) (() =>
      {
        didWait = eventHandle.WaitOne(timeout);
        frame.Continue = false;
      })).Start();
      Dispatcher.PushFrame(frame);
      return didWait;
    }

    private void TimerCheckIsAbortedThread_Tick(object sender, EventArgs e)
    {
      if (this.thread.ThreadState != ThreadState.Stopped && this.thread.ThreadState != ThreadState.Aborted)
        return;
      this.timerCheckIsAbortedThread.Stop();
      this.eventWaitHandle.Set();
    }

    internal string GetCode() => this.code;

    internal enum RunnerState
    {
      running,
      finished,
      stopped,
      errored,
    }

    internal delegate void CurrentStateChanged(PythonCodeRunner.RunnerState runnerState);

    internal delegate void CodeWasModify();

    internal delegate void ShowGameScene(GameScene gameScene);

    internal delegate void StopPressedExternal();

    internal delegate void HighlihtLine(
      int? line,
      int startindex,
      bool isError,
      string errorMessage);

    internal delegate void CodesMatch(bool isMatch, string properOutput, string runnerOutput);

    internal delegate string ReadLineDelegate(string message);

    internal delegate void RefreshOutputAndVariables(string output, string variables);

    internal delegate void RefreshInputView();
  }
}
