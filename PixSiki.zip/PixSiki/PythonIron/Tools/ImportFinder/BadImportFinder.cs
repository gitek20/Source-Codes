﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.ImportFinder.BadImportFinder
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.Collections.Generic;
using System.Linq;

namespace PixBlocks.PythonIron.Tools.ImportFinder
{
  internal class BadImportFinder
  {
    public static string FindImports(string code)
    {
      string[] strArray = code.Split("\n"[0]);
      string str1 = "";
      foreach (string str2 in strArray)
      {
        string str3 = str2;
        bool flag = false;
        int num = str2.IndexOf("import ");
        switch (num)
        {
          case -1:
            if (flag)
            {
              List<string> list = ((IEnumerable<string>) "math,cmath,time,datetime,array,binascii,exceptions,operator,thread,sys,re".Split(","[0])).ToList<string>();
              string str4 = str2.Substring(num + "import ".Length).Replace("\r", "");
              char[] chArray1 = new char[1]{ ","[0] };
              foreach (string str5 in str4.Split(chArray1))
              {
                char[] chArray2 = new char[1]{ " "[0] };
                string str6 = str5.TrimEnd(chArray2).TrimStart(" "[0]);
                if (!list.Contains(str6))
                  throw new Exception("No module named " + str6);
              }
            }
            str1 = str1 + str3 + "\n";
            continue;
          case 0:
            flag = true;
            goto case -1;
          default:
            if (str2.Contains(" import "))
            {
              flag = true;
              goto case -1;
            }
            else
              goto case -1;
        }
      }
      return str1;
    }
  }
}
