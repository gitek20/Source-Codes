﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Integration.Sprite
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using IronPython.Runtime;
using PixBlocks.PythonIron.Tools.Game;
using PixBlocks.PythonIron.Tools.Models;
using System;

namespace PixBlocks.PythonIron.Tools.Integration
{
  public class Sprite
  {
    private bool isDestroyed;
    private bool _flip;
    private Pen _pen;
    private double multiply = Math.PI / 180.0;
    private bool drawLine;
    private double lineSize = 1.0;
    private double _x;
    private double _y;
    private double _size = 50.0;
    private int _image;
    private Vector _position = new Vector(0.0, 0.0);
    private double _angle;
    private Color _color = new Color(15, 142, (int) byte.MaxValue);
    private Color _penColor = new Color(0, 0, (int) byte.MaxValue);
    private bool _penOn;
    private double _penSize = 1.0;
    private string _text;
    private bool isVisible;
    public bool _privIsArrow;

    public bool collide(Sprite sprite)
    {
      if (sprite.isDestroyed || this.isDestroyed || (!this.isVisible || !sprite.isVisible))
        return false;
      double num = this._size * 0.5 + sprite._size * 0.5;
      return Math.Abs(sprite._x - this._x) <= num && Math.Abs(sprite._y - this._y) <= num && Math.Sqrt((sprite._x - this._x) * (sprite._x - this._x) + (sprite._y - this._y) * (sprite._y - this._y)) < num;
    }

    public bool collide(List sprites)
    {
      if (this.isDestroyed || !this.isVisible)
        return false;
      foreach (object sprite in sprites)
      {
        if (this.collide(sprite as Sprite))
          return true;
      }
      return false;
    }

    public void move(double distance)
    {
      if (distance == double.NaN)
        throw new Exception("NaN value");
      double num = 90.0;
      this.position = new Vector(this._x + distance * Math.Sin(this.multiply * (-this.angle + num)), this._y + distance * Math.Cos(this.multiply * (-this.angle + num)));
    }

    internal void set_xyPrivate(double nx, double ny)
    {
      this._x = Math.Min(Math.Max(-100.0, nx), 100.0);
      this._y = Math.Min(Math.Max(-100.0, ny), 100.0);
      this.RefreshView();
    }

    public bool IsVisible
    {
      get => this.isVisible;
      set
      {
        this.isVisible = value;
        this.RefreshView();
      }
    }

    public int image
    {
      get => this._image;
      set
      {
        this._image = (double) value != double.NaN ? value : throw new Exception("NaN value");
        this._text = (string) null;
        this.RefreshView();
      }
    }

    public string text
    {
      get => this._text;
      set
      {
        this._text = value;
        this.RefreshView();
      }
    }

    public double size
    {
      get => this._size;
      set
      {
        this._size = value != double.NaN ? Math.Min(Math.Max(0.0, value), 400.0) : throw new Exception("NaN value");
        this.RefreshView();
      }
    }

    public double angle
    {
      get => this._angle;
      set
      {
        this._angle = value != double.NaN ? value : throw new Exception("NaN value");
        this.RefreshView();
      }
    }

    internal double xPrivate
    {
      get => this._x;
      set
      {
        this._x = Math.Min(Math.Max(-100.0, value), 100.0);
        this.RefreshView();
      }
    }

    internal double yPrivate
    {
      get => this._y;
      set
      {
        this._y = Math.Min(Math.Max(-100.0, value), 100.0);
        this.RefreshView();
      }
    }

    public bool IsDestroyed
    {
      get => this.isDestroyed;
      set => this.isDestroyed = value;
    }

    public Color color
    {
      get => this._color;
      set
      {
        this._color = new Color(value);
        this.RefreshView();
      }
    }

    public bool flip
    {
      get => this._flip;
      set
      {
        this._flip = value;
        this.RefreshView();
      }
    }

    public Color pen_colorPrivate
    {
      get => this._penColor;
      set => this._penColor = new Color(value);
    }

    public bool pen_onPrivate
    {
      get => this._penOn;
      set => this._penOn = value;
    }

    public double pen_sizePrivate
    {
      get => this._penSize;
      set => this._penSize = value;
    }

    public Vector position
    {
      get
      {
        this._position.SetSprite(this);
        return this._position;
      }
      set
      {
        this._position = new Vector(Math.Min(Math.Max(-100.0, value.x), 100.0), Math.Min(Math.Max(-100.0, value.y), 100.0));
        this.position.SetSprite(this);
        this.set_xyPrivate(this._position.x, this._position.y);
      }
    }

    public Pen pen
    {
      get
      {
        if (this._pen == null)
          this._pen = new Pen(this);
        return this._pen;
      }
    }

    public SpriteView SpriteView { get; internal set; }

    public virtual void update()
    {
    }

    public event Sprite.RefreshDelegare refreshEvent;

    private void RefreshView()
    {
      if (this.refreshEvent == null)
        return;
      this.refreshEvent(this);
    }

    internal string AllObjectDescription()
    {
      double num = this._angle % 360.0;
      if (num < 0.0)
        num += 360.0;
      return this.flip.ToString() + "_" + ((int) (this._x + 0.3)).ToString() + "_" + ((int) (this._y + 0.3)).ToString() + "_" + ((int) (this._size + 0.3)).ToString() + "_" + this._image.ToString() + "_" + this._color.r.ToString() + "_" + this._color.g.ToString() + "_" + this._color.b.ToString() + "_" + ((int) (num + 0.3)).ToString();
    }

    internal void DisposeAllElements() => this.SpriteView = (SpriteView) null;

    public delegate void RefreshDelegare(Sprite sprite);
  }
}
