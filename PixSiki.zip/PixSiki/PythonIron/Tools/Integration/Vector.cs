﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Integration.Vector
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.PythonIron.Tools.Game;
using System;

namespace PixBlocks.PythonIron.Tools.Integration
{
  public class Vector
  {
    private Sprite sprite;
    private double _x;
    private double _y;

    public void SetSprite(Sprite sprite) => this.sprite = sprite;

    public Vector(double xx, double yy)
    {
      if (xx == double.NaN)
        throw new Exception("NaN value");
      if (yy == double.NaN)
        throw new Exception("NaN value");
      this._x = xx;
      this._y = yy;
    }

    public double length => Math.Sqrt(this._x * this._x + this._y * this._y);

    public double angle => 180.0 * Math.Atan2(this._y, this._x) / Math.PI;

    public double x
    {
      get => this._x;
      set
      {
        this._x = value;
        if (this.sprite == null)
          return;
        this._x = value != double.NaN ? Math.Min(Math.Max(-100.0, value), 100.0) : throw new Exception("NaN value");
        this.sprite.xPrivate = this._x;
      }
    }

    public double y
    {
      get => this._y;
      set
      {
        this._y = value;
        if (this.sprite == null)
          return;
        this._y = value != double.NaN ? Math.Min(Math.Max(-100.0, value), 100.0) : throw new Exception("NaN value");
        this.sprite.yPrivate = this._y;
      }
    }

    public Vector __add__(Vector v) => new Vector(this._x + v._x, this._y + v._y);

    public Vector __sub__(Vector v) => new Vector(this._x - v._x, this._y - v._y);

    public Vector __iadd__(Vector v) => this.__add__(v);

    public Vector __isub__(Vector v) => this.__sub__(v);

    internal void SetGameScene(GameScene.Mouse mouse) => throw new NotImplementedException();
  }
}
