﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Integration.Color
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;

namespace PixBlocks.PythonIron.Tools.Integration
{
  public class Color
  {
    private int _r;
    private int _g;
    private int _b;

    public Color(int r, int g, int b)
    {
      this._r = Math.Max(0, Math.Min(r, (int) byte.MaxValue));
      this._g = Math.Max(0, Math.Min(g, (int) byte.MaxValue));
      this._b = Math.Max(0, Math.Min(b, (int) byte.MaxValue));
    }

    public Color(Color color)
    {
      this._r = color.r;
      this._g = color.g;
      this._b = color.b;
    }

    public int r => this._r;

    public int g => this._g;

    public int b => this._b;
  }
}
