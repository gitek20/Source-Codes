﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Integration.Sound
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using IronPython.Runtime;
using PixBlocks.SoundPlayer.SoundPlayer.Effects;
using PixBlocks.SoundPlayer.SoundPlayer.Music;
using PixBlocks.SoundPlayer.SoundPlayer.SoundEngine;
using System;
using System.Windows;
using System.Windows.Threading;

namespace PixBlocks.PythonIron.Tools.Integration
{
  public class Sound
  {
    public void play(string music)
    {
      if (music == null || music.Length < 2)
        throw new Exception("Track " + music + " does not exist");
      int result = -1;
      if (!int.TryParse(music.Substring(1), out result))
        throw new Exception("Track " + music + " does not exist");
      if ((int) music[0] == (int) "m"[0])
      {
        AudioPlaybackEngine.Instance.Stop();
        MusicPlayer.Instance.Play(result);
      }
      if ((int) music[0] == (int) "e"[0])
        EffectsPlayer.Instance.PlayEffect(result);
      if ((int) music[0] != (int) "n"[0])
        return;
      EffectsPlayer.Instance.PlayNote(result);
    }

    public void play(List sound)
    {
      float[] sound1 = new float[sound.__len__()];
      for (int index = 0; index < sound.__len__(); ++index)
        sound1[index] = !(sound[index] is int) ? Math.Max(-1f, Math.Min(1f, (float) (double) sound[index])) : Math.Max(-1f, Math.Min(1f, (float) (int) sound[index]));
      for (int index = 0; index < Math.Min(100, sound1.Length - 1); ++index)
      {
        sound1[index] = sound1[index] * ((float) index / 100f);
        sound1[sound1.Length - 1 - index] = sound1[sound1.Length - 1 - index] * ((float) index / 100f);
      }
      EffectsPlayer.Instance.PlaySound(sound1);
    }

    public void stop() => Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() => MusicPlayer.Instance.Stop()));
  }
}
