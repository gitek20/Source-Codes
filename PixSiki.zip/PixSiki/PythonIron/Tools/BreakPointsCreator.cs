﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.BreakPointsCreator
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Collections.Generic;
using System.Linq;

namespace PixBlocks.PythonIron.Tools
{
  internal class BreakPointsCreator
  {
    public static string keyWord = "pix.breakpoint";

    public static string CreateInlineBreakPoints(string code)
    {
      char[] array = new List<char>() { "\t"[0], " "[0] }.ToArray();
      List<string> list = ((IEnumerable<string>) code.Split("\n"[0])).ToList<string>();
      List<string> stringList = new List<string>();
      int num = 0;
      foreach (string str1 in list)
      {
        string str2 = str1.Replace("\r", "").TrimEnd(array);
        string oldValue = str2.TrimStart(array);
        string str3 = str2;
        if (oldValue != "")
          str3 = str2.Replace(oldValue, "");
        string str4 = "";
        if (str2.Length > 1 && (str2[0].ToString() ?? "") != "#")
        {
          string str5 = str2[str2.Length - 1].ToString() ?? "";
          if (str5 == ":" && oldValue.Length > 3 && oldValue.Substring(0, 3) == "if ")
            oldValue = "if " + BreakPointsCreator.keyWord + "(" + num.ToString() + ") and " + oldValue.Substring(3);
          if (str5 == ";")
            str4 = BreakPointsCreator.keyWord + "(" + num.ToString() + ");";
          if (str5 != ":" && str5 != ";")
            str4 = BreakPointsCreator.keyWord + "(" + num.ToString() + ");";
        }
        stringList.Add(str3 + str4 + oldValue);
        ++num;
      }
      stringList.Add(BreakPointsCreator.keyWord + "(" + num.ToString() + ")");
      string str6 = "";
      stringList.Insert(0, "import clr;clr.AddReference('PixBlocks');from PixBlocks.PythonIron.Tools.Integration import * ");
      foreach (string str1 in stringList)
        str6 = str6 + str1 + "\r\n";
      return str6;
    }
  }
}
