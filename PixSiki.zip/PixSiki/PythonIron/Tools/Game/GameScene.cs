﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Game.GameScene
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.PythonIron.Tools.Integration;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace PixBlocks.PythonIron.Tools.Game
{
  public class GameScene
  {
    private Color _background = new Color((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
    private PythonCodeRunner pythonCodeRunner;
    public static GameScene gameSceneStatic;
    private List<Sprite> gameObjects = new List<Sprite>();
    private List<Sprite> newAddedSprites = new List<Sprite>();
    private bool isGameStarted;
    private bool stopGame;
    public GameScene.Mouse mouse = new GameScene.Mouse();
    public Keys keyboard = new Keys();

    public event GameScene.ClearBoardDelegate clearBoard;

    public void clear_pen()
    {
      if (this.clearBoard == null)
        return;
      this.clearBoard(true);
    }

    internal void ClearBoard()
    {
      if (this.clearBoard == null)
        return;
      this.clearBoard(false);
    }

    public event GameScene.BackgroundChange backgroundChange;

    public Color background
    {
      get => this._background;
      set
      {
        if (this.backgroundChange == null)
          return;
        this._background = value;
        this.backgroundChange(value);
      }
    }

    public PythonCodeRunner PythonCodeRunner => this.pythonCodeRunner;

    public GameScene(PythonCodeRunner pythonCodeRunner)
    {
      this.pythonCodeRunner = pythonCodeRunner;
      pythonCodeRunner.currentStateChangedEvent += new PythonCodeRunner.CurrentStateChanged(this.PythonCodeRunner_currentStateChangedEvent);
      this.stopGame = false;
      this.isGameStarted = false;
      GameScene.gameSceneStatic = this;
    }

    private void PythonCodeRunner_currentStateChangedEvent(PythonCodeRunner.RunnerState runnerState)
    {
      if (runnerState != PythonCodeRunner.RunnerState.stopped)
        return;
      this.Reset();
    }

    public event GameScene.AddingNewSprite addingNewSpriteEvnt;

    public void add(Sprite gameObject)
    {
      gameObject.IsDestroyed = false;
      gameObject.IsVisible = true;
      this.stopGame = false;
      if (gameObject.IsDestroyed)
        return;
      if (!this.gameObjects.Contains(gameObject))
        this.gameObjects.Add(gameObject);
      if (this.pythonCodeRunner.RefreshObjectsOnUpdate || gameObject.pen_onPrivate)
      {
        if (this.addingNewSpriteEvnt == null)
          return;
        this.addingNewSpriteEvnt(gameObject);
      }
      else
        this.newAddedSprites.Add(gameObject);
    }

    public void stop()
    {
      this.stopGame = true;
      this.isGameStarted = false;
    }

    public void remove(Sprite gameObject)
    {
      gameObject.IsVisible = false;
      gameObject.IsDestroyed = true;
    }

    public void start()
    {
      if (this.isGameStarted)
        return;
      this.isGameStarted = true;
      this.stopGame = false;
      for (int index1 = 0; index1 < int.MaxValue; ++index1)
      {
        DateTime now = DateTime.Now;
        long ticks = now.Ticks;
        if (this.stopGame)
          break;
        this.pythonCodeRunner.RefreshObjectsOnUpdate = this.pythonCodeRunner.ShowHighLines;
        for (int index2 = 0; index2 < this.gameObjects.Count && !this.stopGame; ++index2)
        {
          if (!this.gameObjects[index2].IsDestroyed)
            this.gameObjects[index2].update();
        }
        this.pythonCodeRunner.RefreshObjectsOnUpdate = true;
        this.PythonCodeRunner.breakpoint(this.PythonCodeRunner.LastLineNumber);
        if (!this.pythonCodeRunner.ShowHighLines)
          Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
          {
            this.pythonCodeRunner.RefreshObjectsNoThread = true;
            foreach (Sprite newAddedSprite in this.newAddedSprites)
            {
              if (this.addingNewSpriteEvnt != null)
                this.addingNewSpriteEvnt(newAddedSprite);
            }
            this.newAddedSprites.Clear();
            this.pythonCodeRunner.RefreshObjectsNoThread = false;
            for (int index = 0; index < this.gameObjects.Count; ++index)
            {
              if (this.gameObjects[index].SpriteView != null)
                this.gameObjects[index].SpriteView.RefreshSprite();
            }
          }));
        now = DateTime.Now;
        int num = (int) ((now.Ticks - ticks) / 10000L);
        if (num < 50)
          Thread.Sleep(50 - num);
        this.keyboard.IterateSteps();
      }
    }

    public event GameScene.ResetView resetViewEvent;

    internal void Reset()
    {
      this.stopGame = true;
      this.ClearBoard();
      this.gameObjects = new List<Sprite>();
      if (this.resetViewEvent == null)
        return;
      try
      {
        Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() => this.resetViewEvent()));
      }
      catch
      {
      }
    }

    public void ShowAllSprites()
    {
      for (int index1 = 0; index1 < 10; ++index1)
      {
        for (int index2 = 0; index2 < 10; ++index2)
        {
          Sprite gameObject = (Sprite) new Arrow();
          gameObject.image = index2 * 10 + index1;
          gameObject.set_xyPrivate((double) ((index1 - 5) * 20 + 10), (double) ((-index2 + 5) * 20) - 6.5);
          gameObject.size = 8.0;
          this.add(gameObject);
        }
      }
    }

    public bool key(string k) => this.keyboard.get(k);

    public delegate void ClearBoardDelegate(bool clearPenOnly);

    public delegate void BackgroundChange(Color index);

    public delegate void AddingNewSprite(Sprite sprite);

    public delegate void ResetView();

    public class Mouse
    {
      public bool _mouseIsEntered;
      private PixBlocks.PythonIron.Tools.Integration.Vector _position = new PixBlocks.PythonIron.Tools.Integration.Vector(0.0, 0.0);
      internal double x;
      internal double y;

      public PixBlocks.PythonIron.Tools.Integration.Vector position
      {
        get
        {
          this._position = new PixBlocks.PythonIron.Tools.Integration.Vector(this.x, this.y);
          return this._position;
        }
      }

      public bool pressed
      {
        get
        {
          if (!this._mouseIsEntered)
            return false;
          bool result = false;
          Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
          {
            if (System.Windows.Input.Mouse.LeftButton != MouseButtonState.Pressed && System.Windows.Input.Mouse.RightButton != MouseButtonState.Pressed)
              return;
            result = true;
          }));
          return result;
        }
      }
    }
  }
}
