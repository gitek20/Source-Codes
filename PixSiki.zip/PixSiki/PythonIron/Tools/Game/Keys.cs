﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Game.Keys
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Collections.Generic;
using System.Linq;

namespace PixBlocks.PythonIron.Tools.Game
{
  public class Keys
  {
    private Dictionary<string, Keys.KeyState> dict = new Dictionary<string, Keys.KeyState>();

    public string TransformKey(string key)
    {
      key = key.Replace("numpa", "");
      for (int index = 0; index < 10; ++index)
        key = key.Replace("d" + index.ToString(), index.ToString() ?? "");
      return key;
    }

    public void keyDown(string key)
    {
      key = this.TransformKey(key);
      if (this.dict.ContainsKey(key))
      {
        Keys.KeyState keyState = this.dict[key];
        if (keyState == Keys.KeyState.pressNextIteration || keyState == Keys.KeyState.unpressed || keyState == Keys.KeyState.pressAndUnpressNextIteration)
          this.dict[key] = Keys.KeyState.pressNextIteration;
        if (keyState != Keys.KeyState.PRESSED && keyState != Keys.KeyState.PRESSEDunpresNextIteration && keyState != Keys.KeyState.PRESSEDForOneIteration)
          return;
        this.dict[key] = Keys.KeyState.PRESSED;
      }
      else
        this.dict.Add(key, Keys.KeyState.pressNextIteration);
    }

    internal void keyUp(string key)
    {
      key = this.TransformKey(key);
      if (this.dict.ContainsKey(key))
      {
        Keys.KeyState keyState = this.dict[key];
        if (keyState == Keys.KeyState.PRESSED || keyState == Keys.KeyState.PRESSEDunpresNextIteration)
          this.dict[key] = Keys.KeyState.PRESSEDunpresNextIteration;
        if (keyState == Keys.KeyState.PRESSEDForOneIteration)
          this.dict[key] = Keys.KeyState.PRESSEDForOneIteration;
        if (keyState != Keys.KeyState.pressNextIteration && keyState != Keys.KeyState.pressAndUnpressNextIteration && keyState != Keys.KeyState.unpressed)
          return;
        this.dict[key] = Keys.KeyState.pressAndUnpressNextIteration;
      }
      else
        this.dict.Add(key, Keys.KeyState.PRESSEDunpresNextIteration);
    }

    public void IterateSteps()
    {
      foreach (string key in this.dict.Keys.ToList<string>())
      {
        int num = (int) this.dict[key];
        if (num == 0)
          this.dict[key] = Keys.KeyState.PRESSED;
        if (num == 1)
          this.dict[key] = Keys.KeyState.unpressed;
        if (num == 3)
          this.dict[key] = Keys.KeyState.unpressed;
        if (num == 2)
          this.dict[key] = Keys.KeyState.PRESSEDForOneIteration;
      }
    }

    public bool get(string key)
    {
      if (this.dict.ContainsKey(key))
      {
        switch (this.dict[key])
        {
          case Keys.KeyState.PRESSEDunpresNextIteration:
          case Keys.KeyState.PRESSEDForOneIteration:
          case Keys.KeyState.PRESSED:
            return true;
        }
      }
      return false;
    }

    public enum KeyState
    {
      pressNextIteration,
      PRESSEDunpresNextIteration,
      pressAndUnpressNextIteration,
      PRESSEDForOneIteration,
      unpressed,
      PRESSED,
    }
  }
}
