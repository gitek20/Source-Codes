﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.PythonIron.Tools.Integration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm
{
  internal class LineJoinAlgorithm
  {
    private Dictionary<string, List<PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo>> keyValuePairs = new Dictionary<string, List<PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo>>();

    public List<Line> JoinLines(List<Line> lines)
    {
      foreach (Line line in lines)
      {
        PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo lineInfo1 = new PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo(line, false);
        if (!this.keyValuePairs.ContainsKey(lineInfo1.description))
          this.keyValuePairs.Add(lineInfo1.description, new List<PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo>());
        this.keyValuePairs[lineInfo1.description].Add(lineInfo1);
        PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo lineInfo2 = new PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo(line, true);
        if (!this.keyValuePairs.ContainsKey(lineInfo2.description))
          this.keyValuePairs.Add(lineInfo2.description, new List<PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo>());
        this.keyValuePairs[lineInfo2.description].Add(lineInfo2);
      }
      foreach (List<PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo> lineInfoList in this.keyValuePairs.Values.ToList<List<PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo>>())
      {
        double val1_1 = double.MaxValue;
        double val1_2 = double.MinValue;
        double val1_3 = double.MaxValue;
        double val1_4 = double.MinValue;
        foreach (PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo lineInfo in lineInfoList)
        {
          val1_1 = Math.Min(val1_1, Math.Min(lineInfo.line.X1, lineInfo.line.X2));
          val1_2 = Math.Max(val1_2, Math.Max(lineInfo.line.X1, lineInfo.line.X2));
          val1_3 = Math.Min(val1_3, Math.Min(lineInfo.line.Y1, lineInfo.line.Y2));
          val1_4 = Math.Max(val1_4, Math.Max(lineInfo.line.Y1, lineInfo.line.Y2));
        }
        foreach (PixBlocks.PythonIron.Tools.Game.LineJoinAlgorithm.LineJoinAlgorithm.LineInfo lineInfo in lineInfoList)
        {
          lineInfo.line.X1 = val1_1;
          lineInfo.line.X2 = val1_1;
          lineInfo.line.Y1 = val1_1;
          lineInfo.line.X1 = val1_1;
        }
      }
      return new List<Line>();
    }

    private class LineInfo
    {
      public string description = "";
      public bool toRemove;
      public bool beginX1;
      public Line line;

      public LineInfo(Line line, bool beginX1)
      {
        this.line = line;
        this.beginX1 = beginX1;
        Line line1 = line;
        string str1 = ((int) (line1.X1 + 0.3)).ToString() + "_" + ((int) (line1.Y1 + 0.3)).ToString() + "_" + ((int) (line1.X2 + 0.3)).ToString() + "_" + ((int) (line1.Y2 + 0.3)).ToString();
        string strB = ((int) (line1.X2 + 0.3)).ToString() + "_" + ((int) (line1.Y2 + 0.3)).ToString() + "_" + ((int) (line1.X1 + 0.3)).ToString() + "_" + ((int) (line1.Y1 + 0.3)).ToString();
        string str2;
        string str3;
        double angle;
        if (str1.CompareTo(strB) < 0)
        {
          str2 = strB;
          str3 = str1;
          angle = new Vector(line1.X1 - line1.X2, line1.Y1 - line1.Y2).angle;
        }
        else
        {
          str2 = str1;
          str3 = strB;
          angle = new Vector(line1.X2 - line1.X1, line1.Y2 - line1.Y1).angle;
        }
        int num = (int) (angle * 5.0 + 0.3);
        string str4 = num.ToString() ?? "";
        string[] strArray = new string[7];
        num = (int) (line1.StrokeThickness + 0.3);
        strArray[0] = num.ToString();
        strArray[1] = "_";
        System.Windows.Media.Color color = (line1.Stroke as SolidColorBrush).Color;
        strArray[2] = color.R.ToString();
        strArray[3] = "_";
        color = (line1.Stroke as SolidColorBrush).Color;
        strArray[4] = color.G.ToString();
        strArray[5] = "_";
        color = (line1.Stroke as SolidColorBrush).Color;
        strArray[6] = color.B.ToString();
        string str5 = string.Concat(strArray);
        if (beginX1)
          this.description = str2 + "_" + str4 + "_" + str5;
        else
          this.description = str3 + "_" + str4 + "_" + str5;
      }
    }
  }
}
