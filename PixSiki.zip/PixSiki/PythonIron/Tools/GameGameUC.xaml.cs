﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Tools.Game.GameUC
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.PythonIron.Tools.Integration;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PixBlocks.PythonIron.Tools.Game
{
  public partial class GameUC : System.Windows.Controls.UserControl, IComponentConnector
  {
    private GameScene gameScene;
    public bool isStopped;
    internal bool IsFrozen;
    internal bool startOnWhite;
    public static GameUC pattern;
    private bool isNormal = true;
    internal Grid mainTopGrid;
    internal Viewbox viewbox;
    internal Grid gridToRender;
    internal System.Windows.Shapes.Rectangle rectRound;
    internal Grid backgroundGrid;
    internal Grid lines;
    internal Grid mainGrid;
    internal Canvas canvas;
    internal TextBlock coords;
    internal System.Windows.Controls.TextBox textBox;
    private bool _contentLoaded;

    public GameUC() => this.InitializeComponent();

    public GameUC(GameScene gameScene)
    {
      this.InitializeComponent();
      if (gameScene == null)
        return;
      this.gameScene = gameScene;
      gameScene.resetViewEvent += new GameScene.ResetView(this.GameScene_resetViewEvent);
      gameScene.backgroundChange += new GameScene.BackgroundChange(this.GameScene_backgroundChange);
      gameScene.addingNewSpriteEvnt += new GameScene.AddingNewSprite(this.GameScene_addingNewSpriteEvnt);
      gameScene.clearBoard += new GameScene.ClearBoardDelegate(this.GameScene_clearBoard);
      System.Windows.Application.Current.MainWindow.PreviewKeyDown += new System.Windows.Input.KeyEventHandler(this.MainWindow_PreviewKeyDown);
      System.Windows.Application.Current.MainWindow.PreviewKeyUp += new System.Windows.Input.KeyEventHandler(this.MainWindow_PreviewKeyUp);
      Keyboard.Focus((IInputElement) this.textBox);
      for (int index = 1; index < 20; ++index)
      {
        Line line = new Line();
        line.X1 = (double) (index * 10);
        line.X2 = (double) (index * 10);
        line.Y1 = 0.0;
        line.Y2 = 200.0;
        line.StrokeThickness = 0.15;
        if (index % 5 == 0)
          line.StrokeThickness = 0.4;
        line.Stroke = (System.Windows.Media.Brush) new SolidColorBrush(System.Windows.Media.Color.FromArgb((byte) 15, (byte) 0, (byte) 0, (byte) 0));
        this.lines.Children.Add((UIElement) line);
      }
      for (int index = 1; index < 20; ++index)
      {
        Line line = new Line();
        line.X1 = 0.0;
        line.X2 = 200.0;
        line.Y1 = (double) (index * 10);
        line.Y2 = (double) (index * 10);
        line.StrokeThickness = 0.15;
        if (index % 5 == 0)
          line.StrokeThickness = 0.4;
        line.Stroke = (System.Windows.Media.Brush) new SolidColorBrush(System.Windows.Media.Color.FromArgb((byte) 15, (byte) 0, (byte) 0, (byte) 0));
        this.lines.Children.Add((UIElement) line);
      }
      this.lines.IsHitTestVisible = false;
    }

    private void MainWindow_PreviewKeyUp(object sender, System.Windows.Input.KeyEventArgs e) => this.gameScene.keyboard.keyUp(e.Key.ToString().ToLower());

    private void MainWindow_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e) => this.gameScene.keyboard.keyDown(e.Key.ToString().ToLower());

    private void GameScene_clearBoard(bool clearPenOnly)
    {
      if (!clearPenOnly)
      {
        this.isStopped = true;
        try
        {
          System.Windows.Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
          {
            if (this.IsFrozen)
              return;
            this.canvas.Children.Clear();
            this.mainGrid.Children.Clear();
            this.mainGrid.Visibility = Visibility.Collapsed;
            if ((this.backgroundGrid.Background as SolidColorBrush).Color.A != (byte) 0)
              this.backgroundGrid.Background = (System.Windows.Media.Brush) new SolidColorBrush(Colors.White);
            if (this.startOnWhite)
              this.mainGrid.Background = (System.Windows.Media.Brush) new SolidColorBrush(Colors.White);
            else
              this.mainGrid.Background = (System.Windows.Media.Brush) new SolidColorBrush(Colors.Transparent);
          }));
        }
        catch
        {
        }
      }
      else
        System.Windows.Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() => this.canvas.Children.Clear()));
    }

    private void GameScene_backgroundChange(PixBlocks.PythonIron.Tools.Integration.Color index) => System.Windows.Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
    {
      this.backgroundGrid.Background = (System.Windows.Media.Brush) new SolidColorBrush(System.Windows.Media.Color.FromRgb((byte) index.r, (byte) index.g, (byte) index.b));
      this.lines.Visibility = Visibility.Collapsed;
    }));

    private void GameScene_resetViewEvent()
    {
      if (this.IsFrozen)
        return;
      this.canvas.Children.Clear();
    }

    private void GameScene_addingNewSpriteEvnt(Sprite sprite)
    {
      if (this.isStopped)
        return;
      if (this.gameScene.PythonCodeRunner.RefreshObjectsNoThread)
        this.mainGrid.Children.Add((UIElement) new SpriteView(sprite, this.gameScene, this.canvas));
      else
        System.Windows.Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() => this.mainGrid.Children.Add((UIElement) new SpriteView(sprite, this.gameScene, this.canvas))));
    }

    private WriteableBitmap CaptureScreen(
      Visual target,
      double dpiX,
      double dpiY,
      string filepath)
    {
      if ((target as Grid).ActualHeight == 0.0)
        return (WriteableBitmap) null;
      if (target == null)
        return (WriteableBitmap) null;
      Rect descendantBounds = VisualTreeHelper.GetDescendantBounds(target);
      RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap((int) (descendantBounds.Width * dpiX / 96.0), (int) (descendantBounds.Height * dpiY / 96.0), dpiX, dpiY, PixelFormats.Pbgra32);
      DrawingVisual drawingVisual = new DrawingVisual();
      using (DrawingContext drawingContext = drawingVisual.RenderOpen())
      {
        VisualBrush visualBrush = new VisualBrush(target);
        drawingContext.DrawRectangle((System.Windows.Media.Brush) visualBrush, (System.Windows.Media.Pen) null, new Rect(new System.Windows.Point(), descendantBounds.Size));
      }
      renderTargetBitmap.Render((Visual) drawingVisual);
      return new WriteableBitmap((BitmapSource) renderTargetBitmap);
    }

    public WriteableBitmap GetUniqueDescriptionOfAllRenderedScene()
    {
      foreach (UIElement child in this.mainGrid.Children)
      {
        SpriteView spriteView = child as SpriteView;
        if (spriteView.sprite._privIsArrow)
          spriteView.Visibility = Visibility.Collapsed;
      }
      this.canvas.Opacity = 1.0;
      this.mainGrid.Opacity = 1.0;
      this.lines.Visibility = Visibility.Collapsed;
      this.rectRound.Visibility = Visibility.Collapsed;
      this.backgroundGrid.Background = (System.Windows.Media.Brush) new SolidColorBrush(Colors.White);
      int num = (int) System.Windows.Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, (Delegate) (() => {})).Wait();
      WriteableBitmap writeableBitmap = this.CaptureScreen((Visual) this.gridToRender, 150.0, 150.0, "d:\\" + Guid.NewGuid().ToString() + ".png");
      this.lines.Visibility = Visibility.Visible;
      this.rectRound.Visibility = Visibility.Visible;
      foreach (UIElement child in this.mainGrid.Children)
      {
        SpriteView spriteView = child as SpriteView;
        if (spriteView.sprite._privIsArrow)
          spriteView.Visibility = Visibility.Visible;
      }
      if (!this.isNormal)
      {
        this.canvas.Opacity = 0.15;
        this.mainGrid.Opacity = 0.15;
        this.backgroundGrid.Background = (System.Windows.Media.Brush) new SolidColorBrush(Colors.White);
      }
      else
      {
        this.canvas.Opacity = 1.0;
        this.mainGrid.Opacity = 1.0;
        this.backgroundGrid.Background = (System.Windows.Media.Brush) new SolidColorBrush(Colors.Transparent);
      }
      return writeableBitmap;
    }

    private void mainGrid_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
    {
      if (this.gameScene == null)
        return;
      this.gameScene.mouse.x = e.GetPosition((IInputElement) this.mainGrid).X - 100.0;
      this.gameScene.mouse.y = -(e.GetPosition((IInputElement) this.mainGrid).Y - 100.0);
    }

    private void Window_LostFocus(object sender, RoutedEventArgs e)
    {
    }

    private void MainGridSizeChanged(object sender, SizeChangedEventArgs e) => this.viewbox_SizeChanged((object) null, (SizeChangedEventArgs) null);

    private void viewbox_SizeChanged(object sender, SizeChangedEventArgs e)
    {
    }

    private void mainGrid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      Keyboard.Focus((IInputElement) this.textBox);
      if (this.gameScene == null)
        return;
      this.gameScene.mouse._mouseIsEntered = true;
    }

    internal void DisposeAllElements()
    {
      foreach (UIElement child in this.mainGrid.Children)
        (child as SpriteView).DisposeAllElements();
      if (this.gameScene != null)
      {
        this.gameScene.resetViewEvent -= new GameScene.ResetView(this.GameScene_resetViewEvent);
        this.gameScene.backgroundChange -= new GameScene.BackgroundChange(this.GameScene_backgroundChange);
        this.gameScene.addingNewSpriteEvnt -= new GameScene.AddingNewSprite(this.GameScene_addingNewSpriteEvnt);
        this.gameScene.clearBoard -= new GameScene.ClearBoardDelegate(this.GameScene_clearBoard);
      }
      System.Windows.Application.Current.MainWindow.PreviewKeyDown -= new System.Windows.Input.KeyEventHandler(this.MainWindow_PreviewKeyDown);
      System.Windows.Application.Current.MainWindow.PreviewKeyUp -= new System.Windows.Input.KeyEventHandler(this.MainWindow_PreviewKeyUp);
      this.mainGrid.Children.Clear();
      this.canvas.Children.Clear();
      this.gameScene = (GameScene) null;
    }

    private void mainGrid_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
    {
      if (this.gameScene == null)
        return;
      this.gameScene.mouse._mouseIsEntered = true;
    }

    private void mainGrid_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
    {
      if (this.gameScene == null)
        return;
      double num1 = e.GetPosition((IInputElement) this.mainGrid).X - 100.0;
      double num2 = -(e.GetPosition((IInputElement) this.mainGrid).Y - 100.0);
      if (num1 <= 100.0 && num1 >= -100.0 && (num2 <= 100.0 && num2 >= -100.0))
        return;
      this.gameScene.mouse._mouseIsEntered = false;
    }

    private void mainGrid_MouseUp(object sender, MouseButtonEventArgs e)
    {
      if (this.gameScene == null)
        return;
      this.gameScene.mouse._mouseIsEntered = true;
    }

    internal double SetOpacity
    {
      set
      {
        this.backgroundGrid.Background = (System.Windows.Media.Brush) new SolidColorBrush(Colors.White);
        this.canvas.Opacity = value;
        this.mainGrid.Opacity = value;
        if (value == 1.0)
          return;
        this.isNormal = false;
        GameUC.pattern = this;
      }
    }

    private void gridToRender_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
    {
      if (this.gameScene == null || this.gameScene.PythonCodeRunner != null && (this.gameScene.PythonCodeRunner.CurrentState != PythonCodeRunner.RunnerState.running || this.gameScene.PythonCodeRunner.IsPaused))
      {
        TextBlock coords1 = this.coords;
        string[] strArray1 = new string[5]
        {
          "Vector(",
          null,
          null,
          null,
          null
        };
        System.Windows.Point position = e.GetPosition((IInputElement) this.gridToRender);
        strArray1[1] = ((int) Math.Min(100.0, Math.Max(-100.0, position.X + 0.5 - 100.0))).ToString();
        strArray1[2] = ",";
        position = e.GetPosition((IInputElement) this.gridToRender);
        strArray1[3] = ((int) -Math.Min(100.0, Math.Max(-100.0, position.Y + 0.5 - 100.0))).ToString();
        strArray1[4] = ")";
        string str1 = string.Concat(strArray1);
        coords1.Text = str1;
        System.Drawing.Color colorAt = this.GetColorAt(System.Windows.Forms.Control.MousePosition.X, System.Windows.Forms.Control.MousePosition.Y);
        TextBlock coords2 = this.coords;
        TextBlock textBlock = coords2;
        string[] strArray2 = new string[8];
        strArray2[0] = coords2.Text;
        strArray2[1] = "\r\nColor(";
        byte num = colorAt.R;
        strArray2[2] = num.ToString();
        strArray2[3] = ",";
        num = colorAt.G;
        strArray2[4] = num.ToString();
        strArray2[5] = ",";
        num = colorAt.B;
        strArray2[6] = num.ToString();
        strArray2[7] = ")";
        string str2 = string.Concat(strArray2);
        textBlock.Text = str2;
        this.coords.Visibility = Visibility.Visible;
      }
      else
      {
        this.coords.Text = "";
        this.coords.Visibility = Visibility.Collapsed;
      }
    }

    private System.Drawing.Color GetColorAt(int x, int y)
    {
      Bitmap bitmap = new Bitmap(1, 1);
      System.Drawing.Rectangle rectangle = new System.Drawing.Rectangle(x, y, 1, 1);
      using (Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap))
        graphics.CopyFromScreen(rectangle.Location, System.Drawing.Point.Empty, rectangle.Size);
      return bitmap.GetPixel(0, 0);
    }

    private void gridToRender_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
    {
      this.coords.Text = "";
      this.coords.Visibility = Visibility.Collapsed;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      System.Windows.Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/tools/game/gameuc.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainTopGrid = (Grid) target;
          this.mainTopGrid.SizeChanged += new SizeChangedEventHandler(this.MainGridSizeChanged);
          break;
        case 2:
          this.viewbox = (Viewbox) target;
          this.viewbox.SizeChanged += new SizeChangedEventHandler(this.viewbox_SizeChanged);
          break;
        case 3:
          this.gridToRender = (Grid) target;
          this.gridToRender.MouseMove += new System.Windows.Input.MouseEventHandler(this.gridToRender_MouseMove);
          this.gridToRender.MouseLeave += new System.Windows.Input.MouseEventHandler(this.gridToRender_MouseLeave);
          break;
        case 4:
          this.rectRound = (System.Windows.Shapes.Rectangle) target;
          break;
        case 5:
          this.backgroundGrid = (Grid) target;
          break;
        case 6:
          this.lines = (Grid) target;
          break;
        case 7:
          this.mainGrid = (Grid) target;
          this.mainGrid.MouseMove += new System.Windows.Input.MouseEventHandler(this.mainGrid_MouseMove);
          this.mainGrid.MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          this.mainGrid.MouseEnter += new System.Windows.Input.MouseEventHandler(this.mainGrid_MouseEnter);
          this.mainGrid.MouseLeave += new System.Windows.Input.MouseEventHandler(this.mainGrid_MouseLeave);
          this.mainGrid.MouseUp += new MouseButtonEventHandler(this.mainGrid_MouseUp);
          break;
        case 8:
          this.canvas = (Canvas) target;
          break;
        case 9:
          this.coords = (TextBlock) target;
          break;
        case 10:
          this.textBox = (System.Windows.Controls.TextBox) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
