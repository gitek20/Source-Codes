﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.PythonIron.Views.CodeView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.DataModels.Questions;
using PixBlocks.PythonIron.SyntaxHighlight;
using PixBlocks.PythonIron.Tools;
using PixBlocks.PythonIron.Tools.Game;
using PixBlocks.PythonIron.Views.ColorPicker;
using PixBlocks.PythonIron.Views.HelpView;
using PixBlocks.PythonIron.Views.images;
using PixBlocks.PythonIron.Views.SoundsSelector;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TemplateElementsGenerator.Icons;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.Views.CodeElements.BlockOfCode.images;
using PixBlocks.Views.CongratulationsView;
using PixBlocks.Views.HelpView;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.PythonIron.Views
{
  public partial class CodeView : UserControl, IComponentConnector
  {
    private PythonCodeRunner pythonCodeRunner;
    private Question question;
    public CircleButton maximaliseButton;
    public CircleButton minimaliseButton;
    private SoundSelector soundSelector;
    private ColorPickerMy colorPickerMy;
    private AllSpritesView allSpritesView;
    private HelpUC helpUC;
    private MainWindowMessageBox messageBox;
    internal StackPanel ButtonStack;
    internal Grid bottonGrid;
    internal Grid topGrid;
    internal TextBox inputIronPythonCode;
    internal Grid leftGrid;
    internal Grid inGridIsViewbox;
    internal SyntaxHighlightBox box;
    private bool _contentLoaded;

    public CodeView(PythonCodeRunner pythonCodeRunner, Question question)
    {
      this.pythonCodeRunner = pythonCodeRunner;
      this.question = question;
      this.InitializeComponent();
      this.maximaliseButton = new CircleButton((UserControl) new MaximaliseIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.ButtonStack.Children.Add((UIElement) this.maximaliseButton);
      this.maximaliseButton.Visibility = Visibility.Collapsed;
      this.maximaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.MaximaliseButton_buttonClickedEvent);
      this.minimaliseButton = new CircleButton((UserControl) new MinimaliseIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.ButtonStack.Children.Add((UIElement) this.minimaliseButton);
      this.minimaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.MinimaliseButton_buttonClickedEvent);
      CircleButton circleButton1 = new CircleButton((UserControl) new InfoIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.ButtonStack.Children.Add((UIElement) circleButton1);
      circleButton1.buttonClickedEvent += new CircleButton.ButtonClicker(this.InfoButton_buttonClickedEvent);
      CircleButton circleButton2 = new CircleButton((UserControl) new GameIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.ButtonStack.Children.Add((UIElement) circleButton2);
      circleButton2.buttonClickedEvent += new CircleButton.ButtonClicker(this.InfoButton2_buttonClickedEvent);
      CircleButton circleButton3 = new CircleButton((UserControl) new ColorsIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.ButtonStack.Children.Add((UIElement) circleButton3);
      circleButton3.buttonClickedEvent += new CircleButton.ButtonClicker(this.ColorPick_buttonClickedEvent);
      CircleButton circleButton4 = new CircleButton((UserControl) new SoundIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.ButtonStack.Children.Add((UIElement) circleButton4);
      circleButton4.buttonClickedEvent += new CircleButton.ButtonClicker(this.SoundPick_buttonClickedEvent);
      if (!question.ExamID.HasValue && UserMenager.UserCanSeeSolutions() && (question != null && question.QuestionType == QuestionType.ClassicQuestionType))
      {
        CircleButton circleButton5 = new CircleButton((UserControl) new ShowSolutionIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
        Grid grid = new Grid();
        grid.Width = 10.0;
        this.ButtonStack.Children.Add((UIElement) grid);
        this.ButtonStack.Children.Add((UIElement) circleButton5);
        circleButton5.buttonClickedEvent += new CircleButton.ButtonClicker(this.LookButton_buttonClickedEvent);
        if (!UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Teacher_isTeacher)
        {
          CircleButton circleButton6 = new CircleButton((UserControl) new TrashIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
          this.ButtonStack.Children.Add((UIElement) circleButton6);
          circleButton6.buttonClickedEvent += new CircleButton.ButtonClicker(this.DeleteCode_buttonClickedEvent);
        }
      }
      if (UserMenager.UserIsSuperAdmin())
      {
        this.topGrid.Visibility = Visibility.Visible;
        this.inputIronPythonCode.Text = question.InputIronPythonCode;
        this.inputIronPythonCode.TextChanged += new TextChangedEventHandler(this.InputIronPythonCode_TextChanged);
        pythonCodeRunner.SetCode(question.Code);
      }
      this.box.Text = pythonCodeRunner.GetCode();
      if (question.QuestionType == QuestionType.InfoType)
        this.box.IsReadOnly = true;
      this.box.CurrentHighlighter = HighlighterManager.Instance.Highlighters["VHDL"];
      this.box.TextChanged += new TextChangedEventHandler(this.Box_TextChanged);
      this.Box_TextChanged((object) null, (TextChangedEventArgs) null);
      this.box.IsLineNumbersMarginVisible = false;
      if (pythonCodeRunner != null)
        pythonCodeRunner.hightLightEvent += new PythonCodeRunner.HighlihtLine(this.PythonCodeRunner_hightLightEvent);
      if (!UserMenager.UserIsSuperAdmin())
        return;
      this.box.IsReadOnly = false;
    }

    private void SoundPick_buttonClickedEvent()
    {
      if (this.soundSelector == null)
        this.soundSelector = new SoundSelector();
      if (this.leftGrid.Visibility == Visibility.Collapsed)
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Children.Add((UIElement) this.soundSelector);
        this.leftGrid.Visibility = Visibility.Visible;
      }
      else if (this.leftGrid.Children.Contains((UIElement) this.soundSelector))
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Children.Add((UIElement) this.soundSelector);
        this.leftGrid.Visibility = Visibility.Visible;
      }
    }

    private void DeleteCode_buttonClickedEvent() => this.box.Text = "";

    private void ColorPick_buttonClickedEvent()
    {
      if (this.colorPickerMy == null)
        this.colorPickerMy = new ColorPickerMy();
      if (this.leftGrid.Visibility == Visibility.Collapsed)
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Children.Add((UIElement) this.colorPickerMy);
        this.leftGrid.Visibility = Visibility.Visible;
      }
      else if (this.leftGrid.Children.Contains((UIElement) this.colorPickerMy))
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Children.Add((UIElement) this.colorPickerMy);
        this.leftGrid.Visibility = Visibility.Visible;
      }
    }

    private void MinimaliseButton_buttonClickedEvent()
    {
      this.maximaliseButton.Visibility = Visibility.Visible;
      this.minimaliseButton.Visibility = Visibility.Collapsed;
    }

    private void MaximaliseButton_buttonClickedEvent()
    {
      this.maximaliseButton.Visibility = Visibility.Collapsed;
      this.minimaliseButton.Visibility = Visibility.Visible;
    }

    private void InfoButton2_buttonClickedEvent()
    {
      if (this.allSpritesView == null)
        this.allSpritesView = new AllSpritesView();
      if (this.leftGrid.Visibility == Visibility.Collapsed)
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Children.Add((UIElement) this.allSpritesView);
        this.leftGrid.Visibility = Visibility.Visible;
      }
      else if (this.leftGrid.Children.Contains((UIElement) this.allSpritesView))
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Children.Add((UIElement) this.allSpritesView);
        this.leftGrid.Visibility = Visibility.Visible;
      }
    }

    private void InfoButton_buttonClickedEvent()
    {
      if (this.helpUC == null)
        this.helpUC = new HelpUC();
      if (this.leftGrid.Visibility == Visibility.Collapsed)
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Children.Add((UIElement) this.helpUC);
        this.leftGrid.Visibility = Visibility.Visible;
      }
      else if (this.leftGrid.Children.Contains((UIElement) this.helpUC))
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.leftGrid.Children.Clear();
        this.leftGrid.Children.Add((UIElement) this.helpUC);
        this.leftGrid.Visibility = Visibility.Visible;
      }
    }

    private void InputIronPythonCode_TextChanged(object sender, TextChangedEventArgs e) => this.question.InputIronPythonCode = this.inputIronPythonCode.Text;

    private void PythonCodeRunner_hightLightEvent(
      int? line,
      int startindex,
      bool isError,
      string errorMessage)
    {
      this.box.HighlightLine(line, startindex, isError);
      if (isError)
      {
        this.bottonGrid.Children.Clear();
        this.bottonGrid.Children.Add((UIElement) new ErrorMessage(errorMessage));
      }
      else
        this.bottonGrid.Children.Clear();
    }

    private void Box_TextChanged(object sender, TextChangedEventArgs e)
    {
      this.bottonGrid.Children.Clear();
      if (this.pythonCodeRunner == null)
        return;
      this.pythonCodeRunner.SetCode(this.box.Text);
    }

    private void inGridIsViewbox_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      this.box.Width = this.inGridIsViewbox.ActualWidth / 1.7;
      this.box.Height = this.inGridIsViewbox.ActualHeight / 1.7;
    }

    internal void DisposeAllElements()
    {
    }

    private void button_Click(object sender, RoutedEventArgs e)
    {
    }

    private void LookButton_buttonClickedEvent()
    {
      if (!UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Teacher_isTeacher)
        this.Accept_buttonClickedEvent();
      else if (QuestionsPointsCounter.GetQuestionPoints(this.question) == 0)
      {
        this.messageBox = new MainWindowMessageBox();
        MainWindowStaticController.mainWindow.mainGrid.Children.Add((UIElement) this.messageBox);
        this.messageBox.accept.buttonClickedEvent += new CircleButton.ButtonClicker(this.Accept_buttonClickedEvent);
        this.messageBox.close.buttonClickedEvent += new CircleButton.ButtonClicker(this.Close_buttonClickedEvent);
      }
      else
        this.Accept_buttonClickedEvent();
    }

    private void Close_buttonClickedEvent()
    {
      if (!MainWindowStaticController.mainWindow.mainGrid.Children.Contains((UIElement) this.messageBox))
        return;
      MainWindowStaticController.mainWindow.mainGrid.Children.Remove((UIElement) this.messageBox);
    }

    private void Accept_buttonClickedEvent()
    {
      if (MainWindowStaticController.mainWindow.mainGrid.Children.Contains((UIElement) this.messageBox))
        MainWindowStaticController.mainWindow.mainGrid.Children.Remove((UIElement) this.messageBox);
      if (!UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Teacher_isTeacher)
      {
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) <= 0)
          QuestionsPointsCounter.SetQuestionPoints(this.question, 1);
      }
      else
      {
        CongratulationsStaticManager.GreesStarShow = false;
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) <= 0)
          QuestionsPointsCounter.SetQuestionPoints(this.question, -1);
      }
      CongratulationsStaticManager.ShowCongratulations();
      this.box.Text = this.question.Code;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/pythoniron/views/codeview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.ButtonStack = (StackPanel) target;
          break;
        case 2:
          this.bottonGrid = (Grid) target;
          break;
        case 3:
          this.topGrid = (Grid) target;
          break;
        case 4:
          this.inputIronPythonCode = (TextBox) target;
          break;
        case 5:
          this.leftGrid = (Grid) target;
          break;
        case 6:
          this.inGridIsViewbox = (Grid) target;
          this.inGridIsViewbox.SizeChanged += new SizeChangedEventHandler(this.inGridIsViewbox_SizeChanged);
          break;
        case 7:
          this.box = (SyntaxHighlightBox) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
