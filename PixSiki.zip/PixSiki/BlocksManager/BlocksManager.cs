﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.BlocksManager.BlocksManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.BlocksManager.BasicBlocks;
using PixBlocks.BlocksManager.BasicBlocks.NewBlocks;
using PixBlocks.BlocksManager.BasicBlocks.NewBlocks3;
using PixBlocks.BlocksManager.BasicBlocks.NewBlocks4;
using PixBlocks.DataModels.Code;
using System;
using System.Windows.Controls;

namespace PixBlocks.BlocksManager
{
  internal class BlocksManager
  {
    public static string[] NamesOfBlocks = new string[43]
    {
      "empty",
      "cactus",
      "cactus2",
      "coinGold",
      "flag2",
      "flagBlue2",
      "flagRed2",
      "flagYellow2",
      "grassCenter",
      "grassCliff_left",
      "grassCliff_right",
      "grassCorner_left",
      "grassCorner_right",
      "grassHill_left",
      "grassHill_right",
      "grassMid",
      "keyBlue",
      "keyRed",
      "keyYellow",
      "kolce2",
      "signExit",
      "singExit2",
      "water",
      "waterTop",
      "box",
      "lava",
      "lavaTop",
      "lockBlue",
      "lockRed",
      "lockYellow",
      "spring",
      "sprung",
      "switchBlue",
      "switchBlueressed",
      "brush",
      "floor",
      "ladder",
      "arrowLeft",
      "arrowRight",
      "arrowTop",
      "arrowDown",
      "egg",
      "carrot"
    };

    public static string NameFromColor(Value color)
    {
      if (color.R % 3 == 0)
      {
        int val1 = ((0 + color.B / 3) * 3 + color.G / 3) * 3 + color.R / 3;
        return PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks[Math.Min(val1, PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks.Length - 1)];
      }
      int num = ((0 + (color.B - 1) / 3) * 3 + (color.G - 1) / 3) * 3 + (color.R - 1) / 3;
      return PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks[Math.Min(num + 26, PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks.Length - 1)];
    }

    public static Value ColorFromBlockName(string block)
    {
      int num1 = -1;
      for (int index = 0; index < PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks.Length; ++index)
      {
        if (PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks[index] == block)
        {
          num1 = index;
          break;
        }
      }
      bool flag = false;
      if (num1 > 26)
      {
        num1 -= 26;
        flag = true;
      }
      int r = num1 % 3 * 3;
      int num2 = num1 / 3;
      int g = num2 % 3 * 3;
      int num3 = num2 / 3;
      int b = num3 % 3 * 3;
      int num4 = num3 / 3;
      return flag ? new Value(r + 1, g + 1, b + 1) : new Value(r, g, b);
    }

    public static UserControl GetUCOfBlock(string block)
    {
      int num = -1;
      for (int index = 0; index < PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks.Length; ++index)
      {
        if (PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks[index] == block)
        {
          num = index;
          break;
        }
      }
      switch (num)
      {
        case -1:
          return (UserControl) new bb_empty();
        case 0:
          return (UserControl) new bb_empty();
        case 1:
          return (UserControl) new bb_cactus();
        case 2:
          return (UserControl) new bb_cactus2();
        case 3:
          return (UserControl) new bb_coinGold();
        case 4:
          return (UserControl) new bb_flag2();
        case 5:
          return (UserControl) new bb_flagBlue2();
        case 6:
          return (UserControl) new bb_flagRed2();
        case 7:
          return (UserControl) new bb_flagYello2();
        case 8:
          return (UserControl) new bb_grassCenter();
        case 9:
          return (UserControl) new bb_grassCliff_left();
        case 10:
          return (UserControl) new bb_grassCliff_right();
        case 11:
          return (UserControl) new bb_grassCorner_left();
        case 12:
          return (UserControl) new bb_grassCorner_right();
        case 13:
          return (UserControl) new bb_grassHill_left();
        case 14:
          return (UserControl) new bb_grassHill_right();
        case 15:
          return (UserControl) new bb_grassMid();
        case 16:
          return (UserControl) new bb_keyBlue();
        case 17:
          return (UserControl) new bb_keyRed();
        case 18:
          return (UserControl) new bb_KeyYellow();
        case 19:
          return (UserControl) new bb_kolce2();
        case 20:
          return (UserControl) new bb_signExit();
        case 21:
          return (UserControl) new bb_singnExit2();
        case 22:
          return (UserControl) new bb_water();
        case 23:
          return (UserControl) new bb_waterTop();
        case 24:
          return (UserControl) new bb_box();
        case 25:
          return (UserControl) new bb_lava();
        case 26:
          return (UserControl) new bb_lavaTop();
        case 27:
          return (UserControl) new bb_lockBlue();
        case 28:
          return (UserControl) new bb_lockRed();
        case 29:
          return (UserControl) new bb_lockYellow();
        case 30:
          return (UserControl) new bb_spring();
        case 31:
          return (UserControl) new bb_sprung();
        case 32:
          return (UserControl) new bb_switchBlue();
        case 33:
          return (UserControl) new bb_switchBluePressed();
        case 34:
          return (UserControl) new bb_3brush();
        case 35:
          return (UserControl) new bb_3floor();
        case 36:
          return (UserControl) new bb_3ladder();
        case 37:
          return (UserControl) new bb_4arrowLeft();
        case 38:
          return (UserControl) new bb_4arrowRight();
        case 39:
          return (UserControl) new bb_4arrowTop();
        case 40:
          return (UserControl) new bb_4arrowDown();
        case 41:
          return (UserControl) new bb_4egg();
        case 42:
          return (UserControl) new bb_4carrot();
        default:
          throw new NotImplementedException();
      }
    }
  }
}
