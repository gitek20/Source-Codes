﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.ColorsManager.ColorConverter
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Drawing;
using System.Globalization;

namespace PixBlocks.Tools.ColorsManager
{
  public class ColorConverter
  {
    public static Color ConvertStringToColor(string hex)
    {
      hex = hex.Replace("#", "");
      byte maxValue = byte.MaxValue;
      int startIndex = 0;
      if (hex.Length == 8)
      {
        maxValue = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber);
        startIndex = 2;
      }
      byte num1 = byte.Parse(hex.Substring(startIndex, 2), NumberStyles.HexNumber);
      byte num2 = byte.Parse(hex.Substring(startIndex + 2, 2), NumberStyles.HexNumber);
      byte num3 = byte.Parse(hex.Substring(startIndex + 4, 2), NumberStyles.HexNumber);
      return Color.FromArgb((int) maxValue, (int) num1, (int) num2, (int) num3);
    }
  }
}
