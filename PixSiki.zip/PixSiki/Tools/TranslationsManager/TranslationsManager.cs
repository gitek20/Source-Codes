﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.TranslationsManager.TranslationsManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.Tools.TranslationManager;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.DataStorageConfig;
using PixBlocks.Tools.TranslationsManager.TSVMenager;
using System.Collections.Generic;

namespace PixBlocks.Tools.TranslationsManager
{
  internal class TranslationsManager : ITranslationManager
  {
    public static TSVImporter templatesTranslation;
    public static TSVImporter categoryTranslation;
    public static TSVImporter questionTranslation;
    public static TSVImporter UITranslation;
    public static TSVPythonImporter pythonTamplateTranslation;

    public static string TranslateTemplatesID(string templatesID)
    {
      if (PixBlocks.Tools.TranslationsManager.TranslationsManager.templatesTranslation == null)
        PixBlocks.Tools.TranslationsManager.TranslationsManager.templatesTranslation = new TSVImporter(DataStorageParams.appOnceClickDataPath + "templates_translation.tsv");
      string languageKey = UserMenager.LanguageKey;
      return PixBlocks.Tools.TranslationsManager.TranslationsManager.templatesTranslation.GetTranslation(templatesID, languageKey);
    }

    public static List<string> GetAvaliableLanguages()
    {
      if (PixBlocks.Tools.TranslationsManager.TranslationsManager.templatesTranslation == null)
        PixBlocks.Tools.TranslationsManager.TranslationsManager.templatesTranslation = new TSVImporter(DataStorageParams.appOnceClickDataPath + "templates_translation.tsv");
      return PixBlocks.Tools.TranslationsManager.TranslationsManager.templatesTranslation.LanguagesKeys;
    }

    public static string TranslateCategoryID(string categoryID)
    {
      if (PixBlocks.Tools.TranslationsManager.TranslationsManager.categoryTranslation == null)
        PixBlocks.Tools.TranslationsManager.TranslationsManager.categoryTranslation = new TSVImporter(DataStorageParams.appOnceClickDataPath + "categories_translation.tsv");
      string languageKey = UserMenager.LanguageKey;
      return PixBlocks.Tools.TranslationsManager.TranslationsManager.categoryTranslation.GetTranslation(categoryID, languageKey);
    }

    public static string TranslateQuestionID(string questionID)
    {
      if (PixBlocks.Tools.TranslationsManager.TranslationsManager.questionTranslation == null)
        PixBlocks.Tools.TranslationsManager.TranslationsManager.questionTranslation = new TSVImporter(DataStorageParams.appOnceClickDataPath + "questions_translation.tsv");
      string languageKey = UserMenager.LanguageKey;
      return PixBlocks.Tools.TranslationsManager.TranslationsManager.questionTranslation.GetTranslation(questionID, languageKey);
    }

    public static string TranslateUIID(string UIID)
    {
      if (PixBlocks.Tools.TranslationsManager.TranslationsManager.UITranslation == null)
        PixBlocks.Tools.TranslationsManager.TranslationsManager.UITranslation = new TSVImporter(DataStorageParams.appOnceClickDataPath + "userInterface_translation.tsv");
      string languageKey = UserMenager.LanguageKey;
      return PixBlocks.Tools.TranslationsManager.TranslationsManager.UITranslation.GetTranslation(UIID, languageKey);
    }

    public static List<string> TranslatePythonTemplate(string functionName)
    {
      if (PixBlocks.Tools.TranslationsManager.TranslationsManager.pythonTamplateTranslation == null)
        PixBlocks.Tools.TranslationsManager.TranslationsManager.pythonTamplateTranslation = new TSVPythonImporter(DataStorageParams.appOnceClickDataPath + "pythontemplates_translations.tsv");
      string languageKey = UserMenager.LanguageKey;
      return PixBlocks.Tools.TranslationsManager.TranslationsManager.pythonTamplateTranslation.GetTranslation(functionName, languageKey);
    }

    public static List<string> GetPythonFunctions()
    {
      if (PixBlocks.Tools.TranslationsManager.TranslationsManager.pythonTamplateTranslation == null)
        PixBlocks.Tools.TranslationsManager.TranslationsManager.pythonTamplateTranslation = new TSVPythonImporter(DataStorageParams.appOnceClickDataPath + "pythontemplates_translations.tsv");
      return PixBlocks.Tools.TranslationsManager.TranslationsManager.pythonTamplateTranslation.GetPythonFunctions();
    }

    public string TranslateTemplatesIDc(string templatesID) => PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateTemplatesID(templatesID);

    public string TranslateCategoryIDc(string categoryID) => PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateCategoryID(categoryID);

    public string TranslateQuestionIDc(string questionID) => PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateQuestionID(questionID);

    public string TranslateUIIDc(string UIID) => PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(UIID);
  }
}
