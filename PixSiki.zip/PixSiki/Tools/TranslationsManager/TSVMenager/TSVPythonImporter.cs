﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.TranslationsManager.TSVMenager.TSVPythonImporter
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Collections.Generic;
using System.IO;

namespace PixBlocks.Tools.TranslationsManager.TSVMenager
{
  internal class TSVPythonImporter
  {
    private string[] lines;
    private List<string> languagesKeys = new List<string>();
    private Dictionary<string, TSVPythonTagName> langDict = new Dictionary<string, TSVPythonTagName>();
    private List<TSVPythonTagName> tags = new List<TSVPythonTagName>();

    public List<string> GetTranslation(string function, string languageKey)
    {
      TSVPythonTagName tsvPythonTagName = (TSVPythonTagName) null;
      return this.langDict.TryGetValue(function, out tsvPythonTagName) ? tsvPythonTagName.GetTranslation(languageKey) : (List<string>) null;
    }

    public TSVPythonImporter(string fileName)
    {
      this.lines = File.ReadAllText(fileName).Split("\r"[0]);
      string[] strArray = this.lines[0].Split("\t"[0]);
      for (int index = 1; index < strArray.Length; ++index)
        this.LanguagesKeys.Add(strArray[index]);
      for (int index = 1; index < this.lines.Length; ++index)
      {
        TSVPythonTagName tsvPythonTagName = new TSVPythonTagName(this.lines[index], this.lines[0]);
        if (!this.langDict.ContainsKey(tsvPythonTagName.TagName))
          this.langDict.Add(tsvPythonTagName.TagName, tsvPythonTagName);
      }
    }

    internal List<string> GetPythonFunctions()
    {
      List<string> stringList = new List<string>();
      foreach (string line in this.lines)
      {
        string str1 = line.Remove(line.IndexOf("\t"));
        if (str1 != "")
        {
          string str2 = str1.Replace("\n", "");
          stringList.Add(str2);
        }
      }
      return stringList;
    }

    public List<string> LanguagesKeys => this.languagesKeys;
  }
}
