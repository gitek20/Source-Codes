﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.TranslationsManager.TSVMenager.PythonItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.Tools.TranslationsManager.TSVMenager
{
  internal class PythonItem
  {
    public string LanguageKey { get; }

    public string Description { get; }

    public string Function { get; }

    public string Example { get; }

    public PythonItem(string languageKey, string tag, string function, string example)
    {
      this.LanguageKey = languageKey;
      this.Description = tag;
      this.Function = function;
      this.Example = example;
    }
  }
}
