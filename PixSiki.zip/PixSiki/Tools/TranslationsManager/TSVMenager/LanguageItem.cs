﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.TranslationsManager.TSVMenager.LanguageItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.Tools.TranslationsManager.TSVMenager
{
  internal class LanguageItem
  {
    private string languageKey;
    private string value;

    public LanguageItem(string languageKey, string value)
    {
      this.languageKey = languageKey;
      this.value = value;
    }

    public string LanguageKey => this.languageKey;

    public string Value => this.value;
  }
}
