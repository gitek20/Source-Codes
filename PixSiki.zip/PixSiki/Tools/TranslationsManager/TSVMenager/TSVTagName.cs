﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.TranslationsManager.TSVMenager.TSVTagName
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Collections.Generic;

namespace PixBlocks.Tools.TranslationsManager.TSVMenager
{
  internal class TSVTagName
  {
    private string tagName;
    private List<LanguageItem> items = new List<LanguageItem>();

    public string TagName => this.tagName;

    public string GetTranslation(string languageKey)
    {
      foreach (LanguageItem languageItem in this.items)
      {
        if (languageItem.LanguageKey == languageKey)
          return languageItem.Value;
      }
      foreach (LanguageItem languageItem in this.items)
      {
        if (languageItem.LanguageKey == "EN")
          return languageItem.Value;
      }
      return "NULL!!!";
    }

    public TSVTagName(string tsvTag, string tsvCaption)
    {
      string[] strArray1 = tsvCaption.Split("\t"[0]);
      string[] strArray2 = tsvTag.Split("\t"[0]);
      this.tagName = strArray2[0].Replace("\n", "");
      for (int index = 1; index < strArray2.Length; ++index)
        this.items.Add(new LanguageItem(strArray1[index], strArray2[index]));
    }
  }
}
