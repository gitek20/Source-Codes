﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.TranslationsManager.TSVMenager.TSVPythonTagName
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Collections.Generic;

namespace PixBlocks.Tools.TranslationsManager.TSVMenager
{
  internal class TSVPythonTagName
  {
    private string tagName;
    private List<PythonItem> items = new List<PythonItem>();

    public string TagName => this.tagName;

    public List<string> GetTranslation(string languageKey)
    {
      foreach (PythonItem pythonItem in this.items)
      {
        if (pythonItem.LanguageKey == languageKey)
          return new List<string>()
          {
            pythonItem.Function,
            pythonItem.Description,
            pythonItem.Example
          };
      }
      return (List<string>) null;
    }

    public TSVPythonTagName(string tsvTagLine, string tsvCaption)
    {
      string[] strArray1 = tsvCaption.Split("\t"[0]);
      string[] strArray2 = tsvTagLine.Split("\t"[0]);
      this.tagName = strArray2[0].Replace("\n", "");
      for (int index = 1; index < strArray2.Length; ++index)
        this.items.Add(new PythonItem(strArray1[index], strArray2[index], strArray2[0], strArray2[1]));
    }
  }
}
