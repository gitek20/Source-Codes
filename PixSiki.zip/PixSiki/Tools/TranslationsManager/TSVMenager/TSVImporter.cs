﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.TranslationsManager.TSVMenager.TSVImporter
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Collections.Generic;
using System.IO;

namespace PixBlocks.Tools.TranslationsManager.TSVMenager
{
  internal class TSVImporter
  {
    private List<string> languagesKeys = new List<string>();
    private Dictionary<string, TSVTagName> langDict = new Dictionary<string, TSVTagName>();
    private List<TSVTagName> tags = new List<TSVTagName>();

    public string GetTranslation(string tagID, string languageKey)
    {
      TSVTagName tsvTagName = (TSVTagName) null;
      return this.langDict.TryGetValue(tagID, out tsvTagName) ? tsvTagName.GetTranslation(languageKey) : "";
    }

    public TSVImporter(string fileName)
    {
      string[] strArray1 = File.ReadAllText(fileName).Split("\r"[0]);
      string[] strArray2 = strArray1[0].Split("\t"[0]);
      for (int index = 1; index < strArray2.Length; ++index)
        this.LanguagesKeys.Add(strArray2[index]);
      for (int index = 1; index < strArray1.Length; ++index)
      {
        TSVTagName tsvTagName = new TSVTagName(strArray1[index], strArray1[0]);
        if (!this.langDict.ContainsKey(tsvTagName.TagName))
          this.langDict.Add(tsvTagName.TagName, tsvTagName);
      }
    }

    public List<string> LanguagesKeys => this.languagesKeys;
  }
}
