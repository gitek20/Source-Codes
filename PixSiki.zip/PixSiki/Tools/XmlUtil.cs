﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.XmlUtil
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace PixBlocks.Tools
{
  public class XmlUtil
  {
    public static string ToXml(object objToXml, bool includeNameSpace)
    {
      try
      {
        XmlSerializer xmlSerializer = new XmlSerializer(objToXml.GetType());
        StringWriter stringWriter = new StringWriter();
        if (!includeNameSpace)
        {
          XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
          namespaces.Add("", "");
          xmlSerializer.Serialize((TextWriter) stringWriter, objToXml, namespaces);
        }
        else
          xmlSerializer.Serialize((TextWriter) stringWriter, objToXml);
        return stringWriter.ToString();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public static void ToXml(object objToXml, string filePath, bool includeNameSpace)
    {
      StreamWriter streamWriter = (StreamWriter) null;
      try
      {
        XmlSerializer xmlSerializer = new XmlSerializer(objToXml.GetType());
        streamWriter = new StreamWriter(filePath);
        if (!includeNameSpace)
        {
          XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
          namespaces.Add("", "");
          xmlSerializer.Serialize((TextWriter) streamWriter, objToXml, namespaces);
        }
        else
          xmlSerializer.Serialize((TextWriter) streamWriter, objToXml);
      }
      catch (Exception ex)
      {
        throw ex;
      }
      finally
      {
        streamWriter?.Close();
      }
    }

    public static void ToXml(
      object objToXml,
      string filePath,
      bool includeNameSpace,
      bool includeStartDocument)
    {
      XmlUtil.SpecialXmlWriter specialXmlWriter1 = (XmlUtil.SpecialXmlWriter) null;
      try
      {
        XmlSerializer xmlSerializer = new XmlSerializer(objToXml.GetType());
        specialXmlWriter1 = new XmlUtil.SpecialXmlWriter(filePath, (Encoding) null, includeStartDocument);
        XmlSerializerNamespaces serializerNamespaces = new XmlSerializerNamespaces();
        serializerNamespaces.Add("", "");
        XmlUtil.SpecialXmlWriter specialXmlWriter2 = specialXmlWriter1;
        object o = objToXml;
        XmlSerializerNamespaces namespaces = serializerNamespaces;
        xmlSerializer.Serialize((XmlWriter) specialXmlWriter2, o, namespaces);
      }
      catch (Exception ex)
      {
        throw ex;
      }
      finally
      {
        specialXmlWriter1?.Close();
      }
    }

    public static object XmlTo(string xmlString, Type type, bool ignoreNameSpace)
    {
      StringReader stringReader = (StringReader) null;
      try
      {
        XmlSerializer xmlSerializer = new XmlSerializer(type);
        object obj;
        if (ignoreNameSpace)
        {
          stringReader = new StringReader(xmlString);
          obj = xmlSerializer.Deserialize((XmlReader) new XmlUtil.NamespaceIgnorantXmlTextReader((TextReader) stringReader));
        }
        else
        {
          stringReader = new StringReader(xmlString);
          obj = xmlSerializer.Deserialize((TextReader) stringReader);
        }
        return obj;
      }
      catch (Exception ex)
      {
        throw ex;
      }
      finally
      {
        stringReader?.Close();
      }
    }

    public static object XmlToFromFile(string filePath, Type type)
    {
      FileStream fileStream1 = (FileStream) null;
      try
      {
        XmlSerializer xmlSerializer = new XmlSerializer(type);
        fileStream1 = new FileStream(filePath, FileMode.Open, FileAccess.Read);
        FileStream fileStream2 = fileStream1;
        return xmlSerializer.Deserialize((Stream) fileStream2);
      }
      catch (Exception ex)
      {
        throw ex;
      }
      finally
      {
        fileStream1?.Close();
      }
    }

    public class NamespaceIgnorantXmlTextReader : XmlTextReader
    {
      public NamespaceIgnorantXmlTextReader(TextReader reader)
        : base(reader)
      {
      }

      public override string NamespaceURI => "";
    }

    public class SpecialXmlWriter : XmlTextWriter
    {
      private bool m_includeStartDocument = true;

      public SpecialXmlWriter(TextWriter tw, bool includeStartDocument)
        : base(tw)
        => this.m_includeStartDocument = includeStartDocument;

      public SpecialXmlWriter(Stream sw, Encoding encoding, bool includeStartDocument)
        : base(sw, (Encoding) null)
        => this.m_includeStartDocument = includeStartDocument;

      public SpecialXmlWriter(string filePath, Encoding encoding, bool includeStartDocument)
        : base(filePath, (Encoding) null)
        => this.m_includeStartDocument = includeStartDocument;

      public override void WriteStartDocument()
      {
        if (!this.m_includeStartDocument)
          return;
        base.WriteStartDocument();
      }
    }
  }
}
