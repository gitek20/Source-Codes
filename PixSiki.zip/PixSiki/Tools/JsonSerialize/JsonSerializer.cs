﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.JsonSerialize.JsonSerializer
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using Newtonsoft.Json;

namespace PixBlocks.Tools.JsonSerialize
{
  public static class JsonSerializer
  {
    public static object Deserialize(string json) => JsonConvert.DeserializeObject(json);

    public static string Serialize(object obj) => JsonConvert.SerializeObject(obj);
  }
}
