﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.ExamsWatcher.ExamsWatcher
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace PixBlocks.Tools.ExamsWatcher
{
  public class ExamsWatcher
  {
    private static PixBlocks.Tools.ExamsWatcher.ExamsWatcher instance;
    private List<int> activeExamsIDs = new List<int>();
    private DispatcherTimer timer = new DispatcherTimer();
    private ServerApi serverApi = new ServerApi();
    private double interval = 10.0;
    public Action<int, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState> onExamChange;
    private bool isStarted;

    public static PixBlocks.Tools.ExamsWatcher.ExamsWatcher Instance
    {
      get
      {
        if (PixBlocks.Tools.ExamsWatcher.ExamsWatcher.instance == null)
          PixBlocks.Tools.ExamsWatcher.ExamsWatcher.instance = new PixBlocks.Tools.ExamsWatcher.ExamsWatcher();
        return PixBlocks.Tools.ExamsWatcher.ExamsWatcher.instance;
      }
    }

    public bool IsStarted
    {
      get => this.isStarted;
      set => this.isStarted = value;
    }

    private ExamsWatcher()
    {
    }

    public void StartWatching(List<Exam> allExams)
    {
      this.StopWatching();
      this.isStarted = true;
      bool? acceptedToStudentsClass = CurrentUserInfo.CurrentUser.Student_isAcceptedToStudentsClass;
      bool flag = true;
      if (!(acceptedToStudentsClass.GetValueOrDefault() == flag & acceptedToStudentsClass.HasValue) && !CurrentUserInfo.CurrentUser.ChampionshipId.HasValue)
        return;
      List<int> intList = new List<int>();
      if (allExams != null)
        allExams.Select<Exam, int>((Func<Exam, int>) (e => e.Id)).ToList<int>();
      else
        this.serverApi.GetAllActiveExamsIDs(CurrentUserInfo.AuthorizeData);
      this.timer.Interval = TimeSpan.FromSeconds(this.interval);
      this.timer.Tick += new EventHandler(this.Timer_Tick);
      this.timer.Start();
    }

    public void StopWatching()
    {
      this.isStarted = false;
      this.timer.Tick -= new EventHandler(this.Timer_Tick);
      this.timer.Stop();
    }

    private void Timer_Tick(object sender, EventArgs e)
    {
      Task<List<int>> apiTask = Task.Factory.StartNew<List<int>>((Func<List<int>>) (() => this.serverApi.GetAllActiveExamsIDs(CurrentUserInfo.AuthorizeData)));
      apiTask.ContinueWith((Action<Task<List<int>>>) (t =>
      {
        List<int> activeExamsIDsOnServer = apiTask.Result;
        List<int> list = this.activeExamsIDs.Where<int>((Func<int, bool>) (id => !activeExamsIDsOnServer.Contains(id))).ToList<int>();
        foreach (int num in activeExamsIDsOnServer.Where<int>((Func<int, bool>) (id => !this.activeExamsIDs.Contains(id))).ToList<int>())
        {
          if (this.onExamChange != null)
            this.onExamChange(num, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState.Created);
        }
        foreach (int num in list)
        {
          if (this.onExamChange != null)
            this.onExamChange(num, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState.Deleted);
        }
        this.activeExamsIDs = activeExamsIDsOnServer;
      }), TaskScheduler.FromCurrentSynchronizationContext());
    }

    public enum ExamState
    {
      Created,
      Deleted,
    }
  }
}
