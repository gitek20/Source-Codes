﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.ColorTransformation.ColorTransorm
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using System;
using System.Windows.Media;

namespace PixBlocks.Tools.ColorTransformation
{
  internal class ColorTransorm
  {
    public static double multiplyFactor = 25.5;
    public static double divisionFactor = 2.0 / 51.0;

    public static Color GetColorFromValue(Value value) => new Color()
    {
      R = ColorTransorm.NormalizeToByte((double) value.R * ColorTransorm.multiplyFactor),
      G = ColorTransorm.NormalizeToByte((double) value.G * ColorTransorm.multiplyFactor),
      B = ColorTransorm.NormalizeToByte((double) value.B * ColorTransorm.multiplyFactor),
      A = byte.MaxValue
    };

    private static byte NormalizeToByte(double value) => (byte) Math.Max(0, Math.Min((int) byte.MaxValue, (int) (value + 0.51)));

    public static Value GetValueFromColor(Color c) => new Value((int) (byte) ((double) c.R * ColorTransorm.divisionFactor), (int) (byte) ((double) c.G * ColorTransorm.divisionFactor), (int) (byte) ((double) c.B * ColorTransorm.divisionFactor));
  }
}
