﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.CodeParser.CodeStringParser
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.DataModels.Code.Variables;
using System;
using System.Collections.Generic;

namespace PixBlocks.Tools.CodeParser
{
  internal class CodeStringParser
  {
    private static List<string> ConvertCodeToLines(string code)
    {
      List<string> stringList = new List<string>();
      stringList.AddRange((IEnumerable<string>) code.Split("\n"[0]));
      for (int index = 0; index < stringList.Count; ++index)
      {
        stringList[index] = stringList[index].Replace("\n", "");
        stringList[index] = stringList[index].Replace("\r", "");
        stringList[index] = stringList[index].Replace(" ", "");
      }
      return stringList;
    }

    public static List<string> GetFirstChildBlockAndRemoveBlock(List<string> codeBlock)
    {
      int index1 = -1;
      for (int index2 = 1; index2 < codeBlock.Count; ++index2)
      {
        if (codeBlock[index2] == "{")
        {
          index1 = index2;
          break;
        }
      }
      if (index1 == -1)
        return new List<string>();
      int num1 = 0;
      int num2 = 0;
      for (int index2 = index1; index2 < codeBlock.Count; ++index2)
      {
        if (codeBlock[index2] == "{")
          ++num1;
        if (codeBlock[index2] == "}")
          --num1;
        if (num1 == 0)
        {
          num2 = index2;
          break;
        }
      }
      List<string> range = codeBlock.GetRange(index1, num2 + 1 - index1);
      codeBlock.RemoveRange(index1, num2 + 1 - index1);
      return range;
    }

    public static List<ICodeElement> GetElementsList(List<string> codeBlock)
    {
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      for (int index = 0; index < int.MaxValue; ++index)
      {
        List<string> blockAndRemoveBlock = CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeBlock);
        if (blockAndRemoveBlock.Count != 0)
          codeElementList.Add(CodeStringParser.GenerateElementFromCodeLines(blockAndRemoveBlock));
        else
          break;
      }
      return codeElementList;
    }

    public static ICodeElement GenerateElementFromCodeLines(List<string> codeBlock)
    {
      if (codeBlock.Count < 2)
        return (ICodeElement) null;
      string str = codeBlock[1];
      if (str == typeof (AssigmentInstruction).ToString())
        return (ICodeElement) new AssigmentInstruction(codeBlock);
      if (str == typeof (IfThenInstruction).ToString())
        return (ICodeElement) new IfThenInstruction(codeBlock);
      if (str == typeof (RepeatNTimes).ToString())
        return (ICodeElement) new RepeatNTimes(codeBlock);
      if (str == typeof (Procedure).ToString())
        return (ICodeElement) new Procedure(codeBlock);
      if (str == typeof (Variable).ToString())
        return (ICodeElement) new Variable(codeBlock);
      throw new Exception();
    }

    public static RepeatNTimes GenerateModelFromCode(string code) => new RepeatNTimes(CodeStringParser.ConvertCodeToLines(code));
  }
}
