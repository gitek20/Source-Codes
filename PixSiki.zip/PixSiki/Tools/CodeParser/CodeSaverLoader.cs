﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.CodeParser.CodeSaverLoader
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.Instructions;
using System.IO;

namespace PixBlocks.Tools.CodeParser
{
  internal class CodeSaverLoader
  {
    public static void SaveCode(RepeatNTimes rootElement, string filepath)
    {
      string internalCode = rootElement.GetInternalCode("");
      File.WriteAllText(filepath, internalCode);
    }

    public static RepeatNTimes LoadCode(string path) => CodeStringParser.GenerateModelFromCode(File.ReadAllText(path));
  }
}
