﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.UserControlToBitmapRenderer
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PixBlocks.Tools
{
  internal class UserControlToBitmapRenderer
  {
    public static RenderTargetBitmap GetImage(UserControl view)
    {
      Size size = new Size(view.ActualWidth, view.ActualHeight);
      if (size.IsEmpty)
        return (RenderTargetBitmap) null;
      RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap((int) size.Width, (int) size.Height, 96.0, 96.0, PixelFormats.Pbgra32);
      DrawingVisual drawingVisual = new DrawingVisual();
      using (DrawingContext drawingContext = drawingVisual.RenderOpen())
      {
        drawingContext.DrawRectangle((Brush) new VisualBrush((Visual) view), (Pen) null, new Rect(new Point(), size));
        drawingContext.Close();
      }
      renderTargetBitmap.Render((Visual) drawingVisual);
      return renderTargetBitmap;
    }

    public static void SaveAsPng(RenderTargetBitmap src, string path)
    {
      PngBitmapEncoder pngBitmapEncoder = new PngBitmapEncoder();
      pngBitmapEncoder.Frames.Add(BitmapFrame.Create((BitmapSource) src));
      using (FileStream fileStream = File.OpenWrite(path))
        pngBitmapEncoder.Save((Stream) fileStream);
    }
  }
}
