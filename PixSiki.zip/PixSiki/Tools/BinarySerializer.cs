﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.BinarySerializer
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows;

namespace PixBlocks.Tools
{
  internal class BinarySerializer
  {
    public static void Serialize(string path, object ob)
    {
      Stream serializationStream = (Stream) File.Open(path, FileMode.Create);
      new BinaryFormatter().Serialize(serializationStream, ob);
      serializationStream.Close();
    }

    public static object Deserialize(string path)
    {
      try
      {
        Stream serializationStream = (Stream) File.Open(path, FileMode.Open, FileAccess.Read);
        object obj = new BinaryFormatter().Deserialize(serializationStream);
        serializationStream.Close();
        return obj;
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.ToString());
        return (object) null;
      }
    }
  }
}
