﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.IpGetter
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.IO;
using System.Net;

namespace PixBlocks.Tools
{
  public static class IpGetter
  {
    public static string GetInternetIP() => "";

    public static string GetIPAddress()
    {
      string str = "";
      using (WebResponse response = WebRequest.Create("http://checkip.dyndns.org/").GetResponse())
      {
        using (StreamReader streamReader = new StreamReader(response.GetResponseStream()))
          str = streamReader.ReadToEnd();
      }
      int startIndex = str.IndexOf("Address: ") + 9;
      int num = str.LastIndexOf("</body>");
      return str.Substring(startIndex, num - startIndex);
    }
  }
}
