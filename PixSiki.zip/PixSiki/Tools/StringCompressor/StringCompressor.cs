﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.StringCompressor.StringCompressor
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace PixBlocks.Tools.StringCompressor
{
  internal class StringCompressor
  {
    public static string CompressString(string text)
    {
      if (text == null)
        text = "";
      byte[] bytes = Encoding.UTF8.GetBytes(text);
      MemoryStream memoryStream = new MemoryStream();
      using (GZipStream gzipStream = new GZipStream((Stream) memoryStream, CompressionMode.Compress, true))
        gzipStream.Write(bytes, 0, bytes.Length);
      memoryStream.Position = 0L;
      byte[] buffer = new byte[memoryStream.Length];
      memoryStream.Read(buffer, 0, buffer.Length);
      byte[] inArray = new byte[buffer.Length + 4];
      Buffer.BlockCopy((Array) buffer, 0, (Array) inArray, 4, buffer.Length);
      Buffer.BlockCopy((Array) BitConverter.GetBytes(bytes.Length), 0, (Array) inArray, 0, 4);
      return Convert.ToBase64String(inArray);
    }

    public static string DecompressString(string compressedText)
    {
      byte[] buffer = Convert.FromBase64String(compressedText);
      using (MemoryStream memoryStream = new MemoryStream())
      {
        int int32 = BitConverter.ToInt32(buffer, 0);
        memoryStream.Write(buffer, 4, buffer.Length - 4);
        byte[] numArray = new byte[int32];
        memoryStream.Position = 0L;
        using (GZipStream gzipStream = new GZipStream((Stream) memoryStream, CompressionMode.Decompress))
          gzipStream.Read(numArray, 0, numArray.Length);
        return Encoding.UTF8.GetString(numArray);
      }
    }
  }
}
