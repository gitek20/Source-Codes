﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.QuestionsParser.QuestionCategoryLoaderAndSever
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Models;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace PixBlocks.Tools.QuestionsParser
{
  internal class QuestionCategoryLoaderAndSever : IBuiltInCoursesManager
  {
    public static List<Question> questions;
    public static List<QuestionCategory> categories;
    private static Dictionary<string, Question> questionsDict;
    private static Dictionary<string, QuestionCategory> categoriesDict;

    public static bool IsCategoryGameOnly(string categoryUniquePathGuid)
    {
      QuestionCategory questionCategory = QuestionCategoryLoaderAndSever.LoadCategory(categoryUniquePathGuid);
      foreach (string subcategoriesUniquePath in questionCategory.SubcategoriesUniquePaths)
      {
        if (!QuestionCategoryLoaderAndSever.IsCategoryGameOnly(subcategoriesUniquePath))
          return false;
      }
      using (List<string>.Enumerator enumerator = questionCategory.SubQuestionsGuids.GetEnumerator())
      {
        if (enumerator.MoveNext())
        {
          Question question = QuestionCategoryLoaderAndSever.QuestionOfGuid(enumerator.Current);
          return (question.IsIronPython || question.IsGame) && (!question.IsIronPython || question.Code.Contains("game.start") || question.QuestionType == QuestionType.FreeCodeType);
        }
      }
      return true;
    }

    public static List<Question> ClassicQuestionsInCategory(
      string categoryUniquePathGuid)
    {
      List<Question> questionList = new List<Question>();
      QuestionCategory questionCategory = QuestionCategoryLoaderAndSever.LoadCategory(categoryUniquePathGuid);
      foreach (string subcategoriesUniquePath in questionCategory.SubcategoriesUniquePaths)
        questionList.AddRange((IEnumerable<Question>) QuestionCategoryLoaderAndSever.ClassicQuestionsInCategory(subcategoriesUniquePath));
      foreach (string subQuestionsGuid in questionCategory.SubQuestionsGuids)
      {
        Question question = QuestionCategoryLoaderAndSever.QuestionOfGuid(subQuestionsGuid);
        if (question.QuestionType == QuestionType.ClassicQuestionType)
          questionList.Add(question);
      }
      return questionList;
    }

    private static List<string> GetDirsRecursivly(string dir)
    {
      List<string> stringList = new List<string>();
      stringList.Add(dir);
      foreach (string dir1 in Directory.EnumerateDirectories(dir).ToList<string>())
        stringList.AddRange((IEnumerable<string>) QuestionCategoryLoaderAndSever.GetDirsRecursivly(dir1));
      return stringList;
    }

    public static Question LoadQuestionFromPath(string path)
    {
      Question fromFile = (Question) XmlUtil.XmlToFromFile(path, typeof (Question));
      fromFile.UserFriendlyName = path.Replace(AppDomain.CurrentDomain.BaseDirectory, "");
      return fromFile;
    }

    public static void BuildCategoriesAndQuestions()
    {
      QuestionCategoryLoaderAndSever.questionsDict = (Dictionary<string, Question>) null;
      QuestionCategoryLoaderAndSever.categoriesDict = (Dictionary<string, QuestionCategory>) null;
      string str = AppDomain.CurrentDomain.BaseDirectory + "\\questions_data\\main";
      if (!Directory.Exists(str))
        Directory.CreateDirectory(str);
      QuestionCategoryLoaderAndSever.questions = new List<Question>();
      QuestionCategoryLoaderAndSever.categories = new List<QuestionCategory>();
      foreach (string path1 in QuestionCategoryLoaderAndSever.GetDirsRecursivly(str))
      {
        List<string> list = Directory.EnumerateDirectories(path1).ToList<string>();
        for (int index = 0; index < list.Count; ++index)
          list[index] = list[index].Replace(str, "");
        List<string> stringList = new List<string>();
        foreach (string path2 in Directory.EnumerateFiles(path1).ToList<string>())
        {
          Question question = QuestionCategoryLoaderAndSever.LoadQuestionFromPath(path2);
          QuestionCategoryLoaderAndSever.questions.Add(question);
          stringList.Add(question.UniqueGuid);
        }
        QuestionCategory questionCategory = new QuestionCategory();
        questionCategory.UniquePath = path1.Replace(str, "");
        string[] strArray = questionCategory.UniquePath.Split("\\"[0]);
        questionCategory.CategoryUserFriendlyName = strArray[strArray.Length - 1];
        if (questionCategory.CategoryUserFriendlyName == "")
          questionCategory.CategoryUserFriendlyName = "start";
        questionCategory.SubQuestionsGuids = stringList;
        questionCategory.SubcategoriesUniquePaths = list;
        QuestionCategoryLoaderAndSever.categories.Add(questionCategory);
      }
      foreach (Question question in QuestionCategoryLoaderAndSever.questions)
        question.CompressCodeAndBitmap();
      BinarySerializer.Serialize("..\\..\\_Data\\questions.bin", (object) QuestionCategoryLoaderAndSever.questions);
      BinarySerializer.Serialize("..\\..\\_Data\\categories.bin", (object) QuestionCategoryLoaderAndSever.categories);
      BinarySerializer.Serialize(".\\_Data\\questions.bin", (object) QuestionCategoryLoaderAndSever.questions);
      BinarySerializer.Serialize(".\\_Data\\categories.bin", (object) QuestionCategoryLoaderAndSever.categories);
      QuestionCategoryLoaderAndSever.SetUserFriendlyNames();
      QuestionCategoryLoaderAndSever.SaveCategoriesAndQuestionsUniqueNames();
    }

    private static void SaveCategoriesAndQuestionsUniqueNames()
    {
      string contents1 = "";
      foreach (QuestionCategory category in QuestionCategoryLoaderAndSever.categories)
        contents1 = contents1 + category.UniquePath + "\r\n";
      File.WriteAllText("AllCategoriesIDs.txt", contents1);
      string contents2 = "";
      foreach (Question question in QuestionCategoryLoaderAndSever.questions)
        contents2 = contents2 + question.UniqueGuid + "\t" + question.UserFriendlyName + "\t" + question.Description + "\r\n";
      File.WriteAllText("AllQuestionsIDs.tsv", contents2);
    }

    internal static bool ContainsQuestionGuid(string uniqueGuid)
    {
      if (uniqueGuid.Contains("_"))
        uniqueGuid = uniqueGuid.Split("_"[0])[1];
      QuestionCategoryLoaderAndSever.LoadQuestionsAndCategories();
      if (QuestionCategoryLoaderAndSever.questionsDict == null)
        QuestionCategoryLoaderAndSever.BuildQuestionsDictionary();
      return QuestionCategoryLoaderAndSever.questionsDict.ContainsKey(uniqueGuid);
    }

    private static void LoadQuestionsAndCategories()
    {
      if (QuestionCategoryLoaderAndSever.questions != null)
        return;
      UserMenager.languageKeyChangedEvet += new UserMenager.LanguageKeyChangedEvet(QuestionCategoryLoaderAndSever.UserMenager_languageKeyChangedEvet);
      QuestionCategoryLoaderAndSever.questions = (List<Question>) BinarySerializer.Deserialize(AppDomain.CurrentDomain.BaseDirectory + "_Data\\questions.bin");
      QuestionCategoryLoaderAndSever.categories = (List<QuestionCategory>) BinarySerializer.Deserialize(AppDomain.CurrentDomain.BaseDirectory + "_Data\\categories.bin");
      foreach (Question question in QuestionCategoryLoaderAndSever.questions)
        question.IsPremiumQuestion = true;
      foreach (QuestionCategory category in QuestionCategoryLoaderAndSever.categories)
      {
        int num = 0;
        foreach (string subQuestionsGuid in category.SubQuestionsGuids)
        {
          if (num < 2 || num > category.SubQuestionsGuids.Count - 5)
            QuestionCategoryLoaderAndSever.QuestionOfGuid(subQuestionsGuid).IsPremiumQuestion = false;
          if (num == category.SubQuestionsGuids.Count - 2 || num == category.SubQuestionsGuids.Count - 3)
            QuestionCategoryLoaderAndSever.QuestionOfGuid(subQuestionsGuid).IsPremiumQuestion = true;
          ++num;
        }
      }
      foreach (QuestionCategory category in QuestionCategoryLoaderAndSever.categories)
      {
        if (category.UniquePath.Contains("aa_create") || category.UniquePath.Contains("zz_admin") || category.UniquePath.Contains("course200"))
        {
          foreach (string subQuestionsGuid in category.SubQuestionsGuids)
            QuestionCategoryLoaderAndSever.QuestionOfGuid(subQuestionsGuid).IsPremiumQuestion = false;
        }
      }
      QuestionCategoryLoaderAndSever.SetUserFriendlyNames();
      BuiltInCoursesInstance.Instance = (IBuiltInCoursesManager) new QuestionCategoryLoaderAndSever();
    }

    private static void UserMenager_languageKeyChangedEvet() => QuestionCategoryLoaderAndSever.SetUserFriendlyNames();

    public static void SetUserFriendlyNames()
    {
      int num1 = 0;
      foreach (string subcategoriesUniquePath1 in QuestionCategoryLoaderAndSever.categories[0].SubcategoriesUniquePaths)
      {
        ++num1;
        QuestionCategory category = QuestionCategoryLoaderAndSever.LoadCategory(subcategoriesUniquePath1);
        string str1 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("course");
        category.CategoryUserFriendlyName = str1 + " " + num1.ToString();
        if (category.IsMyCreation())
        {
          category.CategoryUserFriendlyName = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateCategoryID(category.UniquePath);
          --num1;
        }
        if (category.IsAdminOnlyVisible())
        {
          category.CategoryUserFriendlyName = "(AD)" + category.UniquePath;
          --num1;
        }
        if (category.IsTeatcherOnlyVisible())
        {
          category.CategoryUserFriendlyName = "Materiały nauczyciela";
          --num1;
        }
        int num2 = 0;
        foreach (string subcategoriesUniquePath2 in category.SubcategoriesUniquePaths)
        {
          ++num2;
          QuestionCategory lesson = QuestionCategoryLoaderAndSever.LoadCategory(subcategoriesUniquePath2);
          string str2 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("lesson");
          lesson.CategoryUserFriendlyName = str2 + " " + num2.ToString();
          if (lesson.IsAdminOnlyVisible())
          {
            lesson.CategoryUserFriendlyName = "(AD)" + lesson.UniquePath;
            --num2;
          }
          if (lesson.IsTeatcherOnlyVisible())
          {
            lesson.CategoryUserFriendlyName = "Materiały nauczyciela";
            --num2;
          }
          List<Question> questions = new List<Question>();
          foreach (string subQuestionsGuid in lesson.SubQuestionsGuids)
          {
            Question question = QuestionCategoryLoaderAndSever.QuestionOfGuid(subQuestionsGuid);
            question.SetQuestionCategoryAndLesson(category, lesson);
            questions.Add(question);
          }
          QuestionCategoryLoaderAndSever.SetCaptions(questions);
        }
      }
    }

    public static void SetCaptions(List<Question> questions)
    {
      int num1 = 0;
      int num2 = 0;
      int num3 = 0;
      int num4 = 0;
      foreach (Question question in questions)
      {
        if (question.QuestionType == QuestionType.InfoType)
        {
          ++num2;
          string str = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("sample");
          question.CaptionInCategory = str + " " + num2.ToString();
        }
        if (question.QuestionType == QuestionType.FreeCodeType)
        {
          if ((question.ParenCategory as QuestionCategory).UniquePath.Contains("_create") && (question.IsGame || question.IsIronPython))
          {
            ++num4;
            string str = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("game");
            question.CaptionInCategory = str + " " + num4.ToString();
          }
          else
          {
            ++num3;
            string str = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("fun");
            question.CaptionInCategory = str + " " + num3.ToString();
          }
        }
        if (question.QuestionType == QuestionType.ClassicQuestionType)
        {
          ++num1;
          string str = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("question");
          question.CaptionInCategory = str + " " + num1.ToString();
        }
      }
    }

    public static QuestionCategory GetMainCategory()
    {
      QuestionCategoryLoaderAndSever.LoadQuestionsAndCategories();
      return QuestionCategoryLoaderAndSever.categories.Count > 0 ? QuestionCategoryLoaderAndSever.categories[0] : (QuestionCategory) null;
    }

    public static void SaveQuestion(Question question, string filePath) => XmlUtil.ToXml((object) question, filePath, false);

    private static void BuildQuestionsDictionary()
    {
      QuestionCategoryLoaderAndSever.LoadQuestionsAndCategories();
      QuestionCategoryLoaderAndSever.questionsDict = new Dictionary<string, Question>();
      foreach (Question question in QuestionCategoryLoaderAndSever.questions)
      {
        if (!QuestionCategoryLoaderAndSever.questionsDict.ContainsKey(question.UniqueGuid))
        {
          QuestionCategoryLoaderAndSever.questionsDict.Add(question.UniqueGuid, question);
        }
        else
        {
          int num = (int) MessageBox.Show("ZDUBLOWNAY GUID  " + question.UserFriendlyName + "  " + question.ParenCategory?.ToString() + " " + question.Description + " źródło duplikacji " + QuestionCategoryLoaderAndSever.questionsDict[question.UniqueGuid].UserFriendlyName);
        }
      }
    }

    private static void BuidCategoriesDictionary()
    {
      QuestionCategoryLoaderAndSever.LoadQuestionsAndCategories();
      QuestionCategoryLoaderAndSever.categoriesDict = new Dictionary<string, QuestionCategory>();
      foreach (QuestionCategory category in QuestionCategoryLoaderAndSever.categories)
        QuestionCategoryLoaderAndSever.categoriesDict.Add(category.UniquePath, category);
    }

    public static Question QuestionOfGuid(string uniqueGuid)
    {
      if (uniqueGuid.Contains("_"))
        uniqueGuid = uniqueGuid.Split("_"[0])[1];
      QuestionCategoryLoaderAndSever.LoadQuestionsAndCategories();
      if (QuestionCategoryLoaderAndSever.questionsDict == null)
        QuestionCategoryLoaderAndSever.BuildQuestionsDictionary();
      if (QuestionCategoryLoaderAndSever.questionsDict.ContainsKey(uniqueGuid))
        return QuestionCategoryLoaderAndSever.questionsDict[uniqueGuid];
      CustomMessageBox.Show("Question loading error " + uniqueGuid);
      return new Question()
      {
        UniqueGuid = uniqueGuid,
        QuestionType = QuestionType.InfoType,
        CanEditBitmap = false,
        Code = new RepeatNTimes(1).GetInternalCode(""),
        ImageHeight = 1,
        ImageWidth = 4,
        ImageInBase64 = "AAAA/wAAAP8AAAD/AAAA/w=="
      };
    }

    public static QuestionCategory LoadCategory(string uniquePathGuid)
    {
      QuestionCategoryLoaderAndSever.LoadQuestionsAndCategories();
      if (QuestionCategoryLoaderAndSever.categoriesDict == null)
        QuestionCategoryLoaderAndSever.BuidCategoriesDictionary();
      if (QuestionCategoryLoaderAndSever.categoriesDict.ContainsKey(uniquePathGuid))
        return QuestionCategoryLoaderAndSever.categoriesDict[uniquePathGuid];
      int num = (int) MessageBox.Show("error loading " + uniquePathGuid);
      return (QuestionCategory) null;
    }

    public List<ICategoryData> GetAllMainCategories()
    {
      QuestionCategory mainCategory = QuestionCategoryLoaderAndSever.GetMainCategory();
      List<ICategoryData> categoryDataList = new List<ICategoryData>();
      foreach (string subcategoriesUniquePath in mainCategory.SubcategoriesUniquePaths)
      {
        QuestionCategory questionCategory = QuestionCategoryLoaderAndSever.LoadCategory(subcategoriesUniquePath);
        if (!questionCategory.IsAdminOnlyVisible() || !UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Admin_isAdmin)
          categoryDataList.Add((ICategoryData) questionCategory);
      }
      return categoryDataList;
    }

    public List<ICategoryData> GetAllLessonInCategory(string categoryUniquePath)
    {
      QuestionCategory questionCategory1 = QuestionCategoryLoaderAndSever.LoadCategory(categoryUniquePath);
      List<ICategoryData> categoryDataList = new List<ICategoryData>();
      foreach (string subcategoriesUniquePath in questionCategory1.SubcategoriesUniquePaths)
      {
        QuestionCategory questionCategory2 = QuestionCategoryLoaderAndSever.LoadCategory(subcategoriesUniquePath);
        if (!questionCategory2.IsAdminOnlyVisible() || !UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Admin_isAdmin)
          categoryDataList.Add((ICategoryData) questionCategory2);
      }
      return categoryDataList;
    }

    public List<IQuestionData> GetAllQuestionsInLesson(string lessonUniquePath)
    {
      QuestionCategory questionCategory = QuestionCategoryLoaderAndSever.LoadCategory(lessonUniquePath);
      List<IQuestionData> questionDataList = new List<IQuestionData>();
      foreach (string subQuestionsGuid in questionCategory.SubQuestionsGuids)
        questionDataList.Add((IQuestionData) QuestionCategoryLoaderAndSever.QuestionOfGuid(subQuestionsGuid));
      return questionDataList;
    }

    public ICategoryData GetCourseOfID(string categoryGuid) => (ICategoryData) QuestionCategoryLoaderAndSever.LoadCategory(categoryGuid);

    public Question GetQuestionOfGuid(string questionGuid) => QuestionCategoryLoaderAndSever.QuestionOfGuid(questionGuid);
  }
}
