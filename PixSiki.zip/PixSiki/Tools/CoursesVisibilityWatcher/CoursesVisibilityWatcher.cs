﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using Newtonsoft.Json;
using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PixBlocks.Tools.CoursesVisibilityWatcher
{
  public class CoursesVisibilityWatcher
  {
    private List<string> selectedCategoriesList = new List<string>();
    private List<ICategoryData> mainCategories;
    private QuestionCategoryLoaderAndSever contentData;
    private List<string> selectedLessonsList = new List<string>();
    private List<string> selectedQuestionsList = new List<string>();
    private int numberOfSecondsToRefresh = 10;
    private DateTime lastRefreshTime;
    private DateTime lastServerVisibilityTimestamp;
    private static PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher instance;
    private static int prevUserId = -1;

    public static PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher Instance
    {
      get
      {
        if (UserMenager.IsOffLineUser)
        {
          PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.instance = new PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher();
          return PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.instance;
        }
        if (PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.instance == null || PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.prevUserId != CurrentUserInfo.CurrentUser.Id.Value)
        {
          PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.instance = new PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher();
          PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.prevUserId = CurrentUserInfo.CurrentUser.Id.Value;
        }
        return PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.instance;
      }
    }

    private CoursesVisibilityWatcher()
    {
      this.contentData = new QuestionCategoryLoaderAndSever();
      this.mainCategories = this.contentData.GetAllMainCategories().ToList<ICategoryData>();
      this.selectedCategoriesList = new List<string>();
      foreach (ICategoryData mainCategory in this.mainCategories)
        this.selectedCategoriesList.Add(mainCategory.UniqueGuid());
      this.selectedLessonsList = new List<string>();
      this.selectedQuestionsList = new List<string>();
    }

    private void RefreshStructuresIfOlds()
    {
      if (CurrentUserInfo.CurrentUser.Teacher_isTeacher || !CurrentUserInfo.CurrentUser.Student_studentsClassId.HasValue || DateTime.Now.Ticks - this.lastRefreshTime.Ticks <= 10000000L * (long) this.numberOfSecondsToRefresh)
        return;
      this.lastRefreshTime = DateTime.Now;
      GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => this.LoadVisibilityData()));
    }

    private bool IsParentLessonVisible(string categoryUniquePath)
    {
      if (UserMenager.IsOffLineUser || categoryUniquePath == null || categoryUniquePath.Contains("aa_create"))
        return true;
      this.RefreshStructuresIfOlds();
      foreach (string selectedLessons in this.selectedLessonsList)
      {
        if (categoryUniquePath == selectedLessons)
          return true;
      }
      foreach (string selectedCategories in this.selectedCategoriesList)
      {
        if (categoryUniquePath.Contains(selectedCategories))
          return true;
      }
      return false;
    }

    public bool IsCategoryVisible(string categoryUniquePath)
    {
      if (UserMenager.IsOffLineUser || categoryUniquePath == null || categoryUniquePath.Contains("aa_create"))
        return true;
      this.RefreshStructuresIfOlds();
      foreach (string selectedCategories in this.selectedCategoriesList)
      {
        if (categoryUniquePath.Contains(selectedCategories))
          return true;
      }
      foreach (string selectedLessons in this.selectedLessonsList)
      {
        if (categoryUniquePath == selectedLessons || selectedLessons.Contains(categoryUniquePath))
          return true;
      }
      if ((this.contentData.GetCourseOfID(categoryUniquePath) as QuestionCategory).IsLesson() && (this.contentData.GetCourseOfID(categoryUniquePath) as QuestionCategory).SubQuestionsGuids.Intersect<string>((IEnumerable<string>) this.selectedQuestionsList).Count<string>() > 0)
        return true;
      foreach (string subcategoriesUniquePath in (this.contentData.GetCourseOfID(categoryUniquePath) as QuestionCategory).SubcategoriesUniquePaths)
      {
        if (this.IsCategoryVisible(subcategoriesUniquePath))
          return true;
      }
      return false;
    }

    public bool IsQuestionVisible(string questionGuid)
    {
      if (UserMenager.IsOffLineUser)
        return true;
      this.RefreshStructuresIfOlds();
      return this.IsParentLessonVisible(this.contentData.GetQuestionOfGuid(questionGuid).ParenLesson.UniqueGuid()) || this.selectedQuestionsList.Contains(questionGuid);
    }

    private void LoadVisibilityData()
    {
      int? studentStudentsClassId = CurrentUserInfo.CurrentUser.Student_studentsClassId;
      if (!studentStudentsClassId.HasValue)
        return;
      CoursesVisibility coursesVisibility = new ServerApi().GetCoursesVisibility(studentStudentsClassId.Value, this.lastServerVisibilityTimestamp, new AuthorizeData(CurrentUserInfo.CurrentUser));
      if (coursesVisibility == null)
        return;
      this.lastServerVisibilityTimestamp = coursesVisibility.LastUpdateTime;
      if (coursesVisibility.VisibilityObject == null)
      {
        VisibilityModel visibilityModel = new VisibilityModel();
        List<string> stringList = new List<string>();
        foreach (ICategoryData mainCategory in this.mainCategories)
          stringList.Add((mainCategory as QuestionCategory).UniquePath);
        this.selectedCategoriesList = stringList;
      }
      else
      {
        VisibilityModel visibilityModel = JsonConvert.DeserializeObject<VisibilityModel>(coursesVisibility.VisibilityObject);
        this.selectedCategoriesList = visibilityModel.categoryList;
        this.selectedLessonsList = visibilityModel.lessonsList;
        this.selectedQuestionsList = visibilityModel.questionsList;
      }
    }

    public string GetCoursePath(string lessonPath) => "\\" + string.Concat<char>(lessonPath.Skip<char>(1).TakeWhile<char>((Func<char, bool>) (c => c != '\\')));
  }
}
