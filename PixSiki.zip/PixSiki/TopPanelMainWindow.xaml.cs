﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.MainWindow
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.LoginPanel;
using PixBlocks.TopPanel.PreferencesPanel;
using PixBlocks.TopPanel.TeacherPanel;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel
{
  public partial class MainWindow : Window, IComponentConnector
  {
    internal Button button;
    internal Button button1;
    internal Button button2;
    internal Grid mainGrid;
    private bool _contentLoaded;

    public MainWindow() => this.InitializeComponent();

    private void button_Click(object sender, RoutedEventArgs e)
    {
      this.mainGrid.Children.Clear();
      this.mainGrid.Children.Add((UIElement) new MainLoginPanel());
    }

    private void button1_Click(object sender, RoutedEventArgs e)
    {
      this.mainGrid.Children.Clear();
      this.mainGrid.Children.Add((UIElement) new MainPreferencePanel());
    }

    private void button2_Click(object sender, RoutedEventArgs e)
    {
      this.mainGrid.Children.Clear();
      MainTeacherPanel mainTeacherPanel = new MainTeacherPanel();
      this.mainGrid.Children.Add((UIElement) mainTeacherPanel);
      mainTeacherPanel.mainGrid.Margin = new Thickness(mainTeacherPanel.Margin.Left, 73.0, 0.0, 0.0);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/mainwindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.button = (Button) target;
          this.button.Click += new RoutedEventHandler(this.button_Click);
          break;
        case 2:
          this.button1 = (Button) target;
          this.button1.Click += new RoutedEventHandler(this.button1_Click);
          break;
        case 3:
          this.button2 = (Button) target;
          this.button2.Click += new RoutedEventHandler(this.button2_Click);
          break;
        case 4:
          this.mainGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
