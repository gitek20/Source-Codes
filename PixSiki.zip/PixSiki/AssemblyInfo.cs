﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Resources;

[assembly: Extension]
[assembly: AssemblyTitle("PixBlocks")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("PixBlocks")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyFileVersion("630.0.0.0")]
[assembly: AssemblyAssociatedContentFile("_data/pythontemplates_translations.tsv")]
[assembly: AssemblyAssociatedContentFile("_data/categories.bin")]
[assembly: AssemblyAssociatedContentFile("_data/questions.bin")]
[assembly: AssemblyAssociatedContentFile("_data/categories_translation.tsv")]
[assembly: AssemblyAssociatedContentFile("_data/questions_translation.tsv")]
[assembly: AssemblyAssociatedContentFile("_data/userinterface_translation.tsv")]
[assembly: AssemblyAssociatedContentFile("_data/templates_translation.tsv")]
[assembly: AssemblyVersion("629.0.0.0")]
