﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TemplateElementsGenerator.TemplateModelsGenerator
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Tools.ColorTransformation;
using PixBlocks.Views.CodeElements;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PixBlocks.TemplateElementsGenerator
{
  internal class TemplateModelsGenerator
  {
    private List<ICodeElement> GenerateAllElements()
    {
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      codeElementList.Add((ICodeElement) new RepeatNTimes());
      codeElementList.Add((ICodeElement) new RepeatNTimes(RepeatNTimesType.loopAndStep));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.TurtleSeeColor));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.TurtleSeeImage));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.EqualsNumbers));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.NotEqualsNumbers));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.EqualsColors));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.NotEqualsColors));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.EqualsImages));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.NotEqualsImages));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.Greater));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.GreaterEquals));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.Less));
      codeElementList.Add((ICodeElement) new IfThenInstruction(IfThenInstructionType.LessEqals));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.ClassicAssigmentNumber));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.ClassicAssigmentColor));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.ClassicAssigmentImage));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.ClassicAssigmentImage2Image));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.DrawTurtleColor));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.DrawTurtleImage));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.TurtleLeft));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.TurtleRight));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.TurtleTop));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.TurtleDown));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.PlaySound));
      codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.BreakAll));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.GetR));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.GetG));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.GetB));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.GetColorFromRGB));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.GetPutPixel));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.GetPutImage));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.PutRectangleInColor));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.GetNumberOfColorsInX));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.GetNumberOfColorsInY));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.MathPlus));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.MathMinus));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.MathMulti));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.MathDiv));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.MathMod));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.TurtleX));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.TurtleY));
      codeElementList.Add((ICodeElement) new Procedure(ProceduresTypes.TurtleSee));
      for (int index = -1; index <= 20; ++index)
        codeElementList.Add((ICodeElement) new Variable(VariableType.constant, new Value((long) index)));
      CodeInOut codeInOut = new CodeInOut();
      foreach (string numberVariablesName in codeInOut.CodeStaticVariables.NumberVariablesNames)
        codeElementList.Add((ICodeElement) new Variable(VariableType.variable, ValueType.Number, numberVariablesName));
      codeElementList.Add((ICodeElement) new Variable(VariableType.imageWidth, ValueType.Number));
      codeElementList.Add((ICodeElement) new Variable(VariableType.imageHeight, ValueType.Number));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Black)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.White)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Red)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Color.FromRgb((byte) 0, byte.MaxValue, (byte) 0))));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Blue)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Yellow)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Cyan)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Magenta)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Orange)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Pink)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Violet)));
      codeElementList.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.DarkCyan)));
      foreach (string namesOfBlock in PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks)
        codeElementList.Add((ICodeElement) new Variable(VariableType.constant, namesOfBlock));
      codeElementList.Add((ICodeElement) new Variable(VariableType.variable, ValueType.Image, "b1"));
      foreach (string colorVariablesName in codeInOut.CodeStaticVariables.ColorVariablesNames)
        codeElementList.Add((ICodeElement) new Variable(VariableType.variable, ValueType.Color, colorVariablesName));
      return codeElementList;
    }

    public ICodeElement GetElementOFName(string name)
    {
      foreach (ICodeElement allElement in this.GenerateAllElements())
      {
        if (allElement.GetUniqueName() == name)
          return allElement;
      }
      if (!(name.Substring(0, "Color".Length) == "Color"))
        return (ICodeElement) null;
      string[] strArray = name.Substring("Color".Length).Split("_"[0]);
      return (ICodeElement) new Variable(VariableType.constant, new Value(int.Parse(strArray[0]), int.Parse(strArray[1]), int.Parse(strArray[2])));
    }

    public UserControl GetUserControlFromICodeElement(
      ICodeElement el,
      bool IstemplateElement)
    {
      el.PutIsTemplateElement(IstemplateElement);
      switch (el)
      {
        case RepeatNTimes _:
          RepeatNTimesView repeatNtimesView = new RepeatNTimesView((RepeatNTimes) el);
          return !IstemplateElement ? (UserControl) repeatNtimesView : (UserControl) new TemplatAndDscription((UserControl) repeatNtimesView);
        case IfThenInstruction _:
          IfThenInstructionView thenInstructionView = new IfThenInstructionView((IfThenInstruction) el);
          return !IstemplateElement ? (UserControl) thenInstructionView : (UserControl) new TemplatAndDscription((UserControl) thenInstructionView);
        case AssigmentInstruction _:
          AssigmentInstructionView assigmentInstructionView = new AssigmentInstructionView((AssigmentInstruction) el);
          return !IstemplateElement ? (UserControl) assigmentInstructionView : (UserControl) new TemplatAndDscription((UserControl) assigmentInstructionView);
        case Variable _:
          VariableView variableView = new VariableView((Variable) el);
          return !IstemplateElement ? (UserControl) variableView : (UserControl) new TemplatAndDscription((UserControl) variableView);
        case Procedure _:
          ProcedureView procedureView = new ProcedureView((Procedure) el);
          return !IstemplateElement ? (UserControl) procedureView : (UserControl) new TemplatAndDscription((UserControl) procedureView);
        default:
          return (UserControl) null;
      }
    }

    public StackPanel GatAllCodeViews()
    {
      List<ICodeElement> allElements = this.GenerateAllElements();
      StackPanel stackPanel = new StackPanel();
      WrapPanel wrapPanel1 = new WrapPanel();
      WrapPanel wrapPanel2 = new WrapPanel();
      WrapPanel wrapPanel3 = new WrapPanel();
      WrapPanel wrapPanel4 = new WrapPanel();
      WrapPanel wrapPanel5 = new WrapPanel();
      WrapPanel wrapPanel6 = new WrapPanel();
      WrapPanel wrapPanel7 = new WrapPanel();
      WrapPanel wrapPanel8 = new WrapPanel();
      WrapPanel wrapPanel9 = new WrapPanel();
      WrapPanel wrapPanel10 = new WrapPanel();
      WrapPanel wrapPanel11 = new WrapPanel();
      WrapPanel wrapPanel12 = new WrapPanel();
      WrapPanel wrapPanel13 = new WrapPanel();
      foreach (ICodeElement el in allElements)
      {
        el.PutIsTemplateElement(true);
        if (el is RepeatNTimes)
          wrapPanel1.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
        if (el is IfThenInstruction)
          wrapPanel2.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
        if (el is AssigmentInstruction)
          wrapPanel3.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
        if (el is Variable)
        {
          if (((Variable) el).VariableType == VariableType.constant && ((Variable) el).ValueType == ValueType.Number)
            wrapPanel8.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (((Variable) el).VariableType == VariableType.variable && ((Variable) el).ValueType == ValueType.Number)
            wrapPanel9.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (((Variable) el).VariableType == VariableType.constant && ((Variable) el).ValueType == ValueType.Color)
            wrapPanel11.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (((Variable) el).VariableType == VariableType.variable && ((Variable) el).ValueType == ValueType.Color)
            wrapPanel13.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (((Variable) el).VariableType == VariableType.variable && ((Variable) el).ValueType == ValueType.Image)
            wrapPanel13.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (((Variable) el).VariableType == VariableType.imageWidth || ((Variable) el).VariableType == VariableType.imageHeight)
            wrapPanel10.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (((Variable) el).VariableType == VariableType.constant && ((Variable) el).ValueType == ValueType.Image)
            wrapPanel12.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
        }
        if (el is Procedure)
        {
          Procedure procedure = (Procedure) el;
          if (procedure.ProcedureType == ProceduresTypes.GetR || procedure.ProcedureType == ProceduresTypes.GetG || (procedure.ProcedureType == ProceduresTypes.GetB || procedure.ProcedureType == ProceduresTypes.GetColorFromRGB))
            wrapPanel4.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (procedure.ProcedureType == ProceduresTypes.GetNumberOfColorsInRectangle || procedure.ProcedureType == ProceduresTypes.GetNumberOfColorsInX || (procedure.ProcedureType == ProceduresTypes.GetNumberOfColorsInY || procedure.ProcedureType == ProceduresTypes.PutRectangleInColor) || (procedure.ProcedureType == ProceduresTypes.GetPutPixel || procedure.ProcedureType == ProceduresTypes.GetPutImage))
            wrapPanel5.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (procedure.ProcedureType == ProceduresTypes.MathDiv || procedure.ProcedureType == ProceduresTypes.MathMinus || (procedure.ProcedureType == ProceduresTypes.MathMod || procedure.ProcedureType == ProceduresTypes.MathMulti) || procedure.ProcedureType == ProceduresTypes.MathPlus)
            wrapPanel6.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
          if (procedure.ProcedureType == ProceduresTypes.TurtleSee || procedure.ProcedureType == ProceduresTypes.TurtleX || procedure.ProcedureType == ProceduresTypes.TurtleY)
            wrapPanel7.Children.Add((UIElement) this.GetUserControlFromICodeElement(el, true));
        }
      }
      stackPanel.Children.Add((UIElement) wrapPanel1);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel2);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel3);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel4);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel5);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel6);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel7);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel8);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel9);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel10);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel11);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel12);
      stackPanel.Children.Add((UIElement) new SmallLine());
      stackPanel.Children.Add((UIElement) wrapPanel13);
      return stackPanel;
    }

    public enum CodeViewType
    {
      simpleTurtle,
      advanceTurtlr,
    }
  }
}
