﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.App
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.Tools.TranslationManager;
using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace PixBlocks
{
  public partial class App : Application
  {
    private bool _contentLoaded;

    private void Application_Startup(object sender, StartupEventArgs e)
    {
      try
      {
        TranslationManagerInstance.instance = (ITranslationManager) new PixBlocks.Tools.TranslationsManager.TranslationsManager();
        new MainWindow().Show();
      }
      catch (Exception ex)
      {
        int num1 = (int) MessageBox.Show(ex.Message);
        int num2 = (int) MessageBox.Show(ex.StackTrace);
        int num3 = (int) MessageBox.Show(ex.Source);
        int num4 = (int) MessageBox.Show(ex.InnerException.Message);
        int num5 = (int) MessageBox.Show(ex.InnerException.Source);
        int num6 = (int) MessageBox.Show(ex.InnerException.StackTrace);
        int num7 = (int) MessageBox.Show(ex.InnerException.InnerException.Message);
        int num8 = (int) MessageBox.Show(ex.InnerException.InnerException.Source);
        int num9 = (int) MessageBox.Show(ex.InnerException.InnerException.StackTrace);
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      this.Startup += new StartupEventHandler(this.Application_Startup);
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/app.xaml", UriKind.Relative));
    }

    [STAThread]
    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public static void Main()
    {
      App app = new App();
      app.InitializeComponent();
      app.Run();
    }
  }
}
