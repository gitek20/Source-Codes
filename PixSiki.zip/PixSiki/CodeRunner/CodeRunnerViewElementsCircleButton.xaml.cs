﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.CodeRunner.CodeRunnerViewElements.CircleButton
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.CodeRunner.CodeRunnerViewElements
{
  public partial class CircleButton : UserControl, IComponentConnector
  {
    private UserControl icon;
    private CircleButton.VisualParam isBig = CircleButton.VisualParam.circle;
    private bool isEnabled = true;
    private Color bacgroundcolor;
    internal Grid mainGrid;
    internal Rectangle shadow2;
    internal Rectangle shadow1;
    internal Rectangle shadow3;
    internal Rectangle ellipse;
    internal Rectangle ellipsebotton;
    internal Rectangle disableRect;
    private bool _contentLoaded;

    public CircleButton() => this.InitializeComponent();

    public CircleButton(UserControl icon, Color bacgroundcolor)
    {
      this.InitializeComponent();
      this.MinWidth = 60.0;
      this.mainGrid.MinWidth = 60.0;
      this.disableRect.Visibility = Visibility.Collapsed;
      this.mainGrid.Children.Add((UIElement) icon);
      this.bacgroundcolor = bacgroundcolor;
      this.icon = icon;
      this.RefreshView();
    }

    public CircleButton(UserControl icon, Color bacgroundcolor, CircleButton.VisualParam isBig)
    {
      this.isBig = isBig;
      this.InitializeComponent();
      int num1 = 15;
      this.ellipse.RadiusX = (double) num1;
      this.ellipse.RadiusY = (double) num1;
      this.ellipsebotton.RadiusX = (double) num1;
      this.ellipsebotton.RadiusY = (double) num1;
      this.disableRect.RadiusX = (double) num1;
      this.disableRect.RadiusY = (double) num1;
      this.shadow2.RadiusX = (double) num1;
      this.shadow1.RadiusX = (double) num1;
      this.shadow2.RadiusY = (double) num1;
      this.shadow1.RadiusY = (double) num1;
      this.disableRect.Visibility = Visibility.Collapsed;
      if (isBig == CircleButton.VisualParam.circle)
      {
        this.ellipse.StrokeThickness = 2.0;
        this.ellipse.Stroke = (Brush) new SolidColorBrush(Color.FromRgb((byte) 135, (byte) 200, byte.MaxValue));
        bacgroundcolor = Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue);
        int num2 = 30;
        this.ellipse.RadiusX = (double) num2;
        this.ellipse.RadiusY = (double) num2;
        this.ellipsebotton.RadiusX = (double) num2;
        this.ellipsebotton.RadiusY = (double) num2;
        this.disableRect.RadiusX = (double) num2;
        this.disableRect.RadiusY = (double) num2;
        this.MinHeight = 51.0;
        this.mainGrid.MinHeight = 51.0;
        this.MinWidth = 60.0;
        this.mainGrid.MinWidth = 60.0;
        this.MaxWidth = 60.0;
        this.mainGrid.MaxWidth = 60.0;
        this.shadow2.RadiusX = (double) num2;
        this.shadow1.RadiusX = (double) num2;
        this.shadow2.RadiusY = (double) num2;
        this.shadow1.RadiusY = (double) num2;
      }
      if (isBig == CircleButton.VisualParam.noFrame)
      {
        this.MinHeight = 50.0;
        this.MinWidth = 60.0;
        this.mainGrid.MinWidth = 60.0;
        this.mainGrid.MinHeight = 50.0;
        this.shadow1.Visibility = Visibility.Collapsed;
        this.shadow2.Visibility = Visibility.Collapsed;
        this.shadow3.Visibility = Visibility.Collapsed;
        int num2 = 5;
        this.ellipse.Visibility = Visibility.Collapsed;
        this.ellipsebotton.Visibility = Visibility.Collapsed;
        this.disableRect.Visibility = Visibility.Collapsed;
        this.ellipse.RadiusX = (double) num2;
        this.ellipse.RadiusY = (double) num2;
        this.ellipsebotton.RadiusX = (double) num2;
        this.ellipsebotton.RadiusY = (double) num2;
        this.disableRect.RadiusX = (double) num2;
        this.disableRect.RadiusY = (double) num2;
        this.shadow2.RadiusX = (double) num2;
        this.shadow1.RadiusX = (double) num2;
        this.shadow2.RadiusY = (double) num2;
        this.shadow1.RadiusY = (double) num2;
      }
      if (isBig == CircleButton.VisualParam.big)
      {
        if (bacgroundcolor != Colors.Red)
        {
          this.ellipse.StrokeThickness = 2.0;
          this.ellipse.Stroke = (Brush) new SolidColorBrush(Color.FromRgb((byte) (((int) bacgroundcolor.R + (int) byte.MaxValue) / 2), (byte) (((int) bacgroundcolor.G + (int) byte.MaxValue) / 2), (byte) (((int) bacgroundcolor.B + (int) byte.MaxValue) / 2)));
          bacgroundcolor = Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue);
        }
        int num2 = 30;
        this.ellipse.RadiusX = (double) num2;
        this.ellipse.RadiusY = (double) num2;
        this.ellipsebotton.RadiusX = (double) num2;
        this.ellipsebotton.RadiusY = (double) num2;
        this.disableRect.RadiusX = (double) num2;
        this.disableRect.RadiusY = (double) num2;
        this.shadow2.RadiusX = (double) num2;
        this.shadow1.RadiusX = (double) num2;
        this.shadow2.RadiusY = (double) num2;
        this.shadow1.RadiusY = (double) num2;
        this.MinHeight = 56.0;
        this.MinWidth = 64.0;
        this.mainGrid.MinWidth = 64.0;
        this.mainGrid.MinHeight = 56.0;
      }
      if (isBig == CircleButton.VisualParam.veryBig)
      {
        this.MinHeight = 80.0;
        this.MinWidth = 90.0;
        this.mainGrid.MinWidth = 90.0;
        this.mainGrid.MinHeight = 80.0;
        int num2 = 40;
        this.ellipse.RadiusX = (double) num2;
        this.ellipse.RadiusY = (double) num2;
        this.ellipsebotton.RadiusX = (double) num2;
        this.ellipsebotton.RadiusY = (double) num2;
        this.disableRect.RadiusX = (double) num2;
        this.disableRect.RadiusY = (double) num2;
        this.shadow2.RadiusX = (double) num2;
        this.shadow1.RadiusX = (double) num2;
        this.shadow2.RadiusY = (double) num2;
        this.shadow1.RadiusY = (double) num2;
      }
      if (isBig == CircleButton.VisualParam.CircleBig)
      {
        this.MinHeight = 56.0;
        this.MinWidth = 56.0;
        this.mainGrid.MinWidth = 56.0;
        this.mainGrid.MinHeight = 56.0;
        int num2 = 28;
        this.ellipse.RadiusX = (double) num2;
        this.ellipse.RadiusY = (double) num2;
        this.ellipsebotton.RadiusX = (double) num2;
        this.ellipsebotton.RadiusY = (double) num2;
        this.disableRect.RadiusX = (double) num2;
        this.disableRect.RadiusY = (double) num2;
        this.shadow2.RadiusX = (double) num2;
        this.shadow1.RadiusX = (double) num2;
        this.shadow2.RadiusY = (double) num2;
        this.shadow1.RadiusY = (double) num2;
      }
      if (isBig == CircleButton.VisualParam.longwidth)
      {
        this.MinWidth = 120.0;
        this.mainGrid.MinWidth = 120.0;
      }
      if (isBig == CircleButton.VisualParam.loginBigButton)
      {
        this.MinHeight = 50.0;
        this.MinWidth = 450.0;
        this.mainGrid.MinWidth = 450.0;
        this.mainGrid.MinHeight = 50.0;
      }
      this.mainGrid.Children.Add((UIElement) icon);
      this.bacgroundcolor = bacgroundcolor;
      this.icon = icon;
      this.RefreshView();
    }

    internal void PerformMouseEnter() => this.UserControl_MouseEnter((object) null, (MouseEventArgs) null);

    internal void PerformMouseLeave() => this.UserControl_MouseLeave((object) null, (MouseEventArgs) null);

    public void SetIsEnabled(bool isEnabled)
    {
      this.isEnabled = isEnabled;
      this.RefreshView();
    }

    private void RefreshView()
    {
      if (this.isBig == CircleButton.VisualParam.noFrame)
        return;
      if (!this.isEnabled)
      {
        this.disableRect.Visibility = Visibility.Visible;
        this.icon.Opacity = 0.5;
        this.ellipse.Opacity = 0.4;
        this.shadow1.Visibility = Visibility.Hidden;
        this.shadow2.Visibility = Visibility.Hidden;
        this.ellipsebotton.Visibility = Visibility.Hidden;
      }
      else
      {
        this.disableRect.Visibility = Visibility.Collapsed;
        this.ellipse.Fill = (Brush) new SolidColorBrush(this.bacgroundcolor);
        this.icon.Opacity = 1.0;
        this.ellipse.Opacity = 1.0;
        this.shadow1.Visibility = Visibility.Visible;
        this.shadow2.Visibility = Visibility.Visible;
        this.ellipsebotton.Visibility = Visibility.Visible;
      }
    }

    public event CircleButton.ButtonClicker buttonClickedEvent;

    private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (!this.isEnabled)
        return;
      this.ellipse.Opacity = 0.7;
      if (this.buttonClickedEvent == null)
        return;
      this.buttonClickedEvent();
    }

    private void UserControl_MouseEnter(object sender, MouseEventArgs e)
    {
      if (this.isBig == CircleButton.VisualParam.noFrame)
      {
        this.ellipse.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 235, (byte) 235, (byte) 235));
        this.ellipse.Visibility = Visibility.Visible;
      }
      if (!this.isEnabled)
        return;
      this.ellipse.Opacity = 0.7;
      this.ellipsebotton.Visibility = Visibility.Collapsed;
      this.shadow1.Visibility = Visibility.Collapsed;
      this.shadow2.Visibility = Visibility.Collapsed;
    }

    private void UserControl_MouseLeave(object sender, MouseEventArgs e)
    {
      if (this.isEnabled)
      {
        this.ellipse.Opacity = 1.0;
        this.ellipsebotton.Visibility = Visibility.Visible;
        this.shadow1.Visibility = Visibility.Visible;
        this.shadow2.Visibility = Visibility.Visible;
      }
      if (this.isBig != CircleButton.VisualParam.noFrame)
        return;
      this.ellipse.Visibility = Visibility.Collapsed;
      this.ellipsebotton.Visibility = Visibility.Collapsed;
      this.shadow1.Visibility = Visibility.Collapsed;
      this.shadow2.Visibility = Visibility.Collapsed;
    }

    private void UserControl_MouseUp(object sender, MouseButtonEventArgs e)
    {
      if (!this.isEnabled)
        return;
      this.ellipse.Opacity = 1.0;
    }

    internal void ProgramaticlyClick() => this.UserControl_MouseDown((object) null, (MouseButtonEventArgs) null);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/coderunner/coderunnerviewelements/circlebutton.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.UserControl_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.UserControl_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.UserControl_MouseUp);
          break;
        case 2:
          this.mainGrid = (Grid) target;
          break;
        case 3:
          this.shadow2 = (Rectangle) target;
          break;
        case 4:
          this.shadow1 = (Rectangle) target;
          break;
        case 5:
          this.shadow3 = (Rectangle) target;
          break;
        case 6:
          this.ellipse = (Rectangle) target;
          break;
        case 7:
          this.ellipsebotton = (Rectangle) target;
          break;
        case 8:
          this.disableRect = (Rectangle) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public enum VisualParam
    {
      normal,
      big,
      longwidth,
      loginBigButton,
      veryBig,
      CircleBig,
      noFrame,
      circle,
    }

    public delegate void ButtonClicker();
  }
}
