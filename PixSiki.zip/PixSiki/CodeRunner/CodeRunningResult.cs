﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.CodeRunner.CodeRunningResult
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;

namespace PixBlocks.CodeRunner
{
  public class CodeRunningResult
  {
    private int codeTime;
    private int codePatternTime;
    private int codeLines;
    private int codePatternLines;
    private bool codesMatch;
    private PixBlocks.CodeRunner.CodeRunner codeRunner;
    private PixBlocks.CodeRunner.CodeRunner codePatter;

    public CodeRunningResult(PixBlocks.CodeRunner.CodeRunner codeRunner, PixBlocks.CodeRunner.CodeRunner codePatter)
    {
      this.codeRunner = codeRunner;
      this.codePatter = codePatter;
      this.codesMatch = codeRunner.CodeInOut.Image.IsSameAs(codePatter.CodeInOut.Image) && codeRunner.CodeInOut.CodeStaticVariables.GetVariabeOfName("out").Val.Number == codePatter.CodeInOut.CodeStaticVariables.GetVariabeOfName("out").Val.Number;
      this.codeTime = codeRunner.NumberOfRunnedInstructions;
      this.codePatternTime = codePatter.NumberOfRunnedInstructions;
      int num1 = -1;
      foreach (ICodeElement innerCodeElement in codeRunner.RootElement.InnerCodeElements())
      {
        if (innerCodeElement.IsInstruction())
          ++num1;
      }
      this.codeLines = num1;
      int num2 = -1;
      foreach (ICodeElement innerCodeElement in codePatter.RootElement.InnerCodeElements())
      {
        if (innerCodeElement.IsInstruction())
          ++num2;
      }
      this.codePatternLines = num2;
    }

    public int CodeTime => this.codeTime;

    public int CodePatternTime => this.codePatternTime;

    public int CodeLines => this.codeLines;

    public int CodePatternLines => this.codePatternLines;

    public bool CodesMatch => this.codesMatch;
  }
}
