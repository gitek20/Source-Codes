﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.CodeRunner.CodeRunnerViewElements.SliderView.FastSlider
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.CodeRunner.CodeRunnerViewElements.SliderView
{
  public partial class FastSlider : UserControl, IComponentConnector
  {
    public static double prevVal = 0.3;
    private bool isCodeRunner;
    internal Image image;
    internal Grid image1;
    private bool _contentLoaded;

    public FastSlider(bool isCodeRunner = false)
    {
      this.InitializeComponent();
      this.isCodeRunner = isCodeRunner;
      if (isCodeRunner)
        this.SetVal(FastSlider.prevVal);
      else
        this.SetVal(0.3);
    }

    public FastSlider()
    {
      this.InitializeComponent();
      this.isCodeRunner = false;
      if (this.isCodeRunner)
        this.SetVal(FastSlider.prevVal);
      else
        this.SetVal(0.3);
    }

    public event FastSlider.SliderValueChanged valueChangedEvent;

    public void SetVal(double val)
    {
      double num1 = 190.0 * val + 25.0;
      this.image1.Margin = new Thickness(num1 - 9.0, 11.0, 0.0, 0.0);
      double num2 = (num1 - 25.0) / 190.0;
      if (this.isCodeRunner)
        FastSlider.prevVal = num2;
      if (this.valueChangedEvent == null)
        return;
      this.valueChangedEvent(num2);
    }

    private void Grid_MouseMove(object sender, MouseEventArgs e)
    {
      double num1 = Math.Min(215.0, Math.Max(25.0, e.GetPosition((IInputElement) this).X));
      if (e.RightButton != MouseButtonState.Pressed && e.LeftButton != MouseButtonState.Pressed)
        return;
      this.image1.Margin = new Thickness(num1 - 9.0, 11.0, 0.0, 0.0);
      double num2 = (num1 - 25.0) / 190.0;
      if (this.isCodeRunner)
        FastSlider.prevVal = num2;
      if (this.valueChangedEvent == null)
        return;
      this.valueChangedEvent(num2);
    }

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      double num1 = Math.Min(215.0, Math.Max(25.0, e.GetPosition((IInputElement) this).X));
      if (e.RightButton != MouseButtonState.Pressed && e.LeftButton != MouseButtonState.Pressed)
        return;
      this.image1.Margin = new Thickness(num1 - 9.0, 11.0, 0.0, 0.0);
      double num2 = (num1 - 25.0) / 190.0;
      if (this.isCodeRunner)
        FastSlider.prevVal = num2;
      if (this.valueChangedEvent == null)
        return;
      this.valueChangedEvent(num2);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/coderunner/coderunnerviewelements/sliderview/fastslider.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseMove += new MouseEventHandler(this.Grid_MouseMove);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 2:
          this.image = (Image) target;
          break;
        case 3:
          this.image1 = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void SliderValueChanged(double value);
  }
}
