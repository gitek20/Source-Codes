﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.CodeRunner.CodeRunnerViewElements.Images.FastIcon
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.CodeRunner.CodeRunnerViewElements.Images
{
  public partial class FastIcon : UserControl, IComponentConnector
  {
    internal Rectangle image;
    private bool _contentLoaded;

    public FastIcon() => this.InitializeComponent();

    public void ScaleImage(double scale)
    {
      this.image.Width = 60.0 + (scale - 0.5) * 30.0;
      this.image.Height = 60.0 + (scale - 0.5) * 30.0;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/coderunner/coderunnerviewelements/images/fasticon.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.image = (Rectangle) target;
      else
        this._contentLoaded = true;
    }
  }
}
