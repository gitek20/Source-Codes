﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.CodeRunner.CodeRunner
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Instructions;

namespace PixBlocks.CodeRunner
{
  public class CodeRunner
  {
    private CodeInOut codeInOut;
    private RepeatNTimes rootElement;
    private int numberOfRunnedInstructions;
    private bool invokeEvents = true;
    private ICodeElement currentInstruction;

    public CodeInOut CodeInOut => this.codeInOut;

    public RepeatNTimes RootElement => this.rootElement;

    public bool InvokeEvents
    {
      get => this.invokeEvents;
      set => this.invokeEvents = value;
    }

    public event PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged codeeRunnerStatusChangedEvent;

    public event PixBlocks.CodeRunner.CodeRunner.IterationStepChanged iterationStepChangedEvent;

    public int NumberOfRunnedInstructions => this.numberOfRunnedInstructions;

    public ICodeElement CurrentInstruction => this.currentInstruction;

    public CodeRunner(CodeInOut codeInOut, RepeatNTimes rootElement)
    {
      this.codeInOut = codeInOut;
      this.rootElement = rootElement;
      this.currentInstruction = (ICodeElement) rootElement;
      this.numberOfRunnedInstructions = 0;
      if (this.iterationStepChangedEvent == null)
        return;
      this.iterationStepChangedEvent(this.numberOfRunnedInstructions);
    }

    public void ResetRunning()
    {
      this.numberOfRunnedInstructions = 0;
      if (this.iterationStepChangedEvent != null)
        this.iterationStepChangedEvent(this.numberOfRunnedInstructions);
      this.codeInOut.ResetAll();
      if (this.currentInstruction != null)
        this.currentInstruction.SendCodeRunningStatusStop();
      this.currentInstruction = (ICodeElement) this.rootElement;
      this.rootElement.ResetIterator();
      foreach (ICodeElement innerCodeElement in this.rootElement.InnerCodeElements())
      {
        if (innerCodeElement is RepeatNTimes)
          (innerCodeElement as RepeatNTimes).ResetIterator();
      }
      if (this.codeeRunnerStatusChangedEvent == null || !this.invokeEvents)
        return;
      this.codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped);
    }

    public void RunNextInstruction()
    {
      if (this.iterationStepChangedEvent != null)
        this.iterationStepChangedEvent(this.numberOfRunnedInstructions);
      if (this.currentInstruction == this.rootElement && this.codeeRunnerStatusChangedEvent != null && this.invokeEvents)
        this.codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing);
      if (this.currentInstruction != null)
      {
        ++this.numberOfRunnedInstructions;
        this.currentInstruction.SendCodeRunningStatusStop();
        this.currentInstruction = this.currentInstruction.GetNextInstructionAfter(this.currentInstruction, this.codeInOut);
      }
      if (this.currentInstruction != null)
      {
        this.currentInstruction.SendCodeRunningStatusStart();
        if (this.currentInstruction is AssigmentInstruction)
          this.currentInstruction.RunInnerCode((Value) null, this.codeInOut);
        if (this.currentInstruction is IfThenInstruction)
          (this.currentInstruction as IfThenInstruction).CheckIfConditionIsOK(this.codeInOut);
        if (this.currentInstruction is RepeatNTimes)
          (this.currentInstruction as RepeatNTimes).ResetIterator();
      }
      if (this.currentInstruction != null || this.codeeRunnerStatusChangedEvent == null || !this.invokeEvents)
        return;
      this.codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended);
    }

    internal void SendEndedEvent()
    {
      if (this.codeeRunnerStatusChangedEvent == null || !this.invokeEvents)
        return;
      this.codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended);
    }

    internal void SendResetEvent()
    {
      if (this.codeeRunnerStatusChangedEvent == null || !this.invokeEvents)
        return;
      this.codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped);
    }

    public enum CodeRunnerStatus
    {
      Stopped,
      Plaing,
      Ended,
    }

    public delegate void CodeRunnerStatusChanged(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status);

    public delegate void IterationStepChanged(int step);
  }
}
