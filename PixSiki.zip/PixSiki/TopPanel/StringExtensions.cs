﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.StringExtensions
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace PixBlocks.TopPanel
{
  public static class StringExtensions
  {
    public static bool HasWhitespace(this string s) => s.Any<char>((Func<char, bool>) (c => char.IsWhiteSpace(c)));

    public static string RemoveWhitespaces(this string text) => text = text.Replace(" ", string.Empty);

    public static bool IsNullOrEmpty(this string s) => string.IsNullOrEmpty(s);

    public static bool IsNullOrWhiteSpace(this string s) => string.IsNullOrWhiteSpace(s);

    public static string ConvertPasswordToMD5(string input)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (byte num in new MD5CryptoServiceProvider().ComputeHash(new UTF8Encoding().GetBytes(input)))
        stringBuilder.Append(num.ToString("x3"));
      return stringBuilder.ToString();
    }

    public static string ToStringOrEmpty(this object value) => value != null ? value.ToString() : "null";
  }
}
