﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.EditStudentView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.FaceButtons;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.TeacherPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class EditStudentView : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private User student;
    private bool saveDateBirth;
    internal StackPanel stackPanel;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel studentName;
    internal RoundedTextBoxAndLabel studentSurname;
    internal RoundedTextBoxAndLabel studentRegisterNumber;
    internal RoundedTextBoxAndLabel dateOfBirth;
    internal RoundedTextBoxAndLabel password;
    internal SmallRoundedButton generate;
    internal SmallInfoText faceDescription;
    internal FacesSelector face;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public EditStudentView(User student)
    {
      this.student = student;
      this.InitializeComponent();
      if (student.Email != null)
      {
        this.password.Visibility = Visibility.Collapsed;
        this.studentName.Visibility = Visibility.Collapsed;
        this.studentSurname.Visibility = Visibility.Collapsed;
        this.faceDescription.Visibility = Visibility.Collapsed;
        this.face.Visibility = Visibility.Collapsed;
        this.generate.Visibility = Visibility.Collapsed;
        this.dateOfBirth.Visibility = Visibility.Collapsed;
      }
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("editStudent");
      this.studentName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("firstName");
      this.studentSurname.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("surname");
      this.studentRegisterNumber.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("registerNumber");
      this.password.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (password));
      this.dateOfBirth.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (dateOfBirth));
      DateTime dateTime = new DateTime();
      if (student.DateOfBirth.HasValue)
      {
        dateTime = student.DateOfBirth.Value;
        this.dateOfBirth.textBoxRounded.textBox.Text = student.DateOfBirth.Value.Year.ToString();
      }
      this.faceDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("selectAvatar");
      this.face.SetFace(student.AvatarName);
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.Abort_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("saveStudent");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.EditStudent_clickEvent);
      this.generate.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (generate));
      this.generate.SetColor(SmallRoundedButton.ColorType.white);
      this.generate.SetImage(SmallRoundedButton.IcoType.Settings);
      this.generate.clickEvent += new SmallRoundedButton.ClickDelegate(this.Generate_clickEvent);
      this.studentName.TextInside = student.Name;
      this.studentSurname.TextInside = student.Surname;
      this.password.TextInside = student.Student_explicitPassword;
      this.studentRegisterNumber.TextInside = student.Student_numberInRegister.ToString();
    }

    private void Generate_clickEvent() => this.password.TextInside = StudentPasswordGenerator.GeneratePass();

    private void EditStudent_clickEvent()
    {
      if (this.student.Email != null)
      {
        if (!int.TryParse(this.studentRegisterNumber.TextInside, out int _) && this.studentRegisterNumber.TextInside.Length != 0)
        {
          this.studentRegisterNumber.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("shouldNumber"));
        }
        else
        {
          try
          {
            ServerApi serverApi = new ServerApi();
            if (this.studentRegisterNumber.TextInside.Length != 0)
              this.student.Student_numberInRegister = new int?(Convert.ToInt32(this.studentRegisterNumber.TextInside));
            User student = this.student;
            AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
            serverApi.UpdateOrDeleteUser(student, authorize);
            this.Abort_clickEvent();
          }
          catch (Exception ex)
          {
            CustomMessageBox.Show(ex.Message);
          }
        }
      }
      else if (this.studentName.TextInside.IsNullOrWhiteSpace() || this.studentSurname.TextInside.IsNullOrWhiteSpace() || this.password.TextInside.IsNullOrWhiteSpace() || !int.TryParse(this.studentRegisterNumber.TextInside, out int _) && this.studentRegisterNumber.TextInside.Length != 0)
      {
        if (this.studentName.TextInside.IsNullOrWhiteSpace())
          this.studentName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNameWarn"));
        if (this.studentSurname.TextInside.IsNullOrWhiteSpace())
          this.studentSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterSurnameWarn"));
        if (!int.TryParse(this.studentRegisterNumber.TextInside, out int _) && this.studentRegisterNumber.TextInside.Length != 0)
          this.studentRegisterNumber.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("shouldNumber"));
        if (!this.password.TextInside.IsNullOrWhiteSpace())
          return;
        this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPasswordWarn"));
      }
      else if (this.password.TextInside.HasWhitespace())
        this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noSpaces"));
      else if (this.password.TextInside.Length < 4)
        this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("4chars"));
      else if (this.dateOfBirth.textBoxRounded.textBox.Text.Length > 0)
      {
        string format = "yyyy";
        try
        {
          DateTime.ParseExact(this.dateOfBirth.textBoxRounded.textBox.Text, format, (IFormatProvider) DateTimeFormatInfo.InvariantInfo);
          this.saveDateBirth = true;
          this.UpdateUser();
        }
        catch
        {
          this.dateOfBirth.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("errorFormatDateOfBirth"));
          this.saveDateBirth = false;
        }
      }
      else
        this.UpdateUser();
    }

    private void UpdateUser()
    {
      try
      {
        ServerApi serverApi = new ServerApi();
        this.student.Name = this.studentName.TextInside;
        this.student.Surname = this.studentSurname.TextInside;
        this.student.AvatarName = this.face.GetSelectedFace();
        this.student.Student_explicitPassword = this.password.TextInside;
        if (this.saveDateBirth)
          this.student.DateOfBirth = new DateTime?(DateTime.Parse("01.01." + this.dateOfBirth.textBoxRounded.textBox.Text));
        else if (this.dateOfBirth.textBoxRounded.textBox.Text.Length == 0)
          this.student.DateOfBirth = new DateTime?();
        this.student.Student_numberInRegister = this.studentRegisterNumber.TextInside.Length == 0 ? new int?() : new int?(Convert.ToInt32(this.studentRegisterNumber.TextInside));
        User student = this.student;
        AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
        serverApi.UpdateOrDeleteUser(student, authorize);
        this.Abort_clickEvent();
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.Message);
      }
    }

    private void Abort_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/editstudentview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.stackPanel = (StackPanel) target;
          break;
        case 2:
          this.bigCaption = (BigCaption) target;
          break;
        case 3:
          this.studentName = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.studentSurname = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.studentRegisterNumber = (RoundedTextBoxAndLabel) target;
          break;
        case 6:
          this.dateOfBirth = (RoundedTextBoxAndLabel) target;
          break;
        case 7:
          this.password = (RoundedTextBoxAndLabel) target;
          break;
        case 8:
          this.generate = (SmallRoundedButton) target;
          break;
        case 9:
          this.faceDescription = (SmallInfoText) target;
          break;
        case 10:
          this.face = (FacesSelector) target;
          break;
        case 11:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
