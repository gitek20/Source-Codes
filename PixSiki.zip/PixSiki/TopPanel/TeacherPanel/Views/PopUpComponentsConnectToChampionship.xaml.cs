﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.ConnectToChampionship
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Championsships;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.GlobalProgressBar;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class ConnectToChampionship : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private Championship championship;
    private bool isOfAge;
    private DateTime dateTimeUser;
    private User user;
    private static Regex ValidEmailRegex = ConnectToChampionship.CreateValidEmailRegex();
    internal StackPanel stackPanel;
    internal BigCaption bigCaption;
    internal BigCaption bigCaptionBotton;
    internal RoundedTextBoxAndLabel dateOfBirth;
    internal Label labelEnterBrith;
    internal Label dayTitle;
    internal ComboBox dayOfBirth;
    internal Label monthTitle;
    internal ComboBox monthOfBirth;
    internal Label yearTitle;
    internal ComboBox yearOfBrith;
    internal Grid data18years;
    internal RoundedTextBoxAndLabel userName18;
    internal RoundedTextBoxAndLabel userSurname18;
    internal CheckBox accpetTermsCheckBox18;
    internal ButtonLink terms18;
    internal StackPanel dataNo18years;
    internal TextBlock textOnlyForPL;
    internal RoundedTextBoxAndLabel userName;
    internal RoundedTextBoxAndLabel userSurname;
    internal RoundedTextBoxAndLabel parentName;
    internal RoundedTextBoxAndLabel parentSurname;
    internal RoundedTextBoxAndLabel parentPhone;
    internal RoundedTextBoxAndLabel parentEmail;
    internal CheckBox accpetTermsCheckBox;
    internal ButtonLink terms;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public ConnectToChampionship(Championship championship, User user, StudentsClass studentClass)
    {
      this.InitializeComponent();
      this.user = user;
      this.championship = championship;
      this.bigCaption.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("joinTitle");
      this.bigCaptionBotton.Content = (object) championship.Name;
      this.dateOfBirth.Description = "Podaj Twoj rok urodzenia";
      if (CurrentUserInfo.CurrentUser.Teacher_isTeacher && user.Student_isStudent)
      {
        this.bigCaption.Content = (object) "Dołącz ucznia do konkursu:";
        this.dateOfBirth.Description = "Podaj rok urodzenia ucznia";
      }
      DateTime? dateOfBirth = user.DateOfBirth;
      if (dateOfBirth.HasValue)
      {
        DateTime dateTime = new DateTime();
        dateOfBirth = user.DateOfBirth;
        this.dateOfBirth.textBoxRounded.textBox.Text = DateTime.Parse(dateOfBirth.ToString()).Year.ToString() + "-01-01";
      }
      else
        this.dateOfBirth.textBoxRounded.textBox.Text = studentClass == null ? "" : studentClass.Yearbook.ToString();
      this.userName18.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("firstName");
      this.userSurname18.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("surname");
      this.userName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("firstName");
      this.userSurname.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("surname");
      this.terms.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("regulationsTitle");
      this.terms18.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("regulationsTitle");
      this.accpetTermsCheckBox.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("acceptRegulations");
      this.accpetTermsCheckBox18.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("acceptRegulations");
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("joinToChampionchipBtn");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.Click_Event_AcceptCahmpionship);
      this.actionButtons.confirm.IsEnabled = false;
      this.terms.clickEvent += new ButtonLink.ClickDelegate(this.Click_event_ShowTerms);
      this.terms18.clickEvent += new ButtonLink.ClickDelegate(this.Click_event_ShowTerms);
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.Click_Event_ClosePopup);
      this.labelEnterBrith.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterYourBrith");
      this.yearOfBrith.ItemsSource = (IEnumerable) Enumerable.Range(DateTime.Today.Year - 20, 15).ToList<int>().OrderByDescending<int, int>((Func<int, int>) (n => n));
      this.yearOfBrith.SelectionChanged += new SelectionChangedEventHandler(this.YearOfBrith_SelectionChanged);
      this.yearTitle.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("year");
      dateOfBirth = user.DateOfBirth;
      if (dateOfBirth.HasValue)
      {
        dateOfBirth = user.DateOfBirth;
        DateTime.Parse(dateOfBirth.ToString());
      }
      this.monthTitle.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("month");
      this.monthOfBirth.ItemsSource = (IEnumerable) Enumerable.Range(1, 12).ToList<int>();
      this.monthOfBirth.SelectionChanged += new SelectionChangedEventHandler(this.YearOfBrith_SelectionChanged);
      this.dayTitle.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("day");
      this.dayOfBirth.ItemsSource = (IEnumerable) Enumerable.Range(1, 31).ToList<int>();
      this.dayOfBirth.SelectionChanged += new SelectionChangedEventHandler(this.YearOfBrith_SelectionChanged);
      this.parentName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (parentName));
      this.parentSurname.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (parentSurname));
      this.parentPhone.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (parentPhone));
      this.parentEmail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (parentEmail));
      if (championship.CountryId == 177)
      {
        this.textOnlyForPL.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("textForOnlyPLC");
        this.textOnlyForPL.Visibility = Visibility.Visible;
      }
      else
        this.textOnlyForPL.Visibility = Visibility.Collapsed;
    }

    private void YearOfBrith_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (this.yearOfBrith.SelectedItem == null || this.monthOfBirth.SelectedItem == null || this.dayOfBirth.SelectedItem == null)
        return;
      DateTime dateOfBirth = new DateTime();
      try
      {
        dateOfBirth = new DateTime(int.Parse(this.yearOfBrith.SelectedItem.ToString()), int.Parse(this.monthOfBirth.SelectedItem.ToString()), int.Parse(this.dayOfBirth.SelectedItem.ToString()));
        this.labelEnterBrith.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterYourBrith");
        this.labelEnterBrith.Foreground = (Brush) new SolidColorBrush(Colors.Black);
      }
      catch
      {
        this.labelEnterBrith.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("wrongDate");
        this.labelEnterBrith.Foreground = (Brush) new SolidColorBrush(Colors.Red);
        this.data18years.Visibility = Visibility.Collapsed;
        this.dataNo18years.Visibility = Visibility.Collapsed;
        this.accpetTermsCheckBox.Visibility = Visibility.Collapsed;
        this.accpetTermsCheckBox18.Visibility = Visibility.Collapsed;
      }
      int age = this.GetAge(dateOfBirth);
      this.dateTimeUser = dateOfBirth;
      if (age < 18)
      {
        this.dataNo18years.Visibility = Visibility.Visible;
        this.data18years.Visibility = Visibility.Collapsed;
        this.isOfAge = false;
        this.actionButtons.confirm.IsEnabled = false;
        this.accpetTermsCheckBox.IsChecked = new bool?(false);
        this.accpetTermsCheckBox18.IsChecked = new bool?(false);
      }
      else
      {
        this.data18years.Visibility = Visibility.Visible;
        this.dataNo18years.Visibility = Visibility.Collapsed;
        this.isOfAge = true;
        this.actionButtons.confirm.IsEnabled = false;
        this.accpetTermsCheckBox.IsChecked = new bool?(false);
        this.accpetTermsCheckBox18.IsChecked = new bool?(false);
      }
    }

    public int GetAge(DateTime dateOfBirth)
    {
      DateTime today = DateTime.Today;
      return ((today.Year * 100 + today.Month) * 100 + today.Day - ((dateOfBirth.Year * 100 + dateOfBirth.Month) * 100 + dateOfBirth.Day)) / 10000;
    }

    private static Regex CreateValidEmailRegex() => new Regex("^(?!\\.)(\"([^\"\\r\\\\]|\\\\[\"\\r\\\\])*\"|([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\\.)\\.)*)(?<!\\.)@[a-z0-9][\\w\\.-]*[a-z0-9]\\.[a-z][a-z\\.]*[a-z]$", RegexOptions.IgnoreCase);

    internal static bool EmailIsValid(string emailAddress) => ConnectToChampionship.ValidEmailRegex.IsMatch(emailAddress);

    private bool IsEmailValid(string email) => ConnectToChampionship.EmailIsValid(email);

    private void Click_Event_ClosePopup()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    private void Click_Event_AcceptCahmpionship()
    {
      if (!this.isOfAge)
      {
        if (this.userName.textBoxRounded.textBox.Text.IsNullOrEmpty() || this.userSurname.textBoxRounded.textBox.Text.IsNullOrEmpty() || (this.parentName.textBoxRounded.textBox.Text.IsNullOrEmpty() || this.parentSurname.textBoxRounded.textBox.Text.IsNullOrEmpty()) || (this.parentEmail.textBoxRounded.textBox.Text.IsNullOrEmpty() || this.parentPhone.textBoxRounded.textBox.Text.IsNullOrEmpty() || !this.IsEmailValid(this.parentEmail.textBoxRounded.textBox.Text)))
        {
          if (this.userName.textBoxRounded.textBox.Text.IsNullOrEmpty())
            this.userName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNameWarn"));
          if (this.userSurname.textBoxRounded.textBox.Text.IsNullOrEmpty())
            this.userSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterSurnameWarn"));
          if (this.parentName.textBoxRounded.textBox.Text.IsNullOrEmpty())
            this.parentName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNameC"));
          if (this.parentSurname.textBoxRounded.textBox.Text.IsNullOrEmpty())
            this.parentSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterSurnameC"));
          if (this.parentEmail.textBoxRounded.textBox.Text.IsNullOrEmpty() || !this.IsEmailValid(this.parentEmail.textBoxRounded.textBox.Text))
            this.parentEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterEmailC"));
          if (!this.parentPhone.textBoxRounded.textBox.Text.IsNullOrEmpty())
            return;
          this.parentPhone.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPhoneC"));
        }
        else
          this.ConnectToChampionshipMethod();
      }
      else if (this.userName18.textBoxRounded.textBox.Text.IsNullOrEmpty() || this.userSurname18.textBoxRounded.textBox.Text.IsNullOrEmpty())
      {
        if (this.userName18.textBoxRounded.textBox.Text.IsNullOrEmpty())
          this.userName18.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNameWarn"));
        if (!this.userSurname18.textBoxRounded.textBox.Text.IsNullOrEmpty())
          return;
        this.userSurname18.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterSurnameWarn"));
      }
      else
        this.ConnectToChampionshipMethod();
    }

    public void ConnectToChampionshipMethod() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      ServerApi serverApi = new ServerApi();
      if (!this.isOfAge)
      {
        serverApi.AddOrUpdateParentInfo(new ParentInfo()
        {
          IdChild = CurrentUserInfo.CurrentUser.Id.Value,
          ParentName = this.parentName.textBoxRounded.textBox.Text,
          ParentSurname = this.parentSurname.textBoxRounded.textBox.Text,
          ParentEmail = this.parentEmail.textBoxRounded.textBox.Text,
          ParentPhone = this.parentPhone.textBoxRounded.textBox.Text
        }, new AuthorizeData(CurrentUserInfo.CurrentUser));
        this.user.Name = this.userName.textBoxRounded.textBox.Text;
        this.user.Surname = this.userSurname.textBoxRounded.textBox.Text;
      }
      else
      {
        this.user.Name = this.userName18.textBoxRounded.textBox.Text;
        this.user.Surname = this.userSurname18.textBoxRounded.textBox.Text;
      }
      this.user.ChampionshipId = new int?(this.championship.Id);
      this.user.DateOfBirth = new DateTime?(this.dateTimeUser);
      CurrentUserInfo.CurrentUser = serverApi.UpdateOrDeleteUser(this.user, CurrentUserInfo.AuthorizeData);
      if (this.closePopUpEvent != null)
        this.closePopUpEvent(this.parentPopUp);
      UserMenager.InvokeEventChampionship();
      UserMenager.InvokeEventChampionship();
    }));

    private void Click_event_ShowTerms()
    {
      try
      {
        Process.Start(this.championship.Regulations);
      }
      catch
      {
        CustomMessageBox.Show("Regulamin znajdziesz na: " + this.championship.Regulations);
      }
    }

    private void Abort_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    private void AccpetTermsCheckBox_Checked(object sender, RoutedEventArgs e) => this.actionButtons.confirm.IsEnabled = true;

    private void AccpetTermsCheckBox_Unchecked(object sender, RoutedEventArgs e) => this.actionButtons.confirm.IsEnabled = false;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/connecttochampionship.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.stackPanel = (StackPanel) target;
          break;
        case 2:
          this.bigCaption = (BigCaption) target;
          break;
        case 3:
          this.bigCaptionBotton = (BigCaption) target;
          break;
        case 4:
          this.dateOfBirth = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.labelEnterBrith = (Label) target;
          break;
        case 6:
          this.dayTitle = (Label) target;
          break;
        case 7:
          this.dayOfBirth = (ComboBox) target;
          break;
        case 8:
          this.monthTitle = (Label) target;
          break;
        case 9:
          this.monthOfBirth = (ComboBox) target;
          break;
        case 10:
          this.yearTitle = (Label) target;
          break;
        case 11:
          this.yearOfBrith = (ComboBox) target;
          break;
        case 12:
          this.data18years = (Grid) target;
          break;
        case 13:
          this.userName18 = (RoundedTextBoxAndLabel) target;
          break;
        case 14:
          this.userSurname18 = (RoundedTextBoxAndLabel) target;
          break;
        case 15:
          this.accpetTermsCheckBox18 = (CheckBox) target;
          this.accpetTermsCheckBox18.Checked += new RoutedEventHandler(this.AccpetTermsCheckBox_Checked);
          this.accpetTermsCheckBox18.Unchecked += new RoutedEventHandler(this.AccpetTermsCheckBox_Unchecked);
          break;
        case 16:
          this.terms18 = (ButtonLink) target;
          break;
        case 17:
          this.dataNo18years = (StackPanel) target;
          break;
        case 18:
          this.textOnlyForPL = (TextBlock) target;
          break;
        case 19:
          this.userName = (RoundedTextBoxAndLabel) target;
          break;
        case 20:
          this.userSurname = (RoundedTextBoxAndLabel) target;
          break;
        case 21:
          this.parentName = (RoundedTextBoxAndLabel) target;
          break;
        case 22:
          this.parentSurname = (RoundedTextBoxAndLabel) target;
          break;
        case 23:
          this.parentPhone = (RoundedTextBoxAndLabel) target;
          break;
        case 24:
          this.parentEmail = (RoundedTextBoxAndLabel) target;
          break;
        case 25:
          this.accpetTermsCheckBox = (CheckBox) target;
          this.accpetTermsCheckBox.Checked += new RoutedEventHandler(this.AccpetTermsCheckBox_Checked);
          this.accpetTermsCheckBox.Unchecked += new RoutedEventHandler(this.AccpetTermsCheckBox_Unchecked);
          break;
        case 26:
          this.terms = (ButtonLink) target;
          break;
        case 27:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
