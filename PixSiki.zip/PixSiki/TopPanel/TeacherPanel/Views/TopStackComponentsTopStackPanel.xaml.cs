﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.TopStackPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Models;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.images;
using PixBlocks.Views.AdditionalBrandingView;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents
{
  public partial class TopStackPanel : UserControl, IComponentConnector
  {
    private ITeacherPanelController mainTeacherPanel;
    private List<TopStackItem> topStackItems = new List<TopStackItem>();
    internal RoundedButton backButton;
    internal StackPanel stackPanelLeft;
    private bool _contentLoaded;

    public TopStackPanel(ITeacherPanelController mainTeacherPanel)
    {
      this.InitializeComponent();
      this.mainTeacherPanel = mainTeacherPanel;
      this.backButton.Description = "";
      this.backButton.IsSmallCircle = true;
      this.backButton.SetImage((UserControl) new BackIcon());
      this.backButton.Visibility = Visibility.Collapsed;
      this.backButton.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.ShowBackButtonEnabled();
      UserControl branding = AdditionalBrandingManager.GetBranding();
      branding.Visibility = Visibility.Hidden;
      branding.Height = 60.0;
      this.stackPanelLeft.Children.Add((UIElement) branding);
    }

    public void BackButton_clickEvent()
    {
      if (this.topStackItems.Count > 1)
        this.TopStackItem_topStackClickEvent(this.topStackItems[this.topStackItems.Count - 2]);
      this.ShowBackButtonEnabled();
    }

    public Action GoBack => (Action) (() => this.BackButton_clickEvent());

    private void ShowBackButtonEnabled()
    {
      if (this.topStackItems.Count <= 1)
        this.backButton.SetEnable(true);
      else
        this.backButton.SetEnable(false);
    }

    public void Clear()
    {
      this.stackPanelLeft.Children.Clear();
      this.ShowBackButtonEnabled();
    }

    public void AddToStackPanel(TopStackItem topStackItem)
    {
      this.stackPanelLeft.Children.Add((UIElement) topStackItem);
      this.topStackItems.Add(topStackItem);
      topStackItem.topStackClickEvent += new TopStackItem.TopStackClick(this.TopStackItem_topStackClickEvent);
      this.ShowBackButtonEnabled();
    }

    private void TopStackItem_topStackClickEvent(TopStackItem item)
    {
      int index1 = -1;
      for (int index2 = this.topStackItems.Count - 1; index2 >= 0; --index2)
      {
        if (this.topStackItems[index2] == item)
        {
          index1 = index2 + 1;
          break;
        }
        this.stackPanelLeft.Children.Remove((UIElement) this.topStackItems[index2]);
        this.topStackItems[index2].ModelOnStack.DisposeView();
      }
      this.topStackItems.RemoveRange(index1, this.topStackItems.Count - index1);
      item.ModelOnStack.RefreshView();
      this.mainTeacherPanel.CurrentPanel = item.ModelOnStack;
      this.mainTeacherPanel.ClosePopUp();
      this.ShowBackButtonEnabled();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/topstackcomponents/topstackpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.stackPanelLeft = (StackPanel) target;
        else
          this._contentLoaded = true;
      }
      else
        this.backButton = (RoundedButton) target;
    }
  }
}
