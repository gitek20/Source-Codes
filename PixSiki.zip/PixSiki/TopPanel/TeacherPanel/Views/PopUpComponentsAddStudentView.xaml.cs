﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.AddStudentView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.Tools;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.FaceButtons;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.TeacherPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class AddStudentView : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private int classId;
    internal BigCaption bigCaption;
    internal SmallInfoText addNewStudentsInfo;
    internal RoundedTextBoxAndLabel studentName;
    internal RoundedTextBoxAndLabel studentSurname;
    internal RoundedTextBoxAndLabel numberInRegister;
    internal SmallInfoText smallDescAvatar;
    internal FacesSelector faceSelector;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    public AddStudentView(int classId)
    {
      this.InitializeComponent();
      this.classId = classId;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addStudent");
      this.addNewStudentsInfo.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addNewstudentsInfo") + " " + StudentsClassCodeParser.CodeToClassCode(new int?(classId));
      this.studentName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("firstName");
      this.studentSurname.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("surname");
      this.numberInRegister.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("registerNumber");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.CloseStudentClass_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addStudent");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.AddStudent_clickEvent);
      this.smallDescAvatar.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("selectAvatar");
    }

    private void AddStudent_clickEvent()
    {
      int result = -1;
      if (string.IsNullOrWhiteSpace(this.studentName.TextInside) || string.IsNullOrEmpty(this.studentName.TextInside) || (string.IsNullOrWhiteSpace(this.studentSurname.TextInside) || string.IsNullOrEmpty(this.studentSurname.TextInside)))
      {
        if (string.IsNullOrWhiteSpace(this.studentName.TextInside) || string.IsNullOrEmpty(this.studentName.TextInside))
          this.studentName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("studentNameWarn"));
        if (!string.IsNullOrWhiteSpace(this.studentSurname.TextInside) && !string.IsNullOrEmpty(this.studentSurname.TextInside))
          return;
        this.studentSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("studentSurnameWarn"));
      }
      else if (!string.IsNullOrWhiteSpace(this.numberInRegister.TextInside) && !string.IsNullOrEmpty(this.numberInRegister.TextInside) && (!int.TryParse(this.numberInRegister.TextInside, out result) || result <= 0))
      {
        this.numberInRegister.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("invalidNumberFormat"));
      }
      else
      {
        try
        {
          ServerApi serverApi = new ServerApi();
          StudentsClass studentsClass = new StudentsClass();
          User user1 = new User();
          user1.Name = this.studentName.TextInside;
          user1.Surname = this.studentSurname.TextInside;
          user1.AvatarName = this.faceSelector.GetSelectedFace();
          user1.Student_isStudent = true;
          user1.Student_studentsClassId = new int?(this.classId);
          user1.Student_isAcceptedToStudentsClass = new bool?(true);
          user1.Student_isAssignedToStudentsClass = true;
          if (result > 0)
          {
            user1.Student_numberInRegister = new int?(result);
            user1.Student_login = StudentLoginGenerator.GenerateLogin(this.classId, this.studentName.TextInside, new int?(result));
          }
          else
            user1.Student_login = StudentLoginGenerator.GenerateLogin(this.classId, this.studentName.TextInside);
          user1.Student_isAcceptedToStudentsClass = new bool?(true);
          user1.Student_isAssignedToStudentsClass = true;
          user1.Student_explicitPassword = StudentPasswordGenerator.GeneratePass();
          user1.CountryId = CurrentUserInfo.CurrentUser.CountryId;
          User user2 = user1;
          serverApi.RegisterNewUser(user2);
          this.CloseStudentClass_clickEvent();
        }
        catch (Exception ex)
        {
          CustomMessageBox.Show(ex.Message);
        }
      }
    }

    private void CloseStudentClass_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/addstudentview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.addNewStudentsInfo = (SmallInfoText) target;
          break;
        case 3:
          this.studentName = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.studentSurname = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.numberInRegister = (RoundedTextBoxAndLabel) target;
          break;
        case 6:
          this.smallDescAvatar = (SmallInfoText) target;
          break;
        case 7:
          this.faceSelector = (FacesSelector) target;
          break;
        case 8:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
