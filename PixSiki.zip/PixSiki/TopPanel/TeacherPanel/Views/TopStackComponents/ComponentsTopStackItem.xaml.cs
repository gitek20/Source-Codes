﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components.TopStackItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components
{
  public partial class TopStackItem : UserControl, IComponentConnector
  {
    private ISubPanelOnStackController modelOnStack;
    internal Rectangle deselectedRectangle;
    internal Rectangle selectRectangle;
    internal TextBlock textBox;
    private bool _contentLoaded;

    public ISubPanelOnStackController ModelOnStack => this.modelOnStack;

    public TopStackItem(ISubPanelOnStackController modelOnStack)
    {
      this.modelOnStack = modelOnStack;
      this.InitializeComponent();
      this.textBox.Text = modelOnStack.Description;
      this.selectRectangle.Visibility = Visibility.Collapsed;
      modelOnStack.DescriptionChangeEvent += new DescriptionChange(this.ModelOnStack_DescriptionChangeEvent);
    }

    private void ModelOnStack_DescriptionChangeEvent() => this.textBox.Text = this.modelOnStack.Description;

    private void Grid_MouseEnter(object sender, MouseEventArgs e) => this.selectRectangle.Visibility = Visibility.Visible;

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.selectRectangle.Visibility = Visibility.Collapsed;

    public event TopStackItem.TopStackClick topStackClickEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.topStackClickEvent == null)
        return;
      this.topStackClickEvent(this);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/topstackcomponents/components/topstackitem.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.deselectedRectangle = (Rectangle) target;
          break;
        case 2:
          this.selectRectangle = (Rectangle) target;
          break;
        case 3:
          this.textBox = (TextBlock) target;
          break;
        case 4:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void TopStackClick(TopStackItem item);
  }
}
