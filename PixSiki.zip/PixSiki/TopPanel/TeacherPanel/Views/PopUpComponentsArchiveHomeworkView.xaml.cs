﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.ArchiveHomeworkView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.GlobalProgressBar;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class ArchiveHomeworkView : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private Exam exam;
    internal BigCaption bigCaption;
    internal SmallInfoText info;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public ArchiveHomeworkView(Exam exam, Action backToHomework)
    {
      this.InitializeComponent();
      this.exam = exam;
      if (exam.IsHomework)
      {
        this.bigCaption.Description = "Archiwizuj zadanie domowe";
        this.info.Description = "Czy jesteś pewień, że chcesz archiwizować zadanie domowe " + exam.Name + " ";
      }
      else
      {
        this.bigCaption.Description = "Archiwizuj egzamin";
        this.info.Description = "Czy jesteś pewień, że chcesz archiwizować egzamin " + exam.Name + " ";
      }
      this.actionButtons.abort.Description = "Wstecz";
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_ClickEvent);
      this.actionButtons.confirm.Description = "Archiwizuj";
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.ArchiveButton_ClickEvent);
      this.actionButtons.confirm.clickEvent += (RoundedButton.ClickDelegate) (() => backToHomework());
    }

    private void ArchiveButton_ClickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      ServerApi serverApi = new ServerApi();
      this.exam.IsArchived = true;
      Exam exam = this.exam;
      AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
      serverApi.UpdateOrDeleteExam(exam, authorize);
    }));

    private void BackButton_ClickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/archivehomeworkview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.info = (SmallInfoText) target;
          break;
        case 3:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
