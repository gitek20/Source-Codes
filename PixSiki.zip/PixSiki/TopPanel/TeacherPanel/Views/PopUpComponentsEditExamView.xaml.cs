﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.EditExamView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Championsships;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.GlobalProgressBar;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class EditExamView : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private Championship selectedChampionship;
    private Exam exam;
    internal StackPanel stackPanel;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel homeworkName;
    internal RoundedTextBoxAndLabel homeworkDescription;
    internal CheckBox isChampionship;
    internal ComboBox championshipsList;
    internal Label startYearlabel;
    internal TextBox yearStart;
    internal Label stopYearLabel;
    internal TextBox yearStop;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public EditExamView(Exam exam)
    {
      this.exam = exam;
      this.InitializeComponent();
      this.championshipsList.SelectionChanged += new SelectionChangedEventHandler(this.ChampionshipsList_SelectionChanged);
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("edit");
      this.homeworkName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("name");
      this.homeworkName.textBoxRounded.textBox.Text = exam.Name;
      this.homeworkDescription.textBoxRounded.textBox.Text = exam.Description;
      this.homeworkDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("description");
      if (CurrentUserInfo.CurrentUser.Admin_isAdmin)
      {
        List<Championship> activeChampionships = new ServerApi().GetAllActiveChampionships(CurrentUserInfo.AuthorizeData);
        foreach (Championship championship in activeChampionships)
        {
          ComboBoxItem comboBoxItem = new ComboBoxItem();
          comboBoxItem.Content = (object) (championship.Name + " ( Start: " + championship.Start_date.ToString() + " )");
          comboBoxItem.Tag = (object) championship;
          this.championshipsList.Items.Add((object) comboBoxItem);
        }
        this.isChampionship.Content = (object) "Zadania na mistrzostwa";
        this.isChampionship.Visibility = Visibility.Visible;
        this.championshipsList.Visibility = Visibility.Visible;
        this.startYearlabel.Visibility = Visibility.Visible;
        this.yearStart.Visibility = Visibility.Visible;
        this.stopYearLabel.Visibility = Visibility.Visible;
        this.yearStop.Visibility = Visibility.Visible;
        if (exam.IsChampionship)
        {
          this.isChampionship.IsChecked = new bool?(true);
          DateTime dateTime = new DateTime();
          this.yearStart.Text = exam.ChampionshipStartYear.Value.Year.ToString();
          this.yearStop.Text = exam.ChampionshipStopYear.Value.Year.ToString();
          this.isChampionship.IsChecked = new bool?(true);
          for (int index = 0; index < activeChampionships.Count; ++index)
          {
            int? championshipId = exam.ChampionshipId;
            int id = activeChampionships[index].Id;
            if (championshipId.GetValueOrDefault() == id & championshipId.HasValue)
              this.championshipsList.SelectedIndex = index;
          }
        }
      }
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.Abort_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("save");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.EditExam_clickEvent);
    }

    private void ChampionshipsList_SelectionChanged(object sender, SelectionChangedEventArgs e) => this.selectedChampionship = (this.championshipsList.SelectedItem as ComboBoxItem).Tag as Championship;

    private void EditExam_clickEvent()
    {
      if (this.homeworkName.textBoxRounded.textBox.Text.Length == 0 || this.homeworkDescription.textBoxRounded.textBox.Text.Length == 0)
      {
        if (this.homeworkName.textBoxRounded.textBox.Text.Length == 0)
        {
          if (this.exam.IsHomework)
            this.homeworkName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterHomeworkName"));
          else
            this.homeworkName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterExamName"));
        }
        if (this.homeworkDescription.textBoxRounded.textBox.Text.Length != 0)
          return;
        if (this.exam.IsHomework)
          this.homeworkDescription.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterHomeworkDesc"));
        else
          this.homeworkDescription.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterExamDesc"));
      }
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          ServerApi serverApi = new ServerApi();
          if (this.isChampionship.IsChecked.Value)
          {
            this.exam.IsChampionship = true;
            this.exam.ChampionshipStartYear = new DateTime?(DateTime.Parse("01.01." + this.yearStart.Text));
            this.exam.ChampionshipStopYear = new DateTime?(DateTime.Parse("31.12." + this.yearStop.Text));
            this.exam.ChampionshipId = new int?(this.selectedChampionship.Id);
          }
          else
          {
            this.exam.IsChampionship = false;
            this.exam.ChampionshipStartYear = new DateTime?();
            this.exam.ChampionshipStopYear = new DateTime?();
            this.exam.ChampionshipId = new int?();
          }
          this.exam.Name = this.homeworkName.textBoxRounded.textBox.Text;
          this.exam.Description = this.homeworkDescription.textBoxRounded.textBox.Text;
          Exam exam = this.exam;
          AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
          serverApi.UpdateOrDeleteExam(exam, authorize);
          if (this.closePopUpEvent == null)
            return;
          this.closePopUpEvent(this.parentPopUp);
        }));
    }

    private void Abort_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/editexamview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.stackPanel = (StackPanel) target;
          break;
        case 2:
          this.bigCaption = (BigCaption) target;
          break;
        case 3:
          this.homeworkName = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.homeworkDescription = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.isChampionship = (CheckBox) target;
          break;
        case 6:
          this.championshipsList = (ComboBox) target;
          break;
        case 7:
          this.startYearlabel = (Label) target;
          break;
        case 8:
          this.yearStart = (TextBox) target;
          break;
        case 9:
          this.stopYearLabel = (Label) target;
          break;
        case 10:
          this.yearStop = (TextBox) target;
          break;
        case 11:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
