﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.AddStudentsClassView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.GlobalProgressBar;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class AddStudentsClassView : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private int currentYear;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel className;
    internal RoundedTextBoxAndLabel classDescription;
    internal RoundedTextBoxAndLabel classYear;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public AddStudentsClassView()
    {
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addClass");
      this.className.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (className));
      this.classDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classDescription));
      this.classYear.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classYear));
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.CloseStudentClass_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addClass");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.AddStudentClass_clickEvent);
      this.currentYear = DateTime.Now.Year;
    }

    private void AddStudentClass_clickEvent()
    {
      if (string.IsNullOrWhiteSpace(this.className.TextInside) || string.IsNullOrEmpty(this.className.TextInside) || (string.IsNullOrWhiteSpace(this.classYear.TextInside) || string.IsNullOrEmpty(this.classYear.TextInside)))
      {
        if (string.IsNullOrWhiteSpace(this.className.TextInside) || string.IsNullOrEmpty(this.className.TextInside))
          this.className.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classNameWarn"));
        if (!string.IsNullOrWhiteSpace(this.classYear.TextInside) && !string.IsNullOrEmpty(this.classYear.TextInside))
          return;
        this.classYear.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classYearWarn"));
      }
      else if (this.classYear.textBoxRounded.textBox.Text.Length < 4 || this.classYear.textBoxRounded.textBox.Text.Length > 4)
      {
        this.classYear.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("invalidClassYearFormat"));
      }
      else
      {
        int result;
        if (!int.TryParse(this.classYear.TextInside, out result))
          this.classYear.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("invalidClassYearFormat"));
        else if (result > this.currentYear - 2 || result < this.currentYear - 100)
          this.classYear.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("invalidClassYearRange"));
        else
          GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
          {
            new ServerApi().AddStudentsClass(new StudentsClass()
            {
              Name = this.className.TextInside,
              Description = this.classDescription.TextInside,
              Yearbook = int.Parse(this.classYear.TextInside),
              TeacherID = CurrentUserInfo.CurrentUser.Id.Value
            }, new AuthorizeData(CurrentUserInfo.CurrentUser));
            this.CloseStudentClass_clickEvent();
          }));
      }
    }

    private void CloseStudentClass_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/addstudentsclassview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.className = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.classDescription = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.classYear = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
