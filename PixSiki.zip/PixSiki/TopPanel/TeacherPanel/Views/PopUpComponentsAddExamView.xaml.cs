﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.AddExamView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class AddExamView : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private StudentsClass studentClass;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel examName;
    internal RoundedTextBoxAndLabel examDescription;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public AddExamView(StudentsClass classe)
    {
      this.InitializeComponent();
      this.studentClass = classe;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addExam");
      this.examName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("name");
      this.examDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("description");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackEvent_ClickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("add");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.AddExam_ClickEvent);
    }

    private void AddExam_ClickEvent()
    {
      if (this.examName.textBoxRounded.textBox.Text.Length != 0)
      {
        if (this.examDescription.textBoxRounded.textBox.Text.Length != 0)
        {
          try
          {
            ServerApi serverApi = new ServerApi();
            Exam exam1 = new Exam()
            {
              IsHomework = false,
              StudentsClassId = this.studentClass.Id.Value,
              Name = this.examName.textBoxRounded.textBox.Text,
              Descripton = this.examDescription.textBoxRounded.textBox.Text,
              IsHomeworkVisibly = false
            };
            exam1.StudentsClassId = this.studentClass.Id.Value;
            exam1.IsArchived = false;
            exam1.IsDeleted = false;
            Exam exam2 = exam1;
            AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
            serverApi.AddNewExam(exam2, authorize);
            if (this.closePopUpEvent == null)
              return;
            this.closePopUpEvent(this.parentPopUp);
            return;
          }
          catch (Exception ex)
          {
            CustomMessageBox.Show(ex.ToString());
            return;
          }
        }
      }
      if (this.examName.textBoxRounded.textBox.Text.Length == 0)
        this.examName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterExamName"));
      if (this.examDescription.textBoxRounded.textBox.Text.Length != 0)
        return;
      this.examDescription.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterExamDesc"));
    }

    private void BackEvent_ClickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/addexamview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.examName = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.examDescription = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
