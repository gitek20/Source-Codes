﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.ActionPanelComponents.ActionPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.ActionPanelComponents
{
  public partial class ActionPanel : UserControl, IComponentConnector
  {
    internal TextBlock textBlock;
    internal StackPanel stackPanelLeft;
    internal StackPanel stackPanelRight;
    private bool _contentLoaded;

    public ActionPanel() => this.InitializeComponent();

    public void SetCaption(string caption) => this.textBlock.Text = caption;

    public void Clear()
    {
      this.stackPanelLeft.Children.Clear();
      this.stackPanelRight.Children.Clear();
      this.SetCaption("");
    }

    public void AddToLeftSide(UserControl userControl)
    {
      this.stackPanelLeft.Children.Add((UIElement) userControl);
      userControl.VerticalAlignment = VerticalAlignment.Center;
      Grid grid = new Grid();
      grid.Width = 20.0;
      this.stackPanelLeft.Children.Add((UIElement) grid);
    }

    public void AddToRightSide(UserControl userControl)
    {
      Grid grid = new Grid();
      grid.Width = 20.0;
      this.stackPanelRight.Children.Add((UIElement) grid);
      this.stackPanelRight.Children.Add((UIElement) userControl);
      userControl.VerticalAlignment = VerticalAlignment.Center;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/actionpanelcomponents/actionpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.textBlock = (TextBlock) target;
          break;
        case 2:
          this.stackPanelLeft = (StackPanel) target;
          break;
        case 3:
          this.stackPanelRight = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
