﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.StudentView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.Components.Basic;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components
{
  public partial class StudentView : UserControl, IComponentConnector
  {
    private User student;
    internal Label colTitle1;
    internal TextLabelInfo labelName;
    internal TextLabelInfo labelSurname;
    internal TextLabelInfo labelRegisterNumber;
    internal TextLabelInfo labelLoginOrEmail;
    internal TextLabelInfo labelPassword;
    internal TextLabelInfo labelDateOfBirth;
    internal Label colTitle2;
    internal TextLabelInfo labelLastLogin;
    internal TextLabelInfo loginCounter;
    private bool _contentLoaded;

    public StudentView(User student)
    {
      this.student = student;
      this.InitializeComponent();
      this.colTitle1.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("studentData");
      this.labelName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("firstName");
      this.labelName.TextInside = student.Name;
      this.labelSurname.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("surname");
      this.labelSurname.TextInside = student.Surname;
      this.labelRegisterNumber.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("registerNumber");
      this.labelRegisterNumber.TextInside = student.Student_numberInRegister.HasValue ? student.Student_numberInRegister.ToString() : PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noData");
      this.labelLoginOrEmail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("loginOrEmail");
      this.labelPassword.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("password");
      if (student.Email == null)
      {
        this.labelLoginOrEmail.TextInside = student.Student_login;
        this.labelPassword.TextInside = student.Student_explicitPassword;
      }
      else
      {
        this.labelLoginOrEmail.TextInside = student.Student_login != null ? student.Email + "(" + student.Student_login + ")" : student.Email;
        this.labelPassword.TextInside = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noAccess");
      }
      this.labelDateOfBirth.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("dateOfBirth");
      DateTime? nullable = student.DateOfBirth;
      if (!nullable.HasValue)
      {
        this.labelDateOfBirth.dataLabel.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emptyData");
      }
      else
      {
        DateTime dateTime = new DateTime();
        nullable = student.DateOfBirth;
        this.labelDateOfBirth.dataLabel.Content = (object) nullable.Value.ToString("yyyy");
      }
      this.colTitle2.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("statistics");
      this.labelLastLogin.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("lastLogin");
      nullable = student.LastLoginDate;
      if (nullable.HasValue)
      {
        TextLabelInfo labelLastLogin = this.labelLastLogin;
        nullable = student.LastLoginDate;
        string str = DateTime.Parse(nullable.ToString()).ToLocalTime().ToString();
        labelLastLogin.TextInside = str;
      }
      else
        this.labelLastLogin.TextInside = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noData");
      this.loginCounter.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (loginCounter));
      this.loginCounter.TextInside = student.LoginsCounter.ToString() ?? "";
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/components/studentview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.colTitle1 = (Label) target;
          break;
        case 2:
          this.labelName = (TextLabelInfo) target;
          break;
        case 3:
          this.labelSurname = (TextLabelInfo) target;
          break;
        case 4:
          this.labelRegisterNumber = (TextLabelInfo) target;
          break;
        case 5:
          this.labelLoginOrEmail = (TextLabelInfo) target;
          break;
        case 6:
          this.labelPassword = (TextLabelInfo) target;
          break;
        case 7:
          this.labelDateOfBirth = (TextLabelInfo) target;
          break;
        case 8:
          this.colTitle2 = (Label) target;
          break;
        case 9:
          this.labelLastLogin = (TextLabelInfo) target;
          break;
        case 10:
          this.loginCounter = (TextLabelInfo) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
