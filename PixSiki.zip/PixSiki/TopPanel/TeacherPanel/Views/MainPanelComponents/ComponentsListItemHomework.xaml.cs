﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.ListItemHomework
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components
{
  public partial class ListItemHomework : UserControl, ISearchableItem, IComponentConnector
  {
    internal Action<IListItem> listItemSelectedEvent;
    private IListHomework listItem;
    internal StackPanel Background;
    internal TextBlock textBlockName;
    internal TextBlock textBlockDescription;
    internal Image imageVissibly;
    internal TextBlock textBlockVissibly;
    internal TextBlock textBlockDateTitle;
    internal TextBlock textBlockDate;
    private bool _contentLoaded;

    public ListItemHomework(IListHomework listHomework)
    {
      this.InitializeComponent();
      this.listItem = listHomework;
      this.textBlockName.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("name") + ": " + listHomework.ListName;
      this.textBlockDescription.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("description") + ": " + listHomework.Description;
      this.textBlockDateTitle.Text = listHomework.DateInfo.Header;
      if (listHomework.DateInfo != null)
      {
        if (listHomework.DateInfo.Date.HasValue)
        {
          try
          {
            TextBlock textBlockDate = this.textBlockDate;
            DateTime localTime = listHomework.DateInfo.Date.Value;
            localTime = localTime.ToLocalTime();
            string str = localTime.ToString();
            textBlockDate.Text = str;
            goto label_5;
          }
          catch (Exception ex)
          {
            int num = (int) MessageBox.Show(ex.Message + "---" + ex.StackTrace + "---" + ex.InnerException?.ToString() + "---" + ex.Data?.ToString() + "---");
            goto label_5;
          }
        }
      }
      this.textBlockDate.Text = "--.--.----  --:--";
label_5:
      switch (listHomework.Status)
      {
        case HomeworkStatus.Archived:
          this.textBlockVissibly.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("archived");
          this.textBlockVissibly.Foreground = (Brush) Brushes.Red;
          this.imageVissibly.Source = (ImageSource) new BitmapImage(new Uri("pack://application:,,,/TopPanel/TeacherPanel/Views/MainPanelComponents/Components/Images/ikonki_pix-16.png"));
          break;
        case HomeworkStatus.Closed:
          this.textBlockVissibly.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("ended");
          this.textBlockVissibly.Foreground = (Brush) Brushes.Gray;
          this.imageVissibly.Source = (ImageSource) new BitmapImage(new Uri("pack://application:,,,/TopPanel/TeacherPanel/Views/MainPanelComponents/Components/Images/ikonki_pix-16.png"));
          this.imageVissibly.Opacity = 0.6;
          break;
        case HomeworkStatus.Started:
          this.textBlockVissibly.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("visible");
          this.textBlockVissibly.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 0, (byte) 140, (byte) 195));
          this.imageVissibly.Source = (ImageSource) new BitmapImage(new Uri("pack://application:,,,/TopPanel/TeacherPanel/Views/MainPanelComponents/Components/Images/ikonki_pix-15.png"));
          this.imageVissibly.Opacity = 1.0;
          break;
        case HomeworkStatus.New:
          this.textBlockVissibly.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("invisible");
          this.textBlockVissibly.Foreground = (Brush) Brushes.Black;
          this.imageVissibly.Source = (ImageSource) new BitmapImage(new Uri("pack://application:,,,/TopPanel/TeacherPanel/Views/MainPanelComponents/Components/Images/ikonki_pix-16.png"));
          this.imageVissibly.Opacity = 0.8;
          break;
      }
    }

    public void ShowIfContainsText(string text)
    {
      if (this.listItem.ListNameAndDescriptionContainsText(text))
        this.Visibility = Visibility.Visible;
      else
        this.Visibility = Visibility.Collapsed;
    }

    private void grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      Action<IListItem> itemSelectedEvent = this.listItemSelectedEvent;
      if (itemSelectedEvent == null)
        return;
      itemSelectedEvent((IListItem) this.listItem);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/components/listitemhomework.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.grid_MouseDown);
          break;
        case 2:
          this.Background = (StackPanel) target;
          break;
        case 3:
          this.textBlockName = (TextBlock) target;
          break;
        case 4:
          this.textBlockDescription = (TextBlock) target;
          break;
        case 5:
          this.imageVissibly = (Image) target;
          break;
        case 6:
          this.textBlockVissibly = (TextBlock) target;
          break;
        case 7:
          this.textBlockDateTitle = (TextBlock) target;
          break;
        case 8:
          this.textBlockDate = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
