﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.UserHistoryView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.UserHistoryPanel;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components
{
  public class UserHistoryView : UserControl, IComponentConnector
  {
    private DateTime startDate;
    private DateTime endDate;
    private User user;
    private List<UserSession> userHistory;
    private BigCaption currentWeek = new BigCaption();
    private SmallRoundedButton previousWeek;
    private SmallRoundedButton nextWeek;
    private ServerApi api = new ServerApi();
    internal Grid buttonGrid;
    internal StackPanel mainStackPanel;
    private bool _contentLoaded;

    public UserHistoryView(User user)
    {
      this.InitializeComponent();
      this.user = user;
      this.previousWeek = new SmallRoundedButton()
      {
        Description = "<-"
      };
      this.buttonGrid.Children.Add((UIElement) this.previousWeek);
      this.previousWeek.HorizontalAlignment = HorizontalAlignment.Left;
      this.previousWeek.clickEvent += new SmallRoundedButton.ClickDelegate(this.PreviousClick);
      this.nextWeek = new SmallRoundedButton()
      {
        Description = "->"
      };
      this.buttonGrid.Children.Add((UIElement) this.nextWeek);
      this.nextWeek.HorizontalAlignment = HorizontalAlignment.Right;
      this.nextWeek.clickEvent += new SmallRoundedButton.ClickDelegate(this.NextClick);
      this.buttonGrid.Children.Add((UIElement) this.currentWeek);
      this.currentWeek.HorizontalAlignment = HorizontalAlignment.Center;
      List<DateTime> source = new List<DateTime>();
      for (int index = 0; index > -7; --index)
        source.Add(DateTime.Today.AddDays((double) index));
      this.startDate = source.First<DateTime>((Func<DateTime, bool>) (w => w.DayOfWeek == DayOfWeek.Monday));
      this.endDate = this.startDate.AddDays(7.0);
      this.ShowHistoryData();
    }

    private void NextClick()
    {
      this.startDate = this.startDate.AddDays(7.0);
      this.endDate = this.endDate.AddDays(7.0);
      this.ShowHistoryData();
    }

    private void PreviousClick()
    {
      this.startDate = this.startDate.AddDays(-7.0);
      this.endDate = this.endDate.AddDays(-7.0);
      this.ShowHistoryData();
    }

    private void ShowHistoryData()
    {
      List<UserSession> userHistory = this.api.GetUserHistory(this.user, this.startDate, this.endDate, new AuthorizeData(CurrentUserInfo.CurrentUser));
      if (this.endDate > DateTime.Today)
        this.nextWeek.SetEnable(false);
      else
        this.nextWeek.SetEnable(true);
      if (this.startDate < new DateTime(2019, 7, 1))
        this.previousWeek.SetEnable(false);
      else
        this.previousWeek.SetEnable(true);
      this.mainStackPanel.Children.Clear();
      BigCaption currentWeek = this.currentWeek;
      string shortDateString1 = this.startDate.ToShortDateString();
      DateTime dateTime = this.endDate.AddDays(-1.0);
      string shortDateString2 = dateTime.ToShortDateString();
      string str = shortDateString1 + " - " + shortDateString2;
      currentWeek.Description = str;
      foreach (UserSession userSession in userHistory)
      {
        UIElementCollection children = this.mainStackPanel.Children;
        dateTime = userSession.SignInLog.LoginDate;
        // ISSUE: variable of a boxed type
        __Boxed<DateTime> localTime1 = (ValueType) dateTime.ToLocalTime();
        dateTime = userSession.SignInLog.LogoutDate.Value;
        // ISSUE: variable of a boxed type
        __Boxed<DateTime> localTime2 = (ValueType) dateTime.ToLocalTime();
        HistoryElement historyElement = new HistoryElement(string.Format("{0} - {1}", (object) localTime1, (object) localTime2), userSession.EditedQuestionCodes.Count, userSession.QuestionResults.Count);
        children.Add((UIElement) historyElement);
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/components/userhistorypanel/userhistoryview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.mainStackPanel = (StackPanel) target;
        else
          this._contentLoaded = true;
      }
      else
        this.buttonGrid = (Grid) target;
    }
  }
}
