﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.UserHistoryPanel.HistoryElement
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.UserHistoryPanel
{
  public partial class HistoryElement : UserControl, IComponentConnector
  {
    internal TextBlock session;
    internal TextBlock worked;
    internal TextBlock done;
    private bool _contentLoaded;

    public HistoryElement(string sessionTime, int worked, int done)
    {
      this.InitializeComponent();
      this.session.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (sessionTime)) + sessionTime;
      this.worked.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (worked)) + worked.ToString();
      this.done.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (done)) + done.ToString();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/components/userhistorypanel/historyelement.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.session = (TextBlock) target;
          break;
        case 2:
          this.worked = (TextBlock) target;
          break;
        case 3:
          this.done = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
