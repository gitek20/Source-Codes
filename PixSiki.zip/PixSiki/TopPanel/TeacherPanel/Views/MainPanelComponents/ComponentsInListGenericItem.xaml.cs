﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.InListGenericItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.UserManagment;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components
{
  public partial class InListGenericItem : UserControl, ISearchableItem, IComponentConnector
  {
    private IListItem listItem;
    public Action<IListItem> listItemSelectedEvent;
    internal Rectangle itemInList;
    internal Rectangle selectedHighlight;
    internal TextBlock description;
    internal TextBlock textBlockNameBlue;
    internal StackPanel properties;
    internal StackPanel championshipStackPanel;
    internal Ellipse championshipBulb;
    internal TextBlock championshipText;
    private bool _contentLoaded;

    public IListItem ListItem => this.listItem;

    public InListGenericItem(IListItem listItem)
    {
      this.InitializeComponent();
      this.listItem = listItem;
      this.textBlockNameBlue.Text = listItem.ListName;
      this.description.Visibility = Visibility.Collapsed;
      if (listItem is StudentsClass)
      {
        this.description.Visibility = Visibility.Visible;
        this.description.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("class");
      }
      if (listItem is User)
      {
        this.description.Visibility = Visibility.Visible;
        this.description.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("student");
        if (CurrentUserInfo.CurrenChampionship != null)
        {
          this.championshipStackPanel.Visibility = Visibility.Visible;
          this.championshipText.Text = CurrentUserInfo.CurrenChampionship.Name;
          SolidColorBrush solidColorBrush1 = new SolidColorBrush();
          solidColorBrush1.Color = Color.FromRgb((byte) 204, (byte) 204, (byte) 204);
          SolidColorBrush solidColorBrush2 = new SolidColorBrush();
          solidColorBrush2.Color = Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue);
          if ((listItem as User).ChampionshipId.HasValue)
          {
            int? championshipId = (listItem as User).ChampionshipId;
            int id = CurrentUserInfo.CurrenChampionship.Id;
            if (championshipId.GetValueOrDefault() == id & championshipId.HasValue)
            {
              this.championshipBulb.Fill = (Brush) solidColorBrush2;
              goto label_8;
            }
          }
          this.championshipBulb.Fill = (Brush) solidColorBrush1;
        }
      }
label_8:
      this.AddProperties(listItem.Properties);
      this.selectedHighlight.Visibility = Visibility.Collapsed;
    }

    public InListGenericItem(IListItem listItem, Color colorRGB)
      : this(listItem)
      => this.itemInList.Fill = (Brush) new SolidColorBrush(colorRGB);

    private void AddProperties(List<ListProperty> propertiesToAdd)
    {
      foreach (ListProperty listProperty in propertiesToAdd)
        this.properties.Children.Add((UIElement) new ListPropertyTemplate(listProperty));
    }

    private void selectedHighlight_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.listItemSelectedEvent == null)
        return;
      this.listItemSelectedEvent(this.listItem);
    }

    private void selectedHighlight_MouseEnter(object sender, MouseEventArgs e) => this.selectedHighlight.Visibility = Visibility.Visible;

    private void selectedHighlight_MouseLeave(object sender, MouseEventArgs e) => this.selectedHighlight.Visibility = Visibility.Collapsed;

    public void ShowIfContainsText(string text)
    {
      if (this.listItem.ListNameAndDescriptionContainsText(text))
        this.Visibility = Visibility.Visible;
      else
        this.Visibility = Visibility.Collapsed;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/components/inlistgenericitem.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.itemInList = (Rectangle) target;
          this.itemInList.MouseDown += new MouseButtonEventHandler(this.selectedHighlight_MouseDown);
          this.itemInList.MouseEnter += new MouseEventHandler(this.selectedHighlight_MouseEnter);
          this.itemInList.MouseLeave += new MouseEventHandler(this.selectedHighlight_MouseLeave);
          break;
        case 2:
          this.selectedHighlight = (Rectangle) target;
          this.selectedHighlight.MouseDown += new MouseButtonEventHandler(this.selectedHighlight_MouseDown);
          this.selectedHighlight.MouseEnter += new MouseEventHandler(this.selectedHighlight_MouseEnter);
          this.selectedHighlight.MouseLeave += new MouseEventHandler(this.selectedHighlight_MouseLeave);
          break;
        case 3:
          this.description = (TextBlock) target;
          break;
        case 4:
          this.textBlockNameBlue = (TextBlock) target;
          break;
        case 5:
          this.properties = (StackPanel) target;
          break;
        case 6:
          this.championshipStackPanel = (StackPanel) target;
          break;
        case 7:
          this.championshipBulb = (Ellipse) target;
          break;
        case 8:
          this.championshipText = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
