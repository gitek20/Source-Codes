﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibilityView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using Newtonsoft.Json;
using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models;
using PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents
{
  public class CoursesVisibilityView : UserControl, ICoursesVisibility, IComponentConnector
  {
    private List<ICategoryData> mainCategories = new List<ICategoryData>();
    public List<ICategoryData> selectedCategoriesList = new List<ICategoryData>();
    public List<ICategoryData> selectedLessonsList = new List<ICategoryData>();
    public List<IQuestionData> selectedQuestionsList = new List<IQuestionData>();
    private QuestionCategoryLoaderAndSever contentData;
    private VisibilityModel visibilityModel = new VisibilityModel();
    private ServerApi serverApi;
    private PixBlocks.Server.DataModels.DataModels.CoursesVisibility data;
    private StudentsClass studentsClass;
    private RefreshEvent refreshEvent;
    internal Grid mainGrid;
    internal StackPanel Category;
    internal Label col2Title;
    internal Grid categoryList;
    internal StackPanel mainView;
    private bool _contentLoaded;

    public CoursesVisibilityView(
      StudentsClass studentsClass,
      ITeacherPanelController mainTeacherPanel,
      RefreshEvent refreshEvent)
    {
      this.InitializeComponent();
      this.col2Title.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("coursesVisibilityInfo");
      this.studentsClass = studentsClass;
      this.refreshEvent = refreshEvent;
      this.serverApi = new ServerApi();
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.MainPanel.SetView((UserControl) this);
      this.contentData = new QuestionCategoryLoaderAndSever();
      this.mainCategories = this.contentData.GetAllMainCategories().Where<ICategoryData>((Func<ICategoryData, bool>) (categor => categor.UniqueGuid() != "\\aa_create")).ToList<ICategoryData>();
      this.col2Title.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("coursesVisibilityInfo");
      refreshEvent.RefreshUserControl += new RefreshEvent.Refesh(this.SaveData);
      refreshEvent.canInvoke = true;
      this.LoadVisibilityData();
      this.AllCourseGenerate();
    }

    public void SaveData()
    {
      this.SaveCousreVisibilityDataOnServer();
      this.refreshEvent.RefreshUserControl -= new RefreshEvent.Refesh(this.SaveData);
    }

    private void LoadVisibilityData()
    {
      this.data = this.serverApi.GetCoursesVisibility(this.studentsClass.Id.Value, new DateTime(), new AuthorizeData(CurrentUserInfo.CurrentUser));
      if (this.data == null)
        this.data = new PixBlocks.Server.DataModels.DataModels.CoursesVisibility();
      if (this.data.VisibilityObject == null)
      {
        this.visibilityModel = new VisibilityModel();
        this.selectedCategoriesList = ((IEnumerable<ICategoryData>) this.mainCategories.ToArray()).ToList<ICategoryData>();
      }
      else
      {
        this.visibilityModel = JsonConvert.DeserializeObject<VisibilityModel>(this.data.VisibilityObject);
        this.selectedCategoriesList = this.mainCategories.Where<ICategoryData>((Func<ICategoryData, bool>) (category => this.visibilityModel.categoryList.Any<string>((Func<string, bool>) (coursePath => category.UniqueGuid() == coursePath)))).ToList<ICategoryData>();
        this.selectedLessonsList.AddRange(this.visibilityModel.lessonsList.Select<string, ICategoryData>((Func<string, ICategoryData>) (lesson => this.contentData.GetAllLessonInCategory(this.GetCoursePath(lesson)).Single<ICategoryData>((Func<ICategoryData, bool>) (l => l.UniqueGuid() == lesson)))));
        this.selectedQuestionsList.AddRange((IEnumerable<IQuestionData>) this.visibilityModel.questionsList.Select<string, Question>((Func<string, Question>) (questionGuid => this.contentData.GetQuestionOfGuid(questionGuid))));
      }
    }

    public string GetCoursePath(string lessonPath) => "\\" + string.Concat<char>(lessonPath.Skip<char>(1).TakeWhile<char>((Func<char, bool>) (c => c != '\\')));

    private void SaveCousreVisibilityDataOnServer() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      VisibilityModel visibilityModel = new VisibilityModel();
      visibilityModel.categoryList = this.selectedCategoriesList.Select<ICategoryData, string>((Func<ICategoryData, string>) (c => c.UniqueGuid())).ToList<string>();
      visibilityModel.lessonsList = this.selectedLessonsList.Select<ICategoryData, string>((Func<ICategoryData, string>) (l => l.UniqueGuid())).ToList<string>();
      visibilityModel.questionsList = this.selectedQuestionsList.Select<IQuestionData, string>((Func<IQuestionData, string>) (q => q.QuestionGuid())).ToList<string>();
      this.data.IdClass = this.studentsClass.Id.Value;
      this.data.VisibilityObject = (string) null;
      if (visibilityModel.categoryList.Count != this.mainCategories.Count)
        this.data.VisibilityObject = JsonConvert.SerializeObject((object) visibilityModel);
      this.serverApi.AddOrEditCoursesVisibility(this.data, new AuthorizeData(CurrentUserInfo.CurrentUser));
    }));

    public void AllCourseGenerate()
    {
      this.mainView.Children.Clear();
      if (this.mainCategories.Count < 1)
        this.mainCategories = this.contentData.GetAllMainCategories();
      foreach (ICategoryData mainCategory in this.mainCategories)
        this.mainView.Children.Add((UIElement) new SingleCategoryView(mainCategory, this));
    }

    public List<ICategoryData> GetAllLessonsInCourse(ICategoryData categoryData) => this.contentData.GetAllLessonInCategory(categoryData.UniqueGuid());

    public List<IQuestionData> GetAllQuestionsInLesson(ICategoryData categoryData) => this.contentData.GetAllQuestionsInLesson(categoryData.UniqueGuid());

    public void AddAllCourse(ICategoryData categoryData)
    {
      if (!this.selectedCategoriesList.Exists((Predicate<ICategoryData>) (category => category == categoryData)))
        this.selectedCategoriesList.Add(categoryData);
      this.selectedLessonsList.RemoveAll((Predicate<ICategoryData>) (x => this.GetCoursePath(x.UniqueGuid()) == categoryData.UniqueGuid()));
      this.selectedQuestionsList.RemoveAll((Predicate<IQuestionData>) (q => q.ParenCategory == categoryData));
    }

    public void RemoveAllCourse(ICategoryData categoryData)
    {
      this.selectedCategoriesList.Remove(categoryData);
      this.selectedLessonsList.RemoveAll((Predicate<ICategoryData>) (x => this.GetCoursePath(x.UniqueGuid()) == categoryData.UniqueGuid()));
      this.selectedQuestionsList.RemoveAll((Predicate<IQuestionData>) (q => q.ParenCategory == categoryData));
    }

    public void AddAllLesson(ICategoryData lessonData)
    {
      if (!this.selectedLessonsList.Exists((Predicate<ICategoryData>) (lesson => lesson == lessonData)))
        this.selectedLessonsList.Add(lessonData);
      this.selectedCategoriesList.RemoveAll((Predicate<ICategoryData>) (category => category.UniqueGuid() == this.GetCoursePath(lessonData.UniqueGuid())));
      this.selectedQuestionsList.RemoveAll((Predicate<IQuestionData>) (question => question.ParenLesson == lessonData));
    }

    public void RemoveAllLesson(ICategoryData lessonData) => this.selectedLessonsList.Remove(lessonData);

    public void AddQestion(IQuestionData questionData)
    {
      if (this.selectedQuestionsList.Exists((Predicate<IQuestionData>) (question => question == questionData)))
        return;
      this.selectedQuestionsList.Add(questionData);
    }

    public void RemoveQuestion(IQuestionData questionData) => this.selectedQuestionsList.Remove(questionData);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/coursesvisibility/coursesvisibilityview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.Category = (StackPanel) target;
          break;
        case 3:
          this.col2Title = (Label) target;
          break;
        case 4:
          this.categoryList = (Grid) target;
          break;
        case 5:
          this.mainView = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
