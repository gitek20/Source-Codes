﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.ExamView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.TopPanel.Components.Basic;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components
{
  public partial class ExamView : UserControl, IComponentConnector
  {
    private Exam exam;
    internal Label colTitle1;
    internal TextLabelInfo labelName;
    internal TextLabelInfo labelDescription;
    internal Label colTitle2;
    internal TextLabelInfo labelCreationDate;
    internal TextLabelInfo labelStatus;
    internal TextLabelInfo labelSizeQuestions;
    private bool _contentLoaded;

    public ExamView(Exam exam)
    {
      this.exam = exam;
      this.InitializeComponent();
      if (exam.IsHomework)
        this.colTitle1.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("homeworkData");
      else
        this.colTitle1.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("examData");
      this.labelName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("name");
      this.labelName.TextInside = exam.Name;
      this.labelDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("description");
      this.labelDescription.TextInside = exam.Description;
      this.colTitle2.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("info");
      this.labelCreationDate.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("creationDate");
      TextLabelInfo labelCreationDate = this.labelCreationDate;
      DateTime localTime = DateTime.Parse(exam.CreationDate.ToString());
      localTime = localTime.ToLocalTime();
      string str1 = localTime.ToString();
      labelCreationDate.TextInside = str1;
      this.labelStatus.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("status");
      string str2 = exam.Status.ToString();
      if (!(str2 == "New"))
      {
        if (!(str2 == "Started"))
        {
          if (str2 == "Closed")
            this.labelStatus.TextInside = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("end");
        }
        else
          this.labelStatus.TextInside = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("started");
      }
      else
        this.labelStatus.TextInside = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("new");
      ServerApi serverApi = new ServerApi();
      this.labelSizeQuestions.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("questionQuantity");
      try
      {
        this.labelSizeQuestions.TextInside = serverApi.GetAllQuestionsInExam(exam, new AuthorizeData(CurrentUserInfo.CurrentUser)).Where<ExamQuestion>((Func<ExamQuestion, bool>) (e => QuestionCategoryLoaderAndSever.ContainsQuestionGuid(e.QuestionGuid))).ToList<ExamQuestion>().Count.ToString();
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.ToString());
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/components/examview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.colTitle1 = (Label) target;
          break;
        case 2:
          this.labelName = (TextLabelInfo) target;
          break;
        case 3:
          this.labelDescription = (TextLabelInfo) target;
          break;
        case 4:
          this.colTitle2 = (Label) target;
          break;
        case 5:
          this.labelCreationDate = (TextLabelInfo) target;
          break;
        case 6:
          this.labelStatus = (TextLabelInfo) target;
          break;
        case 7:
          this.labelSizeQuestions = (TextLabelInfo) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
