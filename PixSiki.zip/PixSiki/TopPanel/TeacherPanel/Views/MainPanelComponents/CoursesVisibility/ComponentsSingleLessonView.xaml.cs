﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components.SingleLessonView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components
{
  public partial class SingleLessonView : UserControl, IComponentConnector
  {
    private List<IQuestionData> questionsList = new List<IQuestionData>();
    private CoursesVisibilityView coursesVisibilityView;
    private SingleCategoryView singleCategoryView;
    public ICategoryData lessonData;
    public SingleObjectState singleLessonState = SingleObjectState.Unchecked;
    public int checkedQuestions;
    public int allQuestionsInLesson;
    private bool executeCheckBoxEvent = true;
    private bool executeCheckBoxUncheckedEvent = true;
    internal StackPanel backgroundSingleLesson;
    internal CheckBox singleLessonCheckBox;
    internal TextBlock textLesson;
    internal TextBlock textLessonDescription;
    internal StackPanel questions;
    private bool _contentLoaded;

    public event DataEvent AllLessonSelected;

    public SingleLessonView(
      ICategoryData lessonData,
      SingleCategoryView singleCategoryView,
      CoursesVisibilityView coursesVisibilityView)
    {
      this.InitializeComponent();
      this.coursesVisibilityView = coursesVisibilityView;
      this.lessonData = lessonData;
      this.singleCategoryView = singleCategoryView;
      singleCategoryView.AllCourseSelected += new DataEvent(this.SingleCategoryView_AllCourseSelected);
      this.textLesson.Text = lessonData.TranslatedName();
      this.textLessonDescription.Text = lessonData.TranslatedDescription();
      this.LoadLessonState();
    }

    private void LoadLessonState()
    {
      switch (this.singleCategoryView.singleCategoryState)
      {
        case SingleObjectState.Checked:
          if (this.coursesVisibilityView.selectedLessonsList.Find((Predicate<ICategoryData>) (lesson => lesson == this.lessonData)) != null)
            this.SetLessonState(SingleObjectState.AllChecked, true);
          if (this.coursesVisibilityView.selectedQuestionsList.Find((Predicate<IQuestionData>) (question => question.ParenLesson == this.lessonData)) != null)
          {
            this.SetLessonState(SingleObjectState.Checked, true);
            break;
          }
          break;
        case SingleObjectState.AllChecked:
          this.SetLessonState(SingleObjectState.AllChecked, true);
          break;
        case SingleObjectState.Unchecked:
          this.SetLessonState(SingleObjectState.Unchecked, true);
          break;
        default:
          this.SetLessonState(SingleObjectState.Unchecked, true);
          break;
      }
      this.executeCheckBoxEvent = false;
    }

    private void SingleCategoryView_AllCourseSelected(bool isSelectedAll)
    {
      if (isSelectedAll)
        this.SetLessonState(SingleObjectState.AllChecked, false);
      else
        this.SetLessonState(SingleObjectState.Unchecked, false);
    }

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.questionsList.Count == 0)
      {
        this.questionsList = this.coursesVisibilityView.GetAllQuestionsInLesson(this.lessonData);
        this.allQuestionsInLesson = this.questionsList.Count;
        foreach (IQuestionData questions in this.questionsList)
          this.questions.Children.Add((UIElement) new SingleQuestionView(questions, this.singleCategoryView, this, this.coursesVisibilityView));
      }
      switch (this.questions.Visibility)
      {
        case Visibility.Visible:
          this.questions.Visibility = Visibility.Collapsed;
          break;
        case Visibility.Collapsed:
          this.questions.Visibility = Visibility.Visible;
          break;
      }
    }

    private void singleLessonCheckBox_Checked(object sender, RoutedEventArgs e)
    {
      if (this.singleLessonState == SingleObjectState.AllChecked || this.singleLessonState == SingleObjectState.Unchecked)
        ++this.singleCategoryView.checkedLessons;
      if (!this.executeCheckBoxEvent)
      {
        this.coursesVisibilityView.AddAllLesson(this.lessonData);
        DataEvent allLessonSelected = this.AllLessonSelected;
        if (allLessonSelected != null)
          allLessonSelected(true);
        this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 100, (byte) 15, (byte) 142, byte.MaxValue));
        this.singleLessonState = SingleObjectState.AllChecked;
        if (this.singleCategoryView.checkedLessons == this.singleCategoryView.lessonsList.Count)
        {
          this.singleCategoryView.SetCourseState(SingleObjectState.AllChecked, true);
          this.singleCategoryView.AddAllCourse();
        }
        else
          this.singleCategoryView.SetCourseState(SingleObjectState.Checked, false);
      }
      this.executeCheckBoxEvent = false;
    }

    private void singleLessonCheckBox_Unchecked(object sender, RoutedEventArgs e)
    {
      if (this.singleLessonState == SingleObjectState.AllChecked)
        --this.singleCategoryView.checkedLessons;
      this.coursesVisibilityView.RemoveAllLesson(this.lessonData);
      this.SetLessonState(SingleObjectState.Unchecked, false);
      DataEvent allLessonSelected = this.AllLessonSelected;
      if (allLessonSelected != null)
        allLessonSelected(false);
      foreach (SingleLessonView child in this.singleCategoryView.lessons.Children)
      {
        if (child.singleLessonState == SingleObjectState.AllChecked)
          this.coursesVisibilityView.AddAllLesson(child.lessonData);
      }
      foreach (SingleQuestionView child in this.questions.Children)
      {
        bool? isChecked = child.singleQuestionCheckBox.IsChecked;
        bool flag = true;
        if (isChecked.GetValueOrDefault() == flag & isChecked.HasValue)
          this.coursesVisibilityView.AddQestion(child.questionData);
      }
      if (this.singleCategoryView.checkedLessons == 0 && this.IsAllUncheckedLessonsState())
      {
        this.coursesVisibilityView.RemoveAllCourse(this.singleCategoryView.categoryData);
        this.singleCategoryView.SetCourseState(SingleObjectState.Unchecked, false);
      }
      else
        this.singleCategoryView.SetCourseState(SingleObjectState.Checked, false);
    }

    private bool IsAllUncheckedLessonsState()
    {
      bool flag = true;
      foreach (SingleLessonView child in this.singleCategoryView.lessons.Children)
      {
        if (child.singleLessonState != SingleObjectState.Unchecked)
          flag = false;
      }
      return flag;
    }

    public void SetLessonState(SingleObjectState singleObjectState, bool executeEvent)
    {
      this.executeCheckBoxEvent = executeEvent;
      this.singleLessonState = singleObjectState;
      switch (singleObjectState)
      {
        case SingleObjectState.Checked:
          this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 40, (byte) 15, (byte) 142, byte.MaxValue));
          this.singleLessonCheckBox.IsChecked = new bool?(true);
          break;
        case SingleObjectState.AllChecked:
          this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 100, (byte) 15, (byte) 142, byte.MaxValue));
          this.singleLessonCheckBox.IsChecked = new bool?(true);
          break;
        case SingleObjectState.Unchecked:
          this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Colors.White);
          this.singleLessonCheckBox.IsChecked = new bool?(false);
          break;
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/coursesvisibility/components/singlelessonview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.backgroundSingleLesson = (StackPanel) target;
          break;
        case 2:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 3:
          this.singleLessonCheckBox = (CheckBox) target;
          this.singleLessonCheckBox.Checked += new RoutedEventHandler(this.singleLessonCheckBox_Checked);
          this.singleLessonCheckBox.Unchecked += new RoutedEventHandler(this.singleLessonCheckBox_Unchecked);
          break;
        case 4:
          this.textLesson = (TextBlock) target;
          break;
        case 5:
          this.textLessonDescription = (TextBlock) target;
          break;
        case 6:
          this.questions = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
