﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components.SingleCategoryView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components
{
  public partial class SingleCategoryView : UserControl, IComponentConnector
  {
    private CoursesVisibilityView coursesVisibility;
    public ICategoryData categoryData;
    public List<ICategoryData> lessonsList = new List<ICategoryData>();
    public SingleObjectState singleCategoryState = SingleObjectState.Unchecked;
    public int checkedLessons;
    private bool executeCheckBoxCheckedEvent = true;
    private bool executeCheckBoxUncheckedEvent = true;
    internal StackPanel backgorund;
    internal CheckBox singleCategoryCheckBox;
    internal TextBlock textCategory;
    internal TextBlock textCategoryDescription;
    internal StackPanel lessons;
    private bool _contentLoaded;

    public event DataEvent AllCourseSelected;

    public SingleCategoryView(ICategoryData categoryData, CoursesVisibilityView coursesVisibility)
    {
      this.InitializeComponent();
      this.coursesVisibility = coursesVisibility;
      this.categoryData = categoryData;
      this.textCategory.Text = categoryData.TranslatedName();
      this.textCategoryDescription.Text = categoryData.TranslatedDescription();
      this.LoadCategoryState();
    }

    public void LoadCategoryState()
    {
      if (this.coursesVisibility.selectedCategoriesList.Find((Predicate<ICategoryData>) (category => category.UniqueGuid() == this.categoryData.UniqueGuid())) != null)
      {
        this.SetCourseState(SingleObjectState.AllChecked, false);
      }
      else
      {
        if (this.coursesVisibility.selectedLessonsList.Find((Predicate<ICategoryData>) (lesson => this.coursesVisibility.GetCoursePath(lesson.UniqueGuid()) == this.categoryData.UniqueGuid())) == null && this.coursesVisibility.selectedQuestionsList.Find((Predicate<IQuestionData>) (question => question.ParenCategory == this.categoryData)) == null)
          return;
        this.SetCourseState(SingleObjectState.Checked, false);
      }
    }

    private void singleCategoryCheckBox_Checked(object sender, RoutedEventArgs e)
    {
      if (this.executeCheckBoxCheckedEvent)
      {
        DataEvent allCourseSelected = this.AllCourseSelected;
        if (allCourseSelected != null)
          allCourseSelected(true);
        this.SetCourseState(SingleObjectState.AllChecked, false);
        this.coursesVisibility.AddAllCourse(this.categoryData);
      }
      this.executeCheckBoxCheckedEvent = true;
      this.executeCheckBoxUncheckedEvent = true;
    }

    private void singleCategoryCheckBox_Unchecked(object sender, RoutedEventArgs e)
    {
      if (this.executeCheckBoxUncheckedEvent)
      {
        DataEvent allCourseSelected = this.AllCourseSelected;
        if (allCourseSelected != null)
          allCourseSelected(false);
        this.SetCourseState(SingleObjectState.Unchecked, false);
        this.coursesVisibility.RemoveAllCourse(this.categoryData);
        this.checkedLessons = 0;
      }
      this.executeCheckBoxUncheckedEvent = true;
      this.executeCheckBoxCheckedEvent = true;
    }

    public void InvokeAllCourseChecked(bool check)
    {
      DataEvent allCourseSelected = this.AllCourseSelected;
      if (allCourseSelected == null)
        return;
      allCourseSelected(check);
    }

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.lessonsList.Count == 0)
      {
        this.lessonsList = this.coursesVisibility.GetAllLessonsInCourse(this.categoryData);
        foreach (ICategoryData lessons in this.lessonsList)
          this.lessons.Children.Add((UIElement) new SingleLessonView(lessons, this, this.coursesVisibility));
      }
      switch (this.lessons.Visibility)
      {
        case Visibility.Visible:
          this.lessons.Visibility = Visibility.Collapsed;
          break;
        case Visibility.Collapsed:
          this.lessons.Visibility = Visibility.Visible;
          break;
      }
    }

    public void AddAllCourse() => this.coursesVisibility.AddAllCourse(this.categoryData);

    public void RemoveAllCourse() => this.coursesVisibility.RemoveAllCourse(this.categoryData);

    public void SetCourseState(SingleObjectState categoryState, bool executeCheckBoxEvent)
    {
      switch (categoryState)
      {
        case SingleObjectState.Checked:
          this.backgorund.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 40, (byte) 15, (byte) 142, byte.MaxValue));
          this.executeCheckBoxCheckedEvent = executeCheckBoxEvent;
          this.singleCategoryCheckBox.IsChecked = new bool?(true);
          break;
        case SingleObjectState.AllChecked:
          this.backgorund.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 100, (byte) 15, (byte) 142, byte.MaxValue));
          this.executeCheckBoxCheckedEvent = executeCheckBoxEvent;
          this.singleCategoryCheckBox.IsChecked = new bool?(true);
          break;
        case SingleObjectState.Unchecked:
          this.backgorund.Background = (Brush) new SolidColorBrush(Colors.White);
          this.executeCheckBoxUncheckedEvent = executeCheckBoxEvent;
          this.singleCategoryCheckBox.IsChecked = new bool?(false);
          break;
      }
      this.singleCategoryState = categoryState;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/coursesvisibility/components/singlecategoryview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.backgorund = (StackPanel) target;
          break;
        case 2:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 3:
          this.singleCategoryCheckBox = (CheckBox) target;
          this.singleCategoryCheckBox.Checked += new RoutedEventHandler(this.singleCategoryCheckBox_Checked);
          this.singleCategoryCheckBox.Unchecked += new RoutedEventHandler(this.singleCategoryCheckBox_Unchecked);
          break;
        case 4:
          this.textCategory = (TextBlock) target;
          break;
        case 5:
          this.textCategoryDescription = (TextBlock) target;
          break;
        case 6:
          this.lessons = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
