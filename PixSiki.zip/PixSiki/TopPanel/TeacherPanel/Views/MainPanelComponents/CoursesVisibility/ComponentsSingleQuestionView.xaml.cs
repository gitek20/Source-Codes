﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components.SingleQuestionView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components
{
  public partial class SingleQuestionView : UserControl, IComponentConnector
  {
    public IQuestionData questionData;
    private SingleLessonView singleLessonView;
    private SingleCategoryView singleCategoryView;
    private CoursesVisibilityView coursesVisibility;
    private SingleObjectState singleQuestionState = SingleObjectState.Unchecked;
    private bool executeCheckBoxCheckedEvent = true;
    private bool executeCheckBoxUncheckedEvent = true;
    internal StackPanel backgroundSingleLesson;
    internal CheckBox singleQuestionCheckBox;
    internal TextBlock textQuestion;
    internal TextBlock textQuestionDescription;
    private bool _contentLoaded;

    public SingleQuestionView(
      IQuestionData questionData,
      SingleCategoryView singleCategoryView,
      SingleLessonView singleLessonView,
      CoursesVisibilityView coursesVisibility)
    {
      this.InitializeComponent();
      this.questionData = questionData;
      this.singleLessonView = singleLessonView;
      this.singleCategoryView = singleCategoryView;
      this.coursesVisibility = coursesVisibility;
      singleCategoryView.AllCourseSelected += new DataEvent(this.SingleCategoryView_AllCourseSelected);
      singleLessonView.AllLessonSelected += new DataEvent(this.SingleCategoryView_AllLessonSelected);
      this.textQuestion.Text = questionData.UserFriendlyDescription();
      this.textQuestionDescription.Text = this.GetDescriptionInQuestion(questionData.GetQuestionContent());
      this.LoadQuestionState();
    }

    private void LoadQuestionState()
    {
      if (this.singleLessonView.singleLessonState == SingleObjectState.AllChecked || this.coursesVisibility.selectedQuestionsList.Any<IQuestionData>((Func<IQuestionData, bool>) (question => question.QuestionGuid() == this.questionData.QuestionGuid())))
      {
        this.executeCheckBoxCheckedEvent = false;
        this.singleQuestionCheckBox.IsChecked = new bool?(true);
      }
      else
      {
        this.executeCheckBoxUncheckedEvent = false;
        this.singleQuestionCheckBox.IsChecked = new bool?(false);
      }
    }

    private void SingleCategoryView_AllLessonSelected(bool isSelected)
    {
      if (isSelected)
      {
        this.executeCheckBoxCheckedEvent = false;
        this.singleQuestionCheckBox.IsChecked = new bool?(true);
      }
      else
      {
        this.executeCheckBoxUncheckedEvent = false;
        this.singleQuestionCheckBox.IsChecked = new bool?(false);
      }
    }

    private void SingleCategoryView_AllCourseSelected(bool trueOrFalse)
    {
      if (trueOrFalse)
        this.singleQuestionCheckBox.IsChecked = new bool?(true);
      else
        this.singleQuestionCheckBox.IsChecked = new bool?(false);
    }

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      bool? isChecked = this.singleQuestionCheckBox.IsChecked;
      bool flag = true;
      if (isChecked.GetValueOrDefault() == flag & isChecked.HasValue)
        this.singleQuestionCheckBox.IsChecked = new bool?(false);
      else
        this.singleQuestionCheckBox.IsChecked = new bool?(true);
    }

    private void singleQuestionCheckBox_Checked(object sender, RoutedEventArgs e)
    {
      this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 100, (byte) 15, (byte) 142, byte.MaxValue));
      ++this.singleLessonView.checkedQuestions;
      if (this.executeCheckBoxCheckedEvent)
      {
        if (this.singleLessonView.allQuestionsInLesson == this.singleLessonView.checkedQuestions)
          ++this.singleCategoryView.checkedLessons;
        if (this.singleLessonView.checkedQuestions == this.singleLessonView.allQuestionsInLesson)
        {
          this.singleLessonView.SetLessonState(SingleObjectState.AllChecked, true);
          this.coursesVisibility.AddAllLesson(this.singleLessonView.lessonData);
          if (this.singleCategoryView.checkedLessons == this.singleCategoryView.lessonsList.Count<ICategoryData>())
            this.coursesVisibility.AddAllCourse(this.singleCategoryView.categoryData);
        }
        else
        {
          if (this.singleLessonView.singleLessonState != SingleObjectState.Checked)
            this.singleLessonView.SetLessonState(SingleObjectState.Checked, true);
          this.coursesVisibility.RemoveAllLesson(this.singleLessonView.lessonData);
          this.coursesVisibility.AddQestion(this.questionData);
        }
        if (this.singleCategoryView.checkedLessons == this.singleCategoryView.lessonsList.Count)
          this.singleCategoryView.SetCourseState(SingleObjectState.AllChecked, true);
        else
          this.singleCategoryView.SetCourseState(SingleObjectState.Checked, false);
      }
      this.executeCheckBoxCheckedEvent = true;
    }

    private void singleQuestionCheckBox_Unchecked(object sender, RoutedEventArgs e)
    {
      this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Colors.White);
      --this.singleLessonView.checkedQuestions;
      this.coursesVisibility.RemoveQuestion(this.questionData);
      if (this.executeCheckBoxUncheckedEvent)
      {
        if (this.singleLessonView.allQuestionsInLesson == this.singleLessonView.checkedQuestions + 1)
          --this.singleCategoryView.checkedLessons;
        if (this.singleLessonView.checkedQuestions == 0)
        {
          this.singleLessonView.SetLessonState(SingleObjectState.Unchecked, false);
        }
        else
        {
          if (this.singleLessonView.singleLessonState != SingleObjectState.AllChecked)
          {
            this.coursesVisibility.RemoveAllLesson(this.singleLessonView.lessonData);
            this.coursesVisibility.selectedCategoriesList.Remove(this.singleCategoryView.categoryData);
          }
          if (this.singleLessonView.singleLessonState != SingleObjectState.Checked)
          {
            this.singleLessonView.SetLessonState(SingleObjectState.Checked, false);
            this.coursesVisibility.RemoveAllLesson(this.singleLessonView.lessonData);
            this.coursesVisibility.selectedCategoriesList.Remove(this.singleCategoryView.categoryData);
          }
          foreach (SingleLessonView child in this.singleCategoryView.lessons.Children)
          {
            if (child.singleLessonState == SingleObjectState.AllChecked)
              this.coursesVisibility.AddAllLesson(child.lessonData);
          }
          foreach (SingleQuestionView child in this.singleLessonView.questions.Children)
          {
            this.coursesVisibility.RemoveQuestion(child.questionData);
            bool? isChecked = child.singleQuestionCheckBox.IsChecked;
            bool flag = true;
            if (isChecked.GetValueOrDefault() == flag & isChecked.HasValue)
              this.coursesVisibility.AddQestion(child.questionData);
          }
        }
        if (this.singleCategoryView.checkedLessons == 0)
          this.singleCategoryView.SetCourseState(SingleObjectState.Unchecked, false);
        else
          this.singleCategoryView.SetCourseState(SingleObjectState.Checked, false);
      }
      this.executeCheckBoxUncheckedEvent = true;
    }

    public void SetQuestionState(SingleObjectState singleObjectState, bool executeCheckBoxEvent)
    {
      switch (singleObjectState)
      {
        case SingleObjectState.Checked:
          if (executeCheckBoxEvent)
            this.singleQuestionCheckBox.IsChecked = new bool?(true);
          this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 100, (byte) 15, (byte) 142, byte.MaxValue));
          break;
        case SingleObjectState.AllChecked:
          if (executeCheckBoxEvent)
            this.singleQuestionCheckBox.IsChecked = new bool?(true);
          this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Color.FromArgb((byte) 100, (byte) 15, (byte) 142, byte.MaxValue));
          break;
        case SingleObjectState.Unchecked:
          if (executeCheckBoxEvent)
            this.singleQuestionCheckBox.IsChecked = new bool?(false);
          this.backgroundSingleLesson.Background = (Brush) new SolidColorBrush(Colors.White);
          break;
      }
      this.singleQuestionState = singleObjectState;
    }

    private string GetDescriptionInQuestion(string description)
    {
      string questionContent = this.questionData.GetQuestionContent();
      return (questionContent.Length > 4 ? questionContent.Substring(0, 4) : questionContent) == "http" ? questionContent.Substring(questionContent.IndexOf(" ") + 1) : (this.textQuestionDescription.Text = questionContent);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/coursesvisibility/components/singlequestionview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.backgroundSingleLesson = (StackPanel) target;
          break;
        case 2:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 3:
          this.singleQuestionCheckBox = (CheckBox) target;
          this.singleQuestionCheckBox.Checked += new RoutedEventHandler(this.singleQuestionCheckBox_Checked);
          this.singleQuestionCheckBox.Unchecked += new RoutedEventHandler(this.singleQuestionCheckBox_Unchecked);
          break;
        case 4:
          this.textQuestion = (TextBlock) target;
          break;
        case 5:
          this.textQuestionDescription = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
