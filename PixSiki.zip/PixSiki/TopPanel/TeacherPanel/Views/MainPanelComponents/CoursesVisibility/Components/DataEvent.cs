﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components.DataEvent
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.CoursesVisibility.Components
{
  public delegate void DataEvent(bool trueOrFalse);
}
