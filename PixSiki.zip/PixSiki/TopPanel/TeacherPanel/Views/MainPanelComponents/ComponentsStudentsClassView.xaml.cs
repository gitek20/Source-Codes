﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components.StudentsClassView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.Components.Basic;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components
{
  public partial class StudentsClassView : UserControl, IComponentConnector
  {
    internal Label col1Title;
    internal TextLabelInfo className;
    internal TextLabelInfo classDescription;
    internal TextLabelInfo classYear;
    internal TextLabelInfo classCode;
    private bool _contentLoaded;

    public StudentsClassView(StudentsClass studentsClass)
    {
      this.InitializeComponent();
      this.col1Title.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classData");
      this.className.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (className));
      this.className.TextInside = studentsClass.Name;
      this.classDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classDescription));
      this.classDescription.TextInside = studentsClass.Description;
      this.classYear.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classYear));
      this.classYear.TextInside = studentsClass.Yearbook.ToString();
      this.classCode.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classCode));
      this.classCode.TextInside = studentsClass.GetClassCode();
    }

    private void StackPanel_DragEnter(object sender, DragEventArgs e)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/components/studentsclassview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.col1Title = (Label) target;
          break;
        case 2:
          this.className = (TextLabelInfo) target;
          break;
        case 3:
          this.classDescription = (TextLabelInfo) target;
          break;
        case 4:
          this.classYear = (TextLabelInfo) target;
          break;
        case 5:
          this.classCode = (TextLabelInfo) target;
          break;
        case 6:
          ((UIElement) target).DragEnter += new DragEventHandler(this.StackPanel_DragEnter);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
