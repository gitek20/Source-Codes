﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.DeleteStudentsClass
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class DeleteStudentsClass : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private StudentsClass studentsClass;
    private Action backToClasses;
    internal BigCaption bigCaption;
    internal SmallInfoText info;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public DeleteStudentsClass(StudentsClass studentsClass, Action backToClasses)
    {
      this.InitializeComponent();
      this.studentsClass = studentsClass;
      this.backToClasses = backToClasses;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("deleteClass");
      this.info.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("sureDeleteClass") + " " + studentsClass.Name + "?";
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.CloseStudentClass_clickEvent);
      this.actionButtons.confirm.clickEvent += (RoundedButton.ClickDelegate) (() => backToClasses());
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("delete");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.DeleteClass_clickEvent);
    }

    private void DeleteClass_clickEvent()
    {
      try
      {
        this.studentsClass = new ServerApi().DeleteStudentsClass(this.studentsClass, new AuthorizeData(CurrentUserInfo.CurrentUser));
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.Message);
      }
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    private void CloseStudentClass_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/deletestudentsclass.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.info = (SmallInfoText) target;
          break;
        case 3:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
