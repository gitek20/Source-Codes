﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.MainTable.SingleRow
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.MainTable
{
  public partial class SingleRow : UserControl, IComponentConnector
  {
    private IResultsDataController resultsDataController;
    private User user;
    private int index;
    private List<CellStatistic> allCells = new List<CellStatistic>();
    internal StackPanel mainStack;
    private bool _contentLoaded;

    public SingleRow(
      IResultsDataController resultsDataController,
      StatisticInputData statisticInputData,
      User user,
      int index)
    {
      this.InitializeComponent();
      this.index = index;
      this.user = user;
      this.resultsDataController = resultsDataController;
      this.mainStack.Children.Clear();
      CellStatistic cellStatistic1 = new CellStatistic(resultsDataController, statisticInputData, user, index, true);
      this.mainStack.Children.Add((UIElement) cellStatistic1);
      this.allCells.Add(cellStatistic1);
      if (statisticInputData.DataType == StatisticRowDataType.AllCourses)
      {
        foreach (ICategoryData allMainCategory in resultsDataController.GetAllMainCategories())
        {
          if (!(allMainCategory as QuestionCategory).IsMyCreation())
          {
            StatisticInputData inputData = new StatisticInputData(allMainCategory, user.Id);
            CellStatistic cellStatistic2 = new CellStatistic(resultsDataController, inputData, user, index, false);
            this.allCells.Add(cellStatistic2);
            this.mainStack.Children.Add((UIElement) cellStatistic2);
          }
        }
      }
      if (statisticInputData.DataType == StatisticRowDataType.AllExams || statisticInputData.DataType == StatisticRowDataType.AllHomeWorks)
      {
        foreach (Exam exam in statisticInputData.DataType != StatisticRowDataType.AllExams ? resultsDataController.GetAllHomeworks() : resultsDataController.GetAllExams())
        {
          StatisticInputData inputData = new StatisticInputData(exam, user);
          CellStatistic cellStatistic2 = new CellStatistic(resultsDataController, inputData, user, index, false);
          this.allCells.Add(cellStatistic2);
          this.mainStack.Children.Add((UIElement) cellStatistic2);
        }
      }
      if (statisticInputData.DataType == StatisticRowDataType.Exam || statisticInputData.DataType == StatisticRowDataType.HomeWork)
      {
        Exam examOfId = resultsDataController.GetExamOfId(statisticInputData.ExamID);
        foreach (IQuestionData questionData in resultsDataController.GetAllQuestionsInExam(examOfId))
        {
          if (questionData.IsClassicQuestion())
          {
            CellStatistic cellStatistic2 = new CellStatistic(resultsDataController, questionData, user, index);
            this.allCells.Add(cellStatistic2);
            this.mainStack.Children.Add((UIElement) cellStatistic2);
          }
        }
      }
      if (statisticInputData.DataType == StatisticRowDataType.Course)
      {
        foreach (ICategoryData categoryData in resultsDataController.GetAllLessonInCategory(statisticInputData.CategoryGuid))
        {
          StatisticInputData inputData = new StatisticInputData(categoryData, user.Id);
          CellStatistic cellStatistic2 = new CellStatistic(resultsDataController, inputData, user, index, false);
          this.allCells.Add(cellStatistic2);
          this.mainStack.Children.Add((UIElement) cellStatistic2);
        }
      }
      if (statisticInputData.DataType == StatisticRowDataType.LessonInCourse)
      {
        foreach (IQuestionData questionData in resultsDataController.GetAllQuestionsInLesson(statisticInputData.CategoryGuid))
        {
          if (questionData.IsClassicQuestion())
          {
            CellStatistic cellStatistic2 = new CellStatistic(resultsDataController, questionData, user, index);
            this.allCells.Add(cellStatistic2);
            this.mainStack.Children.Add((UIElement) cellStatistic2);
          }
        }
      }
      CellStatistic cellStatistic3 = new CellStatistic(resultsDataController, statisticInputData, user, index);
      this.allCells.Add(cellStatistic3);
      this.mainStack.Children.Add((UIElement) cellStatistic3);
    }

    internal void DisposeAllElements()
    {
      for (int index = 0; index < this.allCells.Count; ++index)
      {
        this.allCells[index].DisposeAllElements();
        this.allCells[index] = (CellStatistic) null;
      }
      this.mainStack.Children.Clear();
    }

    internal string GetCSVRow()
    {
      string str = (this.index + 1).ToString() + "," + this.user.Name + "," + this.user.Surname;
      foreach (CellStatistic allCell in this.allCells)
        str = str + "," + allCell.GetCSVText();
      return str;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/learnigresultsconponents/maintable/singlerow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.mainStack = (StackPanel) target;
      else
        this._contentLoaded = true;
    }
  }
}
