﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.LearningResultsSelector.SingleItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.LearningResultsSelector
{
  public partial class SingleItem : UserControl, IComponentConnector
  {
    private SingleItem itemParent;
    private List<SingleItem> subItems = new List<SingleItem>();
    private SingleListItemModel singleListItemModel;
    private bool isCollapsed = true;
    private bool isSelected;
    internal Rectangle activeRectangle;
    internal Rectangle selectedRectangle;
    internal TextBlock textName;
    internal TextBlock textDescription;
    internal Grid LeftGrid;
    internal Rectangle whitecircle;
    internal Rectangle backRectangle;
    internal Image imgDown;
    internal Image imgLeft;
    internal StackPanel SubChilds;
    private bool _contentLoaded;

    public SingleListItemModel SingleListItemModel => this.singleListItemModel;

    public SingleItem(SingleListItemModel singleListItemModel, SingleItem itemParent)
    {
      this.itemParent = itemParent;
      this.InitializeComponent();
      this.activeRectangle.Opacity = 0.0;
      this.selectedRectangle.Opacity = 0.0;
      this.singleListItemModel = singleListItemModel;
      this.textName.Text = singleListItemModel.Name;
      this.textDescription.Text = singleListItemModel.Description;
      if (this.textDescription.Text == "" || this.textDescription.Text == null)
        this.textDescription.Visibility = Visibility.Collapsed;
      foreach (SingleListItemModel subModel in singleListItemModel.SubModels)
      {
        SingleItem singleItem = new SingleItem(subModel, this);
        singleItem.ItemSelectionEvent += new SingleItem.ItemSelectionAction(this.SubItem_ItemSelectionEvent);
        this.subItems.Add(singleItem);
        this.SubChilds.Children.Add((UIElement) singleItem);
      }
      this.ShowIsCollapsed();
      if (singleListItemModel.SubModels.Count == 0)
      {
        this.imgDown.Visibility = Visibility.Collapsed;
        this.whitecircle.Visibility = Visibility.Collapsed;
        this.backRectangle.Visibility = Visibility.Collapsed;
        this.imgLeft.Visibility = Visibility.Visible;
        this.imgLeft.Opacity = 0.0;
        this.backRectangle.IsHitTestVisible = false;
        this.LeftGrid.IsHitTestVisible = false;
      }
      this.backRectangle.Visibility = Visibility.Collapsed;
    }

    private void SubItem_ItemSelectionEvent(SingleItem singleItem)
    {
      if (this.ItemSelectionEvent == null)
        return;
      this.ItemSelectionEvent(singleItem);
    }

    public bool IsCollapsed
    {
      set
      {
        this.isCollapsed = value;
        this.ShowIsCollapsed();
      }
    }

    private void ShowIsCollapsed()
    {
      if (this.isCollapsed)
      {
        this.imgDown.Visibility = Visibility.Collapsed;
        this.imgLeft.Visibility = Visibility.Visible;
        this.SubChilds.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.imgDown.Visibility = Visibility.Visible;
        this.imgLeft.Visibility = Visibility.Collapsed;
        this.SubChilds.Visibility = Visibility.Visible;
      }
    }

    internal string GetStackCaption()
    {
      string str = this.singleListItemModel.Name;
      if (this.itemParent != null)
        str = this.itemParent.GetStackCaption() + " > " + str;
      return str;
    }

    private void Rectangle_MouseLeave(object sender, MouseEventArgs e) => this.backRectangle.Visibility = Visibility.Collapsed;

    private void Rectangle_MouseEnter(object sender, MouseEventArgs e) => this.backRectangle.Visibility = Visibility.Visible;

    private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.isCollapsed = !this.isCollapsed;
      this.ShowIsCollapsed();
    }

    public SingleItem ItemParent => this.itemParent;

    public void SelectOnlyItem(SingleListItemModel item)
    {
      if (item == this.singleListItemModel)
      {
        this.activeRectangle.Opacity = 1.0;
        this.textName.Foreground = (Brush) new SolidColorBrush(Colors.White);
        this.textDescription.Foreground = (Brush) new SolidColorBrush(Colors.White);
      }
      else
      {
        this.activeRectangle.Opacity = 0.0;
        this.textName.Foreground = (Brush) new SolidColorBrush(Colors.Black);
        this.textDescription.Foreground = (Brush) new SolidColorBrush(Colors.Black);
      }
      foreach (SingleItem subItem in this.subItems)
        subItem.SelectOnlyItem(item);
    }

    private void activeRectangle_MouseLeave(object sender, MouseEventArgs e) => this.selectedRectangle.Opacity = 0.0;

    private void activeRectangle_MouseEnter(object sender, MouseEventArgs e) => this.selectedRectangle.Opacity = 0.2;

    public event SingleItem.ItemSelectionAction ItemSelectionEvent;

    private void activeRectangle_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.ItemSelectionEvent == null)
        return;
      this.ItemSelectionEvent(this);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/learnigresultsconponents/learningresultsselector/singleitem.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.activeRectangle = (Rectangle) target;
          break;
        case 2:
          this.selectedRectangle = (Rectangle) target;
          break;
        case 3:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.activeRectangle_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.activeRectangle_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.activeRectangle_MouseDown);
          break;
        case 4:
          this.textName = (TextBlock) target;
          break;
        case 5:
          this.textDescription = (TextBlock) target;
          break;
        case 6:
          this.LeftGrid = (Grid) target;
          this.LeftGrid.MouseEnter += new MouseEventHandler(this.Rectangle_MouseEnter);
          this.LeftGrid.MouseLeave += new MouseEventHandler(this.Rectangle_MouseLeave);
          this.LeftGrid.MouseDown += new MouseButtonEventHandler(this.Rectangle_MouseDown);
          break;
        case 7:
          this.whitecircle = (Rectangle) target;
          break;
        case 8:
          this.backRectangle = (Rectangle) target;
          break;
        case 9:
          this.imgDown = (Image) target;
          break;
        case 10:
          this.imgLeft = (Image) target;
          break;
        case 11:
          this.SubChilds = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ItemSelectionAction(SingleItem singleItem);
  }
}
