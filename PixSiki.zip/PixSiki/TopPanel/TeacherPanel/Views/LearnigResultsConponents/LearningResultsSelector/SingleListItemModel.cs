﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.LearningResultsSelector.SingleListItemModel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.TopPanel.TeacherPanel.Models;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System.Collections.Generic;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.LearningResultsSelector
{
  public class SingleListItemModel
  {
    private ResultsDataController resultsDataController;
    private StatisticInputData statisticInputData;
    private string name;
    private string description;
    private List<SingleListItemModel> subModels = new List<SingleListItemModel>();
    private Exam exam;

    public SingleListItemModel(
      StatisticRowDataType statisticRowDataType,
      ResultsDataController resultsDataController)
    {
      this.resultsDataController = resultsDataController;
      if (statisticRowDataType == StatisticRowDataType.AllCourses)
      {
        this.statisticInputData = new StatisticInputData(statisticRowDataType);
        this.name = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("courses");
        this.description = "";
        foreach (ICategoryData allMainCategory in BuiltInCoursesInstance.Instance.GetAllMainCategories())
        {
          if (!(allMainCategory as QuestionCategory).IsMyCreation())
            this.subModels.Add(new SingleListItemModel(new StatisticInputData(StatisticRowDataType.Course)
            {
              CategoryGuid = allMainCategory.UniqueGuid()
            }, allMainCategory));
        }
      }
      if (statisticRowDataType == StatisticRowDataType.AllExams)
      {
        this.statisticInputData = new StatisticInputData(statisticRowDataType);
        this.name = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("tests");
        this.description = "";
        foreach (Exam allExam in resultsDataController.GetAllExams())
          this.subModels.Add(new SingleListItemModel(new StatisticInputData(StatisticRowDataType.Exam)
          {
            ExamID = new int?(allExam.Id)
          }, allExam));
      }
      if (statisticRowDataType != StatisticRowDataType.AllHomeWorks)
        return;
      this.statisticInputData = new StatisticInputData(statisticRowDataType);
      this.name = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("homeworks");
      this.description = "";
      foreach (Exam allHomework in resultsDataController.GetAllHomeworks())
        this.subModels.Add(new SingleListItemModel(new StatisticInputData(StatisticRowDataType.HomeWork)
        {
          ExamID = new int?(allHomework.Id)
        }, allHomework));
    }

    public SingleListItemModel(StatisticInputData statisticInputData, ICategoryData category)
    {
      this.statisticInputData = statisticInputData;
      this.name = category.TranslatedName();
      this.description = category.TranslatedDescription();
      if (!category.IsCourse())
        return;
      foreach (ICategoryData category1 in BuiltInCoursesInstance.Instance.GetAllLessonInCategory(category.UniqueGuid()))
        this.subModels.Add(new SingleListItemModel(new StatisticInputData(StatisticRowDataType.LessonInCourse)
        {
          CategoryGuid = category1.UniqueGuid()
        }, category1));
    }

    public SingleListItemModel(StatisticInputData statisticInputData, Exam exam)
    {
      this.statisticInputData = statisticInputData;
      this.exam = exam;
      this.name = exam.Name;
      this.description = exam.Description;
    }

    public string Name
    {
      get => this.name;
      set => this.name = value;
    }

    public string Description
    {
      get => this.description;
      set => this.description = value;
    }

    public StatisticInputData StatisticInputData
    {
      get => this.statisticInputData;
      set => this.statisticInputData = value;
    }

    internal List<SingleListItemModel> SubModels
    {
      get => this.subModels;
      set => this.subModels = value;
    }
  }
}
