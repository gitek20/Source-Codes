﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.LearningResultsSelector.LearningResultsSelectorView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using Microsoft.Win32;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.LearningResultsSelector
{
  public partial class LearningResultsSelectorView : UserControl, IComponentConnector
  {
    private StudentsClass studentsClass;
    private SingleItem categoriesView;
    private SingleItem examsView;
    private SingleItem homeworksView;
    private ResultsDataController resultsDataController;
    private SingleItem lastSelectedItem;
    private LearingResultsView learingResultsView;
    private SingleItem singleItem;
    internal StackPanel mainStackPanel;
    internal StackPanel buttonsStack;
    internal Grid mainGrid;
    private bool _contentLoaded;

    public LearningResultsSelectorView(
      StudentsClass studentsClass,
      ResultsDataController resultsDataController)
    {
      this.resultsDataController = resultsDataController;
      this.studentsClass = studentsClass;
      this.InitializeComponent();
      RoundedButton roundedButton1 = new RoundedButton();
      roundedButton1.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("refresh");
      roundedButton1.SetColor(RoundedButton.ColorType.white);
      roundedButton1.SetImage(RoundedButton.IcoType.Refresh);
      roundedButton1.Margin = new Thickness(20.0, 0.0, 0.0, 0.0);
      roundedButton1.clickEvent += new RoundedButton.ClickDelegate(this.RefreshButton_clickEvent);
      this.buttonsStack.Children.Add((UIElement) roundedButton1);
      List<User> allUsersInClass = resultsDataController.GetAllUsersInClass();
      // ISSUE: explicit non-virtual call
      if ((allUsersInClass != null ? (__nonvirtual (allUsersInClass.Count) == 0 ? 1 : 0) : 0) == 0)
      {
        RoundedButton roundedButton2 = new RoundedButton();
        roundedButton2.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("exportCsv");
        roundedButton2.clickEvent += new RoundedButton.ClickDelegate(this.ExportCSV_clickEvent);
        roundedButton2.SetImage(RoundedButton.IcoType.Csv);
        roundedButton2.Margin = new Thickness(20.0, 0.0, 0.0, 0.0);
        roundedButton2.SetColor(RoundedButton.ColorType.white);
        this.buttonsStack.Children.Add((UIElement) roundedButton2);
      }
      this.categoriesView = new SingleItem(new SingleListItemModel(StatisticRowDataType.AllCourses, resultsDataController), (SingleItem) null);
      this.categoriesView.ItemSelectionEvent += new SingleItem.ItemSelectionAction(this.CategoriesView_ItemSelectionEvent);
      this.mainStackPanel.Children.Add((UIElement) this.categoriesView);
      this.examsView = new SingleItem(new SingleListItemModel(StatisticRowDataType.AllExams, resultsDataController), (SingleItem) null);
      this.examsView.ItemSelectionEvent += new SingleItem.ItemSelectionAction(this.CategoriesView_ItemSelectionEvent);
      this.mainStackPanel.Children.Add((UIElement) this.examsView);
      this.homeworksView = new SingleItem(new SingleListItemModel(StatisticRowDataType.AllHomeWorks, resultsDataController), (SingleItem) null);
      this.homeworksView.ItemSelectionEvent += new SingleItem.ItemSelectionAction(this.CategoriesView_ItemSelectionEvent);
      this.mainStackPanel.Children.Add((UIElement) this.homeworksView);
      this.CategoriesView_ItemSelectionEvent(this.categoriesView);
      Grid grid = new Grid();
      grid.Height = 20.0;
      this.mainStackPanel.Children.Add((UIElement) grid);
    }

    private void ExportCSV_clickEvent()
    {
      SaveFileDialog saveFileDialog = new SaveFileDialog();
      saveFileDialog.Filter = "CSV file (*.csv)|*.csv";
      bool? nullable = saveFileDialog.ShowDialog();
      bool flag = true;
      if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
        return;
      File.WriteAllText(saveFileDialog.FileName, this.learingResultsView.GetCSVFile());
    }

    private void RefreshButton_clickEvent()
    {
      this.singleItem = this.lastSelectedItem;
      GlobalProgressBarManager.RunFuncionAndProgressBar(new Action(this.RefreshData));
    }

    private void RefreshData()
    {
      this.resultsDataController.RefreshAllData();
      this.ShowCategoriesAsync();
    }

    public event SingleItem.ItemSelectionAction ItemSelectionEvent;

    private void ShowCategoriesAsync()
    {
      if (this.learingResultsView != null)
      {
        this.learingResultsView.DisposeAllElements();
        this.learingResultsView = (LearingResultsView) null;
      }
      this.lastSelectedItem = this.singleItem;
      this.categoriesView.SelectOnlyItem(this.singleItem.SingleListItemModel);
      this.examsView.SelectOnlyItem(this.singleItem.SingleListItemModel);
      this.homeworksView.SelectOnlyItem(this.singleItem.SingleListItemModel);
      this.mainGrid.Children.Clear();
      this.learingResultsView = new LearingResultsView(this.studentsClass.Id.Value, this.singleItem.SingleListItemModel.StatisticInputData, this.resultsDataController);
      this.mainGrid.Children.Add((UIElement) this.learingResultsView);
      this.learingResultsView.SetStackCaption(this.singleItem.GetStackCaption());
      if (this.ItemSelectionEvent == null)
        return;
      this.ItemSelectionEvent(this.singleItem);
    }

    private void CategoriesView_ItemSelectionEvent(SingleItem singleItem)
    {
      this.singleItem = singleItem;
      this.ShowCategoriesAsync();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/learnigresultsconponents/learningresultsselector/learningresultsselectorview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainStackPanel = (StackPanel) target;
          break;
        case 2:
          this.buttonsStack = (StackPanel) target;
          break;
        case 3:
          this.mainGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
