﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.Caption.CaptionsList
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.Caption
{
  public partial class CaptionsList : UserControl, IComponentConnector
  {
    private IResultsDataController resultsDataController;
    private StatisticInputData statisticInputData;
    private List<CaptionStatisticItem> allCaptions = new List<CaptionStatisticItem>();
    internal StackPanel mainStack;
    private bool _contentLoaded;

    public CaptionsList(
      IResultsDataController resultsDataController,
      StatisticInputData statisticInputData,
      User sampleUser)
    {
      this.resultsDataController = resultsDataController;
      this.statisticInputData = statisticInputData;
      this.InitializeComponent();
      CaptionStatisticItem captionStatisticItem1 = new CaptionStatisticItem(resultsDataController, new StatisticInputData(statisticInputData.DataType)
      {
        CategoryGuid = statisticInputData.CategoryGuid,
        DataType = statisticInputData.DataType,
        ExamID = statisticInputData.ExamID,
        UserID = new int?(sampleUser.Id.Value)
      }, (IListItem) null, false, 0);
      this.allCaptions.Add(captionStatisticItem1);
      this.mainStack.Children.Add((UIElement) captionStatisticItem1);
      if (statisticInputData.DataType == StatisticRowDataType.AllCourses)
      {
        int counter = 0;
        foreach (ICategoryData allMainCategory in resultsDataController.GetAllMainCategories())
        {
          if (!(allMainCategory as QuestionCategory).IsMyCreation())
          {
            ++counter;
            CaptionStatisticItem captionStatisticItem2 = new CaptionStatisticItem(resultsDataController, new StatisticInputData(allMainCategory, new int?())
            {
              UserID = new int?(sampleUser.Id.Value)
            }, (IListItem) allMainCategory, false, counter);
            this.allCaptions.Add(captionStatisticItem2);
            this.mainStack.Children.Add((UIElement) captionStatisticItem2);
          }
        }
      }
      if (statisticInputData.DataType == StatisticRowDataType.AllExams || statisticInputData.DataType == StatisticRowDataType.AllHomeWorks)
      {
        int counter = 0;
        foreach (Exam exam in statisticInputData.DataType != StatisticRowDataType.AllExams ? resultsDataController.GetAllHomeworks() : resultsDataController.GetAllExams())
        {
          ++counter;
          CaptionStatisticItem captionStatisticItem2 = new CaptionStatisticItem(resultsDataController, new StatisticInputData(exam, (User) null)
          {
            UserID = new int?(sampleUser.Id.Value)
          }, (IListItem) exam, false, counter);
          this.allCaptions.Add(captionStatisticItem2);
          this.mainStack.Children.Add((UIElement) captionStatisticItem2);
        }
      }
      if (statisticInputData.DataType == StatisticRowDataType.Exam || statisticInputData.DataType == StatisticRowDataType.HomeWork)
      {
        Exam examOfId = resultsDataController.GetExamOfId(statisticInputData.ExamID);
        List<Question> allQuestionsInExam = resultsDataController.GetAllQuestionsInExam(examOfId);
        int counter = 0;
        foreach (IQuestionData questionData in allQuestionsInExam)
        {
          if (questionData.IsClassicQuestion())
          {
            ++counter;
            (questionData as Question).CaptionInCategory = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("question") + " " + counter.ToString();
            CaptionStatisticItem captionStatisticItem2 = new CaptionStatisticItem(resultsDataController, questionData, counter);
            this.allCaptions.Add(captionStatisticItem2);
            this.mainStack.Children.Add((UIElement) captionStatisticItem2);
          }
        }
      }
      if (statisticInputData.DataType == StatisticRowDataType.Course)
      {
        List<ICategoryData> lessonInCategory = resultsDataController.GetAllLessonInCategory(statisticInputData.CategoryGuid);
        int counter = 0;
        foreach (ICategoryData categoryData in lessonInCategory)
        {
          ++counter;
          CaptionStatisticItem captionStatisticItem2 = new CaptionStatisticItem(resultsDataController, new StatisticInputData(categoryData, new int?())
          {
            UserID = new int?(sampleUser.Id.Value)
          }, (IListItem) categoryData, false, counter);
          this.allCaptions.Add(captionStatisticItem2);
          this.mainStack.Children.Add((UIElement) captionStatisticItem2);
        }
      }
      if (statisticInputData.DataType == StatisticRowDataType.LessonInCourse)
      {
        List<IQuestionData> questionsInLesson = resultsDataController.GetAllQuestionsInLesson(statisticInputData.CategoryGuid);
        int counter = 0;
        foreach (IQuestionData questionData in questionsInLesson)
        {
          if (questionData.IsClassicQuestion())
          {
            ++counter;
            CaptionStatisticItem captionStatisticItem2 = new CaptionStatisticItem(resultsDataController, questionData, counter);
            this.allCaptions.Add(captionStatisticItem2);
            this.mainStack.Children.Add((UIElement) captionStatisticItem2);
          }
        }
      }
      CaptionStatisticItem captionStatisticItem3 = new CaptionStatisticItem(resultsDataController, statisticInputData, (IListItem) null, true, 0);
      this.allCaptions.Add(captionStatisticItem3);
      this.mainStack.Children.Add((UIElement) captionStatisticItem3);
      Grid grid = new Grid();
      grid.Width = 1000.0;
      this.mainStack.Children.Add((UIElement) grid);
    }

    internal string GetCSVFileLastRow()
    {
      string str = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("csvMaxPoints");
      foreach (CaptionStatisticItem allCaption in this.allCaptions)
        str = str + "," + allCaption.CSVDescriptionBotton();
      return str;
    }

    internal string GetCSVFileFirstRow()
    {
      string str = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("csvName");
      foreach (CaptionStatisticItem allCaption in this.allCaptions)
        str = str + "," + allCaption.CSVDescription();
      return str;
    }

    internal void DisposeAllElements()
    {
      for (int index = 0; index < this.allCaptions.Count; ++index)
      {
        this.allCaptions[index].DisposeAllElements();
        this.allCaptions[index] = (CaptionStatisticItem) null;
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/learnigresultsconponents/caption/captionslist.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.mainStack = (StackPanel) target;
      else
        this._contentLoaded = true;
    }
  }
}
