﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.MainTable.CellStatistic
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.UserProfileInfo;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.MainTable
{
  public partial class CellStatistic : UserControl, IComponentConnector
  {
    private IResultsDataController resultsDataController;
    private User user;
    private StatisticInputData inputData;
    private IQuestionData questionData;
    private TextBox textComment;
    private bool isComment;
    private QuestionResult questionResult;
    internal Grid backRect;
    internal Rectangle strokeRect;
    internal Grid SumBackground;
    internal Grid selectionRect;
    internal TextBlock userPoints;
    internal TextBlock allpoints;
    private bool _contentLoaded;

    public IQuestionData QuestionData => this.questionData;

    public StatisticInputData StatisticInputData => this.inputData;

    public bool IsComment => this.isComment;

    public User User => this.user;

    public CellStatistic(
      IResultsDataController resultsDataController,
      StatisticInputData inputData,
      User user,
      int index)
    {
      this.isComment = true;
      this.InitializeComponent();
      this.resultsDataController = resultsDataController;
      this.Width = 600.0;
      this.userPoints.Text = "";
      this.allpoints.Text = "";
      this.inputData = inputData;
      this.user = user;
      Viewbox viewbox = new Viewbox();
      this.textComment = new TextBox();
      this.textComment.VerticalContentAlignment = VerticalAlignment.Center;
      this.textComment.Padding = new Thickness(5.0, 0.0, 0.0, 0.0);
      this.textComment.Height = this.Height / 3.0;
      this.textComment.Width = this.Width / 3.0;
      this.textComment.FontSize = 6.0;
      this.textComment.Background = (Brush) new SolidColorBrush(Colors.Transparent);
      this.textComment.BorderBrush = (Brush) new SolidColorBrush(Colors.Transparent);
      this.textComment.FontFamily = new FontFamily("Segoe UI Semibold");
      this.textComment.LostFocus += new RoutedEventHandler(this.comments_LostFocus);
      this.textComment.Text = resultsDataController.GetComment(inputData);
      this.backRect.Children.Add((UIElement) viewbox);
      viewbox.Child = (UIElement) this.textComment;
      if (index % 2 == 1)
        this.backRect.Background = (Brush) new SolidColorBrush(Colors.White);
      else
        this.backRect.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 240, (byte) 240, (byte) 245));
      CellStatistic.rowWasSelectedEvent += new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);
    }

    private void CellStatistic_rowWasSelectedEvent(CellStatistic cellStatistic, bool isSelected)
    {
      int? id1 = this.User.Id;
      int? id2 = cellStatistic.User.Id;
      if (id1.GetValueOrDefault() == id2.GetValueOrDefault() & id1.HasValue == id2.HasValue || this.isComment == cellStatistic.isComment && (this.questionData != null && cellStatistic.questionData != null && this.questionData.QuestionGuid() == cellStatistic.questionData.QuestionGuid() || this.inputData != null && cellStatistic.inputData != null && (cellStatistic.inputData.DataType == this.inputData.DataType && cellStatistic.inputData.CategoryGuid == this.inputData.CategoryGuid)))
      {
        if (isSelected)
          this.selectionRect.Opacity = 0.15;
        else
          this.selectionRect.Opacity = 0.0;
      }
      else
        this.selectionRect.Opacity = 0.0;
    }

    internal string GetCSVText()
    {
      if (this.isComment)
        return this.textComment.Text.Replace(",", " ");
      if (this.inputData != null)
        return this.userPoints.Text;
      return this.questionResult != null ? Math.Max(0, this.questionResult.Points).ToString() ?? "" : "";
    }

    internal void DisposeAllElements() => CellStatistic.rowWasSelectedEvent -= new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);

    public CellStatistic(
      IResultsDataController resultsDataController,
      IQuestionData questionData,
      User user,
      int index)
    {
      this.resultsDataController = resultsDataController;
      this.questionData = questionData;
      this.user = user;
      this.InitializeComponent();
      if (questionData.IsExamQuestion)
      {
        IResultsDataController resultsDataController1 = resultsDataController;
        string questionGuid = questionData.QuestionGuid();
        int? nullable = questionData.ExamID;
        int examId = nullable.Value;
        nullable = user.Id;
        int userID = nullable.Value;
        this.questionResult = resultsDataController1.GetNumberOfPointsInExamOrHomework(questionGuid, examId, userID);
      }
      else
        this.questionResult = resultsDataController.GetNumberOfPointsInLesson(questionData.QuestionGuid(), user.Id.Value);
      this.userPoints.Text = "";
      this.allpoints.Text = "";
      if (index % 2 == 1)
        this.backRect.Background = (Brush) new SolidColorBrush(Colors.White);
      else
        this.backRect.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 240, (byte) 240, (byte) 245));
      Rectangle rectangle = new Rectangle();
      rectangle.HorizontalAlignment = HorizontalAlignment.Center;
      rectangle.VerticalAlignment = VerticalAlignment.Center;
      rectangle.RadiusX = 18.0;
      rectangle.RadiusY = 18.0;
      rectangle.Height = 25.0;
      rectangle.Width = 25.0;
      this.backRect.Children.Add((UIElement) rectangle);
      if (this.questionResult.Points > 0)
        rectangle.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 140, byte.MaxValue));
      else
        rectangle.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 230, (byte) 230, (byte) 230));
      this.userPoints.Visibility = Visibility.Collapsed;
      CellStatistic.rowWasSelectedEvent += new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);
    }

    public CellStatistic(
      IResultsDataController resultsDataController,
      StatisticInputData inputData,
      User user,
      int index,
      bool isBig)
    {
      this.resultsDataController = resultsDataController;
      this.inputData = inputData;
      this.user = user;
      this.InitializeComponent();
      StatisticOutData statisticData = resultsDataController.GetStatisticData(inputData);
      TextBlock userPoints = this.userPoints;
      int num = statisticData.SumOfUserPoints;
      string str1 = num.ToString() ?? "";
      userPoints.Text = str1;
      if (statisticData.SumOfUserPoints == 0)
        this.userPoints.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 200, (byte) 200, (byte) 200));
      TextBlock allpoints = this.allpoints;
      num = statisticData.AllPointsCount;
      string str2 = "(" + num.ToString() + ")";
      allpoints.Text = str2;
      if (isBig)
      {
        this.Width = 150.0;
        this.userPoints.FontSize *= 1.1;
        int sumOfUserPoints = statisticData.SumOfUserPoints;
        this.SumBackground.Visibility = Visibility.Visible;
        this.allpoints.FontSize *= 1.0;
      }
      if (index % 2 == 1)
        this.backRect.Background = (Brush) new SolidColorBrush(Colors.White);
      else
        this.backRect.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 240, (byte) 240, (byte) 245));
      CellStatistic.rowWasSelectedEvent += new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);
    }

    private void comments_LostFocus(object sender, RoutedEventArgs e) => this.resultsDataController.SetComment(this.textComment.Text, this.inputData);

    public static event CellStatistic.RowWasSelected rowWasSelectedEvent;

    private void backRect_MouseEnter(object sender, MouseEventArgs e)
    {
      if (CellStatistic.rowWasSelectedEvent == null)
        return;
      CellStatistic.rowWasSelectedEvent(this, true);
    }

    private void backRect_MouseLeave(object sender, MouseEventArgs e)
    {
      if (CellStatistic.rowWasSelectedEvent == null)
        return;
      CellStatistic.rowWasSelectedEvent(this, false);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/learnigresultsconponents/maintable/cellstatistic.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.backRect = (Grid) target;
          this.backRect.MouseEnter += new MouseEventHandler(this.backRect_MouseEnter);
          this.backRect.MouseLeave += new MouseEventHandler(this.backRect_MouseLeave);
          break;
        case 2:
          this.strokeRect = (Rectangle) target;
          break;
        case 3:
          this.SumBackground = (Grid) target;
          break;
        case 4:
          this.selectionRect = (Grid) target;
          break;
        case 5:
          this.userPoints = (TextBlock) target;
          break;
        case 6:
          this.allpoints = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void RowWasSelected(CellStatistic cellStatistic, bool isSelected);
  }
}
