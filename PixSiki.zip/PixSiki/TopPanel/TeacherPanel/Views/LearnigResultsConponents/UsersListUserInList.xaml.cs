﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.UsersList.UserInList
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.MainTable;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.UsersList
{
  public partial class UserInList : UserControl, IComponentConnector
  {
    private User user;
    private int index;
    internal Grid backRect;
    internal Grid selectionRect;
    internal TextBlock textBlockNumber;
    internal TextBlock textBlock;
    private bool _contentLoaded;

    public UserInList(User user, int index)
    {
      this.user = user;
      this.index = index;
      this.InitializeComponent();
      this.textBlockNumber.Text = (index + 1).ToString() ?? "";
      this.textBlock.Text = user.Name + " " + user.Surname;
      if (index % 2 == 1)
        this.backRect.Background = (Brush) new SolidColorBrush(Colors.White);
      else
        this.backRect.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 240, (byte) 240, (byte) 245));
      CellStatistic.rowWasSelectedEvent += new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);
    }

    private void CellStatistic_rowWasSelectedEvent(CellStatistic cellStatistic, bool isSelected)
    {
      int? id1 = cellStatistic.User.Id;
      int? id2 = this.user.Id;
      if (id1.GetValueOrDefault() == id2.GetValueOrDefault() & id1.HasValue == id2.HasValue)
      {
        if (isSelected)
          this.selectionRect.Opacity = 0.15;
        else
          this.selectionRect.Opacity = 0.0;
      }
      else
        this.selectionRect.Opacity = 0.0;
    }

    internal void DisposeAllElements() => CellStatistic.rowWasSelectedEvent -= new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/learnigresultsconponents/userslist/userinlist.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.backRect = (Grid) target;
          break;
        case 2:
          this.selectionRect = (Grid) target;
          break;
        case 3:
          this.textBlockNumber = (TextBlock) target;
          break;
        case 4:
          this.textBlock = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
