﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.Caption.CaptionStatisticItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.MainTable;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.Caption
{
  public partial class CaptionStatisticItem : UserControl, IComponentConnector
  {
    private StatisticInputData inputData;
    private IResultsDataController resultsDataController;
    private bool commentsCaption;
    private StatisticOutData statisticOutData;
    private IQuestionData questionData;
    internal Grid SumBackground;
    internal Grid selectionRect;
    internal TextBlock textBlock;
    private bool _contentLoaded;

    public CaptionStatisticItem(
      IResultsDataController resultsDataController,
      StatisticInputData inputData,
      IListItem listItem,
      bool commentsCaption,
      int counter)
    {
      this.inputData = inputData;
      this.statisticOutData = resultsDataController.GetStatisticData(inputData);
      this.resultsDataController = resultsDataController;
      this.InitializeComponent();
      if (commentsCaption)
      {
        this.commentsCaption = true;
        this.Width = 600.0;
        this.textBlock.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("comments");
        this.textBlock.HorizontalAlignment = HorizontalAlignment.Left;
        this.textBlock.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
        CellStatistic.rowWasSelectedEvent += new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);
      }
      else
      {
        if (listItem == null)
        {
          this.Width = 150.0;
          this.textBlock.FontSize *= 1.3;
          if (inputData.DataType == StatisticRowDataType.AllCourses)
            this.textBlock.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("courses");
          if (inputData.DataType == StatisticRowDataType.Course || inputData.DataType == StatisticRowDataType.LessonInCourse)
            this.textBlock.Text = resultsDataController.GetCourseOfGuid(inputData.CategoryGuid).TranslatedName();
          this.textBlock.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("sum");
          this.SumBackground.Visibility = Visibility.Visible;
        }
        else
          this.textBlock.Text = listItem.ListName;
        CellStatistic.rowWasSelectedEvent += new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);
      }
    }

    private void CellStatistic_rowWasSelectedEvent(CellStatistic cellStatistic, bool isSelected)
    {
      if (this.questionData != null && cellStatistic.QuestionData != null && this.questionData.QuestionGuid() == cellStatistic.QuestionData.QuestionGuid() || this.inputData != null && cellStatistic.StatisticInputData != null && (this.commentsCaption == cellStatistic.IsComment && this.inputData.DataType == cellStatistic.StatisticInputData.DataType) && this.inputData.CategoryGuid == cellStatistic.StatisticInputData.CategoryGuid || this.commentsCaption == cellStatistic.IsComment && this.commentsCaption)
      {
        if (isSelected)
          this.selectionRect.Opacity = 0.15;
        else
          this.selectionRect.Opacity = 0.0;
      }
      else
        this.selectionRect.Opacity = 0.0;
    }

    public CaptionStatisticItem(
      IResultsDataController resultsDataController,
      IQuestionData questionData,
      int counter)
    {
      this.resultsDataController = resultsDataController;
      this.questionData = questionData;
      this.InitializeComponent();
      this.textBlock.Text = questionData.UserFriendlyDescription();
      CellStatistic.rowWasSelectedEvent += new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);
    }

    internal void DisposeAllElements() => CellStatistic.rowWasSelectedEvent -= new CellStatistic.RowWasSelected(this.CellStatistic_rowWasSelectedEvent);

    internal string CSVDescription() => this.textBlock.Text;

    internal string CSVDescriptionBotton() => this.statisticOutData != null && !this.commentsCaption ? this.statisticOutData.AllPointsCount.ToString() ?? "" : "";

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/learnigresultsconponents/caption/captionstatisticitem.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.SumBackground = (Grid) target;
          break;
        case 2:
          this.selectionRect = (Grid) target;
          break;
        case 3:
          this.textBlock = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
