﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.AddHomeworkView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class AddHomeworkView : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private StudentsClass studentClass;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel homeworkName;
    internal RoundedTextBoxAndLabel homeworkDescription;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public AddHomeworkView(StudentsClass classe)
    {
      this.InitializeComponent();
      this.studentClass = classe;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addHomework");
      this.homeworkName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("name");
      this.homeworkDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("description");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackEvent_ClickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("add");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.AddHomework_ClickEvent);
    }

    private void AddHomework_ClickEvent()
    {
      if (this.homeworkName.textBoxRounded.textBox.Text.Length != 0)
      {
        if (this.homeworkDescription.textBoxRounded.textBox.Text.Length != 0)
        {
          try
          {
            ServerApi serverApi = new ServerApi();
            Exam exam1 = new Exam()
            {
              IsHomework = true,
              StudentsClassId = this.studentClass.Id.Value,
              Name = this.homeworkName.textBoxRounded.textBox.Text,
              Descripton = this.homeworkDescription.textBoxRounded.textBox.Text,
              IsHomeworkVisibly = false
            };
            exam1.StudentsClassId = this.studentClass.Id.Value;
            exam1.IsArchived = false;
            exam1.IsDeleted = false;
            Exam exam2 = exam1;
            AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
            serverApi.AddNewExam(exam2, authorize);
            if (this.closePopUpEvent == null)
              return;
            this.closePopUpEvent(this.parentPopUp);
            return;
          }
          catch (Exception ex)
          {
            CustomMessageBox.Show(ex.ToString());
            return;
          }
        }
      }
      if (this.homeworkName.textBoxRounded.textBox.Text.Length == 0)
        this.homeworkName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterHomeworkName"));
      if (this.homeworkDescription.textBoxRounded.textBox.Text.Length != 0)
        return;
      this.homeworkDescription.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterHomeworkDesc"));
    }

    private void BackEvent_ClickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/addhomeworkview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.homeworkName = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.homeworkDescription = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
