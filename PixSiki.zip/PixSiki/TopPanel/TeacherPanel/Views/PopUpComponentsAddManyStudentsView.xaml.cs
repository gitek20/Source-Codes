﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.AddManyStudentsView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.Tools;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class AddManyStudentsView : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private int classId;
    internal BigCaption bigCaption;
    internal SmallInfoText addManyStudentsInfo;
    internal Rectangle backRectange;
    internal TextBox textBox;
    internal SmallInfoText information;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    public AddManyStudentsView(int classId)
    {
      this.InitializeComponent();
      this.classId = classId;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addManyStudentCaption");
      this.information.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addNewstudentsInfo") + " " + StudentsClassCodeParser.CodeToClassCode(new int?(classId));
      this.addManyStudentsInfo.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("everyStudentInOneLine");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.CloseStudentClass_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addManyStudent");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.AddStudent_clickEvent);
    }

    private void AddStudent_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      List<string> list = ((IEnumerable<string>) this.textBox.Text.Replace("  ", " ").Replace("  ", " ").Split("\n"[0])).ToList<string>();
      List<AddManyStudentsView.NameAndSurname> nameAndSurnameList = new List<AddManyStudentsView.NameAndSurname>();
      foreach (string str in list)
      {
        string name = str.Replace("\r", "").TrimEnd(" "[0]).TrimStart(" "[0]).Replace("  ", " ").Replace(";", "").Replace(",", "").Replace(".", "").Replace(":", "");
        if (name != "")
        {
          if (name.Contains(" "))
          {
            int num = name.IndexOf(" "[0]);
            AddManyStudentsView.NameAndSurname nameAndSurname = new AddManyStudentsView.NameAndSurname(name.Substring(0, num), name.Substring(num).TrimEnd(" "[0]).TrimStart(" "[0]));
            nameAndSurnameList.Add(nameAndSurname);
          }
          else
          {
            AddManyStudentsView.NameAndSurname nameAndSurname = new AddManyStudentsView.NameAndSurname(name, "");
            nameAndSurnameList.Add(nameAndSurname);
          }
        }
      }
      try
      {
        if (nameAndSurnameList.Count > 40)
          throw new Exception(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("tooManyStudents"));
        ServerApi serverApi = new ServerApi();
        foreach (AddManyStudentsView.NameAndSurname nameAndSurname in nameAndSurnameList)
        {
          string name = nameAndSurname.Name;
          string surname = nameAndSurname.Surname;
          User user = new User()
          {
            Name = name,
            Surname = surname,
            AvatarName = "girl",
            Student_isStudent = true,
            Student_studentsClassId = new int?(this.classId),
            Student_isAcceptedToStudentsClass = new bool?(true),
            Student_isAssignedToStudentsClass = true,
            Student_login = StudentLoginGenerator.GenerateLogin(this.classId, name)
          };
          user.Student_isAcceptedToStudentsClass = new bool?(true);
          user.Student_isAssignedToStudentsClass = true;
          user.Student_explicitPassword = StudentPasswordGenerator.GeneratePass();
          user.CountryId = CurrentUserInfo.CurrentUser.CountryId;
          serverApi.RegisterNewUser(user);
        }
        this.CloseStudentClass_clickEvent();
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.Message);
      }
    }));

    private void CloseStudentClass_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/addmanystudentsview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.addManyStudentsInfo = (SmallInfoText) target;
          break;
        case 3:
          this.backRectange = (Rectangle) target;
          break;
        case 4:
          this.textBox = (TextBox) target;
          break;
        case 5:
          this.information = (SmallInfoText) target;
          break;
        case 6:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public class NameAndSurname
    {
      private string name;
      private string surname;

      public NameAndSurname(string name, string surname)
      {
        this.name = name;
        this.surname = surname;
      }

      public string Name
      {
        get => this.name;
        set => this.name = value;
      }

      public string Surname
      {
        get => this.surname;
        set => this.surname = value;
      }
    }
  }
}
