﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.LearingResultsView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.Caption;
using PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.MainTable;
using PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.UsersList;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents
{
  public partial class LearingResultsView : UserControl, IClosableUserControl, IComponentConnector
  {
    private string noElementsInfoText = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noStudents");
    public static double lastScrollOffst;
    private ResultsDataController resultsDataController;
    private List<SingleRow> rows = new List<SingleRow>();
    private List<UserInList> usersInLists = new List<UserInList>();
    private CaptionsList captionsList;
    private GenericPopUp parentPopUp;
    internal StackPanel buttonsStack;
    internal TextBlock stackText;
    internal ScrollViewer UsersScroll;
    internal StackPanel LeftStack;
    internal NoElementsInfo noElementsInfo;
    internal ScrollViewer captionScroll;
    internal Grid TopGrid;
    internal ScrollViewer mainScroll;
    internal StackPanel mainStack;
    private bool _contentLoaded;

    public LearingResultsView(
      int studentsClassID,
      StatisticInputData statisticInputData,
      ResultsDataController resultsDataController)
    {
      this.InitializeComponent();
      this.resultsDataController = resultsDataController;
      this.TopGrid.Children.Clear();
      List<User> allUsersInClass = resultsDataController.GetAllUsersInClass();
      if (allUsersInClass == null)
        return;
      User user1 = new User();
      if (allUsersInClass.Count > 0)
      {
        User sampleUser = allUsersInClass[0];
        this.captionsList = new CaptionsList((IResultsDataController) resultsDataController, statisticInputData, sampleUser);
        this.TopGrid.Children.Add((UIElement) this.captionsList);
        this.LeftStack.Children.Clear();
        int index = 0;
        foreach (User user2 in allUsersInClass)
        {
          UserInList userInList = new UserInList(user2, index);
          this.usersInLists.Add(userInList);
          this.LeftStack.Children.Add((UIElement) userInList);
          StatisticInputData statisticInputData1 = new StatisticInputData(statisticInputData, user2);
          SingleRow singleRow = new SingleRow((IResultsDataController) resultsDataController, statisticInputData1, user2, index);
          this.rows.Add(singleRow);
          this.mainStack.Children.Add((UIElement) singleRow);
          ++index;
        }
        Grid grid = new Grid();
        grid.Height = 1000.0;
        this.LeftStack.Children.Add((UIElement) grid);
        this.mainScroll.ScrollToVerticalOffset(LearingResultsView.lastScrollOffst);
      }
      else
        this.ShowNoElementsInfo();
    }

    internal string GetCSVFile()
    {
      string str = "" + this.captionsList.GetCSVFileFirstRow() + "\r\n";
      foreach (SingleRow row in this.rows)
        str = str + row.GetCSVRow() + "\r\n";
      return str + "\r\n" + this.captionsList.GetCSVFileLastRow();
    }

    internal void DisposeAllElements()
    {
      for (int index = 0; index < this.rows.Count; ++index)
      {
        this.rows[index].DisposeAllElements();
        this.rows[index] = (SingleRow) null;
      }
      for (int index = 0; index < this.usersInLists.Count; ++index)
      {
        this.usersInLists[index].DisposeAllElements();
        this.usersInLists[index] = (UserInList) null;
      }
      this.captionsList?.DisposeAllElements();
      this.captionsList = (CaptionsList) null;
      this.LeftStack.Children.Clear();
      this.TopGrid.Children.Clear();
      this.mainStack.Children.Clear();
    }

    private void BackButton_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public void SetStackCaption(string caption) => this.stackText.Text = caption;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    private void ScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
    {
      this.UsersScroll.ScrollToVerticalOffset(this.mainScroll.VerticalOffset);
      this.captionScroll.ScrollToHorizontalOffset(this.mainScroll.HorizontalOffset);
      LearingResultsView.lastScrollOffst = this.mainScroll.VerticalOffset;
    }

    internal void ShowNoElementsInfo()
    {
      this.noElementsInfo.Description = this.noElementsInfoText;
      this.noElementsInfo.Visibility = Visibility.Visible;
    }

    internal void ShowNoElementsInfo(string infoText)
    {
      this.noElementsInfoText = infoText;
      this.ShowNoElementsInfo();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/learnigresultsconponents/learingresultsview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.buttonsStack = (StackPanel) target;
          break;
        case 2:
          this.stackText = (TextBlock) target;
          break;
        case 3:
          this.UsersScroll = (ScrollViewer) target;
          break;
        case 4:
          this.LeftStack = (StackPanel) target;
          break;
        case 5:
          this.noElementsInfo = (NoElementsInfo) target;
          break;
        case 6:
          this.captionScroll = (ScrollViewer) target;
          break;
        case 7:
          this.TopGrid = (Grid) target;
          break;
        case 8:
          this.mainScroll = (ScrollViewer) target;
          this.mainScroll.ScrollChanged += new ScrollChangedEventHandler(this.ScrollViewer_ScrollChanged);
          break;
        case 9:
          this.mainStack = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
