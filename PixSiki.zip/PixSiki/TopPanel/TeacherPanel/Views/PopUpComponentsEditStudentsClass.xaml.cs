﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.EditStudentsClass
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class EditStudentsClass : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private StudentsClass studentsClass;
    private int currentYear;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel className;
    internal RoundedTextBoxAndLabel classDescription;
    internal RoundedTextBoxAndLabel classYear;
    internal RoundedTextBoxAndLabel classCode;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public EditStudentsClass(StudentsClass studentsClass)
    {
      this.InitializeComponent();
      this.studentsClass = studentsClass;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("editClass");
      this.className.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (className));
      this.className.TextInside = studentsClass.Name;
      this.classDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classDescription));
      this.classDescription.TextInside = studentsClass.Description;
      this.classYear.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classYear));
      this.classYear.TextInside = studentsClass.Yearbook.ToString() ?? "";
      this.classCode.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classCode));
      this.classCode.TextInside = studentsClass.GetClassCode();
      this.classCode.textBoxRounded.backRectange.Visibility = Visibility.Collapsed;
      this.classCode.textBoxRounded.textBox.IsReadOnly = true;
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.CloseStudentClass_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("saveClass");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.AddStudentClass_clickEvent);
      this.currentYear = DateTime.Now.Year;
    }

    private void AddStudentClass_clickEvent()
    {
      if (string.IsNullOrWhiteSpace(this.className.TextInside) || string.IsNullOrEmpty(this.className.TextInside) || (string.IsNullOrWhiteSpace(this.classYear.TextInside) || string.IsNullOrEmpty(this.classYear.TextInside)))
      {
        if (string.IsNullOrWhiteSpace(this.className.TextInside) || string.IsNullOrEmpty(this.className.TextInside))
          this.className.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classNameWarn"));
        if (!string.IsNullOrWhiteSpace(this.classYear.TextInside) && !string.IsNullOrEmpty(this.classYear.TextInside))
          return;
        this.classYear.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classYearWarn"));
      }
      else
      {
        int result;
        if (!int.TryParse(this.classYear.TextInside, out result))
        {
          this.classYear.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("invalidClassYearFormat"));
        }
        else
        {
          if (result <= this.currentYear - 2)
          {
            if (result >= this.currentYear - 100)
            {
              try
              {
                ServerApi serverApi = new ServerApi();
                this.studentsClass.Name = this.className.TextInside;
                this.studentsClass.Description = this.classDescription.TextInside;
                this.studentsClass.Yearbook = int.Parse(this.classYear.TextInside);
                StudentsClass studentsClass = this.studentsClass;
                AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
                serverApi.EditStudentsClass(studentsClass, authorize);
                this.CloseStudentClass_clickEvent();
                return;
              }
              catch (Exception ex)
              {
                CustomMessageBox.Show(ex.Message);
                return;
              }
            }
          }
          this.classYear.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("invalidClassYearRange"));
        }
      }
    }

    private void CloseStudentClass_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/editstudentsclass.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.className = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.classDescription = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.classYear = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.classCode = (RoundedTextBoxAndLabel) target;
          break;
        case 6:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
