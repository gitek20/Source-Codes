﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents.ChangeStatusExam
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.GlobalProgressBar;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents
{
  public partial class ChangeStatusExam : UserControl, IClosableUserControl, IComponentConnector
  {
    private GenericPopUp parentPopUp;
    private Exam exam;
    internal BigCaption bigCaption;
    internal SmallInfoText info;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public GenericPopUp ParentPopUp
    {
      get => this.parentPopUp;
      set => this.parentPopUp = value;
    }

    public event ClosePopUpDelegate.ClosePopUp closePopUpEvent;

    public ChangeStatusExam(Exam exam)
    {
      this.InitializeComponent();
      this.exam = exam;
      string str = !exam.IsHomework ? PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (exam)) : PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("orHomework");
      switch (exam.Status)
      {
        case HomeworkStatus.Started:
          this.bigCaption.textBlock.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("end") + " " + str;
          this.info.textBlocks.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("sureEnd") + " " + str + " " + exam.Name + " ?";
          this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("end");
          this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.StopExam_clickEvent);
          break;
        case HomeworkStatus.New:
          this.bigCaption.textBlock.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("activate") + " " + str;
          this.info.textBlocks.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("sureActivate") + " " + str + " " + exam.Name + " ?";
          this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("activate");
          this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.StartExam_clickEvent);
          break;
      }
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.Abort_clickEvent);
    }

    private void StartExam_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      ServerApi serverApi = new ServerApi();
      this.exam.ExamStartDate = new DateTime?(DateTime.Now);
      Exam exam = this.exam;
      AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
      serverApi.UpdateOrDeleteExam(exam, authorize);
      this.Abort_clickEvent();
    }));

    private void StopExam_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      ServerApi serverApi = new ServerApi();
      this.exam.ExamStopDate = new DateTime?(DateTime.Now);
      Exam exam = this.exam;
      AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
      serverApi.UpdateOrDeleteExam(exam, authorize);
      this.Abort_clickEvent();
    }));

    private void Abort_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this.parentPopUp);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/popupcomponents/changestatusexam.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.info = (SmallInfoText) target;
          break;
        case 3:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
