﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents.LeftPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.TecherPanel;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents
{
  public partial class LeftPanel : UserControl, IComponentConnector
  {
    private List<LeftListItem> items = new List<LeftListItem>();
    internal Grid backGrid;
    internal Rectangle selectionRectangle;
    internal Label labelText;
    internal StackPanel mainStack;
    private bool _contentLoaded;

    public LeftPanel()
    {
      this.InitializeComponent();
      this.labelText.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
    }

    internal void Clear()
    {
      this.mainStack.Children.Clear();
      this.items.Clear();
      this.SetVisibilityOfBackButton(true);
    }

    public LeftListItem SelectedItem
    {
      get
      {
        foreach (LeftListItem leftListItem in this.items)
        {
          if (leftListItem.IsSelected)
            return leftListItem;
        }
        return (LeftListItem) null;
      }
    }

    internal void AddToStack(LeftListItem item)
    {
      this.mainStack.Children.Add((UIElement) item);
      this.items.Add(item);
      item.selectionEvent += new LeftListItem.OnSelection(this.Item_selectionEvent);
    }

    public event LeftPanel.SelectionChanged selectionChangedEvent;

    private void Item_selectionEvent(LeftListItem listItem)
    {
      foreach (LeftListItem leftListItem in this.items)
      {
        if (leftListItem != listItem)
          leftListItem.IsSelected = false;
      }
      if (this.selectionChangedEvent == null)
        return;
      this.selectionChangedEvent();
    }

    private void Rectangle_MouseEnter(object sender, MouseEventArgs e) => this.selectionRectangle.Visibility = Visibility.Visible;

    private void Rectangle_MouseLeave(object sender, MouseEventArgs e) => this.selectionRectangle.Visibility = Visibility.Collapsed;

    public void SetVisibilityOfBackButton(bool isVisible)
    {
      if (isVisible)
        this.backGrid.Visibility = Visibility.Visible;
      else
        this.backGrid.Visibility = Visibility.Collapsed;
    }

    public event LeftPanel.BackButtonClicked backButtonClickedEvent;

    private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.backButtonClickedEvent == null)
        return;
      this.backButtonClickedEvent();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/leftpanelcomponents/leftpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.backGrid = (Grid) target;
          break;
        case 2:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Rectangle_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Rectangle_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Rectangle_MouseDown);
          break;
        case 3:
          this.selectionRectangle = (Rectangle) target;
          break;
        case 4:
          this.labelText = (Label) target;
          break;
        case 5:
          this.mainStack = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void SelectionChanged();

    public delegate void BackButtonClicked();
  }
}
