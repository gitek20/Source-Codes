﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.MainPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents
{
  public partial class MainPanel : UserControl, IComponentConnector
  {
    private List<ISearchableItem> itemsInList = new List<ISearchableItem>();
    private string noElementsInfoText = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noElementsInList");
    private RefreshEvent refreshEvent;
    internal Grid searchGrid;
    internal SearchTextBox searchTextBox;
    internal NoElementsInfo noElementsInfo;
    internal Grid mainGrid;
    internal ScrollViewer scrollViewer;
    internal StackPanel stackPanel;
    internal StackPanel stackPanelForNoAcceptStudents;
    private bool _contentLoaded;

    public MainPanel()
    {
      this.InitializeComponent();
      this.searchTextBox.onTextChanged += new Action<string>(this.SearchTextBox_textChangedEvent);
    }

    public MainPanel(RefreshEvent refreshEvent)
    {
      this.InitializeComponent();
      this.searchTextBox.onTextChanged += new Action<string>(this.SearchTextBox_textChangedEvent);
      this.refreshEvent = refreshEvent;
    }

    private void SearchTextBox_textChangedEvent(string text)
    {
      foreach (ISearchableItem itemsIn in this.itemsInList)
        itemsIn.ShowIfContainsText(text);
    }

    internal void Clear()
    {
      this.refreshEvent.InvokeRefreshEvent();
      this.stackPanel.Children.Clear();
      this.stackPanelForNoAcceptStudents.Children.Clear();
      this.searchGrid.Visibility = Visibility.Collapsed;
      this.noElementsInfo.Visibility = Visibility.Collapsed;
      this.mainGrid.Children.Clear();
      this.itemsInList.Clear();
      this.searchTextBox.TextInside = "";
    }

    internal void SetView(UserControl userControl)
    {
      this.stackPanel.Children.Clear();
      this.stackPanelForNoAcceptStudents.Children.Clear();
      this.mainGrid.Children.Clear();
      this.mainGrid.Children.Add((UIElement) userControl);
      this.itemsInList.Clear();
      this.scrollViewer.Visibility = Visibility.Collapsed;
      this.searchGrid.Visibility = Visibility.Collapsed;
    }

    internal void AddToList(ListItemHomework inItemHomework)
    {
      this.mainGrid.Children.Clear();
      this.stackPanel.Children.Add((UIElement) inItemHomework);
      this.itemsInList.Add((ISearchableItem) inItemHomework);
      this.scrollViewer.Visibility = Visibility.Visible;
      this.stackPanel.Visibility = Visibility.Visible;
      this.searchGrid.Visibility = Visibility.Visible;
      this.searchTextBox.TextInside = "";
    }

    internal void AddToList(InListGenericItem inListGenericItem)
    {
      this.mainGrid.Children.Clear();
      this.stackPanel.Children.Add((UIElement) inListGenericItem);
      this.itemsInList.Add((ISearchableItem) inListGenericItem);
      this.scrollViewer.Visibility = Visibility.Visible;
      this.stackPanel.Visibility = Visibility.Visible;
      this.searchGrid.Visibility = Visibility.Visible;
      this.searchTextBox.TextInside = "";
    }

    internal void AddToList(FiltrInList filtr) => this.stackPanel.Children.Add((UIElement) filtr);

    internal void AddToList(InListGenericItem inListGenericItem, bool isAcceptedStudent)
    {
      this.mainGrid.Children.Clear();
      this.scrollViewer.Visibility = Visibility.Visible;
      this.itemsInList.Add((ISearchableItem) inListGenericItem);
      if (isAcceptedStudent)
      {
        this.stackPanel.Children.Add((UIElement) inListGenericItem);
      }
      else
      {
        inListGenericItem.textBlockNameBlue.Text += PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("waitingForAcceptance");
        this.stackPanelForNoAcceptStudents.Children.Add((UIElement) inListGenericItem);
        this.stackPanel.Visibility = Visibility.Visible;
      }
      this.searchGrid.Visibility = Visibility.Visible;
      this.searchTextBox.TextInside = "";
    }

    public void SetSearchBoxPlaceholderText(string text) => this.searchTextBox.Placeholder = text;

    internal void ShowNoElementsInfo()
    {
      this.noElementsInfo.Description = this.noElementsInfoText;
      this.noElementsInfo.Visibility = Visibility.Visible;
    }

    internal void ShowNoElementsInfo(string infoText)
    {
      this.noElementsInfoText = infoText;
      this.ShowNoElementsInfo();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/views/mainpanelcomponents/mainpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.searchGrid = (Grid) target;
          break;
        case 2:
          this.searchTextBox = (SearchTextBox) target;
          break;
        case 3:
          this.noElementsInfo = (NoElementsInfo) target;
          break;
        case 4:
          this.mainGrid = (Grid) target;
          break;
        case 5:
          this.scrollViewer = (ScrollViewer) target;
          break;
        case 6:
          this.stackPanel = (StackPanel) target;
          break;
        case 7:
          this.stackPanelForNoAcceptStudents = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
