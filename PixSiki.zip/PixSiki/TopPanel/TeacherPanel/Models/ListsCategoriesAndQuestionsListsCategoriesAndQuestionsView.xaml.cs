﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.ListsCategoriesAndQuestionsView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions
{
  public partial class ListsCategoriesAndQuestionsView : UserControl, IMainListQuestions, IComponentConnector
  {
    private List<ICategoryData> mainCategories = new List<ICategoryData>();
    private List<ICategoryData> mainLessons = new List<ICategoryData>();
    private List<IQuestionData> mainQuestions = new List<IQuestionData>();
    public List<IQuestionData> mainSelectedQuestions = new List<IQuestionData>();
    public List<SingleSelectedQuestion> singleSelectedQuestionList = new List<SingleSelectedQuestion>();
    private List<ExamQuestion> questionsDB = new List<ExamQuestion>();
    private Exam exam;
    private ServerApi serverApi = new ServerApi();
    internal Grid mainGrid;
    internal ColumnDefinition rowSelectedQuestions;
    internal StackPanel Category;
    internal Label col2Title;
    internal Grid categoryList;
    internal StackPanel mainView;
    internal TextBlock examDisableText;
    internal Label col1Title;
    internal TextBlock emptySelectedQuestions;
    internal Grid GridSelectedQuestion;
    internal StackPanel selectedTasksList;
    private bool _contentLoaded;

    public ListsCategoriesAndQuestionsView(Exam exam)
    {
      this.InitializeComponent();
      this.exam = exam;
      this.CheckSelectedQuestionsFromDB();
      this.AllCourseGenerate();
      this.CheckEmptyListQuestions();
      this.CheckStatusExam(exam);
    }

    private void SaveExam_ClickEvent()
    {
      List<ExamQuestion> questionsToDB = new List<ExamQuestion>();
      ExamQuestion examQuestion = new ExamQuestion();
      foreach (IQuestionData selectedQuestion in this.mainSelectedQuestions)
        questionsToDB.Add(new ExamQuestion()
        {
          ExamId = this.exam.Id,
          QuestionGuid = selectedQuestion.QuestionGuid(),
          IsDeleted = false,
          RemoveDate = new DateTime?()
        });
      GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
      {
        new ServerApi().AddOrUpdateQuestionsInExam(questionsToDB, new AuthorizeData(CurrentUserInfo.CurrentUser));
        CustomMessageBox.Show("Pomyślnie zapisano zadania");
      }));
    }

    public void AllCourseGenerate()
    {
      this.mainView.Children.Clear();
      if (this.mainCategories.Count < 1)
        this.mainCategories = BuiltInCoursesInstance.Instance.GetAllMainCategories();
      foreach (ICategoryData mainCategory in this.mainCategories)
      {
        if (!(mainCategory as QuestionCategory).IsMyCreation())
          this.mainView.Children.Add((UIElement) new SingleCategory(mainCategory, (IMainListQuestions) this));
      }
    }

    public void CheckSelectedQuestionsFromDB() => this.questionsDB = new ServerApi().GetAllQuestionsInExam(this.exam, new AuthorizeData(CurrentUserInfo.CurrentUser));

    public void RefreshStackPanel()
    {
      this.selectedTasksList.Children.Clear();
      foreach (UIElement selectedQuestion in this.singleSelectedQuestionList)
        this.selectedTasksList.Children.Add(selectedQuestion);
      this.CheckEmptyListQuestions();
    }

    private bool AddQuestiionsToDB(IQuestionData questionData)
    {
      ExamQuestion examQuestion = new ExamQuestion();
      examQuestion.ExamId = this.exam.Id;
      examQuestion.QuestionGuid = questionData.QuestionGuid();
      examQuestion.IsDeleted = false;
      examQuestion.RemoveDate = new DateTime?();
      try
      {
        return this.serverApi.AddQuestionInExam(examQuestion, new AuthorizeData(CurrentUserInfo.CurrentUser));
      }
      catch
      {
        return false;
      }
    }

    public void AddQuestion(
      IQuestionData questionData,
      SingleSelectedQuestion singleSelectedQuestion,
      bool addToDB)
    {
      bool flag = true;
      if (addToDB)
      {
        if (!this.AddQuestiionsToDB(questionData))
          flag = false;
        else
          Console.WriteLine("OK add question");
      }
      if (flag)
      {
        this.mainSelectedQuestions.Add(questionData);
        this.selectedTasksList.Children.Add((UIElement) singleSelectedQuestion);
        this.singleSelectedQuestionList.Add(singleSelectedQuestion);
        this.CheckEmptyListQuestions();
      }
      else
        CustomMessageBox.Show("Error add question to DB.");
    }

    public bool RemoveQuestionFromDBAsync(IQuestionData questionData)
    {
      ExamQuestion examQuestion = new ExamQuestion();
      examQuestion.ExamId = this.exam.Id;
      examQuestion.QuestionGuid = questionData.QuestionGuid();
      examQuestion.IsDeleted = false;
      examQuestion.RemoveDate = new DateTime?();
      try
      {
        return this.serverApi.DeleteQuestionInExam(examQuestion, new AuthorizeData(CurrentUserInfo.CurrentUser));
      }
      catch
      {
        return false;
      }
    }

    public void RemoveQuestion(
      IQuestionData questionData,
      SingleSelectedQuestion singleSelectedQuestion)
    {
      GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
      {
        if (this.RemoveQuestionFromDBAsync(questionData))
        {
          this.mainSelectedQuestions.Remove(questionData);
          this.singleSelectedQuestionList.Remove(singleSelectedQuestion);
          this.RefreshStackPanel();
          this.CheckEmptyListQuestions();
          Console.WriteLine("OK Remove question");
        }
        else
          CustomMessageBox.Show("Error delete question from DB");
      }));
    }

    public bool CheckCheckedQuestions(IQuestionData questionData) => this.questionsDB.Find((Predicate<ExamQuestion>) (x => x.QuestionGuid == questionData.QuestionGuid())) != null;

    public void CheckEmptyListQuestions()
    {
      if (this.singleSelectedQuestionList.Count == 0)
        this.emptySelectedQuestions.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noQuestions");
      else
        this.emptySelectedQuestions.Text = "";
    }

    public void CheckStatusExam(Exam exam)
    {
      if (exam.IsHomework)
      {
        this.col1Title.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("questionsList");
        this.col2Title.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("selectQuestions");
      }
      else
      {
        this.col1Title.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("questionsListExam");
        this.col2Title.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("selectQuestionsExam");
      }
      if (exam.Status == HomeworkStatus.Started)
      {
        this.Category.Visibility = Visibility.Collapsed;
        this.categoryList.Visibility = Visibility.Collapsed;
        this.examDisableText.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("homeworkBlock");
        this.examDisableText.Visibility = Visibility.Visible;
        this.categoryList.IsEnabled = false;
        this.rowSelectedQuestions.Width = new GridLength(100.0, GridUnitType.Star);
        this.GridSelectedQuestion.Margin = new Thickness(20.0, 145.0, 20.0, 10.0);
      }
      else
      {
        if (exam.Status != HomeworkStatus.Closed && exam.Status != HomeworkStatus.Archived)
          return;
        this.categoryList.IsEnabled = false;
        this.categoryList.Cursor = Cursors.No;
      }
    }

    private bool CheckExamStatusForSelectedQuestions() => this.exam.Status == HomeworkStatus.New;

    public bool IsNewExam => this.CheckExamStatusForSelectedQuestions();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/models/listscategoriesandquestions/listscategoriesandquestionsview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.rowSelectedQuestions = (ColumnDefinition) target;
          break;
        case 3:
          this.Category = (StackPanel) target;
          break;
        case 4:
          this.col2Title = (Label) target;
          break;
        case 5:
          this.categoryList = (Grid) target;
          break;
        case 6:
          this.mainView = (StackPanel) target;
          break;
        case 7:
          this.examDisableText = (TextBlock) target;
          break;
        case 8:
          this.col1Title = (Label) target;
          break;
        case 9:
          this.emptySelectedQuestions = (TextBlock) target;
          break;
        case 10:
          this.GridSelectedQuestion = (Grid) target;
          break;
        case 11:
          this.selectedTasksList = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
