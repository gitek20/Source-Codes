﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.LearningResultsPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.TecherPanel;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers
{
  internal class LearningResultsPanel : ISubPanelOnStackController
  {
    private ITeacherPanelController mainTeacherPanel;
    private int studentsClassID;
    private StatisticInputData statisticInputData;
    private LeftListItem learningResults;

    public LearningResultsPanel(
      int studentsClassID,
      StatisticInputData statisticInputData,
      ITeacherPanelController mainTeacherPanel)
    {
      this.studentsClassID = studentsClassID;
      this.statisticInputData = statisticInputData;
      this.mainTeacherPanel = mainTeacherPanel;
      StudentsClass studentsClassById = new ServerApi().GetStudentsClassById(studentsClassID, new AuthorizeData(CurrentUserInfo.CurrentUser));
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) new RoundedButton()
      {
        Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("refresh")
      });
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) new RoundedButton()
      {
        Description = "Esportuj PDF"
      });
      mainTeacherPanel.ActionPanel.SetCaption("Klasa " + studentsClassById.Name + " > Kursy > Wyniki nauki");
      TopStackItem topStackItem = new TopStackItem((ISubPanelOnStackController) this);
      mainTeacherPanel.TopStackPanel.AddToStackPanel(topStackItem);
      this.learningResults = new LeftListItem();
      this.learningResults.Description = "Wyniki nauki";
      this.learningResults.IsSelected = true;
      this.RefreshView();
      mainTeacherPanel.LeftPanel.selectionChangedEvent += new LeftPanel.SelectionChanged(this.LeftPanel_selectionChangedEvent);
    }

    private void LeftPanel_selectionChangedEvent() => this.ShowSelectedView();

    public string Description
    {
      get
      {
        if (this.statisticInputData.DataType == StatisticRowDataType.AllCourses)
          return "Kursy";
        if (this.statisticInputData.DataType == StatisticRowDataType.Course)
          return "Kurs ??";
        return this.statisticInputData.DataType == StatisticRowDataType.LessonInCourse ? "Lekcja ??" : "NULL";
      }
    }

    public event DescriptionChange DescriptionChangeEvent;

    public void RefreshView()
    {
      this.mainTeacherPanel.LeftPanel.Clear();
      this.mainTeacherPanel.LeftPanel.AddToStack(this.learningResults);
      this.ShowSelectedView();
      if (this.DescriptionChangeEvent == null)
        return;
      this.DescriptionChangeEvent();
    }

    public void DisposeView()
    {
    }

    private void ShowSelectedView()
    {
      if (this.mainTeacherPanel.LeftPanel.SelectedItem != this.learningResults)
        return;
      this.mainTeacherPanel.MainPanel.Clear();
    }
  }
}
