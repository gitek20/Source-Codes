﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.ExamPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.TopPanel.Components.TecherPanel;
using PixBlocks.TopPanel.Components.TecherPanel.Icons;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements;
using PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components;
using System;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers
{
  internal class ExamPanel : ISubPanelOnStackController
  {
    private Exam exam;
    private ITeacherPanelController mainTeacherPanel;
    private LeftListItem homeworkData;
    private LeftListItem homeworksList;
    private LeftListItem lastSelectedItem;

    public ExamPanel(Exam exam, ITeacherPanelController mainTeacherPanel)
    {
      this.exam = exam;
      this.mainTeacherPanel = mainTeacherPanel;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.LeftPanel.Clear();
      this.homeworksList = new LeftListItem((UserControl) new Questions());
      this.homeworksList.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("questionList");
      this.homeworkData = new LeftListItem((UserControl) new EditData());
      this.homeworkData.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("edit");
      this.homeworkData.IsSelected = true;
      TopStackItem topStackItem = new TopStackItem((ISubPanelOnStackController) this);
      mainTeacherPanel.TopStackPanel.AddToStackPanel(topStackItem);
      this.RefreshView();
      mainTeacherPanel.LeftPanel.selectionChangedEvent += new LeftPanel.SelectionChanged(this.LeftPanel_selectionChangedEvent);
    }

    private void LeftPanel_selectionChangedEvent() => this.ShowSelectedView();

    public string Description => this.exam.Name ?? "";

    public event DescriptionChange DescriptionChangeEvent;

    public void RefreshView()
    {
      this.mainTeacherPanel.LeftPanel.Clear();
      this.mainTeacherPanel.LeftPanel.AddToStack(this.homeworksList);
      this.mainTeacherPanel.LeftPanel.AddToStack(this.homeworkData);
      this.ShowSelectedView();
      DescriptionChange descriptionChangeEvent = this.DescriptionChangeEvent;
      if (descriptionChangeEvent == null)
        return;
      descriptionChangeEvent();
    }

    public void DisposeView()
    {
    }

    private void ShowSelectedView()
    {
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.homeworkData)
        GlobalProgressBarManager.RunFuncionAndProgressBar(new Action(this.ShowHomeworkData));
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.homeworksList && this.homeworksList != this.lastSelectedItem)
        GlobalProgressBarManager.RunFuncionAndProgressBar(new Action(this.ShowHomeworkTasksList));
      this.lastSelectedItem = this.mainTeacherPanel.LeftPanel.SelectedItem;
    }

    private void ShowHomeworkData()
    {
      HomeworkDataController homeworkDataController = new HomeworkDataController(this.exam, this.mainTeacherPanel);
    }

    private void ShowHomeworkTasksList()
    {
      HomeworkListController homeworkListController = new HomeworkListController(this.exam, this.mainTeacherPanel);
    }
  }
}
