﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements.HomeworkListController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using System;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements
{
  public class HomeworkListController
  {
    private Exam exam;
    private ITeacherPanelController mainTeacherPanel;

    public HomeworkListController(Exam exam, ITeacherPanelController mainTeacherPanel)
    {
      this.exam = exam;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      ExamTasksListView examTasksListView = new ExamTasksListView(exam);
      mainTeacherPanel.MainPanel.SetView((UserControl) examTasksListView);
    }

    private void AddStudentToClass_clickEvent()
    {
      try
      {
        ServerApi serverApi = new ServerApi();
        this.mainTeacherPanel.TopStackPanel.GoBack();
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.Message);
      }
    }
  }
}
