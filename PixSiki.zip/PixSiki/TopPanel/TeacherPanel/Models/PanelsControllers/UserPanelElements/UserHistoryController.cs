﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements.UserHistoryController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements
{
  internal class UserHistoryController
  {
    private StudentsClass studentsClass;
    private User user;
    private ITeacherPanelController mainTecherPanel;

    public UserHistoryController(
      StudentsClass studentsClass,
      User user,
      ITeacherPanelController mainTecherPanel)
    {
      this.studentsClass = studentsClass;
      this.user = user;
      this.mainTecherPanel = mainTecherPanel;
      mainTecherPanel.MainPanel.Clear();
      mainTecherPanel.ActionPanel.Clear();
      mainTecherPanel.ActionPanel.SetCaption(studentsClass.Name + " > " + user.Name + " " + user.Surname + " > " + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("userHistory"));
      this.ShowUserHistory();
    }

    private void ShowUserHistory() => this.mainTecherPanel.MainPanel.SetView((UserControl) new UserHistoryView(this.user));
  }
}
