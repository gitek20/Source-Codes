﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements.HomeworkDataController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements
{
  public class HomeworkDataController
  {
    private Exam exam;
    private ITeacherPanelController mainTeacherPanel;

    public HomeworkDataController(Exam exam, ITeacherPanelController mainTeacherPanel)
    {
      this.exam = exam;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      bool flag1 = false;
      bool flag2 = false;
      RoundedButton roundedButton1 = new RoundedButton();
      roundedButton1.SetColor(RoundedButton.ColorType.white);
      switch (exam.Status)
      {
        case HomeworkStatus.Deleted:
          if (exam.IsDeleted)
          {
            roundedButton1.Visibility = Visibility.Hidden;
            break;
          }
          break;
        case HomeworkStatus.Archived:
          flag2 = false;
          break;
        case HomeworkStatus.Closed:
          roundedButton1.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("archive");
          roundedButton1.SetImage(RoundedButton.IcoType.Archive);
          roundedButton1.clickEvent += new RoundedButton.ClickDelegate(this.ArchiveExam_clickEvent);
          flag2 = false;
          break;
        case HomeworkStatus.Started:
          roundedButton1.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("end");
          roundedButton1.SetImage(RoundedButton.IcoType.Stop);
          roundedButton1.clickEvent += new RoundedButton.ClickDelegate(this.CloseExam_clickEvent);
          flag2 = true;
          break;
        case HomeworkStatus.New:
          roundedButton1.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("begin");
          roundedButton1.SetImage(RoundedButton.IcoType.Visibly);
          roundedButton1.clickEvent += new RoundedButton.ClickDelegate(this.StartExam_clickEvent);
          flag1 = true;
          flag2 = true;
          break;
      }
      if (flag2)
        mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton1);
      RoundedButton roundedButton2 = new RoundedButton();
      roundedButton2.Description = !exam.IsHomework ? PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("editExam") : PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("editHomework");
      roundedButton2.SetColor(RoundedButton.ColorType.white);
      roundedButton2.SetImage(RoundedButton.IcoType.Edit);
      roundedButton2.clickEvent += new RoundedButton.ClickDelegate(this.EditExam_clickEvent);
      if (flag1)
        mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton2);
      RoundedButton roundedButton3 = new RoundedButton();
      roundedButton3.Description = !exam.IsHomework ? PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("deleteExam") : PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("deleteHomework");
      roundedButton3.clickEvent += new RoundedButton.ClickDelegate(this.DeleteExam_clickEvent);
      roundedButton3.SetColor(RoundedButton.ColorType.white);
      roundedButton3.SetImage(RoundedButton.IcoType.Delete);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton3);
      ExamView examView = new ExamView(exam);
      mainTeacherPanel.MainPanel.SetView((UserControl) examView);
    }

    private void ArchiveExam_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new ArchiveHomeworkView(this.exam, this.mainTeacherPanel.TopStackPanel.GoBack), false, false);

    private void CloseExam_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new ChangeStatusExam(this.exam), false, false);

    private void StartExam_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      if (new ServerApi().GetAllQuestionsInExam(this.exam, new AuthorizeData(CurrentUserInfo.CurrentUser)).Count<ExamQuestion>() > 0)
        this.mainTeacherPanel.ShowPopupWindow((UserControl) new ChangeStatusExam(this.exam), false, false);
      else
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("minimumIs1"));
    }));

    private void EditExam_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new EditExamView(this.exam), false, false);

    private void DeleteExam_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new DeleteExamView(this.exam, this.mainTeacherPanel.TopStackPanel.GoBack), false, false);
  }
}
