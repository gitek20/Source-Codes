﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements.UserDataController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements
{
  internal class UserDataController
  {
    private User user;
    private StudentsClass studentsClass;
    private ITeacherPanelController mainTeacherPanel;

    public UserDataController(
      StudentsClass studentsClass,
      User user,
      ITeacherPanelController mainTeacherPanel)
    {
      this.studentsClass = studentsClass;
      this.user = user;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption(studentsClass.Name + " > " + user.Name + " " + user.Surname + " > Edycja ucznia");
      if (user.Student_isAcceptedToStudentsClass.Value)
      {
        RoundedButton roundedButton1 = new RoundedButton();
        roundedButton1.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("loginOnStudentAccount");
        roundedButton1.SetImage(RoundedButton.IcoType.Visibly);
        roundedButton1.SetColor(RoundedButton.ColorType.white);
        roundedButton1.clickEvent += new RoundedButton.ClickDelegate(this.loginOnStudentAccountInNewWindow_ClickEvent);
        mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton1);
        RoundedButton roundedButton2 = new RoundedButton();
        roundedButton2.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("editStudent");
        roundedButton2.SetColor(RoundedButton.ColorType.white);
        roundedButton2.SetImage(RoundedButton.IcoType.Edit);
        mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton2);
        roundedButton2.clickEvent += new RoundedButton.ClickDelegate(this.EditStudent_clickEvent);
      }
      if (!user.Student_isAcceptedToStudentsClass.Value)
      {
        RoundedButton roundedButton = new RoundedButton();
        roundedButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addStudent");
        roundedButton.clickEvent += new RoundedButton.ClickDelegate(this.AddStudentToClass_clickEvent);
        roundedButton.SetColor(RoundedButton.ColorType.white);
        roundedButton.SetImage(RoundedButton.IcoType.AddStudent);
        mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton);
      }
      RoundedButton roundedButton3 = new RoundedButton();
      roundedButton3.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("deleteStudent");
      roundedButton3.clickEvent += new RoundedButton.ClickDelegate(this.DeleteStudent_clickEvent);
      roundedButton3.SetColor(RoundedButton.ColorType.white);
      roundedButton3.SetImage(RoundedButton.IcoType.Delete);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton3);
      StudentView studentView = new StudentView(user);
      mainTeacherPanel.MainPanel.SetView((UserControl) studentView);
    }

    private void ConnectToChampionship_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new ConnectToChampionship(CurrentUserInfo.CurrenChampionship, this.user, this.studentsClass), false, false);

    [DllImport("user32.dll")]
    private static extern bool SetWindowText(IntPtr hWnd, string text);

    [DllImport("user32.dll")]
    private static extern IntPtr FindWindow(string windowClass, string windowName);

    private void loginOnStudentAccountInNewWindow_ClickEvent()
    {
      string str = Environment.CurrentDirectory + "\\" + Assembly.GetExecutingAssembly().GetName().Name;
      Process process = new Process();
      try
      {
        process.StartInfo.FileName = str;
        process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
        process.StartInfo.Arguments = !this.user.Email.IsNullOrEmpty() ? this.user.Email + " " + this.user.Md5Password : this.user.Student_login + " " + this.user.Student_explicitPassword;
        process.Start();
        Thread.Sleep(1000);
        UserDataController.SetWindowText(process.MainWindowHandle, this.user.Name + " " + this.user.Surname);
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.ToString());
      }
    }

    private void AddStudentToClass_clickEvent()
    {
      try
      {
        ServerApi serverApi = new ServerApi();
        this.user.Student_isAcceptedToStudentsClass = new bool?(true);
        User user = this.user;
        AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
        serverApi.UpdateOrDeleteUser(user, authorize);
        this.mainTeacherPanel.TopStackPanel.GoBack();
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.Message);
      }
    }

    private void EditStudent_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new EditStudentView(this.user), false, false);

    private void DeleteStudent_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new DeleteStudent(this.user, this.mainTeacherPanel.TopStackPanel.GoBack), false, false);
  }
}
