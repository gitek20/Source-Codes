﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements.TeachResultsController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements
{
  internal class TeachResultsController
  {
    private User user;
    private StudentsClass studentsClass;
    private ITeacherPanelController mainTeacherPanel;

    public TeachResultsController(
      StudentsClass studentsClass,
      User user,
      ITeacherPanelController mainTeacherPanel)
    {
      this.studentsClass = studentsClass;
      this.user = user;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption(studentsClass.Name + " > " + user.Name + " " + user.Surname + " > Wyniki nauki");
    }
  }
}
