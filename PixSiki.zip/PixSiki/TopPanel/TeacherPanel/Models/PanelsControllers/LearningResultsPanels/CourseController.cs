﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.LearningResultsPanels.CourseController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.TecherPanel;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.LearningResultsPanels
{
  internal class CourseController : ISubPanelOnStackController
  {
    private StudentsClass studentsClass;
    private ITeacherPanelController mainTeacherPanel;
    private string uniqueCourseGuid;

    public CourseController(
      StudentsClass studentsClass,
      ITeacherPanelController mainTeacherPanel,
      string uniqueCourseGuid)
    {
      this.uniqueCourseGuid = uniqueCourseGuid;
      this.studentsClass = studentsClass;
      this.mainTeacherPanel = mainTeacherPanel;
      ServerApi serverApi = new ServerApi();
      TopStackItem topStackItem = new TopStackItem((ISubPanelOnStackController) this);
      mainTeacherPanel.TopStackPanel.AddToStackPanel(topStackItem);
      LeftListItem leftListItem = new LeftListItem();
      leftListItem.Description = "Kurs ?";
      mainTeacherPanel.LeftPanel.Clear();
      mainTeacherPanel.LeftPanel.AddToStack(leftListItem);
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption("Klasa " + studentsClass.Name + " > Kursy");
      this.RefreshView();
    }

    private void TeachingResults_clickEvent() => this.mainTeacherPanel.SetLearningResultPanel(this.studentsClass.Id.Value, new StatisticInputData(StatisticRowDataType.Course)
    {
      CategoryGuid = this.uniqueCourseGuid
    });

    public string Description => "Kurs ?";

    public event DescriptionChange DescriptionChangeEvent;

    public void RefreshView()
    {
      RoundedButton roundedButton = new RoundedButton();
      roundedButton.Description = "Wyniki kursu";
      roundedButton.clickEvent += new RoundedButton.ClickDelegate(this.TeachingResults_clickEvent);
      this.mainTeacherPanel.ActionPanel.Clear();
      this.mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton);
      this.mainTeacherPanel.MainPanel.Clear();
      foreach (IListItem listItem in BuiltInCoursesInstance.Instance.GetAllLessonInCategory(this.uniqueCourseGuid))
        this.mainTeacherPanel.MainPanel.AddToList(new InListGenericItem(listItem));
      if (this.DescriptionChangeEvent == null)
        return;
      this.DescriptionChangeEvent();
    }

    public void DisposeView()
    {
    }
  }
}
