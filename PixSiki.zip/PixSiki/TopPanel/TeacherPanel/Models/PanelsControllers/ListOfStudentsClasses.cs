﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.ListOfStudentsClasses
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.TecherPanel;
using PixBlocks.TopPanel.Components.TecherPanel.Icons;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.ListOfStudentsClassesElements;
using PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components;
using System;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers
{
  internal class ListOfStudentsClasses : ISubPanelOnStackController
  {
    private int teacherID;
    private ITeacherPanelController mainTeacherPanel;
    private LeftListItem activeClasses;
    private LeftListItem arhiveClasses;

    public ListOfStudentsClasses(int teacherID, ITeacherPanelController mainTeacherPanel)
    {
      this.teacherID = teacherID;
      this.mainTeacherPanel = mainTeacherPanel;
      TopStackItem topStackItem = new TopStackItem((ISubPanelOnStackController) this);
      mainTeacherPanel.TopStackPanel.AddToStackPanel(topStackItem);
      this.activeClasses = new LeftListItem((UserControl) new ActiveClasses());
      this.activeClasses.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (activeClasses));
      this.activeClasses.IsSelected = true;
      this.RefreshView();
      mainTeacherPanel.LeftPanel.selectionChangedEvent += new LeftPanel.SelectionChanged(this.LeftPanel_selectionChangedEvent);
    }

    private void LeftPanel_selectionChangedEvent() => this.ShowSelectedView();

    public string Description => PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classes");

    public event DescriptionChange DescriptionChangeEvent;

    public void RefreshView()
    {
      this.mainTeacherPanel.LeftPanel.Clear();
      this.mainTeacherPanel.LeftPanel.AddToStack(this.activeClasses);
      this.mainTeacherPanel.LeftPanel.SetVisibilityOfBackButton(false);
      this.ShowSelectedView();
      if (this.DescriptionChangeEvent == null)
        return;
      this.DescriptionChangeEvent();
    }

    public void DisposeView()
    {
    }

    private void ShowSelectedView()
    {
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.activeClasses)
      {
        ActiveClassesController classesController;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => classesController = new ActiveClassesController(this.teacherID, this.mainTeacherPanel)));
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem != this.arhiveClasses)
        return;
      ArchiveClassesController classesController1;
      GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => classesController1 = new ArchiveClassesController(this.teacherID, this.mainTeacherPanel)));
    }
  }
}
