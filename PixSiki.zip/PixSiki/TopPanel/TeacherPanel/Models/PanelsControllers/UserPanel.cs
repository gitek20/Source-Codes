﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.Components.TecherPanel;
using PixBlocks.TopPanel.Components.TecherPanel.Icons;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements;
using PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.UserPanelElements;
using PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components;
using System;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers
{
  internal class UserPanel : ISubPanelOnStackController
  {
    private User user;
    private StudentsClass studentsClass;
    private ITeacherPanelController mainTeacherPanel;
    private LeftListItem userData;
    private LeftListItem results;
    private LeftListItem userHistory;
    private LeftListItem lastSelectedItem;

    public UserPanel(
      StudentsClass studentsClass,
      User user,
      ITeacherPanelController mainTeacherPanel)
    {
      this.studentsClass = studentsClass;
      this.user = user;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.LeftPanel.Clear();
      this.results = new LeftListItem((UserControl) new TeachingResults());
      this.results.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("learningResoults");
      this.userData = new LeftListItem((UserControl) new EditData());
      this.userData.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("studentData");
      this.userHistory = new LeftListItem((UserControl) new ArchiveClasses());
      this.userHistory.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (userHistory));
      this.userData.IsSelected = true;
      TopStackItem topStackItem = new TopStackItem((ISubPanelOnStackController) this);
      mainTeacherPanel.TopStackPanel.AddToStackPanel(topStackItem);
      this.RefreshView();
      mainTeacherPanel.LeftPanel.selectionChangedEvent += new LeftPanel.SelectionChanged(this.LeftPanel_selectionChangedEvent);
    }

    private void LeftPanel_selectionChangedEvent() => this.ShowSelectedView();

    public string Description => this.user.Name + " " + this.user.Surname;

    public event DescriptionChange DescriptionChangeEvent;

    public void RefreshView()
    {
      this.mainTeacherPanel.LeftPanel.Clear();
      if (this.user.Student_isAcceptedToStudentsClass.Value)
        this.mainTeacherPanel.LeftPanel.AddToStack(this.results);
      this.mainTeacherPanel.LeftPanel.AddToStack(this.userData);
      this.ShowSelectedView();
      if (this.DescriptionChangeEvent == null)
        return;
      this.DescriptionChangeEvent();
    }

    public void DisposeView()
    {
    }

    private void ShowSelectedView()
    {
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.userData)
      {
        UserDataController userDataController;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => userDataController = new UserDataController(this.studentsClass, this.user, this.mainTeacherPanel)));
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.results && this.results != this.lastSelectedItem)
      {
        TeachingResultsSelectController selectController;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => selectController = new TeachingResultsSelectController(this.studentsClass, this.user, this.mainTeacherPanel)));
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.userHistory && this.userHistory != this.lastSelectedItem)
      {
        UserHistoryController historyController = new UserHistoryController(this.studentsClass, this.user, this.mainTeacherPanel);
      }
      this.lastSelectedItem = this.mainTeacherPanel.LeftPanel.SelectedItem;
    }
  }
}
