﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.ListOfStudentsClassesElements.ActiveClassesController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.ListOfStudentsClassesElements
{
  internal class ActiveClassesController
  {
    private int teacherID;
    private ITeacherPanelController mainTeacherPanel;

    public ActiveClassesController(int teacherID, ITeacherPanelController mainTeacherPanel)
    {
      this.teacherID = teacherID;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption("Panel nauczyciela > Aktywne klasy");
      mainTeacherPanel.MainPanel.Clear();
      RoundedButton roundedButton = new RoundedButton();
      roundedButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addClass");
      roundedButton.clickEvent += new RoundedButton.ClickDelegate(this.AddClass_clickEvent);
      roundedButton.SetImage(RoundedButton.IcoType.Add);
      roundedButton.SetColor(RoundedButton.ColorType.white);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton);
      List<StudentsClass> list = new ServerApi().GetAllStudentsClasses(teacherID, new AuthorizeData(CurrentUserInfo.CurrentUser)).Where<StudentsClass>((Func<StudentsClass, bool>) (sc => !sc.IsArchived && !sc.IsDeleted)).ToList<StudentsClass>();
      list.Sort();
      foreach (IListItem listItem in list)
      {
        InListGenericItem inListGenericItem = new InListGenericItem(listItem);
        inListGenericItem.listItemSelectedEvent += new Action<IListItem>(this.InListGenericItem_listItemSelectedEvent);
        mainTeacherPanel.MainPanel.AddToList(inListGenericItem);
      }
    }

    private void InListGenericItem_listItemSelectedEvent(IListItem listItem)
    {
      if (!(listItem as StudentsClass).Id.HasValue)
        this.mainTeacherPanel.SetStudentsClassPanel(-1);
      else
        this.mainTeacherPanel.SetStudentsClassPanel((listItem as StudentsClass).Id.Value);
    }

    private void AddClass_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new AddStudentsClassView(), false, false);
  }
}
