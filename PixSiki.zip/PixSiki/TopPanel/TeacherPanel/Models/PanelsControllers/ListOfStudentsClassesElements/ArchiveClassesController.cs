﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.ListOfStudentsClassesElements.ArchiveClassesController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.ListOfStudentsClassesElements
{
  internal class ArchiveClassesController
  {
    private int teacherID;
    private ITeacherPanelController mainTeacherPanel;

    public ArchiveClassesController(int teacherID, ITeacherPanelController mainTeacherPanel)
    {
      this.teacherID = teacherID;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption("Panel nauczyciela > Archiwalne klasy");
      mainTeacherPanel.MainPanel.Clear();
      List<StudentsClass> list = new ServerApi().GetAllStudentsClasses(teacherID, new AuthorizeData(CurrentUserInfo.CurrentUser)).Where<StudentsClass>((Func<StudentsClass, bool>) (sc => sc.IsArchived && !sc.IsDeleted)).ToList<StudentsClass>();
      list.Sort();
      foreach (IListItem listItem in list)
      {
        InListGenericItem inListGenericItem = new InListGenericItem(listItem);
        inListGenericItem.listItemSelectedEvent += new Action<IListItem>(this.InListGenericItem_listItemSelectedEvent);
        mainTeacherPanel.MainPanel.AddToList(inListGenericItem);
      }
    }

    private void InListGenericItem_listItemSelectedEvent(IListItem listItem)
    {
      if (!(listItem as StudentsClass).Id.HasValue)
        this.mainTeacherPanel.SetStudentsClassPanel(-1);
      else
        this.mainTeacherPanel.SetStudentsClassPanel((listItem as StudentsClass).Id.Value);
    }
  }
}
