﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements.EditStudentsClassController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements
{
  internal class EditStudentsClassController
  {
    private ITeacherPanelController mainTeacherPanel;
    private StudentsClass studentsClass;

    public EditStudentsClassController(
      StudentsClass studentsClass,
      ITeacherPanelController mainTeacherPanel)
    {
      this.mainTeacherPanel = mainTeacherPanel;
      this.studentsClass = studentsClass;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption("Klasa " + studentsClass.Name + " > Edycja klasy");
      RoundedButton roundedButton1 = new RoundedButton();
      roundedButton1.SetImage(RoundedButton.IcoType.Edit);
      roundedButton1.SetColor(RoundedButton.ColorType.white);
      roundedButton1.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("editClass");
      roundedButton1.SetImage(RoundedButton.IcoType.EditPage);
      roundedButton1.SetColor(RoundedButton.ColorType.white);
      roundedButton1.clickEvent += new RoundedButton.ClickDelegate(this.EditClass_clickEvent);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton1);
      RoundedButton roundedButton2 = new RoundedButton();
      roundedButton2.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("deleteClass");
      roundedButton2.SetImage(RoundedButton.IcoType.Delete);
      roundedButton2.SetColor(RoundedButton.ColorType.white);
      roundedButton2.SetImage(RoundedButton.IcoType.Delete);
      roundedButton2.clickEvent += new RoundedButton.ClickDelegate(this.DeleteStudentsClass_clickEvent);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton2);
      this.studentsClass.Name = studentsClass.Name;
      this.studentsClass.Description = studentsClass.Description;
      this.studentsClass.Yearbook = studentsClass.Yearbook;
      mainTeacherPanel.MainPanel.SetView((UserControl) new StudentsClassView(this.studentsClass));
    }

    private void DeleteStudentsClass_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new DeleteStudentsClass(this.studentsClass, this.mainTeacherPanel.TopStackPanel.GoBack), false, false);

    private void ArchiviseStudentsClass_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new ArchiviseStudentsClass(this.studentsClass), false, false);

    private void EditClass_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new EditStudentsClass(this.studentsClass), false, false);
  }
}
