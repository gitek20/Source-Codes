﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements.AllHomeworksListController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements
{
  internal class AllHomeworksListController
  {
    private StudentsClass studentsClass;
    private ITeacherPanelController mainTeacherPanel;

    public AllHomeworksListController(
      StudentsClass studentsClass,
      ITeacherPanelController mainTeacherPanel)
    {
      this.studentsClass = studentsClass;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption("Klasa " + studentsClass.Name + " > Prace domowe");
      RoundedButton roundedButton = new RoundedButton();
      roundedButton.SetColor(RoundedButton.ColorType.white);
      roundedButton.SetImage(RoundedButton.IcoType.Add);
      roundedButton.clickEvent += new RoundedButton.ClickDelegate(this.AddHomework_clickEvent);
      roundedButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addHomework");
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton);
      this.LoadAllHomeworks();
    }

    private void LoadAllHomeworks()
    {
      List<Exam> list = new ServerApi().GetAllExamsInClass(this.studentsClass, new AuthorizeData(CurrentUserInfo.CurrentUser)).Where<Exam>((Func<Exam, bool>) (e => e.IsHomework && e.Status != HomeworkStatus.Deleted && e.Status != HomeworkStatus.Archived)).ToList<Exam>();
      if (list.Count == 0)
      {
        this.mainTeacherPanel.MainPanel.ShowNoElementsInfo();
      }
      else
      {
        list.Sort();
        foreach (IListHomework listHomework in list)
        {
          ListItemHomework inItemHomework = new ListItemHomework(listHomework);
          inItemHomework.listItemSelectedEvent += new Action<IListItem>(this.InListGenericItem_listItemSelectedEvent);
          this.mainTeacherPanel.MainPanel.AddToList(inItemHomework);
        }
      }
    }

    private void AddHomework_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new AddHomeworkView(this.studentsClass), false, false);

    public void InListGenericItem_listItemSelectedEvent(IListItem listItem) => this.mainTeacherPanel.SetExamPanel(listItem as Exam);
  }
}
