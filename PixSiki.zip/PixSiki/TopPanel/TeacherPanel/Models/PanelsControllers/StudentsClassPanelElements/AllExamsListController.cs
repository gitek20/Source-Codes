﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements.AllExamsListController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements
{
  internal class AllExamsListController
  {
    private ITeacherPanelController mainTeacherPanel;
    private StudentsClass studentsClass;

    public AllExamsListController(
      StudentsClass studentsClass,
      ITeacherPanelController mainTeacherPanel)
    {
      this.mainTeacherPanel = mainTeacherPanel;
      this.studentsClass = studentsClass;
      ServerApi serverApi = new ServerApi();
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption("Klasa " + studentsClass.Name + " > Sprawdziany");
      RoundedButton roundedButton = new RoundedButton();
      roundedButton.SetColor(RoundedButton.ColorType.white);
      roundedButton.SetImage(RoundedButton.IcoType.Add);
      roundedButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addExam");
      roundedButton.clickEvent += new RoundedButton.ClickDelegate(this.AddExam_clickEvent);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton);
      StudentsClass studentsClass1 = studentsClass;
      AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
      List<Exam> list = serverApi.GetAllExamsInClass(studentsClass1, authorize).Where<Exam>((Func<Exam, bool>) (e => !e.IsHomework && e.Status != HomeworkStatus.Deleted && e.Status != HomeworkStatus.Archived)).ToList<Exam>();
      if (list.Count == 0)
      {
        mainTeacherPanel.MainPanel.ShowNoElementsInfo();
      }
      else
      {
        foreach (IListHomework listHomework in list)
        {
          ListItemHomework inItemHomework = new ListItemHomework(listHomework);
          inItemHomework.listItemSelectedEvent += new Action<IListItem>(this.InListGenericItem_listItemSelectedEvent);
          mainTeacherPanel.MainPanel.AddToList(inItemHomework);
        }
      }
    }

    public void InListGenericItem_listItemSelectedEvent(IListItem listItem) => this.mainTeacherPanel.SetExamPanel(listItem as Exam);

    private void AddExam_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new AddExamView(this.studentsClass), false, false);
  }
}
