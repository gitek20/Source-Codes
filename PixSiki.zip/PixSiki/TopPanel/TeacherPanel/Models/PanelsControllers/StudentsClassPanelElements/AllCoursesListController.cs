﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements.AllCoursesListController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using System;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements
{
  internal class AllCoursesListController
  {
    private StudentsClass studentsClass;
    private ITeacherPanelController mainTeacherPanel;

    public AllCoursesListController(
      StudentsClass studentsClass,
      ITeacherPanelController mainTeacherPanel)
    {
      this.studentsClass = studentsClass;
      this.mainTeacherPanel = mainTeacherPanel;
      ServerApi serverApi = new ServerApi();
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption("Klasa " + studentsClass.Name + " > Kursy");
      RoundedButton roundedButton = new RoundedButton();
      roundedButton.Description = "Wynikijj nauki";
      roundedButton.clickEvent += new RoundedButton.ClickDelegate(this.TeachingResults_clickEvent);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton);
      foreach (ICategoryData allMainCategory in BuiltInCoursesInstance.Instance.GetAllMainCategories())
      {
        if (!(allMainCategory as QuestionCategory).IsMyCreation())
        {
          InListGenericItem inListGenericItem = new InListGenericItem((IListItem) allMainCategory);
          inListGenericItem.listItemSelectedEvent += new Action<IListItem>(this.InListGenericItem_listItemSelectedEvent);
          mainTeacherPanel.MainPanel.AddToList(inListGenericItem);
        }
      }
    }

    private void InListGenericItem_listItemSelectedEvent(IListItem listItem) => this.mainTeacherPanel.SetSingleCoursePanel(this.studentsClass, (listItem as ICategoryData).UniqueGuid());

    private void TeachingResults_clickEvent() => this.mainTeacherPanel.SetLearningResultPanel(this.studentsClass.Id.Value, new StatisticInputData(StatisticRowDataType.AllCourses));
  }
}
