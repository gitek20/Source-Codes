﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements.TeachingResultsSelectController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Views.LearnigResultsConponents.LearningResultsSelector;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements
{
  internal class TeachingResultsSelectController
  {
    private StudentsClass studentsClass;
    private ITeacherPanelController mainTeacherPanel;
    private ResultsDataController resultsDataController;
    private User user;

    public TeachingResultsSelectController(
      StudentsClass studentsClass,
      ITeacherPanelController mainTeacherPanel)
    {
      this.studentsClass = studentsClass;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      this.resultsDataController = new ResultsDataController(studentsClass.Id.Value);
      LearningResultsSelectorView resultsSelectorView = new LearningResultsSelectorView(studentsClass, this.resultsDataController);
      mainTeacherPanel.MainPanel.SetView((UserControl) resultsSelectorView);
    }

    public TeachingResultsSelectController(
      StudentsClass studentsClass,
      User user,
      ITeacherPanelController mainTeacherPanel)
    {
      this.studentsClass = studentsClass;
      this.user = user;
      this.mainTeacherPanel = mainTeacherPanel;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      this.resultsDataController = new ResultsDataController(studentsClass.Id.Value, user);
      LearningResultsSelectorView resultsSelectorView = new LearningResultsSelectorView(studentsClass, this.resultsDataController);
      mainTeacherPanel.MainPanel.SetView((UserControl) resultsSelectorView);
    }

    private void RefreshButton_clickEvent() => this.resultsDataController.RefreshAllData();
  }
}
