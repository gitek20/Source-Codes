﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements.AllStudentsListController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.GeneratorPDF;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents.Components;
using PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents;
using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Media;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements
{
  public class AllStudentsListController
  {
    private ITeacherPanelController mainTeacherPanel;
    private StudentsClass studentsClass;
    private List<User> listStudents;

    public AllStudentsListController(
      StudentsClass studentsClass,
      ITeacherPanelController mainTeacherPanel)
    {
      ServerApi serverApi = new ServerApi();
      this.mainTeacherPanel = mainTeacherPanel;
      this.studentsClass = studentsClass;
      mainTeacherPanel.MainPanel.Clear();
      mainTeacherPanel.ActionPanel.Clear();
      mainTeacherPanel.ActionPanel.SetCaption("Klasa " + studentsClass.Name + " > Uczniowie");
      RoundedButton roundedButton1 = new RoundedButton();
      roundedButton1.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addStudent");
      roundedButton1.SetColor(RoundedButton.ColorType.white);
      roundedButton1.SetImage(RoundedButton.IcoType.Add);
      roundedButton1.clickEvent += new RoundedButton.ClickDelegate(this.AddStudent_clickEvent);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton1);
      RoundedButton roundedButton2 = new RoundedButton();
      roundedButton2.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addManyStudent");
      roundedButton2.SetColor(RoundedButton.ColorType.white);
      roundedButton2.SetImage(RoundedButton.IcoType.Add);
      roundedButton2.clickEvent += new RoundedButton.ClickDelegate(this.AddStudents_clickEvent);
      mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton2);
      StudentsClass studentsClass1 = studentsClass;
      AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
      List<User> allStudentsInClass = serverApi.GetAllStudentsInClass(studentsClass1, authorize);
      if (allStudentsInClass.Count == 0)
      {
        mainTeacherPanel.MainPanel.ShowNoElementsInfo();
      }
      else
      {
        bool? acceptedToStudentsClass;
        if (allStudentsInClass.Count > 0)
        {
          bool flag = false;
          for (int index = 0; index < allStudentsInClass.Count; ++index)
          {
            acceptedToStudentsClass = allStudentsInClass[index].Student_isAcceptedToStudentsClass;
            if (acceptedToStudentsClass.Value)
              flag = true;
          }
          if (flag)
          {
            RoundedButton roundedButton3 = new RoundedButton();
            roundedButton3.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("printPDF");
            roundedButton3.SetColor(RoundedButton.ColorType.white);
            roundedButton3.SetImage(RoundedButton.IcoType.Pdf);
            roundedButton3.clickEvent += new RoundedButton.ClickDelegate(this.PrintStudetsCard_clickEvent);
            mainTeacherPanel.ActionPanel.AddToLeftSide((UserControl) roundedButton3);
          }
        }
        allStudentsInClass.Sort();
        foreach (User user in allStudentsInClass)
        {
          acceptedToStudentsClass = user.Student_isAcceptedToStudentsClass;
          if (acceptedToStudentsClass.Value)
          {
            InListGenericItem inListGenericItem = new InListGenericItem((IListItem) user, Colors.White);
            inListGenericItem.listItemSelectedEvent += new Action<IListItem>(this.InListGenericItem_listItemSelectedEvent);
            mainTeacherPanel.MainPanel.AddToList(inListGenericItem, true);
          }
          else
          {
            InListGenericItem inListGenericItem = new InListGenericItem((IListItem) user, Colors.WhiteSmoke);
            inListGenericItem.listItemSelectedEvent += new Action<IListItem>(this.InListGenericItem_listItemSelectedEvent);
            mainTeacherPanel.MainPanel.AddToList(inListGenericItem, false);
          }
        }
        this.listStudents = allStudentsInClass;
      }
    }

    private void PrintStudetsCard_clickEvent() => GeneratePDF.GeneratePDFListUsersInClass(this.listStudents, this.studentsClass.Name, "");

    private void AddStudent_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new AddStudentView(this.studentsClass.Id.Value), false, false);

    private void AddStudents_clickEvent() => this.mainTeacherPanel.ShowPopupWindow((UserControl) new AddManyStudentsView(this.studentsClass.Id.Value), false, false);

    public void InListGenericItem_listItemSelectedEvent(IListItem listItem) => this.mainTeacherPanel.SetUserPanel(this.studentsClass, listItem as User);
  }
}
