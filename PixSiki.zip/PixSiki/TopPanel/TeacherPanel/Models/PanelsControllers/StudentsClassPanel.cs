﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.TecherPanel;
using PixBlocks.TopPanel.Components.TecherPanel.Icons;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility;
using PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.StudentsClassPanelElements;
using PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents.Components;
using System;
using System.Collections.Generic;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers
{
  internal class StudentsClassPanel : ISubPanelOnStackController
  {
    private int studentsClassID;
    private StudentsClass studentsClass;
    private ITeacherPanelController mainTeacherPanel;
    private List<User> studentsList;
    private RefreshEvent eventController;
    private LeftListItem teachingResults;
    private LeftListItem classData;
    private LeftListItem activeStudents;
    private LeftListItem exams;
    private LeftListItem homeWorks;
    private LeftListItem courses;
    private LeftListItem coursesVisibility;
    private LeftListItem lastSelectedItem;

    public StudentsClassPanel(
      int studentsClassID,
      ITeacherPanelController mainTeacherPanel,
      RefreshEvent eventController)
    {
      ServerApi serverApi = new ServerApi();
      this.eventController = eventController;
      this.studentsClassID = studentsClassID;
      this.mainTeacherPanel = mainTeacherPanel;
      this.studentsClass = serverApi.GetStudentsClassById(studentsClassID, new AuthorizeData(CurrentUserInfo.CurrentUser));
      TopStackItem topStackItem = new TopStackItem((ISubPanelOnStackController) this);
      mainTeacherPanel.TopStackPanel.AddToStackPanel(topStackItem);
      this.activeStudents = new LeftListItem((UserControl) new ManyStudents());
      this.activeStudents.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("students");
      this.classData = new LeftListItem((UserControl) new EditData());
      this.classData.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classData));
      this.studentsList = serverApi.GetAllStudentsInClass(this.studentsClass, new AuthorizeData(CurrentUserInfo.CurrentUser));
      this.teachingResults = new LeftListItem((UserControl) new TeachingResults());
      this.teachingResults.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("learningResoults");
      this.courses = new LeftListItem((UserControl) new AllHomework());
      this.courses.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (courses));
      this.homeWorks = new LeftListItem((UserControl) new AllHomework());
      this.homeWorks.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("homeworks");
      this.exams = new LeftListItem((UserControl) new AllExams());
      this.exams.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (exams));
      this.coursesVisibility = new LeftListItem((UserControl) new Visibiility());
      this.coursesVisibility.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("courseView");
      this.RefreshView();
      this.activeStudents.IsSelected = true;
      this.ShowSelectedView();
      mainTeacherPanel.LeftPanel.selectionChangedEvent += new LeftPanel.SelectionChanged(this.LeftPanel_selectionChangedEvent);
    }

    private void LeftPanel_selectionChangedEvent() => this.ShowSelectedView();

    public string Description => this.studentsClass.Name;

    public event DescriptionChange DescriptionChangeEvent;

    public void RefreshView()
    {
      this.mainTeacherPanel.LeftPanel.Clear();
      this.mainTeacherPanel.LeftPanel.AddToStack(this.activeStudents);
      this.mainTeacherPanel.LeftPanel.AddToStack(this.teachingResults);
      this.mainTeacherPanel.LeftPanel.AddToStack(this.exams);
      this.mainTeacherPanel.LeftPanel.AddToStack(this.homeWorks);
      this.mainTeacherPanel.LeftPanel.AddToStack(this.coursesVisibility);
      this.mainTeacherPanel.LeftPanel.AddToStack(this.classData);
      this.ShowSelectedView();
      if (this.DescriptionChangeEvent == null)
        return;
      this.DescriptionChangeEvent();
    }

    public void DisposeView()
    {
    }

    private void ShowSelectedView()
    {
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.activeStudents)
      {
        AllStudentsListController studentsListController;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => studentsListController = new AllStudentsListController(this.studentsClass, this.mainTeacherPanel)));
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.exams)
      {
        AllExamsListController examsListController;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => examsListController = new AllExamsListController(this.studentsClass, this.mainTeacherPanel)));
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.classData)
      {
        EditStudentsClassController studentsClassController = new EditStudentsClassController(this.studentsClass, this.mainTeacherPanel);
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.courses)
      {
        AllCoursesListController coursesListController = new AllCoursesListController(this.studentsClass, this.mainTeacherPanel);
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.homeWorks)
      {
        AllHomeworksListController homeworksListController;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => homeworksListController = new AllHomeworksListController(this.studentsClass, this.mainTeacherPanel)));
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.teachingResults && this.teachingResults != this.lastSelectedItem)
      {
        TeachingResultsSelectController selectController;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => selectController = new TeachingResultsSelectController(this.studentsClass, this.mainTeacherPanel)));
      }
      if (this.mainTeacherPanel.LeftPanel.SelectedItem == this.coursesVisibility && this.coursesVisibility != this.lastSelectedItem)
      {
        CoursesVisibilityView coursesVisibilityView = new CoursesVisibilityView(this.studentsClass, this.mainTeacherPanel, this.eventController);
      }
      this.lastSelectedItem = this.mainTeacherPanel.LeftPanel.SelectedItem;
    }
  }
}
