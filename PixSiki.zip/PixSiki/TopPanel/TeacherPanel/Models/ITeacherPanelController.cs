﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.ITeacherPanelController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Views.ActionPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents;
using System.Windows.Controls;

namespace PixBlocks.TopPanel.TeacherPanel.Models
{
  public interface ITeacherPanelController
  {
    ActionPanel ActionPanel { get; }

    LeftPanel LeftPanel { get; }

    ISubPanelOnStackController CurrentPanel { get; set; }

    MainPanel MainPanel { get; }

    TopStackPanel TopStackPanel { get; }

    void SetListOfStudentsClassesPanel(int teacherID);

    void SetStudentsClassPanel(int studentsClassID);

    void SetUserPanel(StudentsClass studentsClass, User user);

    void SetExamPanel(Exam exam);

    void ShowPopupWindow(UserControl newUserControl, bool showCloseButton, bool showFullWidthPopUp);

    void ClosePopUp();

    void SetLearningResultPanel(int studentsClassID, StatisticInputData statisticInputData);

    void SetSingleCoursePanel(StudentsClass studentsClass, string courseGuid);
  }
}
