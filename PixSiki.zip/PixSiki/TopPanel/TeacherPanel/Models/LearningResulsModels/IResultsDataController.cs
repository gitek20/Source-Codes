﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels.IResultsDataController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.UserProfileInfo;
using System.Collections.Generic;

namespace PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels
{
  public interface IResultsDataController
  {
    void RefreshAllData();

    QuestionResult GetNumberOfPointsInLesson(string questionGuid, int userID);

    QuestionResult GetNumberOfPointsInExamOrHomework(
      string questionGuid,
      int examId,
      int userID);

    ICategoryData GetCourseOfGuid(string categoryGuid);

    void SetNumberOfPoints(QuestionResult questionResult);

    List<ICategoryData> GetAllMainCategories();

    List<ICategoryData> GetAllLessonInCategory(string categoryGuid);

    List<IQuestionData> GetAllQuestionsInLesson(string lessonGuid);

    Exam GetExamOfId(int? examID);

    StatisticOutData GetStatisticData(StatisticInputData statisticInputData);

    List<Question> GetAllQuestionsInExam(Exam exam);

    string GetComment(StatisticInputData statisticInputData);

    List<User> GetAllUsersInClass();

    void SetComment(string text, StatisticInputData inputData);

    List<Exam> GetAllHomeworks();

    List<Exam> GetAllExams();
  }
}
