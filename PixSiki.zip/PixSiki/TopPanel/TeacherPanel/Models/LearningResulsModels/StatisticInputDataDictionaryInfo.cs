﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels.StatisticInputDataDictionaryInfo
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.UserProfileInfo;

namespace PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels
{
  internal class StatisticInputDataDictionaryInfo
  {
    private StatisticInputData statisticInputData;
    private StatisticOutData statisticOutData;
    private int userID;
    private StatisticRowDataType rowType;

    public StatisticInputData StatisticInputData => this.statisticInputData;

    public StatisticOutData StatisticOutData => this.statisticOutData;

    public StatisticInputDataDictionaryInfo(StatisticRowDataType rowType, int userID)
    {
      this.rowType = rowType;
      this.statisticInputData = new StatisticInputData(rowType);
      this.statisticInputData.UserID = new int?(userID);
      this.userID = userID;
      this.statisticOutData = new StatisticOutData();
      this.statisticOutData.AllPointsCount = 0;
      this.statisticOutData.SumOfUserPoints = 0;
    }

    public StatisticInputDataDictionaryInfo(
      StatisticRowDataType rowType,
      ICategoryData category,
      int userID)
    {
      this.rowType = rowType;
      this.statisticInputData = new StatisticInputData(rowType);
      this.statisticInputData.CategoryGuid = category.UniqueGuid();
      this.statisticInputData.UserID = new int?(userID);
      this.userID = userID;
      this.statisticOutData = new StatisticOutData();
      this.statisticOutData.AllPointsCount = 0;
      this.statisticOutData.SumOfUserPoints = 0;
    }

    public StatisticInputDataDictionaryInfo(StatisticRowDataType rowType, Exam exam, int userID)
    {
      this.rowType = rowType;
      this.statisticInputData = new StatisticInputData(rowType);
      this.statisticInputData.CategoryGuid = (string) null;
      this.statisticInputData.ExamID = new int?(exam.Id);
      this.statisticInputData.UserID = new int?(userID);
      this.userID = userID;
      this.statisticOutData = new StatisticOutData();
      this.statisticOutData.AllPointsCount = 0;
      this.statisticOutData.SumOfUserPoints = 0;
    }

    internal void AddStatisticInfo(StatisticInputDataDictionaryInfo categoryDictInfo)
    {
      this.statisticOutData.AllPointsCount += categoryDictInfo.StatisticOutData.AllPointsCount;
      this.statisticOutData.SumOfUserPoints += categoryDictInfo.StatisticOutData.SumOfUserPoints;
    }

    internal string ToDictString() => this.StatisticInputData.ToDictString();

    internal void AddQuestionInfo(IQuestionData question, QuestionResult questionResult)
    {
      if (!question.IsClassicQuestion())
        return;
      ++this.statisticOutData.AllPointsCount;
      if (questionResult.Points <= 0)
        return;
      this.statisticOutData.SumOfUserPoints += questionResult.Points;
    }
  }
}
