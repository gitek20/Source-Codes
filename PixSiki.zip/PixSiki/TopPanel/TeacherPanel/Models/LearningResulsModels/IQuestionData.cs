﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels.IQuestionData
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels
{
  public interface IQuestionData
  {
    bool IsClassicQuestion();

    bool IsSample();

    bool IsGame();

    bool IsFree();

    string QuestionGuid();

    bool IsExamQuestion { get; }

    int? ExamID { get; }

    string GetQuestionContent();

    string UserFriendlyDescription();

    ICategoryData ParenCategory { get; }

    ICategoryData ParenLesson { get; }
  }
}
