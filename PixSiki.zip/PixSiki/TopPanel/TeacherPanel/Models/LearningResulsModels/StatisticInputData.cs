﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels.StatisticInputData
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;

namespace PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels
{
  public class StatisticInputData
  {
    private StatisticRowDataType dataType;
    private int? userID;
    private string categoryGuid;
    private int? examID;

    public StatisticRowDataType DataType
    {
      get => this.dataType;
      set => this.dataType = value;
    }

    public int? UserID
    {
      get => this.userID;
      set => this.userID = value;
    }

    public string CategoryGuid
    {
      get => this.categoryGuid;
      set => this.categoryGuid = value;
    }

    public int? ExamID
    {
      get => this.examID;
      set => this.examID = value;
    }

    public StatisticInputData(StatisticRowDataType statisticRowDataType) => this.DataType = statisticRowDataType;

    public StatisticInputData(ICategoryData categoryData, int? userID)
    {
      this.DataType = !categoryData.IsCourse() ? StatisticRowDataType.LessonInCourse : StatisticRowDataType.Course;
      this.CategoryGuid = categoryData.UniqueGuid();
      this.UserID = userID;
    }

    public StatisticInputData(StatisticInputData statisticInputData, User user)
    {
      this.categoryGuid = statisticInputData.categoryGuid;
      this.dataType = statisticInputData.dataType;
      this.examID = statisticInputData.examID;
      this.userID = user.Id;
    }

    public StatisticInputData(Exam exam, User user)
    {
      this.dataType = !exam.IsHomework ? StatisticRowDataType.Exam : StatisticRowDataType.HomeWork;
      this.examID = new int?(exam.Id);
      if (user == null)
        return;
      this.UserID = user.Id;
    }

    public string ToDictString() => this.DataType.ToString() + this.UserID.ToStringOrEmpty() + this.CategoryGuid.ToStringOrEmpty() + this.ExamID.ToStringOrEmpty();
  }
}
