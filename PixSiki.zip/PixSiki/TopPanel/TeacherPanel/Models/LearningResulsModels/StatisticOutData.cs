﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels.StatisticOutData
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels
{
  public class StatisticOutData
  {
    private int allPointsCount;
    private int sumOfUserPoints;

    public int AllPointsCount
    {
      get => this.allPointsCount;
      set => this.allPointsCount = value;
    }

    public int SumOfUserPoints
    {
      get => this.sumOfUserPoints;
      set => this.sumOfUserPoints = value;
    }
  }
}
