﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels.ResultsDataController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.UserProfileInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels
{
  public class ResultsDataController : IResultsDataController
  {
    private int studentsClassID;
    private List<User> users;
    private User user;
    private Dictionary<string, StatisticInputDataDictionaryInfo> statisticInputDataDict = new Dictionary<string, StatisticInputDataDictionaryInfo>();
    private Dictionary<string, QuestionResult> questionResultsDictionary = new Dictionary<string, QuestionResult>();
    private Dictionary<string, Comment> commentDictionary = new Dictionary<string, Comment>();
    private List<QuestionResult> questionResultsFromStudentsClass = new List<QuestionResult>();
    private List<Comment> commentsFromStudentsClass = new List<Comment>();
    private List<Exam> allExamsForStudentsClass = new List<Exam>();
    private List<Question> questionsInExams = new List<Question>();

    public ResultsDataController(int studentsClassID)
    {
      this.studentsClassID = studentsClassID;
      this.RefreshAllData();
    }

    public ResultsDataController(int studentsClassID, User user)
    {
      this.user = user;
      this.studentsClassID = studentsClassID;
      this.RefreshAllData();
    }

    public List<ICategoryData> GetAllLessonInCategory(string categoryGuid) => BuiltInCoursesInstance.Instance.GetAllLessonInCategory(categoryGuid);

    public List<ICategoryData> GetAllMainCategories() => BuiltInCoursesInstance.Instance.GetAllMainCategories();

    public List<IQuestionData> GetAllQuestionsInLesson(string lessonGuid) => BuiltInCoursesInstance.Instance.GetAllQuestionsInLesson(lessonGuid);

    public List<User> GetAllUsersInClass() => this.users;

    public QuestionResult GetNumberOfPointsInLesson(Question question, int userID) => question.IsExamQuestion ? this.GetQuestionResultFromDictionary(new int?(question.GetExam().Id), question.UniqueGuid, userID) : this.GetQuestionResultFromDictionary(new int?(), question.UniqueGuid, userID);

    public QuestionResult GetNumberOfPointsInLesson(string questionGuid, int userID) => this.GetQuestionResultFromDictionary(new int?(), questionGuid, userID);

    public QuestionResult GetNumberOfPointsInExamOrHomework(
      string questionGuid,
      int examGuid,
      int userID)
    {
      return this.GetQuestionResultFromDictionary(new int?(examGuid), questionGuid, userID);
    }

    public List<Exam> GetAllExams() => this.allExamsForStudentsClass.Where<Exam>((Func<Exam, bool>) (e => !e.IsHomework)).ToList<Exam>();

    public List<Exam> GetAllHomeworks() => this.allExamsForStudentsClass.Where<Exam>((Func<Exam, bool>) (e => e.IsHomework)).ToList<Exam>();

    public StatisticOutData GetStatisticData(StatisticInputData statisticInputData)
    {
      if (this.statisticInputDataDict.ContainsKey(statisticInputData.ToDictString()))
        return this.statisticInputDataDict[statisticInputData.ToDictString()].StatisticOutData;
      return new StatisticOutData()
      {
        AllPointsCount = 1000,
        SumOfUserPoints = 99999
      };
    }

    private void ClearCommentDictionary() => this.commentDictionary.Clear();

    private void AddToCommentDictionary(Comment comment)
    {
      if (this.commentDictionary.ContainsKey(comment.ToDictString()))
        this.commentDictionary[comment.ToDictString()] = comment;
      else
        this.commentDictionary.Add(comment.ToDictString(), comment);
    }

    private Comment GetCommentFromDictionary(StatisticInputData statisticInputData)
    {
      Comment comment = (Comment) null;
      if (this.commentDictionary.TryGetValue(statisticInputData.ToDictString(), out comment))
        return comment;
      return new Comment(statisticInputData.UserID.Value, statisticInputData.CategoryGuid, statisticInputData.ExamID, statisticInputData.DataType.ToString())
      {
        UserID = statisticInputData.UserID.Value,
        ExamID = statisticInputData.ExamID,
        CategoryGuid = statisticInputData.CategoryGuid,
        StatisticRowDataType = statisticInputData.DataType.ToString(),
        Text = ""
      };
    }

    private void ClearQuestionResultDictionary() => this.questionResultsDictionary.Clear();

    private void AddToQuestionResultDictionary(QuestionResult questionResult)
    {
      string key = questionResult.ExamId.ToString() + "_" + questionResult.QuestionGuid + "_" + questionResult.UserID.ToString();
      if (this.questionResultsDictionary.ContainsKey(key))
        this.questionResultsDictionary[key] = questionResult;
      else
        this.questionResultsDictionary.Add(key, questionResult);
    }

    private QuestionResult GetQuestionResultFromDictionary(
      int? examID,
      string questionGuid,
      int userID)
    {
      QuestionResult questionResult = (QuestionResult) null;
      if (this.questionResultsDictionary.TryGetValue(examID.ToString() + "_" + questionGuid + "_" + userID.ToString(), out questionResult))
        return questionResult;
      return new QuestionResult()
      {
        QuestionGuid = questionGuid,
        UserID = userID,
        IsExamQuestion = examID.HasValue,
        ExamId = examID,
        Points = 0
      };
    }

    private void BuildDictsStructure()
    {
      this.ClearQuestionResultDictionary();
      foreach (QuestionResult questionResult in this.questionResultsFromStudentsClass)
        this.AddToQuestionResultDictionary(questionResult);
      this.ClearCommentDictionary();
      foreach (Comment comment in this.commentsFromStudentsClass)
        this.AddToCommentDictionary(comment);
      this.statisticInputDataDict.Clear();
      foreach (User user in this.users)
      {
        int userID = user.Id.Value;
        StatisticInputDataDictionaryInfo dataDictionaryInfo = new StatisticInputDataDictionaryInfo(StatisticRowDataType.AllCourses, userID);
        foreach (ICategoryData allMainCategory in BuiltInCoursesInstance.Instance.GetAllMainCategories())
        {
          if (!(allMainCategory as QuestionCategory).IsMyCreation())
          {
            StatisticInputDataDictionaryInfo categoryDictInfo1 = new StatisticInputDataDictionaryInfo(StatisticRowDataType.Course, allMainCategory, userID);
            foreach (ICategoryData category in BuiltInCoursesInstance.Instance.GetAllLessonInCategory(allMainCategory.UniqueGuid()))
            {
              StatisticInputDataDictionaryInfo categoryDictInfo2 = new StatisticInputDataDictionaryInfo(StatisticRowDataType.LessonInCourse, category, userID);
              foreach (IQuestionData question in BuiltInCoursesInstance.Instance.GetAllQuestionsInLesson(category.UniqueGuid()))
                categoryDictInfo2.AddQuestionInfo(question, this.GetNumberOfPointsInLesson(question as Question, userID));
              categoryDictInfo1.AddStatisticInfo(categoryDictInfo2);
              this.statisticInputDataDict.Add(categoryDictInfo2.ToDictString(), categoryDictInfo2);
            }
            dataDictionaryInfo.AddStatisticInfo(categoryDictInfo1);
            this.statisticInputDataDict.Add(categoryDictInfo1.ToDictString(), categoryDictInfo1);
          }
        }
        this.statisticInputDataDict.Add(dataDictionaryInfo.ToDictString(), dataDictionaryInfo);
      }
      foreach (User user in this.users)
      {
        int userID = user.Id.Value;
        StatisticInputDataDictionaryInfo dataDictionaryInfo1 = new StatisticInputDataDictionaryInfo(StatisticRowDataType.AllExams, userID);
        foreach (Exam allExam in this.GetAllExams())
        {
          StatisticInputDataDictionaryInfo categoryDictInfo = new StatisticInputDataDictionaryInfo(StatisticRowDataType.Exam, allExam, userID);
          foreach (Question question in this.GetAllQuestionsInExam(allExam))
            categoryDictInfo.AddQuestionInfo((IQuestionData) question, this.GetNumberOfPointsInExamOrHomework(question.UniqueGuid, allExam.Id, userID));
          dataDictionaryInfo1.AddStatisticInfo(categoryDictInfo);
          this.statisticInputDataDict.Add(categoryDictInfo.ToDictString(), categoryDictInfo);
        }
        this.statisticInputDataDict.Add(dataDictionaryInfo1.ToDictString(), dataDictionaryInfo1);
        StatisticInputDataDictionaryInfo dataDictionaryInfo2 = new StatisticInputDataDictionaryInfo(StatisticRowDataType.AllHomeWorks, userID);
        foreach (Exam allHomework in this.GetAllHomeworks())
        {
          StatisticInputDataDictionaryInfo categoryDictInfo = new StatisticInputDataDictionaryInfo(StatisticRowDataType.HomeWork, allHomework, userID);
          foreach (Question question in this.GetAllQuestionsInExam(allHomework))
            categoryDictInfo.AddQuestionInfo((IQuestionData) question, this.GetNumberOfPointsInExamOrHomework(question.UniqueGuid, allHomework.Id, userID));
          dataDictionaryInfo2.AddStatisticInfo(categoryDictInfo);
          this.statisticInputDataDict.Add(categoryDictInfo.ToDictString(), categoryDictInfo);
        }
        this.statisticInputDataDict.Add(dataDictionaryInfo2.ToDictString(), dataDictionaryInfo2);
      }
    }

    public void RefreshAllData()
    {
      ServerApi serverApi = new ServerApi();
      User currentUser = CurrentUserInfo.CurrentUser;
      StudentsClass result = serverApi.GetStudentsClassByIdAsync(this.studentsClassID, new AuthorizeData(currentUser)).Result;
      if (this.user == null)
      {
        this.users = serverApi.GetAllStudentsInClass(result, new AuthorizeData(currentUser)).Where<User>((Func<User, bool>) (s =>
        {
          bool? acceptedToStudentsClass = s.Student_isAcceptedToStudentsClass;
          bool flag = true;
          return acceptedToStudentsClass.GetValueOrDefault() == flag & acceptedToStudentsClass.HasValue;
        })).ToList<User>();
        this.users.Sort();
        this.questionResultsFromStudentsClass = serverApi.GetAllResultsForStudentsClassAsync(result, new AuthorizeData(currentUser)).Result;
        this.commentsFromStudentsClass = serverApi.GetAllCommentsFromStudentsClassAsync(result, new AuthorizeData(currentUser)).Result;
      }
      else
      {
        this.users = new List<User>();
        this.users.Add(this.user);
        this.questionResultsFromStudentsClass = serverApi.GetAllQuestionsResultsAsync(this.user, new AuthorizeData(currentUser)).Result;
        this.commentsFromStudentsClass = serverApi.GetAllCommentsForUserAsync(this.user, new AuthorizeData(currentUser)).Result;
      }
      this.allExamsForStudentsClass = serverApi.GetAllExamsInClass(result, new AuthorizeData(currentUser)).Where<Exam>((Func<Exam, bool>) (e => !e.IsDeleted && !e.IsArchived)).ToList<Exam>();
      this.questionsInExams = new List<Question>();
      foreach (ExamQuestion examQuestion in serverApi.GetAllQuestionsInAllExamsInStudentsClass(result, new AuthorizeData(CurrentUserInfo.CurrentUser)).Where<ExamQuestion>((Func<ExamQuestion, bool>) (e => QuestionCategoryLoaderAndSever.ContainsQuestionGuid(e.QuestionGuid))).ToList<ExamQuestion>())
        this.questionsInExams.Add(BuiltInCoursesInstance.Instance.GetQuestionOfGuid(examQuestion.QuestionGuid).GetDeepCopyForExam(this.GetExamOfId(new int?(examQuestion.ExamId))));
      this.BuildDictsStructure();
    }

    public void SetNumberOfPoints(QuestionResult questionResult)
    {
    }

    public ICategoryData GetCourseOfGuid(string categoryGuid) => BuiltInCoursesInstance.Instance.GetCourseOfID(categoryGuid);

    public string GetComment(StatisticInputData statisticInputData) => this.GetCommentFromDictionary(statisticInputData).Text;

    public void SetComment(string text, StatisticInputData inputData)
    {
      ServerApi serverApi = new ServerApi();
      Comment comment1 = new Comment(inputData.UserID.Value, inputData.CategoryGuid, inputData.ExamID, inputData.DataType.ToString(), text);
      this.AddToCommentDictionary(comment1);
      Comment comment2 = comment1;
      AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
      serverApi.AddOrUpdateCommentAsync(comment2, authorize);
    }

    public List<Question> GetAllQuestionsInExam(Exam exam) => this.questionsInExams.Where<Question>((Func<Question, bool>) (e => e.GetExam() == exam)).ToList<Question>();

    public Exam GetExamOfId(int? examID) => this.allExamsForStudentsClass.Where<Exam>((Func<Exam, bool>) (e =>
    {
      int id = e.Id;
      int? nullable = examID;
      int valueOrDefault = nullable.GetValueOrDefault();
      return id == valueOrDefault & nullable.HasValue;
    })).FirstOrDefault<Exam>();
  }
}
