﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.IBuiltInCoursesManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System.Collections.Generic;

namespace PixBlocks.TopPanel.TeacherPanel.Models
{
  public interface IBuiltInCoursesManager
  {
    List<ICategoryData> GetAllMainCategories();

    List<ICategoryData> GetAllLessonInCategory(string categoryGuid);

    List<IQuestionData> GetAllQuestionsInLesson(string lessonGuid);

    ICategoryData GetCourseOfID(string categoryGuid);

    Question GetQuestionOfGuid(string questionGuid);
  }
}
