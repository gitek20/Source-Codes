﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.IMainListQuestions
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components;

namespace PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions
{
  public interface IMainListQuestions
  {
    void AddQuestion(
      IQuestionData questionData,
      SingleSelectedQuestion singleSelectedQuestion,
      bool addToDB);

    void RemoveQuestion(IQuestionData questionData, SingleSelectedQuestion singleSelectedQuestion);

    bool CheckCheckedQuestions(IQuestionData questionData);

    bool IsNewExam { get; }
  }
}
