﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components.SingleCategory
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components
{
  public partial class SingleCategory : UserControl, IComponentConnector
  {
    private bool open;
    private ICategoryData category;
    private double lessonHeight;
    private List<ICategoryData> mainLessons = new List<ICategoryData>();
    private IMainListQuestions questions;
    internal TextBlock textCategory;
    internal TextBlock textCategoryDescription;
    internal StackPanel lessons;
    private bool _contentLoaded;

    public SingleCategory(ICategoryData category, IMainListQuestions questions)
    {
      this.category = category;
      this.questions = questions;
      this.InitializeComponent();
      this.textCategory.Text = category.ListName;
      this.textCategoryDescription.Text = category.TranslatedDescription();
      this.open = false;
      this.LessonGenerate();
    }

    public void LessonGenerate()
    {
      if (this.open)
        this.lessons.Visibility = Visibility.Visible;
      else
        this.lessons.Visibility = Visibility.Collapsed;
      if (this.mainLessons.Count >= 1)
        return;
      this.mainLessons = BuiltInCoursesInstance.Instance.GetAllLessonInCategory(this.category.UniqueGuid());
      foreach (ICategoryData mainLesson in this.mainLessons)
        this.lessons.Children.Add((UIElement) new SingleLesson(mainLesson, this.questions));
    }

    private void ShowLessons_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.open = !this.open;
      this.LessonGenerate();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/models/listscategoriesandquestions/components/singlecategory.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.ShowLessons_MouseDown);
          break;
        case 2:
          this.textCategory = (TextBlock) target;
          break;
        case 3:
          this.textCategoryDescription = (TextBlock) target;
          break;
        case 4:
          this.lessons = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
