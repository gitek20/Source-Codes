﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components.SingleLesson
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components
{
  public partial class SingleLesson : UserControl, IComponentConnector
  {
    private ICategoryData lesson;
    private double sizeQuestion;
    private bool open;
    private List<IQuestionData> mainQuestions = new List<IQuestionData>();
    private IMainListQuestions questions;
    internal TextBlock singleLessonTitle;
    internal TextBlock singleLessonDescription;
    internal StackPanel mainLessons;
    internal StackPanel questionsList;
    private bool _contentLoaded;

    public SingleLesson(ICategoryData lesson, IMainListQuestions questions)
    {
      this.InitializeComponent();
      this.lesson = lesson;
      this.questions = questions;
      this.singleLessonTitle.Text = lesson.ListName;
      this.singleLessonDescription.Text = lesson.TranslatedDescription();
      this.open = false;
      this.GenerateAllQuestions();
    }

    public void GenerateAllQuestions()
    {
      if (this.open)
        this.questionsList.Visibility = Visibility.Visible;
      else
        this.questionsList.Visibility = Visibility.Collapsed;
      if (this.mainQuestions.Count >= 1)
        return;
      this.mainQuestions = BuiltInCoursesInstance.Instance.GetAllQuestionsInLesson(this.lesson.UniqueGuid());
      foreach (IQuestionData mainQuestion in this.mainQuestions)
        this.questionsList.Children.Add((UIElement) new SingleQuestion(mainQuestion, this.questions));
    }

    private void ShowQuestions_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.open = !this.open;
      this.GenerateAllQuestions();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/models/listscategoriesandquestions/components/singlelesson.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.ShowQuestions_MouseDown);
          break;
        case 2:
          this.singleLessonTitle = (TextBlock) target;
          break;
        case 3:
          this.singleLessonDescription = (TextBlock) target;
          break;
        case 4:
          this.mainLessons = (StackPanel) target;
          break;
        case 5:
          this.questionsList = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
