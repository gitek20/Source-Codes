﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components.SingleQuestion
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components
{
  public partial class SingleQuestion : UserControl, IComponentConnector
  {
    private IQuestionData question;
    private IMainListQuestions questions;
    private SingleSelectedQuestion singleSelectedQuestion;
    public Action Test;
    private bool addToDb;
    internal CheckBox singleQuestionCheckBox;
    internal TextBlock singleQuestionTitle;
    internal TextBlock singleQuestionContent;
    private bool _contentLoaded;

    public Action UncheckQuestion => this.Test;

    public SingleQuestion(IQuestionData question, IMainListQuestions questions)
    {
      this.InitializeComponent();
      this.question = question;
      this.questions = questions;
      this.singleQuestionTitle.Text = question.UserFriendlyDescription();
      string questionContent = question.GetQuestionContent();
      this.singleQuestionContent.Text = !((questionContent.Length > 4 ? questionContent.Substring(0, 4) : questionContent) == "http") ? questionContent : questionContent.Substring(questionContent.IndexOf(" ") + 1);
      this.Test += (Action) (() => this.singleQuestionCheckBox.IsChecked = new bool?(false));
      this.singleSelectedQuestion = new SingleSelectedQuestion(question, questions, this.UncheckQuestion);
      if (questions.CheckCheckedQuestions(question))
      {
        this.addToDb = false;
        this.singleQuestionCheckBox.IsChecked = new bool?(true);
      }
      else
        this.addToDb = true;
    }

    private void SingleQuestion_Checked(object sender, RoutedEventArgs e) => this.questions.AddQuestion(this.question, this.singleSelectedQuestion, this.addToDb);

    private void SingleQuestion_Unchecked(object sender, RoutedEventArgs e) => this.questions.RemoveQuestion(this.question, this.singleSelectedQuestion);

    private void SingleQuestion_MouseDown(object sender, MouseButtonEventArgs e)
    {
      CheckBox questionCheckBox = this.singleQuestionCheckBox;
      bool? isChecked = this.singleQuestionCheckBox.IsChecked;
      bool? nullable = isChecked.HasValue ? new bool?(!isChecked.GetValueOrDefault()) : new bool?();
      questionCheckBox.IsChecked = nullable;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/models/listscategoriesandquestions/components/singlequestion.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.SingleQuestion_MouseDown);
          break;
        case 2:
          this.singleQuestionCheckBox = (CheckBox) target;
          this.singleQuestionCheckBox.Checked += new RoutedEventHandler(this.SingleQuestion_Checked);
          this.singleQuestionCheckBox.Unchecked += new RoutedEventHandler(this.SingleQuestion_Unchecked);
          break;
        case 3:
          this.singleQuestionTitle = (TextBlock) target;
          break;
        case 4:
          this.singleQuestionContent = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
