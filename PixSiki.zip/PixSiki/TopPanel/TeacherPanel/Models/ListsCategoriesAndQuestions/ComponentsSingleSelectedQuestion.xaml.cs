﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components.SingleSelectedQuestion
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;

namespace PixBlocks.TopPanel.TeacherPanel.Models.ListsCategoriesAndQuestions.Components
{
  public partial class SingleSelectedQuestion : UserControl, IComponentConnector
  {
    private IMainListQuestions questions;
    private IQuestionData question;
    private SingleQuestion singleQuestion;
    private Action uncheckQuestion;
    internal TextBlock nameQuestion;
    internal TextBlock contentQuestion;
    internal Image btnDelete;
    private bool _contentLoaded;

    public SingleSelectedQuestion(
      IQuestionData question,
      IMainListQuestions questions,
      Action UncheckQuestion)
    {
      this.InitializeComponent();
      this.question = question;
      this.questions = questions;
      this.uncheckQuestion = UncheckQuestion;
      if (questions.IsNewExam)
        this.btnDelete.Visibility = Visibility.Visible;
      else
        this.btnDelete.Visibility = Visibility.Collapsed;
      this.nameQuestion.Text = question.ParenCategory.ListName + " -> " + question.ParenLesson.ListName + " -> " + question.UserFriendlyDescription();
      string questionContent = question.GetQuestionContent();
      if ((questionContent.Length > 4 ? questionContent.Substring(0, 4) : questionContent) == "http")
        this.contentQuestion.Text = questionContent.Substring(questionContent.IndexOf(" ") + 1);
      else
        this.contentQuestion.Text = questionContent;
    }

    private void ImageDeleteQuestion_MouseDown(object sender, MouseButtonEventArgs e) => Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
    {
      Action uncheckQuestion = this.uncheckQuestion;
      if (uncheckQuestion != null)
        uncheckQuestion();
      this.questions.RemoveQuestion(this.question, this);
    }));

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/models/listscategoriesandquestions/components/singleselectedquestion.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.nameQuestion = (TextBlock) target;
          break;
        case 2:
          this.contentQuestion = (TextBlock) target;
          break;
        case 3:
          this.btnDelete = (Image) target;
          this.btnDelete.MouseDown += new MouseButtonEventHandler(this.ImageDeleteQuestion_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
