﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.StudentLoginGenerator
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.Tools;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Helpers;
using System;

namespace PixBlocks.TopPanel.TeacherPanel.Models
{
  internal class StudentLoginGenerator
  {
    public static string GenerateLogin(int idClass, string studentName, int? registerNumber)
    {
      string classCode = StudentsClassCodeParser.CodeToClassCode(new int?(idClass));
      string studentLogin = Authorize.RemoveWhitespaces(classCode + studentName + registerNumber.ToString());
      try
      {
        ServerApi serverApi = new ServerApi();
        if (!serverApi.StudentsLoginsCheckAvaible(studentLogin))
        {
          int num = 0;
          do
          {
            ++num;
            studentLogin = classCode + num.ToString() + studentName + registerNumber.ToString();
          }
          while (!serverApi.StudentsLoginsCheckAvaible(studentLogin));
        }
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(ex.ToString());
      }
      return studentLogin;
    }

    public static string GenerateLogin(int idClass, string studentName) => StudentLoginGenerator.GenerateLogin(idClass, studentName, new int?());
  }
}
