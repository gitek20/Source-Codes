﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility.RefreshEvent
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility
{
  public class RefreshEvent
  {
    public bool canInvoke;

    public event RefreshEvent.Refesh RefreshUserControl;

    public void InvokeRefreshEvent()
    {
      if (this.canInvoke)
      {
        RefreshEvent.Refesh refreshUserControl = this.RefreshUserControl;
        if (refreshUserControl != null)
          refreshUserControl();
      }
      this.canInvoke = false;
    }

    public delegate void Refesh();
  }
}
