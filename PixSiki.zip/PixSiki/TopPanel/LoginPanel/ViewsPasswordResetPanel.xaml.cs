﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Views.PasswordResetPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.LoginPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.LoginPanel.Views
{
  public partial class PasswordResetPanel : UserControl, IComponentConnector
  {
    private ILoginPanelController mainController;
    internal BigCaption bigCaption;
    internal SmallInfoText information;
    internal RoundedTextBoxAndLabel newPassword;
    internal RoundedTextBoxAndLabel confirmNewPassword;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public PasswordResetPanel(ILoginPanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordChange");
      this.newPassword.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (newPassword));
      this.confirmNewPassword.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (confirmNewPassword));
      this.information.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNewPasswordTwice");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.abort.SetColor(RoundedButton.ColorType.white);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("save");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.SaveButton_clickEvent);
      this.actionButtons.confirm.SetColor(RoundedButton.ColorType.blue);
    }

    private void SaveButton_clickEvent()
    {
      string currentUserPassword = CurrentUserInfo.CurrentUser.Md5Password;
      if (this.newPassword.textBoxRounded.textBox.Text.Contains(" ") || this.confirmNewPassword.textBoxRounded.textBox.Text.Contains(" ") || (this.newPassword.TextInside.Trim().Length < 5 || this.confirmNewPassword.TextInside.Trim().Length < 5) || (this.newPassword.TextInside.Length > 25 || this.confirmNewPassword.TextInside.Length > 25))
      {
        if (this.newPassword.TextInside.Trim().Length < 5)
          this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNewPasswordWarn"));
        if (this.newPassword.TextInside.Trim().Length > 25)
          this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNewPasswordWarn"));
        if (this.confirmNewPassword.TextInside.Trim().Length < 5)
          this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNewPasswordAgainWarn"));
        if (this.confirmNewPassword.TextInside.Trim().Length < 25)
          this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNewPasswordAgainWarn"));
        if (this.newPassword.TextInside.Contains(" "))
          this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noSpaces"));
        if (!this.confirmNewPassword.TextInside.Contains(" "))
          return;
        this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noSpaces"));
      }
      else if (this.newPassword.textBoxRounded.passwordBox.Password.Length < 5)
        this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordRange"));
      else if (this.newPassword.textBoxRounded.passwordBox.Password != this.confirmNewPassword.textBoxRounded.passwordBox.Password)
        this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordsDiffer"));
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          ServerApi serverApi = new ServerApi();
          User currentUser = CurrentUserInfo.CurrentUser;
          currentUser.Md5Password = Authorize.ConvertPasswordToMD5(this.confirmNewPassword.TextInside);
          User user = currentUser;
          AuthorizeData authorize = new AuthorizeData(currentUser.Id.Value, currentUserPassword);
          serverApi.UpdateOrDeleteUser(user, authorize);
          this.mainController.ShowLoginView();
        }));
    }

    private void BackButton_clickEvent() => this.mainController.ShowEnterPinPanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/loginpanel/views/passwordresetpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.information = (SmallInfoText) target;
          break;
        case 3:
          this.newPassword = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.confirmNewPassword = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
