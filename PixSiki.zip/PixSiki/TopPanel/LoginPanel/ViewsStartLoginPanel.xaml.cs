﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Views.StartLoginPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Properties;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.DBModels;
using PixBlocks.Server.DataModels.DataModels.Woocommerce;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.LanguageComboBox;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.LoginPanel.Models;
using PixBlocks.UpdaterFTP.Controllers;
using PixBlocks.Views.AdditionalBrandingView;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.LoginPanel.Views
{
  public partial class StartLoginPanel : UserControl, IComponentConnector
  {
    private ILoginPanelController mainController;
    internal RoundedTextBoxAndLabel loginEmail;
    internal RoundedTextBoxAndLabel password;
    internal CheckBox rememberPassword;
    internal ButtonLink forgetPassword;
    internal ButtonLink enterPin;
    internal RoundedButton loginButton;
    internal RoundedButton register;
    internal RoundedButton demoButton;
    internal SmallInfoText classLoginInfo;
    internal ExtendedLanguageComboBox LanguageComboBox;
    private bool _contentLoaded;

    public StartLoginPanel(ILoginPanelController mainController)
    {
      this.InitializeComponent();
      this.mainController = mainController;
      this.loginButton.clickEvent += new RoundedButton.ClickDelegate(this.LoginButton_clickEvent);
      this.enterPin.clickEvent += new ButtonLink.ClickDelegate(this.enterActivationPinAgainEvent);
      this.loginEmail.Description = "Login lub e-mail";
      this.password.Description = "Hasło";
      this.rememberPassword.IsChecked = new bool?(Settings.Default.RememberPassword);
      if (this.rememberPassword.IsChecked.Value)
      {
        string username = Settings.Default.Username;
        string password = Settings.Default.Password;
        if (!username.IsNullOrEmpty() && !password.IsNullOrEmpty())
        {
          this.loginEmail.TextInside = username;
          this.password.TextInside = password;
        }
      }
      this.password.IsInPasswordMode = true;
      this.register.SetColor(RoundedButton.ColorType.white);
      this.register.clickEvent += new RoundedButton.ClickDelegate(this.Register_clickEvent);
      this.forgetPassword.clickEvent += new ButtonLink.ClickDelegate(this.ForgetPassword_clickEvent);
      this.demoButton.SetColor(RoundedButton.ColorType.white);
      this.demoButton.clickEvent += new RoundedButton.ClickDelegate(this.demoButton_clickEvent);
      UserMenager.languageKeyChangedEvet += new UserMenager.LanguageKeyChangedEvet(this.UserMenager_languageKeyChangedEvet);
      this.UserMenager_languageKeyChangedEvet();
      this.LanguageComboBox.selectedItemeEvent += new SimpleLanguageComboBoxItem.SelectedLanguage(this.LanguageComboBox_selectedItemeEvent);
    }

    public void CheckUpdatesMSI()
    {
      if (!PixBlocks.Version.isMSIVersion)
        return;
      new StarterUpdater(this.mainController).CheckUpdateMSI();
    }

    private void enterActivationPinAgainEvent() => this.mainController.ShowNoActivationEmailInfo("");

    private void LanguageComboBox_selectedItemeEvent(SimpleLanguageComboBoxItem.Languages language)
    {
      if (language == SimpleLanguageComboBoxItem.Languages.polish)
        UserMenager.LanguageKey = "PL";
      if (language == SimpleLanguageComboBoxItem.Languages.english)
        UserMenager.LanguageKey = "EN";
      if (language != SimpleLanguageComboBoxItem.Languages.russian)
        return;
      UserMenager.LanguageKey = "RU";
    }

    private void UserMenager_languageKeyChangedEvet()
    {
      this.rememberPassword.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("rememberMe");
      this.loginEmail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("loginOrEmail");
      this.password.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("password");
      this.loginButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("logIn");
      this.register.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("register");
      this.forgetPassword.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("forgetPassword");
      this.enterPin.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("pressYorPinAgain");
      this.demoButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("offlineVer");
      this.classLoginInfo.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("areStudent");
    }

    private void ForgetPassword_clickEvent() => this.mainController.ShowResendPasswordView();

    public event MainLoginPanel.LoginSucessfull loginSucesfullEvent;

    private void LoginButton_clickEvent()
    {
      if (!UserMenager.procedureLoginInvoke)
        UserMenager.procedureLoginInvoke = true;
      GlobalProgressBarManager.RunFuncionAndProgressBar(new Action(this.DoLogin));
    }

    private void DoLogin()
    {
      if (this.password.TextInside.IsNullOrEmpty() || this.loginEmail.TextInside.IsNullOrEmpty())
      {
        if (this.password.TextInside.IsNullOrEmpty())
          this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterYourPassword"));
        if (!this.loginEmail.TextInside.IsNullOrEmpty())
          return;
        this.loginEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterYourLoginOrEmail"));
      }
      else
      {
        ServerApi serverApi = new ServerApi();
        UserAuthorizeResult result1 = serverApi.AuthorizeUser(this.loginEmail.TextInside, this.password.TextInside, false, new LicenseData(UserMenager.LanguageKey, IpGetter.GetIPAddress()));
        AdditionalBrandingManager.SetNewPartnerImage(result1.SchoolLogoInBase64);
        if (this.password.TextInside.Length == 48)
        {
          UserAuthorizeResult result2 = serverApi.AuthorizeUser(this.loginEmail.TextInside, this.password.TextInside, true, new LicenseData(UserMenager.LanguageKey, IpGetter.GetIPAddress()));
          AdditionalBrandingManager.SetNewPartnerImage(result2.SchoolLogoInBase64);
          if (result2.IsUserInDB)
          {
            CurrentUserInfo.CurrentUser = result2.User;
            CurrentUserInfo.pixBlocksLicense = result2.PixBlocksLicense;
            this.ProceedLogin(result2);
            CustomMessageBox.Show("Zalogowałeś się hasłem zakodowanym!");
            return;
          }
        }
        if (result1.IsUserInDB)
        {
          CurrentUserInfo.CurrentUser = result1.User;
          CurrentUserInfo.pixBlocksLicense = result1.PixBlocksLicense;
          if (result1.IsPasswordCorrect)
          {
            this.SaveSignInLog();
            this.RememberPassword(this.loginEmail.TextInside, this.password.TextInside);
            if (!result1.IsStudent)
            {
              if (result1.User.IsEmailActivated)
                this.ProceedLogin(result1);
              else
                this.mainController.ShowNoActivationEmailInfo(this.loginEmail.TextInside);
            }
            else
              this.ProceedLogin(result1);
          }
          else
            this.WrongLoginOrPassword();
        }
        else
          this.WrongLoginOrPassword();
      }
    }

    private void RememberPassword(string login, string password)
    {
      Settings.Default.RememberPassword = this.rememberPassword.IsChecked.Value;
      if (this.rememberPassword.IsChecked.Value)
      {
        Settings.Default.Username = login;
        Settings.Default.Password = password;
      }
      Settings.Default.Save();
    }

    private void SaveSignInLog()
    {
      try
      {
        new ServerApi().SaveUserSignInLog(SignInLog.CreateOnlineSignInLog(CurrentUserInfo.CurrentUser.Id.Value));
      }
      catch
      {
      }
    }

    private void WrongLoginOrPassword()
    {
      this.loginEmail.ShowWarning("Podany login lub hasło jest błędne!");
      this.loginEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("loginOrPasswordIsIncorrect"));
      this.password.ShowWarning("");
    }

    private void ProceedLogin(UserAuthorizeResult result)
    {
      CurrentUserInfo.logoutThisAccount = false;
      CurrentUserInfo.CurrentUser = result.User;
      CurrentUserInfo.loginDate = DateTime.Now;
      UserMenager.IsOffLineUser = false;
      if (this.loginSucesfullEvent == null)
        return;
      this.loginSucesfullEvent();
    }

    private void Register_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => this.mainController.ShowRegistrationView()));

    private void demoButton_clickEvent() => this.mainController.ShowDemoVersionInformation();

    private void LoginOnKeyDownHandler(object sender, KeyEventArgs e)
    {
      if (e.Key == Key.Return)
      {
        if (UserMenager.procedureLoginInvoke)
          return;
        this.LoginButton_clickEvent();
        UserMenager.procedureLoginInvoke = true;
      }
      else
        UserMenager.procedureLoginInvoke = false;
    }

    private void loginButton_Loaded(object sender, RoutedEventArgs e)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/loginpanel/views/startloginpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.loginEmail = (RoundedTextBoxAndLabel) target;
          break;
        case 2:
          this.password = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.rememberPassword = (CheckBox) target;
          break;
        case 4:
          this.forgetPassword = (ButtonLink) target;
          break;
        case 5:
          this.enterPin = (ButtonLink) target;
          break;
        case 6:
          this.loginButton = (RoundedButton) target;
          break;
        case 7:
          this.register = (RoundedButton) target;
          break;
        case 8:
          this.demoButton = (RoundedButton) target;
          break;
        case 9:
          this.classLoginInfo = (SmallInfoText) target;
          break;
        case 10:
          this.LanguageComboBox = (ExtendedLanguageComboBox) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
