﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Views.SendRegistationEmailInfo
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.LoginPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.LoginPanel.Views
{
  public partial class SendRegistationEmailInfo : UserControl, IComponentConnector
  {
    private ILoginPanelController mainController;
    internal BigCaption registrationConfirm;
    internal SmallInfoText smallInfo;
    internal RoundedTextBoxAndLabel pinCode;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public SendRegistationEmailInfo(ILoginPanelController mainController, string email)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.registrationConfirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("registrationFinished");
      this.smallInfo.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPINRegistrationBegin") + email + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPINRegistrationInter") + email + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPINRegistrationEnd");
      this.pinCode.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("PIN");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("activate");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.CheckActivationPinCode_clickEvent);
      this.actionButtons.confirm.SetColor(RoundedButton.ColorType.blue);
    }

    private void CheckActivationPinCode_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      if (this.pinCode.textBoxRounded.textBox.Text == PinCode.PinCodeActivationAccount.ToString())
      {
        CurrentUserInfo.CurrentUser.IsEmailActivated = true;
        new ServerApi().UpdateOrDeleteUser(CurrentUserInfo.CurrentUser, Authorize.AuthorizeCurrentUser());
        this.mainController.ShowLoginView();
      }
      else
        this.pinCode.ShowWarning("Niepoprawny kod PIN ");
    }));

    private void BackButton_clickEvent() => this.mainController.ShowLoginView();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/loginpanel/views/sendregistationemailinfo.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.registrationConfirm = (BigCaption) target;
          break;
        case 2:
          this.smallInfo = (SmallInfoText) target;
          break;
        case 3:
          this.pinCode = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
