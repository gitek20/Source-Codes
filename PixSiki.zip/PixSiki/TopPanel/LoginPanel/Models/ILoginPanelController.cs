﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Models.ILoginPanelController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.TopPanel.LoginPanel.Models
{
  public interface ILoginPanelController
  {
    void ShowRegistrationView();

    void ShowLoginView();

    void ShowResendPasswordView();

    void ShowConfirmRegistrationView(string email);

    void ShowNoActivationEmailInfo(string email);

    void ShowInternetConnectionError();

    void ShowDemoVersionInformation();

    void ShowEnterPinPanel();

    void ShowNewestVersionMSIAvaiable(string url, string fileName);

    void ShowPasswordResetPanel();
  }
}
