﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Models.StartLoginPanelModels.LoginData
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.TopPanel.LoginPanel.Models.StartLoginPanelModels
{
  internal class LoginData
  {
    private string login;
    private string password;

    public LoginData(string login, string password)
    {
      this.login = login;
      this.password = password;
    }

    public string Login => this.login;

    public string Password => this.password;
  }
}
