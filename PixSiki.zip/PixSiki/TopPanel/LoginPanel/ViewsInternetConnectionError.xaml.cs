﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Views.InternetConnectionError
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.LoginPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.LoginPanel.Views
{
  public partial class InternetConnectionError : UserControl, IComponentConnector
  {
    private ILoginPanelController mainController;
    internal BigCaption loginEmail;
    internal SmallInfoTextError smallInfo;
    internal RoundedButton backButton;
    private bool _contentLoaded;

    public InternetConnectionError(ILoginPanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.loginEmail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noInternet");
      this.smallInfo.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("justOffline");
      this.backButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.backButton.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
    }

    private void BackButton_clickEvent() => this.mainController.ShowLoginView();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/loginpanel/views/internetconnectionerror.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.loginEmail = (BigCaption) target;
          break;
        case 2:
          this.smallInfo = (SmallInfoTextError) target;
          break;
        case 3:
          this.backButton = (RoundedButton) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
