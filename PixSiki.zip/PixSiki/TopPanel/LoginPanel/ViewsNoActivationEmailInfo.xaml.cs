﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Views.NoActivationEmailInfo
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.DBModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.LoginPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.LoginPanel.Views
{
  public partial class NoActivationEmailInfo : UserControl, IComponentConnector
  {
    private string email;
    private ILoginPanelController mainController;
    internal BigCaption loginEmail;
    internal SmallInfoTextError smallInfo;
    internal RoundedTextBoxAndLabel emailLabel;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public NoActivationEmailInfo(ILoginPanelController mainController, string email)
    {
      this.mainController = mainController;
      this.email = email;
      this.InitializeComponent();
      this.loginEmail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("verifyEmail");
      this.smallInfo.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("verifyEmailInfo");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("activate");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.ActivateAccount_clickEvent);
      this.actionButtons.confirm.SetColor(RoundedButton.ColorType.blue);
    }

    private void ActivateAccount_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      PinCodeResult pinCodeResult = new ServerApi().SendActivationEmailPin(CurrentUserInfo.CurrentUser.Email, CurrentUserInfo.CurrentUser.Name, "english");
      if (pinCodeResult.EmailSend)
      {
        PinCode.PinCodeActivationAccount = pinCodeResult.PinCode;
        this.mainController.ShowConfirmRegistrationView(this.email);
      }
      else
        CustomMessageBox.Show("Błąd");
    }));

    private void BackButton_clickEvent() => this.mainController.ShowLoginView();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/loginpanel/views/noactivationemailinfo.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.loginEmail = (BigCaption) target;
          break;
        case 2:
          this.smallInfo = (SmallInfoTextError) target;
          break;
        case 3:
          this.emailLabel = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
