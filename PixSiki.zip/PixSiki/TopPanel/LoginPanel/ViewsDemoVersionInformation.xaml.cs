﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Views.DemoVersionInformation
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.DataStorageConfig;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.FaceButtons;
using PixBlocks.TopPanel.LoginPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.LoginPanel.Views
{
  public partial class DemoVersionInformation : UserControl, IComponentConnector
  {
    private ILoginPanelController mainController;
    internal BigCaption loginEmail;
    internal RoundedTextBoxAndLabel loginName;
    internal SmallInfoText avatarDescription;
    internal FacesSelector FaceSelect;
    internal SmallInfoTextError smallInfo;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public DemoVersionInformation(ILoginPanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.loginName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterName");
      this.avatarDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("chooseAvatar");
      this.loginEmail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("offline");
      this.smallInfo.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("offlineWarn");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("begin");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.OkButton_clickEvent);
      this.actionButtons.confirm.SetColor(RoundedButton.ColorType.blue);
      string path1 = DataStorageParams.appUserDataPath + "lastuserface.lastuserface";
      if (File.Exists(path1))
        this.FaceSelect.SetFace(File.ReadAllText(path1));
      string path2 = DataStorageParams.appUserDataPath + "lastuserlogin.lastuserlogin";
      if (File.Exists(path2))
        this.loginName.TextInside = File.ReadAllText(path2);
      this.loginName.textBoxRounded.KeyDown += new KeyEventHandler(this.TextBoxRounded_KeyDown);
    }

    private void TextBoxRounded_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.Key != Key.Return)
        return;
      e.Handled = true;
      this.OkButton_clickEvent();
    }

    private void BackButton_clickEvent() => this.mainController.ShowLoginView();

    public event MainLoginPanel.LoginSucessfull loginSucesfullEvent;

    private void OkButton_clickEvent()
    {
      if (this.loginName.TextInside.IsNullOrEmpty())
      {
        this.loginName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNameWarn"));
      }
      else
      {
        if (!Directory.Exists(DataStorageParams.appUserDataPath))
          Directory.CreateDirectory(DataStorageParams.appUserDataPath);
        File.WriteAllText(DataStorageParams.appUserDataPath + "lastuserlogin.lastuserlogin", this.loginName.TextInside);
        File.WriteAllText(DataStorageParams.appUserDataPath + "lastuserface.lastuserface", this.FaceSelect.GetSelectedFace());
        UserMenager.IsOffLineUser = true;
        UserMenager.SetUserName(this.loginName.TextInside);
        UserMenager.SetUserFace(this.FaceSelect.GetSelectedFace());
        CurrentUserInfo.CurrentUser = new User()
        {
          Name = this.loginName.textBoxRounded.textBox.Text,
          AvatarName = this.FaceSelect.GetSelectedFace()
        };
        if (this.loginSucesfullEvent != null)
          this.loginSucesfullEvent();
        this.SaveSignInLog();
      }
    }

    private void SaveSignInLog()
    {
      try
      {
        new ServerApi().SaveUserSignInLog(SignInLog.CreateOfflineSignInLog());
      }
      catch (Exception ex)
      {
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/loginpanel/views/demoversioninformation.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.loginEmail = (BigCaption) target;
          break;
        case 2:
          this.loginName = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.avatarDescription = (SmallInfoText) target;
          break;
        case 4:
          this.FaceSelect = (FacesSelector) target;
          break;
        case 5:
          this.smallInfo = (SmallInfoTextError) target;
          break;
        case 6:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
