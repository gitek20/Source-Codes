﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.Views.RegisterPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.DBModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.DataStorageConfig;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.CountrySelectorComboBox;
using PixBlocks.TopPanel.Components.FaceButtons;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.LoginPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.LoginPanel.Views
{
  public partial class RegisterPanel : UserControl, IComponentConnector
  {
    private ILoginPanelController mainController;
    private static Regex ValidEmailRegex = RegisterPanel.CreateValidEmailRegex();
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel loginName;
    internal RoundedTextBoxAndLabel loginSurname;
    internal SmallInfoText avatarDescription;
    internal FacesSelector FaceSelect;
    internal RoundedTextBoxAndLabel loginEmail;
    internal RoundedTextBoxAndLabel loginEmail2;
    internal RoundedTextBoxAndLabel password;
    internal RoundedTextBoxAndLabel passwordAgain;
    internal CountrySelector countryKey;
    internal DateTimeComboBox datePicker;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public RegisterPanel(ILoginPanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("registration");
      this.loginName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterName");
      this.loginSurname.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterSurname");
      this.loginEmail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterEmail");
      this.loginEmail.CancelCopyPastle = true;
      this.loginEmail2.CancelCopyPastle = true;
      this.password.IsInPasswordMode = true;
      this.passwordAgain.IsInPasswordMode = true;
      this.loginEmail2.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterEmailAgain");
      this.avatarDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("chooseAvatar");
      this.password.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (password));
      this.passwordAgain.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (passwordAgain));
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.abort.SetColor(RoundedButton.ColorType.white);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("register");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.RegisterButton_clickEvent);
      this.actionButtons.confirm.SetColor(RoundedButton.ColorType.blue);
      this.countryKey.CountryLabel.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("countrySelect");
      this.countryKey.LoadCountries();
      this.datePicker.InitializeDate();
      this.actionButtons.confirm.IsEnabled = true;
    }

    private void ShowTermsInBrowser_ClickEvent()
    {
      try
      {
        string str = new StreamReader(DataStorageParams.appUserDataPath + "languagekey.languagekey").ReadLine();
        if (!(str == "PL"))
        {
          if (!(str == "ENG"))
            return;
          Process.Start("www.pixblocks.com/regulations_ENG.pdf");
        }
        else
          Process.Start("www.pixblocks.com/regulations_PL.pdf");
      }
      catch
      {
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("whereYouFindRegulations"));
      }
    }

    private static Regex CreateValidEmailRegex() => new Regex("^(?!\\.)(\"([^\"\\r\\\\]|\\\\[\"\\r\\\\])*\"|([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\\.)\\.)*)(?<!\\.)@[a-z0-9][\\w\\.-]*[a-z0-9]\\.[a-z][a-z\\.]*[a-z]$", RegexOptions.IgnoreCase);

    internal static bool EmailIsValid(string emailAddress) => RegisterPanel.ValidEmailRegex.IsMatch(emailAddress);

    private bool IsEmailValid(string email) => RegisterPanel.EmailIsValid(email);

    private void RegisterButton_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar(new Action(this.RegisterAction));

    private void RegisterAction()
    {
      if (this.loginName.textBoxRounded.textBox.Text.Trim().Length == 0 || this.loginSurname.textBoxRounded.textBox.Text.Trim().Length == 0 || (this.loginEmail.textBoxRounded.textBox.Text.Trim().Length == 0 || this.password.textBoxRounded.passwordBox.Password.Length == 0) || (this.passwordAgain.textBoxRounded.passwordBox.Password.Length == 0 || this.datePicker.IsEmptyLabel()))
      {
        if (this.loginName.textBoxRounded.textBox.Text.Trim().Length == 0)
          this.loginName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNameWarn"));
        if (this.loginSurname.textBoxRounded.textBox.Text.Trim().Length == 0)
          this.loginSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterSurnameWarn"));
        if (this.loginEmail.textBoxRounded.textBox.Text.Trim().Length == 0)
          this.loginEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterEmailWarn"));
        if (this.password.textBoxRounded.passwordBox.Password.Length == 0)
          this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPasswordWarn"));
        if (this.passwordAgain.textBoxRounded.passwordBox.Password.Length == 0)
          this.passwordAgain.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPasswordAgainWarn"));
        if (!Authorize.CheckEmailFormat(this.loginEmail.textBoxRounded.textBox.Text))
          this.loginEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterValidEmail"));
        if (!Authorize.CheckEmailFormat(this.loginEmail2.textBoxRounded.textBox.Text))
          this.loginEmail2.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterValidEmail"));
        if (!this.datePicker.IsEmptyLabel())
          return;
        this.datePicker.ShowWarnigEmptyDate();
      }
      else if (this.loginName.textBoxRounded.textBox.Text.Length > 30 || this.loginSurname.textBoxRounded.textBox.Text.Length > 30 || this.loginEmail.textBoxRounded.textBox.Text.Length > 50)
      {
        if (this.loginName.textBoxRounded.textBox.Text.Length > 30)
          this.loginName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("max30"));
        else if (this.loginSurname.textBoxRounded.textBox.Text.Length > 30)
        {
          this.loginSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("max30"));
        }
        else
        {
          if (this.loginEmail.textBoxRounded.textBox.Text.Length <= 50)
            return;
          this.loginEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("max50"));
        }
      }
      else if (this.loginEmail.textBoxRounded.TextInside.ToLower() != this.loginEmail2.TextInside.ToLower())
      {
        this.loginEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emailError"));
        this.loginEmail2.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emailError"));
      }
      else if (!this.IsEmailValid(this.loginEmail.TextInside) || this.loginEmail.TextInside.ToLower() != this.loginEmail2.TextInside.ToLower())
        this.loginEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterValidEmail"));
      else if (this.password.TextInside.HasWhitespace())
      {
        this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noSpaces"));
        this.passwordAgain.ShowWarning("");
      }
      else if (this.password.textBoxRounded.passwordBox.Password.Length < 5 || this.password.textBoxRounded.passwordBox.Password.Length > 25)
      {
        this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordRange"));
        this.password.warningLabel.FontSize = 15.0;
        this.passwordAgain.ShowWarning("");
      }
      else if (this.password.textBoxRounded.passwordBox.Password != this.passwordAgain.textBoxRounded.passwordBox.Password)
      {
        this.password.ShowWarning("");
        this.passwordAgain.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordsDiffer"));
      }
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          ServerApi serverApi = new ServerApi();
          User newUser = Users.CreateNewUser(this.loginName.textBoxRounded.textBox.Text, this.loginSurname.textBoxRounded.textBox.Text, this.datePicker.GetDate(), this.FaceSelect.GetSelectedFace(), this.loginEmail.textBoxRounded.textBox.Text, Authorize.ConvertPasswordToMD5(this.passwordAgain.textBoxRounded.passwordBox.Password), this.countryKey.GetCountryId());
          newUser.Student_isStudent = true;
          UserAddingResult result = serverApi.RegisterNewUserAsync(newUser).Result;
          if (result.IsEmailExist)
            this.loginEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emailOccupied"));
          else if (!result.IsEmailExist)
          {
            if (result.User.Email == newUser.Email && result.User.Md5Password == newUser.Md5Password)
            {
              CurrentUserInfo.CurrentUser = result.User;
              PinCodeResult pinCodeResult = serverApi.SendActivationEmailPin(CurrentUserInfo.CurrentUser.Email, CurrentUserInfo.CurrentUser.Name, UserMenager.LanguageKey);
              if (pinCodeResult.EmailSend)
              {
                PinCode.PinCodeActivationAccount = pinCodeResult.PinCode;
                this.mainController.ShowConfirmRegistrationView(CurrentUserInfo.CurrentUser.Email);
              }
              else
              {
                CustomMessageBox.Show("Błąd wysłania mail");
                this.actionButtons.confirm.IsEnabled = true;
              }
            }
            else
              CustomMessageBox.Show("Błąd");
          }
          else
            this.mainController.ShowInternetConnectionError();
        }));
    }

    private void textBox_PreviewExecuted(object sender, ExecutedRoutedEventArgs e)
    {
      if (e.Command != ApplicationCommands.Copy && e.Command != ApplicationCommands.Cut && e.Command != ApplicationCommands.Paste)
        return;
      e.Handled = true;
    }

    private void BackButton_clickEvent() => this.mainController.ShowLoginView();

    private void AcceptTerms_Checked(object sender, RoutedEventArgs e) => this.actionButtons.confirm.IsEnabled = true;

    private void AcceptTerms_Unchecked(object sender, RoutedEventArgs e) => this.actionButtons.confirm.IsEnabled = false;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/loginpanel/views/registerpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.loginName = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.loginSurname = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.avatarDescription = (SmallInfoText) target;
          break;
        case 5:
          this.FaceSelect = (FacesSelector) target;
          break;
        case 6:
          this.loginEmail = (RoundedTextBoxAndLabel) target;
          break;
        case 7:
          this.loginEmail2 = (RoundedTextBoxAndLabel) target;
          break;
        case 8:
          this.password = (RoundedTextBoxAndLabel) target;
          this.password.AddHandler(CommandManager.PreviewExecutedEvent, (Delegate) new ExecutedRoutedEventHandler(this.textBox_PreviewExecuted));
          break;
        case 9:
          this.passwordAgain = (RoundedTextBoxAndLabel) target;
          this.passwordAgain.AddHandler(CommandManager.PreviewExecutedEvent, (Delegate) new ExecutedRoutedEventHandler(this.textBox_PreviewExecuted));
          break;
        case 10:
          this.countryKey = (CountrySelector) target;
          break;
        case 11:
          this.datePicker = (DateTimeComboBox) target;
          break;
        case 12:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
