﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.GlobalProgressBar.GlobalProgressBarManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace PixBlocks.TopPanel.GlobalProgressBar
{
  public static class GlobalProgressBarManager
  {
    private static PixBlocks.TopPanel.GlobalProgressBar.GlobalProgressBar globalProgressBar = new PixBlocks.TopPanel.GlobalProgressBar.GlobalProgressBar();
    private static Grid mainGridStatic;
    public static Action actionstatic;
    private static bool otherProcessIsRunning = false;

    public static void SetMainGrid(Grid mainGrid)
    {
      GlobalProgressBarManager.mainGridStatic = mainGrid;
      GlobalProgressBarManager.globalProgressBar.SetMainGrid(mainGrid);
    }

    public static void ShowProgressBar() => GlobalProgressBarManager.globalProgressBar.Show();

    public static void HideProgressBar() => GlobalProgressBarManager.globalProgressBar.StartHiding();

    public static void RunFuncionAndProgressBar(Action action)
    {
      if (GlobalProgressBarManager.otherProcessIsRunning)
        action();
      GlobalProgressBarManager.otherProcessIsRunning = true;
      GlobalProgressBarManager.actionstatic = action;
      GlobalProgressBarManager.ShowProgressBar();
      BackgroundWorker backgroundWorker = new BackgroundWorker();
      backgroundWorker.DoWork += new DoWorkEventHandler(GlobalProgressBarManager.BackgroundWorker_DoWork);
      backgroundWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(GlobalProgressBarManager.BackgroundWorker_RunWorkerCompleted);
      backgroundWorker.RunWorkerAsync();
    }

    private static void BackgroundWorker_RunWorkerCompleted(
      object sender,
      RunWorkerCompletedEventArgs e)
    {
      Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
      {
        GlobalProgressBarManager.HideProgressBar();
        GlobalProgressBarManager.otherProcessIsRunning = false;
      }));
    }

    private static void BackgroundWorker_DoWork(object sender, DoWorkEventArgs e) => Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
    {
      try
      {
        GlobalProgressBarManager.actionstatic();
      }
      catch (Exception ex)
      {
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
      }
    }));
  }
}
