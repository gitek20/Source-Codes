﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.GlobalProgressBar.GlobalProgressBar
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;

namespace PixBlocks.TopPanel.GlobalProgressBar
{
  public partial class GlobalProgressBar : UserControl, IComponentConnector
  {
    private Grid mainGridStatic;
    private DispatcherTimer timer = new DispatcherTimer(DispatcherPriority.Send);
    private double mainOpacity = 1.0;
    internal Grid NoClickGrid;
    internal Grid mainInfo;
    internal Label loadingContent;
    private bool _contentLoaded;

    public GlobalProgressBar()
    {
      this.InitializeComponent();
      this.timer.Tick += new EventHandler(this.Timer_Tick);
      this.timer.Interval = new TimeSpan(0, 0, 0, 0, 2);
    }

    public void SetMainGrid(Grid mainGridStatic) => this.mainGridStatic = mainGridStatic;

    internal void Show()
    {
      if (this.mainGridStatic == null)
        return;
      if (!this.mainGridStatic.Children.Contains((UIElement) this))
      {
        this.mainGridStatic.Children.Add((UIElement) this);
        this.mainGridStatic.UpdateLayout();
        Thread.Sleep(10);
        this.mainGridStatic.UpdateLayout();
      }
      this.NoClickGrid.Visibility = Visibility.Visible;
      this.mainInfo.Opacity = 1.0;
      this.mainOpacity = 1.0;
      this.timer.Stop();
    }

    internal void StartHiding() => this.timer.Start();

    private void Timer_Tick(object sender, EventArgs e)
    {
      this.mainOpacity -= 0.1;
      this.mainOpacity = Math.Max(this.mainOpacity, 0.0);
      this.mainInfo.Opacity = this.mainOpacity;
      if (this.mainOpacity != 0.0)
        return;
      this.timer.Stop();
      if (!this.mainGridStatic.Children.Contains((UIElement) this))
        return;
      this.mainGridStatic.Children.Remove((UIElement) this);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/globalprogressbar/globalprogressbar.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.NoClickGrid = (Grid) target;
          break;
        case 2:
          this.mainInfo = (Grid) target;
          break;
        case 3:
          this.loadingContent = (Label) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
