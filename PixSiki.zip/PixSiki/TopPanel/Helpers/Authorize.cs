﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Helpers.Authorize
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.UserManagment;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;

namespace PixBlocks.TopPanel.Helpers
{
  internal class Authorize
  {
    public static string RemoveWhitespaces(string text) => text = text.Replace(" ", string.Empty);

    public static string ConvertPasswordToMD5(string input)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (byte num in new MD5CryptoServiceProvider().ComputeHash(new UTF8Encoding().GetBytes(input)))
        stringBuilder.Append(num.ToString("x3"));
      return stringBuilder.ToString();
    }

    public static AuthorizeData AuthorizeCurrentUser() => new AuthorizeData(CurrentUserInfo.CurrentUser);

    public static bool CheckEmailFormat(string email)
    {
      try
      {
        return new MailAddress(email).Address == email;
      }
      catch
      {
        return false;
      }
    }

    public static bool CheckForInternetConnection()
    {
      try
      {
        using (WebClient webClient = new WebClient())
        {
          using (webClient.OpenRead("http://clients3.google.com/generate_204"))
            return true;
        }
      }
      catch
      {
        return false;
      }
    }
  }
}
