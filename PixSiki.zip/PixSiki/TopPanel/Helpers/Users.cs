﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Helpers.Users
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using System;

namespace PixBlocks.TopPanel.Helpers
{
  internal class Users
  {
    public static User CreateNewUser(
      string name,
      string surname,
      DateTime dateOfBrith,
      string avatarName,
      string email,
      string password,
      int countryId)
    {
      return new User()
      {
        Name = name,
        Surname = surname,
        DateOfBirth = new DateTime?(dateOfBrith),
        AvatarName = avatarName,
        Email = email,
        Md5Password = password,
        CountryId = new int?(countryId)
      };
    }
  }
}
