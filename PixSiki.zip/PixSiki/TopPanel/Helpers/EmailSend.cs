﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Helpers.EmailSend
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.ServerAPI;

namespace PixBlocks.TopPanel.Helpers
{
  internal class EmailSend
  {
    public static bool SenderActivationEmail(
      string email,
      string idUser,
      string userName,
      string password)
    {
      ServerApi serverApi = new ServerApi();
      return true;
    }
  }
}
