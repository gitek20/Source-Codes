﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.PasswordChangedInfo
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class PasswordChangedInfo : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    internal BigCaption info;
    internal RoundedButton confirm;
    private bool _contentLoaded;

    public PasswordChangedInfo(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.info.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordChanged");
      this.confirm.clickEvent += new RoundedButton.ClickDelegate(this.Confirm_clickEvent);
      this.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("ok");
    }

    private void Confirm_clickEvent() => this.mainController.ShowStartPreferencePanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/passwordchangedinfo.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.confirm = (RoundedButton) target;
        else
          this._contentLoaded = true;
      }
      else
        this.info = (BigCaption) target;
    }
  }
}
