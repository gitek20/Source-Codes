﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.BecomeTeacherPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class BecomeTeacherPanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel schoolName;
    internal RoundedTextBoxAndLabel email;
    internal RoundedTextBoxAndLabel phone;
    internal RoundedTextBoxAndLabel city;
    internal RoundedTextBoxAndLabel address;
    internal RoundedTextBoxAndLabel password;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public BecomeTeacherPanel(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("becomeTeacher");
      this.city.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("town");
      this.schoolName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (schoolName));
      this.phone.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("schoolPhoneNumber");
      this.email.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("schoolEmailAddress");
      this.address.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("schoolAddress");
      this.password.IsInPasswordMode = true;
      this.password.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("yourPassword");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("confirm");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.ConfirmButton_clickEvent);
    }

    private void ConfirmButton_clickEvent()
    {
      string md5 = Authorize.ConvertPasswordToMD5(this.password.TextInside);
      if (!this.schoolName.TextInside.IsNullOrWhiteSpace())
      {
        if (this.schoolName.TextInside.Split("-"[0]).Length == 3 && this.schoolName.TextInside.Contains("391-"))
        {
          GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
          {
            try
            {
              ServerApi serverApi = new ServerApi();
              User currentUser = CurrentUserInfo.CurrentUser;
              currentUser.Student_isStudent = false;
              currentUser.Teacher_isTeacher = true;
              School school = serverApi.AddSchool(new School(this.schoolName.TextInside, this.phone.TextInside, this.email.TextInside, this.city.TextInside, this.address.TextInside, currentUser.Id.GetValueOrDefault()), Authorize.AuthorizeCurrentUser());
              currentUser.Teacher_schoolId = new int?(school.Id);
              currentUser.Teacher_isAssignedToSchool = true;
              currentUser.Teacher_isAcceptedToSchool = true;
              serverApi.UpdateOrDeleteUser(currentUser, new AuthorizeData(currentUser));
              this.mainController.ShowBecomeTeacherInfo();
            }
            catch (Exception ex)
            {
              int num = (int) MessageBox.Show(ex.Message);
            }
          }));
          return;
        }
      }
      if (this.city.TextInside.IsNullOrWhiteSpace() || this.schoolName.TextInside.IsNullOrWhiteSpace() || (this.phone.TextInside.IsNullOrWhiteSpace() || this.email.TextInside.IsNullOrWhiteSpace()) || (!Authorize.CheckEmailFormat(this.email.TextInside) || this.address.TextInside.IsNullOrWhiteSpace() || (this.password.TextInside.IsNullOrWhiteSpace() || CurrentUserInfo.CurrentUser.Md5Password != md5)))
      {
        if (this.city.TextInside.IsNullOrWhiteSpace())
          this.city.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("townWarn"));
        if (this.schoolName.TextInside.IsNullOrWhiteSpace())
          this.schoolName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("schoolNameWarn"));
        if (this.phone.TextInside.IsNullOrWhiteSpace())
          this.phone.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("phoneNumberWarn"));
        if (this.email.TextInside.IsNullOrWhiteSpace())
          this.email.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("schoolEmailWarn"));
        else if (!Authorize.CheckEmailFormat(this.email.TextInside))
          this.email.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterValidEmail"));
        if (this.address.TextInside.IsNullOrWhiteSpace())
          this.address.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addressWarn"));
        if (this.password.TextInside.IsNullOrWhiteSpace())
        {
          this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPasswordWarn"));
        }
        else
        {
          if (!(CurrentUserInfo.CurrentUser.Md5Password != md5))
            return;
          this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("wrongPassword"));
        }
      }
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          ServerApi serverApi = new ServerApi();
          User currentUser = CurrentUserInfo.CurrentUser;
          currentUser.Student_isStudent = false;
          currentUser.Teacher_isTeacher = true;
          School school = serverApi.AddSchool(new School(this.schoolName.TextInside, this.phone.TextInside, this.email.TextInside, this.city.TextInside, this.address.TextInside, currentUser.Id.GetValueOrDefault()), Authorize.AuthorizeCurrentUser());
          currentUser.Teacher_schoolId = new int?(school.Id);
          currentUser.Teacher_isAssignedToSchool = true;
          currentUser.Teacher_isAcceptedToSchool = true;
          serverApi.UpdateOrDeleteUser(currentUser, new AuthorizeData(currentUser));
          this.mainController.ShowBecomeTeacherInfo();
        }));
    }

    private void BackButton_clickEvent() => this.mainController.ShowStartPreferencePanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/becometeacherpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.schoolName = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.email = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.phone = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.city = (RoundedTextBoxAndLabel) target;
          break;
        case 6:
          this.address = (RoundedTextBoxAndLabel) target;
          break;
        case 7:
          this.password = (RoundedTextBoxAndLabel) target;
          break;
        case 8:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
