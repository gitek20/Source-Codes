﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.LicenseKeyPanelView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Woocommerce;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class LicenseKeyPanelView : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    private ServerApi serverApi;
    internal BigCaption bigCaption;
    internal Grid GridPanel;
    internal SmallInfoText myLicense;
    internal Rectangle backRectange;
    internal SmallInfoText myBlocks;
    internal SmallInfoText myPython;
    internal SmallInfoText teacherLicense;
    internal Rectangle backRectange2;
    internal SmallInfoText teacherBlocks;
    internal SmallInfoText teacherPython;
    internal SmallInfoText teacherconnectedStudents;
    internal SmallInfoText teacherMaxConnectedStudents;
    internal RoundedTextBoxAndLabel enterKey;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public LicenseKeyPanelView(IPreferencePanelController mainController)
    {
      this.InitializeComponent();
      this.mainController = mainController;
      this.serverApi = new ServerApi();
      this.myLicense.textBlocks.FontSize = 22.0;
      this.myBlocks.textBlocks.FontSize = 20.0;
      this.myPython.textBlocks.FontSize = 20.0;
      this.teacherBlocks.textBlocks.FontSize = 20.0;
      this.teacherPython.textBlocks.FontSize = 20.0;
      this.teacherLicense.textBlocks.FontSize = 22.0;
      this.myBlocks.textBlocks.FontWeight = FontWeights.Bold;
      this.myPython.textBlocks.FontWeight = FontWeights.Bold;
      this.teacherBlocks.textBlocks.FontWeight = FontWeights.Bold;
      this.teacherPython.textBlocks.FontWeight = FontWeights.Bold;
      this.RefreshView();
    }

    private void RefreshView()
    {
      this.myLicense.textBlocks.FontWeight = FontWeights.UltraBold;
      this.teacherLicense.textBlocks.FontWeight = FontWeights.UltraBold;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("license");
      this.myLicense.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("myLicenses");
      string str1 = "";
      DateTime dateTime;
      string str2;
      DateTime? nullable;
      if (CurrentUserInfo.pixBlocksLicense != null && CurrentUserInfo.pixBlocksLicense.ExpiresAtBlocksContent.HasValue)
      {
        string str3 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("validFor");
        dateTime = CurrentUserInfo.pixBlocksLicense.ExpiresAtBlocksContent.Value;
        dateTime = dateTime.Date;
        string str4 = dateTime.ToString("MM/dd/yyyy");
        str2 = str3 + " " + str4;
        nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtBlocksContent;
        dateTime = CurrentUserInfo.pixBlocksLicense.ServerDateNow;
        if ((nullable.HasValue ? (nullable.GetValueOrDefault() < dateTime ? 1 : 0) : 0) != 0)
        {
          str2 = str2 + " (" + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("licenseHasExpired") + ")";
          this.myBlocks.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Red);
        }
        else
          this.myBlocks.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Green);
      }
      else
        str2 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emptyLicense") ?? "";
      string str5 = "";
      string str6;
      if (CurrentUserInfo.pixBlocksLicense != null)
      {
        nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtPythonContent;
        if (nullable.HasValue)
        {
          string str3 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("validFor");
          nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtPythonContent;
          dateTime = nullable.Value;
          dateTime = dateTime.Date;
          string str4 = dateTime.ToString("MM/dd/yyyy");
          str6 = str3 + " " + str4;
          nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtPythonContent;
          dateTime = CurrentUserInfo.pixBlocksLicense.ServerDateNow;
          if ((nullable.HasValue ? (nullable.GetValueOrDefault() < dateTime ? 1 : 0) : 0) != 0)
          {
            str6 = str6 + " (" + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("licenseHasExpired") + ")";
            this.myPython.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Red);
            goto label_11;
          }
          else
          {
            this.myPython.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Green);
            goto label_11;
          }
        }
      }
      str6 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emptyLicense") ?? "";
label_11:
      this.myBlocks.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("blocks") + ": " + str2;
      this.myPython.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("python") + ": " + str6;
      bool? acceptedToStudentsClass = CurrentUserInfo.CurrentUser.Student_isAcceptedToStudentsClass;
      if (!acceptedToStudentsClass.Value && !CurrentUserInfo.CurrentUser.Teacher_isTeacher)
      {
        this.teacherLicense.Visibility = Visibility.Collapsed;
        this.teacherBlocks.Visibility = Visibility.Collapsed;
        this.teacherBlocks.Visibility = Visibility.Collapsed;
        this.teacherconnectedStudents.Visibility = Visibility.Collapsed;
        this.teacherMaxConnectedStudents.Visibility = Visibility.Collapsed;
      }
      if (CurrentUserInfo.pixBlocksLicense != null)
      {
        acceptedToStudentsClass = CurrentUserInfo.CurrentUser.Student_isAcceptedToStudentsClass;
        if (acceptedToStudentsClass.Value)
        {
          this.teacherLicense.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("schoolLicense");
          string str3;
          if (CurrentUserInfo.pixBlocksLicense.IsTeacherBlocksActive)
          {
            str3 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("yes");
            this.teacherBlocks.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Green);
          }
          else
            str3 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("no");
          string str4;
          if (CurrentUserInfo.pixBlocksLicense.IsTeacherPythonActive)
          {
            str4 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("yes");
            this.teacherPython.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Green);
          }
          else
            str4 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("no");
          this.teacherBlocks.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("blocks") + ": " + str3;
          this.teacherPython.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("python") + ": " + str4;
          this.teacherconnectedStudents.Visibility = Visibility.Collapsed;
          this.teacherMaxConnectedStudents.Visibility = Visibility.Collapsed;
        }
      }
      if (CurrentUserInfo.CurrentUser.Teacher_isTeacher)
      {
        this.backRectange2.Visibility = Visibility.Visible;
        this.teacherLicense.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("teacherLicene");
        str1 = "";
        string str3;
        if (CurrentUserInfo.pixBlocksLicense != null)
        {
          nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtBlocksContentToMyStudents;
          if (nullable.HasValue)
          {
            string str4 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("validFor");
            nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtBlocksContentToMyStudents;
            dateTime = nullable.Value;
            dateTime = dateTime.Date;
            string str7 = dateTime.ToString("MM/dd/yyyy");
            str3 = str4 + ": " + str7;
            nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtBlocksContentToMyStudents;
            dateTime = CurrentUserInfo.pixBlocksLicense.ServerDateNow;
            if ((nullable.HasValue ? (nullable.GetValueOrDefault() < dateTime ? 1 : 0) : 0) != 0)
            {
              str3 = str3 + " (" + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("licenseHasExpired") + ")";
              this.teacherBlocks.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Red);
              goto label_29;
            }
            else
            {
              this.teacherBlocks.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Green);
              goto label_29;
            }
          }
        }
        str3 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emptyLicense");
label_29:
        str5 = "";
        string str8;
        if (CurrentUserInfo.pixBlocksLicense != null)
        {
          nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtPythonContentToMyStudents;
          if (nullable.HasValue)
          {
            string str4 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("validFor");
            nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtPythonContentToMyStudents;
            dateTime = nullable.Value;
            dateTime = dateTime.Date;
            string str7 = dateTime.ToString("MM/dd/yyyy");
            str8 = str4 + ": " + str7;
            nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtPythonContentToMyStudents;
            dateTime = CurrentUserInfo.pixBlocksLicense.ServerDateNow;
            if ((nullable.HasValue ? (nullable.GetValueOrDefault() < dateTime ? 1 : 0) : 0) != 0)
            {
              str8 = str8 + " (" + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("licenseHasExpired") + ")";
              this.teacherPython.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Red);
              goto label_35;
            }
            else
            {
              this.teacherPython.textBlocks.Foreground = (Brush) new SolidColorBrush(Colors.Green);
              goto label_35;
            }
          }
        }
        str8 = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emptyLicense");
label_35:
        this.teacherBlocks.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("blocks") + " " + str3;
        this.teacherPython.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("python") + " " + str8;
        nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtBlocksContentToMyStudents;
        if (!nullable.HasValue)
        {
          nullable = CurrentUserInfo.pixBlocksLicense.ExpiresAtPythonContentToMyStudents;
          if (!nullable.HasValue)
          {
            this.teacherconnectedStudents.Visibility = Visibility.Collapsed;
            this.teacherMaxConnectedStudents.Visibility = Visibility.Collapsed;
            goto label_39;
          }
        }
        this.teacherconnectedStudents.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("connectedStudents") + ": " + CurrentUserInfo.pixBlocksLicense.ConnectedStudents.ToString();
        this.teacherMaxConnectedStudents.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("maxConnectedStudents") + ": " + CurrentUserInfo.pixBlocksLicense.MaxConnectedStudents.ToString();
      }
label_39:
      this.enterKey.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterYourLicenseKey");
      this.enterKey.textBoxRounded.textBox.HorizontalContentAlignment = HorizontalAlignment.Center;
      this.enterKey.textBoxRounded.textBox.CharacterCasing = CharacterCasing.Upper;
      this.enterKey.textBoxRounded.textBox.MaxLength = 19;
      this.actionButtons.confirm.SetEnable(false);
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.Abort_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("activate");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.Confirm_clickEvent);
    }

    private void RefreshPixBlocksLicense() => CurrentUserInfo.pixBlocksLicense = this.serverApi.GetActivePixBlocksLicense(CurrentUserInfo.AuthorizeData, new LicenseData(UserMenager.LanguageKey, IpGetter.GetIPAddress()));

    private void Confirm_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      if (this.enterKey.textBoxRounded.textBox.Text.Length == 0)
      {
        this.enterKey.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("errorKey"));
      }
      else
      {
        AuthorizeData authorizeData = new AuthorizeData(CurrentUserInfo.CurrentUser);
        string message;
        switch (this.serverApi.ActivateLicenseKey(this.enterKey.textBoxRounded.textBox.Text, IpGetter.GetIPAddress(), CurrentUserInfo.AuthorizeData))
        {
          case ResponseActivationKeyStatus.KeyActivate:
            this.RefreshPixBlocksLicense();
            this.RefreshView();
            this.enterKey.textBoxRounded.textBox.Text = "";
            message = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("successfullyActivateKey");
            break;
          case ResponseActivationKeyStatus.KeyAlreadyActivated:
            message = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("keyAlreadyActivated");
            break;
          case ResponseActivationKeyStatus.KeyActivationLimit:
            message = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("keyActivationLimit");
            break;
          case ResponseActivationKeyStatus.KeyExpired:
            message = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("keyExpired");
            break;
          case ResponseActivationKeyStatus.KeyOnlyForTeacher:
            message = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("keyOnlyForTeacher");
            break;
          case ResponseActivationKeyStatus.KeyNotFound:
            message = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("keyNotFound");
            break;
          case ResponseActivationKeyStatus.Error404:
            message = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("error404");
            break;
          default:
            message = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("error404");
            break;
        }
        CustomMessageBox.Show(message);
      }
    }));

    private void Abort_clickEvent() => this.mainController.ShowStartPreferencePanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/licensekeypanelview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.GridPanel = (Grid) target;
          break;
        case 3:
          this.myLicense = (SmallInfoText) target;
          break;
        case 4:
          this.backRectange = (Rectangle) target;
          break;
        case 5:
          this.myBlocks = (SmallInfoText) target;
          break;
        case 6:
          this.myPython = (SmallInfoText) target;
          break;
        case 7:
          this.teacherLicense = (SmallInfoText) target;
          break;
        case 8:
          this.backRectange2 = (Rectangle) target;
          break;
        case 9:
          this.teacherBlocks = (SmallInfoText) target;
          break;
        case 10:
          this.teacherPython = (SmallInfoText) target;
          break;
        case 11:
          this.teacherconnectedStudents = (SmallInfoText) target;
          break;
        case 12:
          this.teacherMaxConnectedStudents = (SmallInfoText) target;
          break;
        case 13:
          this.enterKey = (RoundedTextBoxAndLabel) target;
          break;
        case 14:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
