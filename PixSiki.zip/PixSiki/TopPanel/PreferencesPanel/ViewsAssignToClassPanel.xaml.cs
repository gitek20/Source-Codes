﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.AssignToClassPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.Tools;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class AssignToClassPanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    internal BigCaption bigCaption;
    internal SmallInfoText instruction;
    internal RoundedTextBoxAndLabel classID;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public AssignToClassPanel(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classJoin");
      this.classID.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (classID));
      this.instruction.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classIDInfo");
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("join");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.AssignButton_clickEvent);
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
    }

    private void AssignButton_clickEvent()
    {
      if (string.IsNullOrWhiteSpace(this.classID.TextInside))
        this.classID.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classIDWarn"));
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          ServerApi serverApi = new ServerApi();
          int? code = StudentsClassCodeParser.ClasCodeToCode(this.classID.TextInside.ToUpper().TrimEnd(' ').TrimStart(' '));
          if (code.HasValue)
          {
            StudentsClass studentsClassById = serverApi.GetStudentsClassById(code.Value, new AuthorizeData(CurrentUserInfo.CurrentUser));
            if (studentsClassById != null)
            {
              CurrentUserInfo.CurrentUser = serverApi.AddUserToStudentsClass(studentsClassById, CurrentUserInfo.CurrentUser, new AuthorizeData(CurrentUserInfo.CurrentUser));
              this.mainController.ShowStartPreferencePanel();
            }
            else
              this.classID.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noClass"));
          }
          else
            this.classID.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noClass"));
        }));
    }

    private void BackButton_clickEvent() => this.mainController.ShowStartPreferencePanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/assigntoclasspanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.instruction = (SmallInfoText) target;
          break;
        case 3:
          this.classID = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
