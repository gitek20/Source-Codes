﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Models.IPreferencePanelController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;

namespace PixBlocks.TopPanel.PreferencesPanel.Models
{
  public interface IPreferencePanelController
  {
    void ShowProfileEditPanel();

    void ShowStartPreferencePanel();

    void ShowPasswordEditPanel();

    void ShowAssignToClassPanel();

    void ShowUnassignFromClassPanel();

    void ShowSetEmailPanel();

    void ShowEnterPinPanel(string email);

    void ShowRemoveAccountPanel();

    void ShowRemoveAccountInfo();

    void ShowBecomeTeacherPanel();

    void ShowPasswordChangedInfo();

    void ShowBecomeTeacherInfo();

    void ShowImportFromOfflineProfile();

    void ShowUnassignFromClassInfo();

    void ShowEditSchool(School school);

    void ShowEnterLicenseKeyPanel();
  }
}
