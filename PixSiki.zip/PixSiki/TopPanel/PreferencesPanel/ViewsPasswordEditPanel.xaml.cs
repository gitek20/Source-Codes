﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.PasswordEditPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class PasswordEditPanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel currentPassword;
    internal RoundedTextBoxAndLabel newPassword;
    internal RoundedTextBoxAndLabel confirmNewPassword;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public PasswordEditPanel(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordChange");
      this.currentPassword.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (currentPassword));
      this.newPassword.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (newPassword));
      this.confirmNewPassword.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (confirmNewPassword));
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("save");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.SaveButton_clickEvent);
    }

    private void SaveButton_clickEvent()
    {
      string currentUserPassword = CurrentUserInfo.CurrentUser.Md5Password;
      if (this.newPassword.TextInside.HasWhitespace() || this.confirmNewPassword.TextInside.HasWhitespace() || (this.currentPassword.TextInside.Trim().Length == 0 || this.newPassword.TextInside.Trim().Length == 0) || (this.confirmNewPassword.TextInside.Trim().Length == 0 || this.newPassword.TextInside.Length > 25 || (this.confirmNewPassword.TextInside.Length > 25 || Authorize.ConvertPasswordToMD5(this.currentPassword.TextInside) != currentUserPassword)))
      {
        if (this.confirmNewPassword.TextInside.Trim().Length > 25)
          this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordRange"));
        if (this.newPassword.TextInside.Trim().Length > 25)
          this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordRange"));
        if (Authorize.ConvertPasswordToMD5(this.currentPassword.TextInside) != currentUserPassword)
          this.currentPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("currentPasswordWarn"));
        if (this.newPassword.TextInside.Trim().Length == 0)
          this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNewPasswordWarn"));
        if (this.confirmNewPassword.TextInside.Trim().Length == 0)
          this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNewPasswordAgainWarn"));
        if (this.newPassword.TextInside.HasWhitespace())
          this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noSpaces"));
        if (!this.confirmNewPassword.TextInside.HasWhitespace())
          return;
        this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noSpaces"));
      }
      else if (this.currentPassword.textBoxRounded.passwordBox.Password.Length < 5)
        this.currentPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("min5"));
      else if (this.newPassword.textBoxRounded.passwordBox.Password.Length < 5)
        this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("min5"));
      else if (this.newPassword.textBoxRounded.passwordBox.Password != this.confirmNewPassword.textBoxRounded.passwordBox.Password)
      {
        this.newPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordsDiffer"));
        this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordsDiffer"));
      }
      else if (this.currentPassword.textBoxRounded.passwordBox.Password == this.newPassword.textBoxRounded.passwordBox.Password)
        this.confirmNewPassword.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordsMustDiffer"));
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          ServerApi serverApi = new ServerApi();
          User currentUser = CurrentUserInfo.CurrentUser;
          currentUser.Md5Password = Authorize.ConvertPasswordToMD5(this.confirmNewPassword.TextInside);
          User user = currentUser;
          AuthorizeData authorize = new AuthorizeData(currentUser.Id.Value, currentUserPassword);
          serverApi.UpdateOrDeleteUser(user, authorize);
          this.mainController.ShowPasswordChangedInfo();
        }));
    }

    private void BackButton_clickEvent() => this.mainController.ShowStartPreferencePanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/passwordeditpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.currentPassword = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.newPassword = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.confirmNewPassword = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
