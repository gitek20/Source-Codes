﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.RemoveAccountInfo
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class RemoveAccountInfo : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    internal BigCaption bigCaption;
    internal SmallInfoText information;
    internal RoundedButton OkButton;
    private bool _contentLoaded;

    public RemoveAccountInfo(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("accountDeleted");
      this.information.Description = "";
      this.OkButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("ok");
      this.OkButton.clickEvent += new RoundedButton.ClickDelegate(this.OkButton_clickEvent);
    }

    public event RemoveAccountInfo.LogoutAction LogoutEvent;

    private void OkButton_clickEvent()
    {
      if (this.LogoutEvent == null)
        return;
      this.LogoutEvent();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/removeaccountinfo.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.information = (SmallInfoText) target;
          break;
        case 3:
          this.OkButton = (RoundedButton) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void LogoutAction();
  }
}
