﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.EnterSetEmailPinPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class EnterSetEmailPinPanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    private string email;
    internal BigCaption bigCaption;
    internal SmallInfoText information;
    internal RoundedTextBoxAndLabel enterPin;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public EnterSetEmailPinPanel(string email, IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.email = email;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPIN");
      this.enterPin.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("PIN");
      this.information.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPINpanel");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("next");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.ConfirmPin_clickEvent);
    }

    private void BackButton_clickEvent() => this.mainController.ShowSetEmailPanel();

    private void ConfirmPin_clickEvent()
    {
      if (this.enterPin.textBoxRounded.textBox.Text == PinCode.PinCodeResetPassword.ToString())
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          ServerApi serverApi = new ServerApi();
          User currentUser = CurrentUserInfo.CurrentUser;
          AuthorizeData authorizeData = new AuthorizeData(currentUser);
          currentUser.Email = this.email;
          currentUser.IsEmailActivated = true;
          currentUser.Md5Password = Authorize.ConvertPasswordToMD5(currentUser.Student_explicitPassword);
          currentUser.Student_explicitPassword = (string) null;
          User user = currentUser;
          AuthorizeData authorize = authorizeData;
          serverApi.UpdateOrDeleteUser(user, authorize);
          this.mainController.ShowStartPreferencePanel();
        }));
      else
        this.enterPin.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("invalidPIN"));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/entersetemailpinpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.information = (SmallInfoText) target;
          break;
        case 3:
          this.enterPin = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
