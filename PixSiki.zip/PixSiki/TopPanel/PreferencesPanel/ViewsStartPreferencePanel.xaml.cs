﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.StartPreferencePanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.FaceButtons;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.UserMenagment.ToyShopMenager;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class StartPreferencePanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    private School resultSchool;
    internal BigCaption bigCaption;
    internal ProfilePreview profilePreview;
    internal RoundedButton editProfile;
    internal RoundedButton activateLicenseKey;
    internal RoundedButton assignToClass;
    internal RoundedButton editSchoolData;
    internal RoundedButton setEMail;
    internal RoundedButton changePassword;
    internal RoundedButton becomeTeacher;
    internal RoundedButton importOfflineUser;
    internal RoundedButton removeAccount;
    private bool _contentLoaded;

    public StartPreferencePanel(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.importOfflineUser.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("importProfile");
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("userProfile");
      this.editProfile.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (editProfile));
      this.importOfflineUser.clickEvent += new RoundedButton.ClickDelegate(this.ImportOfflineUser_clickEvent);
      this.editProfile.clickEvent += new RoundedButton.ClickDelegate(this.EditProfile_clickEvent);
      this.becomeTeacher.clickEvent += new RoundedButton.ClickDelegate(this.BecomeTeacher_clickEvent);
      this.activateLicenseKey.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("licenses");
      this.activateLicenseKey.clickEvent += new RoundedButton.ClickDelegate(this.ActivateLicenseKey_clickEvent);
      if (CurrentUserInfo.checkLicenseStatus)
        this.activateLicenseKey.Visibility = Visibility.Visible;
      if (CurrentUserInfo.pixBlocksLicense == null || CurrentUserInfo.pixBlocksLicense.IsFreeLicense)
        this.activateLicenseKey.Visibility = Visibility.Collapsed;
      this.profilePreview.pointsSize.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("allUserPoints") + ": " + (StaticToyManager.ToysInfos.GetTotalMoneyInRoom() + QuestionsPointsCounter.GetPointsForCurrentUser() - 6).ToString();
      if (!CurrentUserInfo.CurrentUser.Student_isAssignedToStudentsClass)
      {
        this.assignToClass.clickEvent += new RoundedButton.ClickDelegate(this.AssignToClass_clickEvent);
        this.assignToClass.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classJoin");
      }
      else
      {
        this.assignToClass.clickEvent += new RoundedButton.ClickDelegate(this.UnassignFromClass_clickEvent);
        this.assignToClass.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classLeave");
      }
      if (CurrentUserInfo.CurrentUser.Teacher_isTeacher)
        this.assignToClass.Visibility = Visibility.Collapsed;
      if (string.IsNullOrEmpty(CurrentUserInfo.CurrentUser.Email))
      {
        this.setEMail.clickEvent += new RoundedButton.ClickDelegate(this.SetEMail_clickEvent);
        this.setEMail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("setEmail");
        this.removeAccount.Visibility = Visibility.Collapsed;
        this.becomeTeacher.Visibility = Visibility.Collapsed;
        this.changePassword.Visibility = Visibility.Collapsed;
        this.assignToClass.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.becomeTeacher.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("iAmTeacher");
        this.setEMail.Visibility = Visibility.Collapsed;
        this.removeAccount.clickEvent += new RoundedButton.ClickDelegate(this.RemoveAccount_clickEvent);
        this.removeAccount.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("deleteAccount");
        this.changePassword.clickEvent += new RoundedButton.ClickDelegate(this.ChangePassword_clickEvent);
        this.changePassword.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (changePassword));
      }
      if (CurrentUserInfo.CurrentUser.Student_isStudent)
      {
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          string studentsClassName;
          if (!CurrentUserInfo.CurrentUser.Student_studentsClassId.HasValue)
          {
            studentsClassName = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noClassAttached");
          }
          else
          {
            StudentsClass studentsClassById = new ServerApi().GetStudentsClassById(CurrentUserInfo.CurrentUser.Student_studentsClassId.Value, new AuthorizeData(CurrentUserInfo.CurrentUser));
            studentsClassName = !CurrentUserInfo.CurrentUser.Student_isAcceptedToStudentsClass.Value ? studentsClassById.Name + " " + PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("waitingForAcceptance") : studentsClassById.Name;
          }
          string email = CurrentUserInfo.CurrentUser.Email != null ? CurrentUserInfo.CurrentUser.Email : PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noAddress");
          this.profilePreview.ShowInfo(FacesSelector.GetCurrentUserAvatar(), new UserShortInfo(CurrentUserInfo.CurrentUser.Name, CurrentUserInfo.CurrentUser.Surname, email, studentsClassName), "student");
        }));
      }
      else
      {
        if (!CurrentUserInfo.CurrentUser.Teacher_isTeacher)
          return;
        this.becomeTeacher.Visibility = Visibility.Collapsed;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          string studentsClassName;
          if (!CurrentUserInfo.CurrentUser.Teacher_schoolId.HasValue)
          {
            studentsClassName = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noSchoolAttached");
          }
          else
          {
            this.resultSchool = new ServerApi().GetSchool(CurrentUserInfo.CurrentUser, Authorize.AuthorizeCurrentUser());
            studentsClassName = this.resultSchool.Name;
            this.editSchoolData.Visibility = Visibility.Visible;
            this.editSchoolData.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (editSchoolData));
            this.editSchoolData.clickEvent += new RoundedButton.ClickDelegate(this.SchoolEditPanel_clickEvent);
          }
          string email = CurrentUserInfo.CurrentUser.Email != null ? CurrentUserInfo.CurrentUser.Email : PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noAddress");
          this.profilePreview.ShowInfo(FacesSelector.GetCurrentUserAvatar(), new UserShortInfo(CurrentUserInfo.CurrentUser.Name, CurrentUserInfo.CurrentUser.Surname, email, studentsClassName), "teacher");
        }));
      }
    }

    private void ActivateLicenseKey_clickEvent() => this.mainController.ShowEnterLicenseKeyPanel();

    private void SchoolEditPanel_clickEvent() => this.mainController.ShowEditSchool(this.resultSchool);

    private void ImportOfflineUser_clickEvent() => this.mainController.ShowImportFromOfflineProfile();

    private void BecomeTeacher_clickEvent() => this.mainController.ShowBecomeTeacherPanel();

    private void RemoveAccount_clickEvent() => this.mainController.ShowRemoveAccountPanel();

    private void SetEMail_clickEvent() => this.mainController.ShowSetEmailPanel();

    private void UnassignFromClass_clickEvent() => this.mainController.ShowUnassignFromClassPanel();

    private void AssignToClass_clickEvent() => this.mainController.ShowAssignToClassPanel();

    private void ChangePassword_clickEvent() => this.mainController.ShowPasswordEditPanel();

    private void EditProfile_clickEvent() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() => this.mainController.ShowProfileEditPanel()));

    private void profilePreview_Loaded(object sender, RoutedEventArgs e)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/startpreferencepanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.profilePreview = (ProfilePreview) target;
          break;
        case 3:
          this.editProfile = (RoundedButton) target;
          break;
        case 4:
          this.activateLicenseKey = (RoundedButton) target;
          break;
        case 5:
          this.assignToClass = (RoundedButton) target;
          break;
        case 6:
          this.editSchoolData = (RoundedButton) target;
          break;
        case 7:
          this.setEMail = (RoundedButton) target;
          break;
        case 8:
          this.changePassword = (RoundedButton) target;
          break;
        case 9:
          this.becomeTeacher = (RoundedButton) target;
          break;
        case 10:
          this.importOfflineUser = (RoundedButton) target;
          break;
        case 11:
          this.removeAccount = (RoundedButton) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
