﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.BecomeTeacherInfo
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class BecomeTeacherInfo : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    internal BigCaption info;
    internal SmallInfoText logout;
    internal RoundedButton confirm;
    private bool _contentLoaded;

    public BecomeTeacherInfo(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.logout.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("youWillBeLogout");
      this.info.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("youBecameTeacher");
      this.confirm.clickEvent += new RoundedButton.ClickDelegate(this.Confirm_clickEvent);
      this.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("ok");
    }

    public event BecomeTeacherInfo.LogoutAction LogoutEvent;

    private void Confirm_clickEvent()
    {
      if (this.LogoutEvent == null)
        return;
      this.LogoutEvent();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/becometeacherinfo.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.info = (BigCaption) target;
          break;
        case 2:
          this.logout = (SmallInfoText) target;
          break;
        case 3:
          this.confirm = (RoundedButton) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void LogoutAction();
  }
}
