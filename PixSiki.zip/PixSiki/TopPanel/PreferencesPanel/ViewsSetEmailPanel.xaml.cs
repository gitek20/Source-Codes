﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.SetEmailPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.DBModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class SetEmailPanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    internal BigCaption bigCaption;
    internal SmallInfoText information;
    internal RoundedTextBoxAndLabel newEmail;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public SetEmailPanel(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("addEmail");
      this.information.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterEmailAdd");
      this.newEmail.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterEmail");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("next");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.SaveButton_clickEvent);
    }

    private void SaveButton_clickEvent()
    {
      string email = this.newEmail.TextInside;
      if (!Authorize.CheckEmailFormat(email))
      {
        if (Authorize.CheckEmailFormat(email))
          return;
        this.newEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterValidEmail"));
      }
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          ServerApi serverApi = new ServerApi();
          if (!serverApi.IsUserInDB(email))
          {
            PinCodeResult pinCodeResult = serverApi.SendSetEmailMessage(email, CurrentUserInfo.CurrentUser.Student_login, UserMenager.LanguageKey);
            if (!pinCodeResult.EmailSend)
              return;
            CurrentUserInfo.CurrentUser = pinCodeResult.Userin;
            PinCode.PinCodeResetPassword = pinCodeResult.PinCode;
            this.mainController.ShowEnterPinPanel(email);
          }
          else
            this.newEmail.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("emailOccupied"));
        }));
    }

    private void BackButton_clickEvent() => this.mainController.ShowStartPreferencePanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/setemailpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.information = (SmallInfoText) target;
          break;
        case 3:
          this.newEmail = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
