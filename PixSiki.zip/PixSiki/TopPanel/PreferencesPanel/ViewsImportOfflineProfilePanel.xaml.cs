﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.ImportOfflineProfilePanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Tools;
using PixBlocks.Tools.DataStorageConfig;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using PixBlocks.UserMenagment.StaticEditedCodeMenager;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.UserMenagment.UserProfileSaverAndLoader;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class ImportOfflineProfilePanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    private List<string> logins = new List<string>();
    internal BigCaption bigCaption;
    internal SmallInfoText instruction;
    internal RoundedTextBoxAndLabel offlineUserName;
    internal ActionButtons actionButtons;
    internal RoundedButton importButton;
    private bool _contentLoaded;

    public ImportOfflineProfilePanel(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("importProfile");
      this.offlineUserName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("offlineLogin");
      this.offlineUserName.textBoxRounded.textChangedEvent += new RoundedTextBox.TextChanged(this.TextBoxRounded_textChangedEvent);
      this.instruction.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("importInstruction");
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("import");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.Confirm_clickEvent);
      this.importButton.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.importButton.SetColor(RoundedButton.ColorType.white);
      this.importButton.clickEvent += new RoundedButton.ClickDelegate(this.Abort_clickEvent);
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.Abort_clickEvent);
      this.actionButtons.confirm.SetEnable(true);
      foreach (string str in Directory.EnumerateFiles(DataStorageParams.appUserDataPath).ToList<string>())
      {
        if (str.Contains(".userprofile"))
          this.logins.Add(str.ToLower().Replace(".userprofile", "").Replace(DataStorageParams.appUserDataPath.ToLower(), ""));
      }
    }

    private void TextBoxRounded_textChangedEvent(string text)
    {
      if (this.logins.Contains(text.ToLower()))
        this.actionButtons.confirm.SetEnable(false);
      else
        this.actionButtons.confirm.SetEnable(true);
    }

    private void Abort_clickEvent() => this.mainController.ShowStartPreferencePanel();

    private void Confirm_clickEvent()
    {
      UserProfileData userProfileData = (UserProfileData) BinarySerializer.Deserialize(DataStorageParams.appUserDataPath + this.offlineUserName.textBoxRounded.TextInside.ToLower() + ".userprofile");
      int num = 0;
      foreach (QuestionPoint questionPoint in userProfileData.QuestionPoints)
      {
        Question question = new Question();
        question.UniqueGuid = questionPoint.UniqueQuestionID;
        if (QuestionsPointsCounter.GetQuestionPoints(question) == 0)
        {
          ++num;
          QuestionsPointsCounter.SetQuestionPoints(question, questionPoint.NumberOfPoints);
        }
      }
      foreach (EditedQuestionCode questionsCode in userProfileData.QuestionsCodes)
      {
        EditedQuestionCode editedQuestionCode = QuestionsCodesManager.GetEditedQuestionCode(new Question()
        {
          UniqueGuid = questionsCode.UniqueQuestionName
        });
        if (editedQuestionCode == null)
        {
          QuestionsCodesManager.AddEditedQuestionCodeFromOfflineProfile(questionsCode);
        }
        else
        {
          questionsCode.CompressCodeAndBitmap();
          editedQuestionCode.CompressCodeAndBitmap();
          if (this.SizeOfString(editedQuestionCode.CodeCompressed) < this.SizeOfString(questionsCode.CodeCompressed) && this.SizeOfString(editedQuestionCode.ImageInBase64Compressed) <= this.SizeOfString(questionsCode.ImageInBase64Compressed))
            QuestionsCodesManager.AddEditedQuestionCodeFromOfflineProfile(questionsCode);
        }
      }
      this.offlineUserName.Visibility = Visibility.Collapsed;
      this.instruction.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("importSuccess");
      this.instruction.HorizontalAlignment = HorizontalAlignment.Center;
      this.actionButtons.Visibility = Visibility.Collapsed;
      this.importButton.Visibility = Visibility.Visible;
    }

    private int SizeOfString(string s) => s == null ? 0 : s.Length;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/importofflineprofilepanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.instruction = (SmallInfoText) target;
          break;
        case 3:
          this.offlineUserName = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        case 5:
          this.importButton = (RoundedButton) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
