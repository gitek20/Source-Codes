﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.ProfileEditPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Woocommerce;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.CountrySelectorComboBox;
using PixBlocks.TopPanel.Components.FaceButtons;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class ProfileEditPanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    private DateTime dDate;
    private bool saveDateBirth;
    private DateTime date;
    internal BigCaption bigCaption;
    internal RoundedTextBoxAndLabel loginName;
    internal RoundedTextBoxAndLabel loginSurname;
    internal RoundedTextBoxAndLabel dateOfBirth;
    internal CountrySelector countryKey;
    internal DateTimeComboBox dateTimeComboBox;
    internal SmallInfoText avatarDescription;
    internal FacesSelector Face;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public ProfileEditPanel(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("profileEdit");
      this.loginName.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterName");
      this.loginSurname.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterSurname");
      this.avatarDescription.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("chooseAvatar");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("save");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.SaveButton_clickEvent);
      this.loginName.textBoxRounded.textBox.Text = CurrentUserInfo.CurrentUser.Name;
      this.loginSurname.textBoxRounded.textBox.Text = CurrentUserInfo.CurrentUser.Surname;
      this.dateTimeComboBox.InitializeDate();
      if (CurrentUserInfo.CurrentUser.DateOfBirth.HasValue)
      {
        DateTimeComboBox dateTimeComboBox = this.dateTimeComboBox;
        int year = CurrentUserInfo.CurrentUser.DateOfBirth.Value.Year;
        DateTime dateTime = CurrentUserInfo.CurrentUser.DateOfBirth.Value;
        int month = dateTime.Month;
        dateTime = CurrentUserInfo.CurrentUser.DateOfBirth.Value;
        int day = dateTime.Day;
        DateTime date = new DateTime(year, month, day);
        dateTimeComboBox.SetDate(date);
      }
      this.Face.SetFace(CurrentUserInfo.CurrentUser.AvatarName);
      if (string.IsNullOrEmpty(CurrentUserInfo.CurrentUser.Email))
      {
        this.loginName.IsEnabled = false;
        this.loginSurname.IsEnabled = false;
      }
      this.countryKey.LoadCountries();
      int? countryId = CurrentUserInfo.CurrentUser.CountryId;
      if (countryId.HasValue)
      {
        CountrySelector countryKey = this.countryKey;
        countryId = CurrentUserInfo.CurrentUser.CountryId;
        int idCountry = countryId.Value;
        countryKey.SetCountryId(idCountry);
      }
      else
        this.countryKey.SetCountryId(177);
    }

    private void SaveButton_clickEvent()
    {
      if (this.loginName.textBoxRounded.textBox.Text.Length < 1 || this.loginSurname.textBoxRounded.textBox.Text.Length < 1 || (this.loginName.textBoxRounded.textBox.Text.Length > 100 || this.loginSurname.textBoxRounded.textBox.Text.Length > 100) || (ProfileEditPanel.hasSpecialChar(this.loginName.textBoxRounded.textBox.Text) || ProfileEditPanel.hasSpecialChar(this.loginSurname.textBoxRounded.textBox.Text)))
      {
        if (this.loginName.textBoxRounded.textBox.Text.Length < 1)
          this.loginName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterNameWarn"));
        if (this.loginSurname.textBoxRounded.textBox.Text.Length < 1)
          this.loginSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterSurnameWarn"));
        if (this.loginName.textBoxRounded.textBox.Text.Length > 100 || this.loginSurname.textBoxRounded.textBox.Text.Length > 100)
        {
          if (this.loginName.textBoxRounded.textBox.Text.Length > 100)
            this.loginName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("nameIsToLong"));
          if (this.loginSurname.textBoxRounded.textBox.Text.Length > 100)
            this.loginSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("surnameIsToLong"));
        }
        if (!ProfileEditPanel.hasSpecialChar(this.loginName.textBoxRounded.textBox.Text) && !ProfileEditPanel.hasSpecialChar(this.loginSurname.textBoxRounded.textBox.Text))
          return;
        if (ProfileEditPanel.hasSpecialChar(this.loginName.textBoxRounded.textBox.Text))
          this.loginName.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("nameHaveSpecialChar"));
        if (!ProfileEditPanel.hasSpecialChar(this.loginSurname.textBoxRounded.textBox.Text))
          return;
        this.loginSurname.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("surnameHaveSpecialChar"));
      }
      else if (!this.dateTimeComboBox.CheckAllEmpty())
      {
        if (this.dateTimeComboBox.CheckFormatDate())
        {
          this.saveDateBirth = true;
          this.UpdateUser();
        }
        else
          this.saveDateBirth = false;
      }
      else
        this.UpdateUser();
    }

    public static bool hasSpecialChar(string input)
    {
      foreach (char ch in "\\|!#$%&/()=?»«@£§€{}.-;'<>_,^+”*[]:`~")
      {
        if (input.Contains<char>(ch))
          return true;
      }
      return false;
    }

    public void UpdateUser() => GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
    {
      ServerApi serverApi = new ServerApi();
      User currentUser = CurrentUserInfo.CurrentUser;
      currentUser.Name = this.loginName.textBoxRounded.textBox.Text;
      currentUser.Surname = this.loginSurname.textBoxRounded.textBox.Text;
      currentUser.AvatarName = this.Face.GetSelectedFace();
      currentUser.CountryId = new int?(this.countryKey.GetCountryId());
      if (this.saveDateBirth)
        currentUser.DateOfBirth = new DateTime?(this.dateTimeComboBox.GetDate());
      serverApi.UpdateOrDeleteUser(currentUser, Authorize.AuthorizeCurrentUser());
      CurrentUserInfo.pixBlocksLicense = serverApi.GetActivePixBlocksLicense(new AuthorizeData(currentUser), new LicenseData(UserMenager.LanguageKey, IpGetter.GetIPAddress()));
      this.mainController.ShowStartPreferencePanel();
      CurrentUserInfo.CurrentUser = currentUser;
    }));

    private void BackButton_clickEvent() => this.mainController.ShowStartPreferencePanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/profileeditpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.loginName = (RoundedTextBoxAndLabel) target;
          break;
        case 3:
          this.loginSurname = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.dateOfBirth = (RoundedTextBoxAndLabel) target;
          break;
        case 5:
          this.countryKey = (CountrySelector) target;
          break;
        case 6:
          this.dateTimeComboBox = (DateTimeComboBox) target;
          break;
        case 7:
          this.avatarDescription = (SmallInfoText) target;
          break;
        case 8:
          this.Face = (FacesSelector) target;
          break;
        case 9:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
