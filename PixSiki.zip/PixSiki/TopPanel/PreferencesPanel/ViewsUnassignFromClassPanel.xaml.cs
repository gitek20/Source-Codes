﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.Views.UnassignFromClassPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.TopPanel.Helpers;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel.Views
{
  public partial class UnassignFromClassPanel : UserControl, IComponentConnector
  {
    private IPreferencePanelController mainController;
    internal BigCaption bigCaption;
    internal SmallInfoText instruction;
    internal RoundedTextBoxAndLabel password;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public UnassignFromClassPanel(IPreferencePanelController mainController)
    {
      this.mainController = mainController;
      this.InitializeComponent();
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("classLeave");
      this.password.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID(nameof (password));
      this.instruction.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("passwordToLeaveClass");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.BackButton_clickEvent);
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("leave");
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.UnassignButton_clickEvent);
    }

    private void UnassignButton_clickEvent()
    {
      string md5 = Authorize.ConvertPasswordToMD5(this.password.TextInside);
      if (string.IsNullOrWhiteSpace(this.password.TextInside))
        this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterPasswordWarn"));
      else if (CurrentUserInfo.CurrentUser.Md5Password != md5)
        this.password.ShowWarning(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("wrongPassword"));
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          CurrentUserInfo.CurrentUser = new ServerApi().RemoveUserFromStudentsClass(CurrentUserInfo.CurrentUser, new AuthorizeData(CurrentUserInfo.CurrentUser));
          this.mainController.ShowUnassignFromClassInfo();
        }));
    }

    private void BackButton_clickEvent() => this.mainController.ShowStartPreferencePanel();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/views/unassignfromclasspanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.instruction = (SmallInfoText) target;
          break;
        case 3:
          this.password = (RoundedTextBoxAndLabel) target;
          break;
        case 4:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
