﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.PreferencesPanel.MainPreferencePanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using PixBlocks.TopPanel.PreferencesPanel.Views;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.PreferencesPanel
{
  public partial class MainPreferencePanel : UserControl, IPreferencePanelController, IComponentConnector
  {
    private GenericPopUp popUp;
    internal Grid mainGrid;
    private bool _contentLoaded;

    public MainPreferencePanel()
    {
      this.InitializeComponent();
      this.popUp = new GenericPopUp();
      StartPreferencePanel startPreferencePanel = new StartPreferencePanel((IPreferencePanelController) this);
      this.popUp.IsCloseButton(false);
      this.popUp.AddComponent((UserControl) startPreferencePanel);
      this.mainGrid.Children.Add((UIElement) this.popUp);
    }

    public void ShowPasswordChangedInfo() => this.popUp.AddComponent((UserControl) new PasswordChangedInfo((IPreferencePanelController) this));

    public void ShowProfileEditPanel() => this.popUp.AddComponent((UserControl) new ProfileEditPanel((IPreferencePanelController) this));

    public void ShowStartPreferencePanel() => this.popUp.AddComponent((UserControl) new StartPreferencePanel((IPreferencePanelController) this));

    public void ShowPasswordEditPanel() => this.popUp.AddComponent((UserControl) new PasswordEditPanel((IPreferencePanelController) this));

    public void ShowAssignToClassPanel() => this.popUp.AddComponent((UserControl) new AssignToClassPanel((IPreferencePanelController) this));

    public void ShowUnassignFromClassPanel() => this.popUp.AddComponent((UserControl) new UnassignFromClassPanel((IPreferencePanelController) this));

    public void ShowSetEmailPanel() => this.popUp.AddComponent((UserControl) new SetEmailPanel((IPreferencePanelController) this));

    public void ShowEnterPinPanel(string email) => this.popUp.AddComponent((UserControl) new EnterSetEmailPinPanel(email, (IPreferencePanelController) this));

    public void ShowRemoveAccountPanel() => this.popUp.AddComponent((UserControl) new RemoveAccountPanel((IPreferencePanelController) this));

    public event RemoveAccountInfo.LogoutAction LogoutEvent;

    private void RemoveAccountInfo_LogoutEvent()
    {
      RemoveAccountInfo.LogoutAction logoutEvent = this.LogoutEvent;
      if (logoutEvent == null)
        return;
      logoutEvent();
    }

    public void ShowRemoveAccountInfo()
    {
      RemoveAccountInfo removeAccountInfo = new RemoveAccountInfo((IPreferencePanelController) this);
      removeAccountInfo.LogoutEvent += new RemoveAccountInfo.LogoutAction(this.RemoveAccountInfo_LogoutEvent);
      this.popUp.AddComponent((UserControl) removeAccountInfo);
    }

    public void ShowBecomeTeacherPanel() => this.popUp.AddComponent((UserControl) new BecomeTeacherPanel((IPreferencePanelController) this));

    public void ShowBecomeTeacherInfo()
    {
      BecomeTeacherInfo becomeTeacherInfo = new BecomeTeacherInfo((IPreferencePanelController) this);
      becomeTeacherInfo.LogoutEvent += new BecomeTeacherInfo.LogoutAction(this.RemoveAccountInfo_LogoutEvent);
      this.popUp.AddComponent((UserControl) becomeTeacherInfo);
    }

    public void ShowImportFromOfflineProfile() => this.popUp.AddComponent((UserControl) new ImportOfflineProfilePanel((IPreferencePanelController) this));

    public void ShowUnassignFromClassInfo()
    {
      UnassignFromClassInfo unassignFromClassInfo = new UnassignFromClassInfo((IPreferencePanelController) this);
      unassignFromClassInfo.LogoutEvent += new UnassignFromClassInfo.LogoutAction(this.RemoveAccountInfo_LogoutEvent);
      this.popUp.AddComponent((UserControl) unassignFromClassInfo);
    }

    public void ShowEditSchool(School school) => this.popUp.AddComponent((UserControl) new SchoolEdit((IPreferencePanelController) this, school));

    public void ShowEnterLicenseKeyPanel() => this.popUp.AddComponent((UserControl) new LicenseKeyPanelView((IPreferencePanelController) this));

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/preferencespanel/mainpreferencepanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.mainGrid = (Grid) target;
      else
        this._contentLoaded = true;
    }
  }
}
