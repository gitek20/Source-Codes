﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.TecherPanel.LeftListItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.TopPanel.Components.TecherPanel
{
  public partial class LeftListItem : UserControl, IComponentConnector
  {
    private bool isSelected;
    internal Grid selectedRectangle3;
    internal Grid deselectedRectangle;
    internal Grid enterdRectangle;
    internal TextBlock textBox;
    internal Grid iconGrid;
    private bool _contentLoaded;

    public LeftListItem()
    {
      this.InitializeComponent();
      this.IsSelected = false;
      this.enterdRectangle.Visibility = Visibility.Collapsed;
    }

    public LeftListItem(UserControl icon)
    {
      this.InitializeComponent();
      this.IsSelected = false;
      this.enterdRectangle.Visibility = Visibility.Collapsed;
      this.iconGrid.Children.Add((UIElement) icon);
    }

    public event LeftListItem.OnSelection selectionEvent;

    public string Description
    {
      set => this.textBox.Text = value;
    }

    public bool IsSelected
    {
      set
      {
        this.isSelected = value;
        if (value)
        {
          if (this.selectionEvent != null)
            this.selectionEvent(this);
          this.selectedRectangle3.Visibility = Visibility.Visible;
          this.deselectedRectangle.Visibility = Visibility.Collapsed;
          this.enterdRectangle.Visibility = Visibility.Collapsed;
          this.textBox.Foreground = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));
        }
        else
        {
          this.selectedRectangle3.Visibility = Visibility.Collapsed;
          this.deselectedRectangle.Visibility = Visibility.Visible;
          this.enterdRectangle.Visibility = Visibility.Collapsed;
          this.textBox.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 35, (byte) 35, (byte) 35));
        }
      }
      get => this.isSelected;
    }

    private void Grid_MouseEnter(object sender, MouseEventArgs e)
    {
      if (this.isSelected)
        return;
      this.enterdRectangle.Visibility = Visibility.Visible;
    }

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.enterdRectangle.Visibility = Visibility.Collapsed;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e) => this.IsSelected = true;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/techerpanel/leftlistitem.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.selectedRectangle3 = (Grid) target;
          break;
        case 2:
          this.deselectedRectangle = (Grid) target;
          break;
        case 3:
          this.enterdRectangle = (Grid) target;
          break;
        case 4:
          this.textBox = (TextBlock) target;
          break;
        case 5:
          this.iconGrid = (Grid) target;
          break;
        case 6:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void OnSelection(LeftListItem listItem);
  }
}
