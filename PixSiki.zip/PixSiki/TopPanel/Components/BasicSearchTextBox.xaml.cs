﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.SearchTextBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.Basic
{
  public partial class SearchTextBox : UserControl, IComponentConnector
  {
    public Action<string> onTextChanged;
    private bool isInWarningMode;
    private bool isInPasswordMode;
    internal Rectangle backRectange;
    internal Rectangle warningRect;
    internal Viewbox viewbox;
    internal Grid gridInViewBox;
    internal TextBox textBox;
    internal Label placeholder;
    internal Image loupeIcon;
    internal Image xButton;
    private bool _contentLoaded;

    public SearchTextBox()
    {
      this.InitializeComponent();
      this.xButton.Visibility = Visibility.Hidden;
      this.textBox.TextChanged += new TextChangedEventHandler(this.TextBox_TextChanged);
      this.IsInWarningMode = false;
      this.placeholder.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("search");
    }

    private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
      TextBox textBox = sender as TextBox;
      if (textBox.Text.Length > 0)
      {
        this.placeholder.Visibility = Visibility.Collapsed;
        this.xButton.Visibility = Visibility.Visible;
        this.loupeIcon.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.placeholder.Visibility = Visibility.Visible;
        this.xButton.Visibility = Visibility.Collapsed;
        this.loupeIcon.Visibility = Visibility.Visible;
      }
      Action<string> onTextChanged = this.onTextChanged;
      if (onTextChanged == null)
        return;
      onTextChanged(textBox.Text);
    }

    public string TextInside
    {
      get => this.textBox.Text;
      set => this.textBox.Text = value;
    }

    public bool IsInWarningMode
    {
      set
      {
        this.isInWarningMode = value;
        this.warningRect.Visibility = this.isInWarningMode ? Visibility.Visible : Visibility.Hidden;
      }
      get => this.isInWarningMode;
    }

    public bool IsInPasswordMode
    {
      set
      {
        this.isInPasswordMode = value;
        this.textBox.Visibility = this.isInPasswordMode ? Visibility.Collapsed : Visibility.Visible;
      }
      get => this.isInPasswordMode;
    }

    public string Placeholder
    {
      get => (string) this.placeholder.Content;
      set => this.placeholder.Content = (object) value;
    }

    private void textBox_GotFocus(object sender, RoutedEventArgs e) => this.backRectange.Stroke = (Brush) new SolidColorBrush(Colors.CornflowerBlue);

    private void textBox_LostFocus(object sender, RoutedEventArgs e) => this.backRectange.Stroke = (Brush) new SolidColorBrush(Colors.LightGray);

    private void UserControl_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
      if (this.IsEnabled)
      {
        this.textBox.FontWeight = FontWeights.Normal;
        this.backRectange.Visibility = Visibility.Visible;
      }
      else
      {
        this.textBox.FontWeight = FontWeights.Bold;
        this.textBox.Foreground = (Brush) new SolidColorBrush(Colors.Black);
        this.backRectange.Visibility = Visibility.Collapsed;
      }
    }

    private void xButton_Click(object sender, RoutedEventArgs e) => this.textBox.Text = "";

    private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      Grid gridInViewBox1 = this.gridInViewBox;
      double actualWidth = this.ActualWidth;
      Thickness margin1 = this.viewbox.Margin;
      double left = margin1.Left;
      margin1 = this.viewbox.Margin;
      double right = margin1.Right;
      double num1 = left + right;
      double num2 = (actualWidth - num1) / 3.0;
      gridInViewBox1.Width = num2;
      Grid gridInViewBox2 = this.gridInViewBox;
      double actualHeight = this.ActualHeight;
      Thickness margin2 = this.viewbox.Margin;
      double top = margin2.Top;
      margin2 = this.viewbox.Margin;
      double bottom = margin2.Bottom;
      double num3 = top + bottom;
      double num4 = (actualHeight - num3) / 3.0;
      gridInViewBox2.Height = num4;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/searchtextbox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).IsEnabledChanged += new DependencyPropertyChangedEventHandler(this.UserControl_IsEnabledChanged);
          ((FrameworkElement) target).SizeChanged += new SizeChangedEventHandler(this.UserControl_SizeChanged);
          break;
        case 2:
          this.backRectange = (Rectangle) target;
          break;
        case 3:
          this.warningRect = (Rectangle) target;
          break;
        case 4:
          this.viewbox = (Viewbox) target;
          break;
        case 5:
          this.gridInViewBox = (Grid) target;
          break;
        case 6:
          this.textBox = (TextBox) target;
          this.textBox.GotFocus += new RoutedEventHandler(this.textBox_GotFocus);
          this.textBox.LostFocus += new RoutedEventHandler(this.textBox_LostFocus);
          break;
        case 7:
          this.placeholder = (Label) target;
          break;
        case 8:
          this.loupeIcon = (Image) target;
          break;
        case 9:
          this.xButton = (Image) target;
          this.xButton.MouseDown += new MouseButtonEventHandler(this.xButton_Click);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
