﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.RoundedButton
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.Basic
{
  public partial class RoundedButton : UserControl, IComponentConnector
  {
    public static bool isClicked;
    private bool isSmallCircle;
    private Image sender;
    internal Grid mainGrid;
    internal Rectangle shadow2;
    internal Rectangle shadow1;
    internal Rectangle blueRect;
    internal Rectangle gradient;
    internal Image imageBtn;
    internal TextBlock buttonText;
    internal Grid iconGrid;
    private bool _contentLoaded;

    public RoundedButton() => this.InitializeComponent();

    public event RoundedButton.ClickDelegate clickEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.clickEvent == null || RoundedButton.isClicked)
        return;
      this.clickEvent();
    }

    internal void SetImage(UserControl backIcon)
    {
      this.iconGrid.Children.Clear();
      this.iconGrid.Children.Add((UIElement) backIcon);
    }

    private void Rectangle_MouseEnter(object sender, MouseEventArgs e)
    {
      this.blueRect.Opacity = 0.6;
      this.shadow1.Visibility = Visibility.Collapsed;
      this.shadow2.Visibility = Visibility.Collapsed;
    }

    private void Rectangle_MouseLeave(object sender, MouseEventArgs e)
    {
      this.blueRect.Opacity = 1.0;
      this.shadow1.Visibility = Visibility.Visible;
      this.shadow2.Visibility = Visibility.Visible;
    }

    public void SetImage(RoundedButton.IcoType ico)
    {
      this.buttonText.Margin = new Thickness(65.0, 0.0, 20.0, 4.0);
      this.mainGrid.ClearValue(FrameworkElement.WidthProperty);
      switch (ico)
      {
        case RoundedButton.IcoType.Add:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Add_ico.jpg", UriKind.Relative));
          break;
        case RoundedButton.IcoType.AddStudent:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Add_student.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Save:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Save-as-icon.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Edit:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Edit.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.EditPage:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Edit_page.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Stop:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/stop-2-icon.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Delete:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Delete.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Refresh:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Refresh.jpg", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Visibly:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Visibly.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Pdf:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Pdf_ico.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Csv:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Csv_ico.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Archive:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Archive_ico.png", UriKind.Relative));
          break;
        case RoundedButton.IcoType.Chapionship:
          this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Championships.png", UriKind.Relative));
          break;
      }
    }

    public void SetColor(RoundedButton.ColorType colorType)
    {
      switch (colorType)
      {
        case RoundedButton.ColorType.red:
          this.blueRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 235, (byte) 67, (byte) 53));
          this.blueRect.StrokeThickness = 0.0;
          this.buttonText.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, (byte) 225));
          break;
        case RoundedButton.ColorType.white:
          this.blueRect.Fill = (Brush) new SolidColorBrush(Colors.White);
          this.blueRect.StrokeThickness = 2.0;
          this.buttonText.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, (byte) 225));
          break;
        case RoundedButton.ColorType.blue:
          this.blueRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, (byte) 225));
          this.blueRect.StrokeThickness = 0.0;
          break;
      }
    }

    public void SetEnable(bool isEnable)
    {
      if (isEnable)
      {
        this.IsEnabled = false;
        this.blueRect.Opacity = 0.6;
        this.shadow1.Visibility = Visibility.Collapsed;
        this.shadow2.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.IsEnabled = true;
        this.blueRect.Opacity = 1.0;
        this.shadow1.Visibility = Visibility.Visible;
        this.shadow2.Visibility = Visibility.Visible;
      }
    }

    public string Description
    {
      get => this.buttonText.Text;
      set => this.buttonText.Text = value.ToUpper();
    }

    public bool IsSmallCircle
    {
      set
      {
        this.isSmallCircle = value;
        if (!value)
          return;
        this.mainGrid.Width = 58.0;
      }
      get => this.isSmallCircle;
    }

    private void UserControl_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
      if (this.IsEnabled)
        this.Opacity = 1.0;
      else
        this.Opacity = 0.2;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/roundedbutton.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).IsEnabledChanged += new DependencyPropertyChangedEventHandler(this.UserControl_IsEnabledChanged);
          break;
        case 2:
          this.mainGrid = (Grid) target;
          break;
        case 3:
          this.shadow2 = (Rectangle) target;
          break;
        case 4:
          this.shadow1 = (Rectangle) target;
          break;
        case 5:
          this.blueRect = (Rectangle) target;
          break;
        case 6:
          this.gradient = (Rectangle) target;
          break;
        case 7:
          this.imageBtn = (Image) target;
          break;
        case 8:
          this.buttonText = (TextBlock) target;
          break;
        case 9:
          this.iconGrid = (Grid) target;
          break;
        case 10:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Rectangle_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Rectangle_MouseLeave);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ClickDelegate();

    public enum IcoType
    {
      Add,
      AddStudent,
      Save,
      Edit,
      EditPage,
      Stop,
      Delete,
      Trash,
      Refresh,
      Visibly,
      Pdf,
      Csv,
      Archive,
      Chapionship,
    }

    public enum ColorType
    {
      red,
      white,
      blue,
    }
  }
}
