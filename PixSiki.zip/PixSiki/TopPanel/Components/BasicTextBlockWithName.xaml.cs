﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.TextBlockWithName
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.Components.Basic
{
  public partial class TextBlockWithName : UserControl, IComponentConnector
  {
    internal TextBlock title;
    internal TextBlock description;
    private bool _contentLoaded;

    public TextBlockWithName() => this.InitializeComponent();

    public string Title
    {
      get => this.title.Text;
      set => this.title.Text = value;
    }

    public string Description
    {
      get => this.description.Text;
      set => this.description.Text = value;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/textblockwithname.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.description = (TextBlock) target;
        else
          this._contentLoaded = true;
      }
      else
        this.title = (TextBlock) target;
    }
  }
}
