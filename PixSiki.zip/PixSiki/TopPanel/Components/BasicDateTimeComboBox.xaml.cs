﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.DateTimeComboBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.UserManagment;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.TopPanel.Components.Basic
{
  public partial class DateTimeComboBox : UserControl, IComponentConnector
  {
    internal Label labelEnterBrith;
    internal ComboBox dayOfBirth;
    internal Label dayTitle;
    internal ComboBox monthOfBirth;
    internal Label monthTitle;
    internal ComboBox yearOfBrith;
    internal Label yearTitle;
    private bool _contentLoaded;

    public DateTimeComboBox() => this.InitializeComponent();

    public void InitializeDate()
    {
      this.labelEnterBrith.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("enterYourBrith");
      this.yearOfBrith.ItemsSource = (IEnumerable) Enumerable.Range(DateTime.Today.Year - 60, 55).ToList<int>().OrderByDescending<int, int>((Func<int, int>) (n => n));
      this.yearTitle.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("year");
      this.monthTitle.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("month");
      this.monthOfBirth.ItemsSource = (IEnumerable) Enumerable.Range(1, 12).ToList<int>();
      this.dayTitle.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("day");
      this.dayOfBirth.ItemsSource = (IEnumerable) Enumerable.Range(1, 31).ToList<int>();
    }

    public void SetDate(DateTime date)
    {
      this.dayOfBirth.SelectedIndex = date.Day - 1;
      this.monthOfBirth.SelectedIndex = date.Month - 1;
      this.yearOfBrith.SelectedValue = (object) date.Year;
    }

    public bool CheckFormatDate()
    {
      try
      {
        DateTime dateTime = new DateTime(int.Parse(this.yearOfBrith.SelectedValue.ToString()), int.Parse(this.monthOfBirth.SelectedValue.ToString()), int.Parse(this.dayOfBirth.SelectedValue.ToString()));
        return true;
      }
      catch
      {
        this.labelEnterBrith.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("wrongDate");
        this.labelEnterBrith.Foreground = (Brush) new SolidColorBrush(Colors.Red);
        return false;
      }
    }

    public bool IsEmptyLabel()
    {
      try
      {
        return this.yearOfBrith.Text.ToString().IsNullOrEmpty() || this.monthOfBirth.Text.ToString().IsNullOrEmpty() || this.dayOfBirth.Text.ToString().IsNullOrEmpty();
      }
      catch
      {
        return true;
      }
    }

    public void ShowWarnigEmptyDate()
    {
      this.labelEnterBrith.Foreground = (Brush) new SolidColorBrush(Colors.Red);
      this.labelEnterBrith.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("wrongDate");
      this.dayOfBirth.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 204, (byte) 204));
      this.monthOfBirth.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 204, (byte) 204));
      this.yearOfBrith.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 204, (byte) 204));
    }

    public void SetDateFromCurrentUser()
    {
      if (!CurrentUserInfo.CurrentUser.DateOfBirth.HasValue)
        return;
      this.SetDate(CurrentUserInfo.CurrentUser.DateOfBirth.Value);
    }

    public bool CheckComeOfAge()
    {
      DateTime dateTime = new DateTime();
      if (!this.CheckFormatDate())
        throw new ArgumentException("Format date error", "Error");
      DateTime date = this.GetDate();
      DateTime today = DateTime.Today;
      return ((today.Year * 100 + today.Month) * 100 + today.Day - ((date.Year * 100 + date.Month) * 100 + date.Day)) / 10000 >= 18;
    }

    public DateTime GetDate()
    {
      try
      {
        return new DateTime(int.Parse(this.yearOfBrith.SelectedValue.ToString()), int.Parse(this.monthOfBirth.SelectedValue.ToString()), int.Parse(this.dayOfBirth.SelectedValue.ToString()));
      }
      catch
      {
        throw new ArgumentException("Format date error", "Error");
      }
    }

    public bool CheckAllEmpty() => this.dayOfBirth.SelectedValue == null && this.monthOfBirth.SelectedValue == null && this.yearOfBrith.SelectedValue == null;

    private void dayOfBrith_SelectionChanged(object sender, SelectionChangedEventArgs e) => this.dayOfBirth.Background = (Brush) new SolidColorBrush(Colors.White);

    private void monthOfBirth_SelectionChanged(object sender, SelectionChangedEventArgs e) => this.monthOfBirth.Background = (Brush) new SolidColorBrush(Colors.White);

    private void yearOfBrith_SelectionChanged(object sender, SelectionChangedEventArgs e) => this.yearOfBrith.Background = (Brush) new SolidColorBrush(Colors.White);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/datetimecombobox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.labelEnterBrith = (Label) target;
          break;
        case 2:
          this.dayOfBirth = (ComboBox) target;
          this.dayOfBirth.SelectionChanged += new SelectionChangedEventHandler(this.dayOfBrith_SelectionChanged);
          break;
        case 3:
          this.dayTitle = (Label) target;
          break;
        case 4:
          this.monthOfBirth = (ComboBox) target;
          this.monthOfBirth.SelectionChanged += new SelectionChangedEventHandler(this.monthOfBirth_SelectionChanged);
          break;
        case 5:
          this.monthTitle = (Label) target;
          break;
        case 6:
          this.yearOfBrith = (ComboBox) target;
          this.yearOfBrith.SelectionChanged += new SelectionChangedEventHandler(this.yearOfBrith_SelectionChanged);
          break;
        case 7:
          this.yearTitle = (Label) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
