﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.LanguageComboBox.ExtendedLanguageComboBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.UserManagment;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.LanguageComboBox
{
  public partial class ExtendedLanguageComboBox : UserControl, IComponentConnector
  {
    private bool isClicked;
    private bool isEntered;
    internal Rectangle shadow;
    internal Rectangle HighlightRect;
    internal Image polishFlag;
    internal Image englishFlag;
    internal Image russianFlag;
    internal Label LanguageNameLabel;
    internal SelectionLanguageComboBox SelectionLanguageComboBox;
    private bool _contentLoaded;

    public ExtendedLanguageComboBox()
    {
      this.InitializeComponent();
      this.SelectionLanguageComboBox.selectedLanguageEvent += new SimpleLanguageComboBoxItem.SelectedLanguage(this.SelectionComboBox_selectedItemeEvent);
      this.SelectionLanguageComboBox.SelectCurrentLanguage();
      this.SelectionLanguageComboBox.Visibility = Visibility.Collapsed;
    }

    private void UserMenager_userDataChangedEvent() => this.LanguageName = UserMenager.GetCurrentUserName();

    public void CollapseComboBox()
    {
      this.isClicked = false;
      if (!this.isEntered)
        this.HighlightRect.Opacity = 0.001;
      this.SelectionLanguageComboBox.Visibility = Visibility.Collapsed;
    }

    public event SimpleLanguageComboBoxItem.SelectedLanguage selectedItemeEvent;

    private void SelectionComboBox_selectedItemeEvent(SimpleLanguageComboBoxItem.Languages language)
    {
      this.isClicked = false;
      this.HighlightRect.Opacity = 0.001;
      this.SelectionLanguageComboBox.Visibility = Visibility.Collapsed;
      this.polishFlag.Visibility = Visibility.Collapsed;
      this.englishFlag.Visibility = Visibility.Collapsed;
      this.russianFlag.Visibility = Visibility.Collapsed;
      if (language == SimpleLanguageComboBoxItem.Languages.polish)
      {
        this.polishFlag.Visibility = Visibility.Visible;
        this.LanguageName = "Polski";
      }
      if (language == SimpleLanguageComboBoxItem.Languages.english)
      {
        this.englishFlag.Visibility = Visibility.Visible;
        this.LanguageName = "English";
      }
      if (language == SimpleLanguageComboBoxItem.Languages.russian)
      {
        this.russianFlag.Visibility = Visibility.Visible;
        this.LanguageName = "Pусский";
      }
      if (this.selectedItemeEvent == null)
        return;
      this.selectedItemeEvent(language);
    }

    public string LanguageName
    {
      set => this.LanguageNameLabel.Content = (object) value;
    }

    public event ExtendedLanguageComboBox.ComboBoxClicked comboBoxClickedEvent;

    private void HighlightRect_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.comboBoxClickedEvent != null)
        this.comboBoxClickedEvent();
      this.isEntered = true;
      if (this.SelectionLanguageComboBox.Visibility == Visibility.Visible)
      {
        this.SelectionLanguageComboBox.Visibility = Visibility.Collapsed;
        this.isClicked = false;
      }
      else
      {
        this.SelectionLanguageComboBox.Visibility = Visibility.Visible;
        this.isClicked = true;
      }
    }

    private void HighlightRect_MouseEnter(object sender, MouseEventArgs e)
    {
      this.isEntered = true;
      if (this.isClicked)
        return;
      this.HighlightRect.Opacity = 0.2;
    }

    private void HighlightRect_MouseLeave(object sender, MouseEventArgs e)
    {
      this.isEntered = false;
      if (this.isClicked)
        return;
      this.HighlightRect.Opacity = 0.001;
    }

    internal void SelectFirstItem() => this.SelectionLanguageComboBox.SelectFirstItem();

    private void SelectionComboBox_Loaded(object sender, RoutedEventArgs e)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/languagecombobox/extendedlanguagecombobox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.shadow = (Rectangle) target;
          this.shadow.MouseDown += new MouseButtonEventHandler(this.HighlightRect_MouseDown);
          this.shadow.MouseEnter += new MouseEventHandler(this.HighlightRect_MouseEnter);
          this.shadow.MouseLeave += new MouseEventHandler(this.HighlightRect_MouseLeave);
          break;
        case 2:
          this.HighlightRect = (Rectangle) target;
          this.HighlightRect.MouseDown += new MouseButtonEventHandler(this.HighlightRect_MouseDown);
          this.HighlightRect.MouseEnter += new MouseEventHandler(this.HighlightRect_MouseEnter);
          this.HighlightRect.MouseLeave += new MouseEventHandler(this.HighlightRect_MouseLeave);
          break;
        case 3:
          this.polishFlag = (Image) target;
          break;
        case 4:
          this.englishFlag = (Image) target;
          break;
        case 5:
          this.russianFlag = (Image) target;
          break;
        case 6:
          this.LanguageNameLabel = (Label) target;
          break;
        case 7:
          this.SelectionLanguageComboBox = (SelectionLanguageComboBox) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ComboBoxClicked();
  }
}
