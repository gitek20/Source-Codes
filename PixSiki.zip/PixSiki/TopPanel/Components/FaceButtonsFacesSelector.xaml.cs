﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.FaceButtons.FacesSelector
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.FaceButtons.Images;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.Components.FaceButtons
{
  public partial class FacesSelector : UserControl, IComponentConnector
  {
    private List<SingleFace> faces = new List<SingleFace>();
    internal WrapPanel stackPanel;
    private bool _contentLoaded;

    public FacesSelector()
    {
      this.InitializeComponent();
      this.faces.Add(new SingleFace((UserControl) new GirlIcon(), UserAgeType.girl));
      this.faces.Add(new SingleFace((UserControl) new BoyIcon(), UserAgeType.boy));
      this.faces.Add(new SingleFace((UserControl) new WomanIcon(), UserAgeType.woman));
      this.faces.Add(new SingleFace((UserControl) new ManIcon(), UserAgeType.man));
      this.faces.Add(new SingleFace((UserControl) new GirlIcon1(), UserAgeType.girl1));
      this.faces.Add(new SingleFace((UserControl) new BoyIcon1(), UserAgeType.boy1));
      this.faces.Add(new SingleFace((UserControl) new WomanIcon1(), UserAgeType.woman1));
      this.faces.Add(new SingleFace((UserControl) new ManIcon1(), UserAgeType.man1));
      this.faces.Add(new SingleFace((UserControl) new GirlIcon2(), UserAgeType.girl2));
      this.faces.Add(new SingleFace((UserControl) new BoyIcon2(), UserAgeType.boy2));
      this.faces.Add(new SingleFace((UserControl) new WomanIcon2(), UserAgeType.woman2));
      this.faces.Add(new SingleFace((UserControl) new ManIcon2(), UserAgeType.man2));
      this.faces.Add(new SingleFace((UserControl) new GirlIcon3(), UserAgeType.girl3));
      this.faces.Add(new SingleFace((UserControl) new BoyIcon3(), UserAgeType.boy3));
      this.faces.Add(new SingleFace((UserControl) new WomanIcon3(), UserAgeType.woman3));
      this.faces.Add(new SingleFace((UserControl) new ManIcon3(), UserAgeType.man3));
      this.faces[0].IsSelected = true;
      foreach (SingleFace face in this.faces)
      {
        this.stackPanel.Children.Add((UIElement) face);
        face.FaceSelectedEvent += new SingleFace.FaceSelected(this.Face_FaceSelectedEvent);
      }
    }

    public string GetSelectedFace()
    {
      foreach (SingleFace face in this.faces)
      {
        if (face.IsSelected)
          return face.UserAgeType.ToString();
      }
      return (string) null;
    }

    public static UserAgeType GetCurrentUserAvatar()
    {
      UserAgeType userAgeType = UserAgeType.girl;
      if (CurrentUserInfo.CurrentUser.AvatarName == "girl")
        return UserAgeType.girl;
      if (CurrentUserInfo.CurrentUser.AvatarName == "boy")
        userAgeType = UserAgeType.boy;
      else if (CurrentUserInfo.CurrentUser.AvatarName == "woman")
        userAgeType = UserAgeType.woman;
      else if (CurrentUserInfo.CurrentUser.AvatarName == "man")
      {
        userAgeType = UserAgeType.man;
      }
      else
      {
        if (CurrentUserInfo.CurrentUser.AvatarName == "girl1")
          return UserAgeType.girl1;
        if (CurrentUserInfo.CurrentUser.AvatarName == "boy1")
          userAgeType = UserAgeType.boy1;
        else if (CurrentUserInfo.CurrentUser.AvatarName == "woman1")
          userAgeType = UserAgeType.woman1;
        else if (CurrentUserInfo.CurrentUser.AvatarName == "man1")
        {
          userAgeType = UserAgeType.man1;
        }
        else
        {
          if (CurrentUserInfo.CurrentUser.AvatarName == "girl2")
            return UserAgeType.girl2;
          if (CurrentUserInfo.CurrentUser.AvatarName == "boy2")
            userAgeType = UserAgeType.boy2;
          else if (CurrentUserInfo.CurrentUser.AvatarName == "woman2")
            userAgeType = UserAgeType.woman2;
          else if (CurrentUserInfo.CurrentUser.AvatarName == "man2")
          {
            userAgeType = UserAgeType.man2;
          }
          else
          {
            if (CurrentUserInfo.CurrentUser.AvatarName == "girl3")
              return UserAgeType.girl3;
            if (CurrentUserInfo.CurrentUser.AvatarName == "boy3")
              userAgeType = UserAgeType.boy3;
            else if (CurrentUserInfo.CurrentUser.AvatarName == "woman3")
              userAgeType = UserAgeType.woman3;
            else if (CurrentUserInfo.CurrentUser.AvatarName == "man3")
              userAgeType = UserAgeType.man3;
          }
        }
      }
      return userAgeType;
    }

    public void SetFace(string faceName)
    {
      foreach (SingleFace face in this.faces)
      {
        UserAgeType userAgeType = face.UserAgeType;
        face.IsSelected = userAgeType.ToString() == faceName;
      }
    }

    public void Face_FaceSelectedEvent(SingleFace face)
    {
      foreach (SingleFace face1 in this.faces)
      {
        if (face1 != face)
          face1.IsSelected = false;
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/facebuttons/facesselector.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.stackPanel = (WrapPanel) target;
      else
        this._contentLoaded = true;
    }
  }
}
