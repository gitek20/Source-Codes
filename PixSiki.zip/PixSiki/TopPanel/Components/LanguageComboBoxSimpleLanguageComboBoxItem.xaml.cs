﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.LanguageComboBox.SimpleLanguageComboBoxItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.LanguageComboBox
{
  public partial class SimpleLanguageComboBoxItem : UserControl, IComponentConnector
  {
    private SimpleLanguageComboBoxItem.Languages language;
    internal Rectangle selectedRectangle;
    internal Rectangle highlightRectangle;
    internal TextBlock textBox;
    internal Image polishFlag;
    internal Image englishFlag;
    internal Image russianFlag;
    private bool _contentLoaded;

    public SimpleLanguageComboBoxItem(SimpleLanguageComboBoxItem.Languages language)
    {
      this.language = language;
      this.InitializeComponent();
      this.highlightRectangle.Opacity = 0.001;
      if (language == SimpleLanguageComboBoxItem.Languages.polish)
      {
        this.textBox.Text = "Polski";
        this.polishFlag.Visibility = Visibility.Visible;
      }
      if (language == SimpleLanguageComboBoxItem.Languages.english)
      {
        this.textBox.Text = "English";
        this.englishFlag.Visibility = Visibility.Visible;
      }
      if (language != SimpleLanguageComboBoxItem.Languages.russian)
        return;
      this.textBox.Text = "Pусский";
      this.russianFlag.Visibility = Visibility.Visible;
    }

    public bool IsSelected
    {
      set
      {
        if (value)
        {
          this.selectedRectangle.Visibility = Visibility.Visible;
          this.textBox.Foreground = (Brush) new SolidColorBrush(Colors.White);
        }
        else
        {
          this.selectedRectangle.Visibility = Visibility.Collapsed;
          this.textBox.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 51, (byte) 51, (byte) 51));
        }
      }
    }

    public SimpleLanguageComboBoxItem.Languages MyLanguage => this.language;

    public event SimpleLanguageComboBoxItem.SelectedLanguage selectedLanguageEvent;

    private void highlightRectangle_MouseDown(object sender, MouseButtonEventArgs e) => this.SelectAndInvokeEvent();

    public void SelectAndInvokeEvent()
    {
      this.IsSelected = true;
      if (this.selectedLanguageEvent == null)
        return;
      this.selectedLanguageEvent(this.language);
    }

    private void highlightRectangle_MouseEnter(object sender, MouseEventArgs e) => this.highlightRectangle.Opacity = 0.2;

    private void highlightRectangle_MouseLeave(object sender, MouseEventArgs e) => this.highlightRectangle.Opacity = 0.001;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/languagecombobox/simplelanguagecomboboxitem.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.selectedRectangle = (Rectangle) target;
          this.selectedRectangle.MouseDown += new MouseButtonEventHandler(this.highlightRectangle_MouseDown);
          this.selectedRectangle.MouseEnter += new MouseEventHandler(this.highlightRectangle_MouseEnter);
          this.selectedRectangle.MouseLeave += new MouseEventHandler(this.highlightRectangle_MouseLeave);
          break;
        case 2:
          this.highlightRectangle = (Rectangle) target;
          this.highlightRectangle.MouseDown += new MouseButtonEventHandler(this.highlightRectangle_MouseDown);
          this.highlightRectangle.MouseEnter += new MouseEventHandler(this.highlightRectangle_MouseEnter);
          this.highlightRectangle.MouseLeave += new MouseEventHandler(this.highlightRectangle_MouseLeave);
          break;
        case 3:
          this.textBox = (TextBlock) target;
          break;
        case 4:
          this.polishFlag = (Image) target;
          break;
        case 5:
          this.englishFlag = (Image) target;
          break;
        case 6:
          this.russianFlag = (Image) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public enum Languages
    {
      polish,
      english,
      russian,
    }

    public delegate void SelectedLanguage(SimpleLanguageComboBoxItem.Languages language);
  }
}
