﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.SmallRoundedButton
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.Basic
{
  public class SmallRoundedButton : UserControl, IComponentConnector
  {
    private bool isSmallCircle;
    internal Grid mainGrid;
    internal Rectangle shadow2;
    internal Rectangle shadow1;
    internal Rectangle blueRect;
    internal Rectangle gradient;
    internal Image imageBtn;
    internal TextBlock buttonText;
    internal Grid iconGrid;
    private bool _contentLoaded;

    public SmallRoundedButton() => this.InitializeComponent();

    public event SmallRoundedButton.ClickDelegate clickEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.clickEvent == null)
        return;
      this.clickEvent();
    }

    internal void SetImage(UserControl backIcon)
    {
      this.iconGrid.Children.Clear();
      this.iconGrid.Children.Add((UIElement) backIcon);
    }

    private void Rectangle_MouseEnter(object sender, MouseEventArgs e)
    {
      this.blueRect.Opacity = 0.6;
      this.shadow1.Visibility = Visibility.Collapsed;
      this.shadow2.Visibility = Visibility.Collapsed;
    }

    private void Rectangle_MouseLeave(object sender, MouseEventArgs e)
    {
      this.blueRect.Opacity = 1.0;
      this.shadow1.Visibility = Visibility.Visible;
      this.shadow2.Visibility = Visibility.Visible;
    }

    public void SetImage(SmallRoundedButton.IcoType ico)
    {
      this.buttonText.Margin = new Thickness(65.0, 0.0, 20.0, 4.0);
      this.mainGrid.ClearValue(FrameworkElement.WidthProperty);
      if (ico != SmallRoundedButton.IcoType.Settings)
        return;
      this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("images/Settings.png", UriKind.Relative));
    }

    public void SetColor(SmallRoundedButton.ColorType colorType)
    {
      if (colorType == SmallRoundedButton.ColorType.blue)
      {
        this.blueRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, (byte) 225));
        this.blueRect.StrokeThickness = 0.0;
      }
      if (colorType == SmallRoundedButton.ColorType.green)
      {
        this.blueRect.Fill = (Brush) new SolidColorBrush(Colors.White);
        this.blueRect.StrokeThickness = 2.0;
        this.buttonText.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, (byte) 225));
      }
      if (colorType != SmallRoundedButton.ColorType.white)
        return;
      this.blueRect.Fill = (Brush) new SolidColorBrush(Colors.White);
      this.blueRect.StrokeThickness = 2.0;
      this.buttonText.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, (byte) 225));
    }

    public void SetEnable(bool isEnable)
    {
      if (isEnable)
      {
        this.IsEnabled = true;
        this.blueRect.Opacity = 1.0;
        this.shadow1.Visibility = Visibility.Visible;
        this.shadow2.Visibility = Visibility.Visible;
      }
      else
      {
        this.IsEnabled = false;
        this.blueRect.Opacity = 0.6;
        this.shadow1.Visibility = Visibility.Collapsed;
        this.shadow2.Visibility = Visibility.Collapsed;
      }
    }

    public string Description
    {
      get => this.buttonText.Text;
      set => this.buttonText.Text = value.ToUpper();
    }

    public bool IsSmallCircle
    {
      set
      {
        this.isSmallCircle = value;
        if (!value)
          return;
        this.mainGrid.Width = 58.0;
      }
      get => this.isSmallCircle;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/smallrundedbutton.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.shadow2 = (Rectangle) target;
          break;
        case 3:
          this.shadow1 = (Rectangle) target;
          break;
        case 4:
          this.blueRect = (Rectangle) target;
          break;
        case 5:
          this.gradient = (Rectangle) target;
          break;
        case 6:
          this.imageBtn = (Image) target;
          break;
        case 7:
          this.buttonText = (TextBlock) target;
          break;
        case 8:
          this.iconGrid = (Grid) target;
          break;
        case 9:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Rectangle_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Rectangle_MouseLeave);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ClickDelegate();

    public enum IcoType
    {
      Settings,
    }

    public enum ColorType
    {
      white,
      green,
      blue,
    }
  }
}
