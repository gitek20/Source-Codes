﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.FaceButtons.ProfilePreview
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.FaceButtons.Images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.Components.FaceButtons
{
  public partial class ProfilePreview : UserControl, IComponentConnector
  {
    internal Grid faceGrid;
    internal TextBlock nameAndSurname;
    internal TextBlock studentsClassInfo;
    internal TextBlock emailInfo;
    internal TextBlock pointsSize;
    internal TextBlock licenseInfo;
    internal TextBlock expiredDate;
    private bool _contentLoaded;

    public ProfilePreview()
    {
      this.InitializeComponent();
      this.pointsSize.Text = "punkty";
    }

    public void ShowInfo(UserAgeType ageType, UserShortInfo userShortInfo, string userType)
    {
      this.faceGrid.Children.Clear();
      if (ageType == UserAgeType.boy)
        this.faceGrid.Children.Add((UIElement) new BoyIcon());
      if (ageType == UserAgeType.girl)
        this.faceGrid.Children.Add((UIElement) new GirlIcon());
      if (ageType == UserAgeType.man)
        this.faceGrid.Children.Add((UIElement) new ManIcon());
      if (ageType == UserAgeType.woman)
        this.faceGrid.Children.Add((UIElement) new WomanIcon());
      if (ageType == UserAgeType.boy1)
        this.faceGrid.Children.Add((UIElement) new BoyIcon1());
      if (ageType == UserAgeType.girl1)
        this.faceGrid.Children.Add((UIElement) new GirlIcon1());
      if (ageType == UserAgeType.man1)
        this.faceGrid.Children.Add((UIElement) new ManIcon1());
      if (ageType == UserAgeType.woman1)
        this.faceGrid.Children.Add((UIElement) new WomanIcon1());
      if (ageType == UserAgeType.boy2)
        this.faceGrid.Children.Add((UIElement) new BoyIcon2());
      if (ageType == UserAgeType.girl2)
        this.faceGrid.Children.Add((UIElement) new GirlIcon2());
      if (ageType == UserAgeType.man2)
        this.faceGrid.Children.Add((UIElement) new ManIcon2());
      if (ageType == UserAgeType.woman2)
        this.faceGrid.Children.Add((UIElement) new WomanIcon2());
      if (ageType == UserAgeType.boy3)
        this.faceGrid.Children.Add((UIElement) new BoyIcon3());
      if (ageType == UserAgeType.girl3)
        this.faceGrid.Children.Add((UIElement) new GirlIcon3());
      if (ageType == UserAgeType.man3)
        this.faceGrid.Children.Add((UIElement) new ManIcon3());
      if (ageType == UserAgeType.woman3)
        this.faceGrid.Children.Add((UIElement) new WomanIcon3());
      if (userType == "student")
      {
        this.nameAndSurname.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("student") + ": " + userShortInfo.Name + " " + userShortInfo.Surname;
        this.studentsClassInfo.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("class") + ": " + userShortInfo.StudentsClassName;
        this.emailInfo.Text = "e-mail: " + userShortInfo.Email;
      }
      else if (userType == "teacher")
      {
        this.nameAndSurname.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("teacher") + ": " + userShortInfo.Name + " " + userShortInfo.Surname;
        this.studentsClassInfo.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("school") + ": " + userShortInfo.StudentsClassName;
        this.emailInfo.Text = "e-mail: " + userShortInfo.Email;
      }
      else if (userType == "parent")
      {
        this.nameAndSurname.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("parent") + ": " + userShortInfo.Name + " " + userShortInfo.Surname;
        this.studentsClassInfo.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("student") + ": " + userShortInfo.StudentsClassName;
        this.emailInfo.Text = "e-mail: " + userShortInfo.Email;
      }
      else
      {
        if (!(userType == "child"))
          return;
        this.nameAndSurname.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("child") + ": " + userShortInfo.Name + " " + userShortInfo.Surname;
        this.studentsClassInfo.Text = " " + userShortInfo.StudentsClassName;
        this.emailInfo.Text = "e-mail: " + userShortInfo.Email;
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/facebuttons/profilepreview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.faceGrid = (Grid) target;
          break;
        case 2:
          this.nameAndSurname = (TextBlock) target;
          break;
        case 3:
          this.studentsClassInfo = (TextBlock) target;
          break;
        case 4:
          this.emailInfo = (TextBlock) target;
          break;
        case 5:
          this.pointsSize = (TextBlock) target;
          break;
        case 6:
          this.licenseInfo = (TextBlock) target;
          break;
        case 7:
          this.expiredDate = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
