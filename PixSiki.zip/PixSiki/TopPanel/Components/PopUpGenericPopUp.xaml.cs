﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.PopUp.GenericPopUp
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp.images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.PopUp
{
  public partial class GenericPopUp : UserControl, IComponentConnector
  {
    internal Grid blueBackground;
    internal Grid insideGrid;
    internal Rectangle shadow2;
    internal Rectangle shadow1;
    internal Grid mainGrid;
    internal RoundedButton closeButton;
    private bool _contentLoaded;

    public GenericPopUp()
    {
      this.InitializeComponent();
      this.closeButton.SetColor(RoundedButton.ColorType.red);
      this.IsCloseButton(false);
      this.closeButton.Description = "";
      this.closeButton.SetImage((UserControl) new CloseIcon());
      this.closeButton.clickEvent += new RoundedButton.ClickDelegate(this.CloseButton_clickEvent);
      this.ShowBlueBackground = false;
    }

    private void CloseButton_clickEvent()
    {
      if (this.closePopUpEvent == null)
        return;
      this.closePopUpEvent(this);
    }

    public event GenericPopUp.ClosePopUp closePopUpEvent;

    public bool ShowBlueBackground
    {
      set
      {
        if (value)
          this.blueBackground.Visibility = Visibility.Visible;
        else
          this.blueBackground.Visibility = Visibility.Collapsed;
      }
    }

    public void AddComponent(UserControl userControl)
    {
      this.mainGrid.Children.Clear();
      this.mainGrid.Children.Add((UIElement) userControl);
    }

    public void IsCloseButton(bool isCloseButton)
    {
      if (isCloseButton)
        this.closeButton.Visibility = Visibility.Visible;
      else
        this.closeButton.Visibility = Visibility.Collapsed;
    }

    internal void IsFullWidth(bool showFullWidthPopUp)
    {
      if (!showFullWidthPopUp)
        return;
      this.VerticalAlignment = VerticalAlignment.Stretch;
      this.HorizontalAlignment = HorizontalAlignment.Stretch;
      this.mainGrid.Width = double.NaN;
      this.mainGrid.Height = double.NaN;
      this.mainGrid.Margin = new Thickness(20.0, 0.0, 30.0, 10.0);
      this.insideGrid.VerticalAlignment = VerticalAlignment.Stretch;
      this.insideGrid.HorizontalAlignment = HorizontalAlignment.Stretch;
      this.insideGrid.Margin = new Thickness(6.0);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/popup/genericpopup.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.blueBackground = (Grid) target;
          break;
        case 2:
          this.insideGrid = (Grid) target;
          break;
        case 3:
          this.shadow2 = (Rectangle) target;
          break;
        case 4:
          this.shadow1 = (Rectangle) target;
          break;
        case 5:
          this.mainGrid = (Grid) target;
          break;
        case 6:
          this.closeButton = (RoundedButton) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ClosePopUp(GenericPopUp genericPopUp);
  }
}
