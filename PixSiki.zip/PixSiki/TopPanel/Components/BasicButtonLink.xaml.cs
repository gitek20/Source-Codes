﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.ButtonLink
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.Components.Basic
{
  public partial class ButtonLink : UserControl, IComponentConnector
  {
    internal TextBlock buttonText;
    private bool _contentLoaded;

    public ButtonLink() => this.InitializeComponent();

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.clickEvent == null)
        return;
      this.clickEvent();
    }

    public event ButtonLink.ClickDelegate clickEvent;

    private void Grid_MouseEnter(object sender, MouseEventArgs e) => this.buttonText.Opacity = 0.6;

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.buttonText.Opacity = 1.0;

    public string Description
    {
      get => this.buttonText.Text;
      set => this.buttonText.Text = value;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/buttonlink.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
        {
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
        }
        else
          this._contentLoaded = true;
      }
      else
        this.buttonText = (TextBlock) target;
    }

    public delegate void ClickDelegate();
  }
}
