﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.RoundedTextBoxAndLabel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.Components.Basic
{
  public partial class RoundedTextBoxAndLabel : UserControl, IComponentConnector
  {
    internal RoundedTextBox textBoxRounded;
    internal Label label;
    internal Label warningLabel;
    private bool _contentLoaded;

    public RoundedTextBoxAndLabel()
    {
      this.InitializeComponent();
      this.HideWarning();
      this.textBoxRounded.textChangedEvent += new RoundedTextBox.TextChanged(this.TextBoxRounded_textChangedEvent);
    }

    public bool CancelCopyPastle
    {
      get => this.textBoxRounded.CancelCopyPastle;
      set => this.textBoxRounded.CancelCopyPastle = value;
    }

    private void TextBoxRounded_textChangedEvent(string text) => this.HideWarning();

    public string Description
    {
      set => this.label.Content = (object) value;
      get => (string) this.label.Content;
    }

    public bool IsInPasswordMode
    {
      set => this.textBoxRounded.IsInPasswordMode = value;
      get => this.textBoxRounded.IsInPasswordMode;
    }

    public void ShowWarning(string worningMessage)
    {
      this.label.Visibility = Visibility.Collapsed;
      this.warningLabel.Visibility = Visibility.Visible;
      this.warningLabel.Content = (object) worningMessage;
      this.textBoxRounded.IsInWarningMode = true;
    }

    public void HideWarning()
    {
      this.label.Visibility = Visibility.Visible;
      this.textBoxRounded.IsInWarningMode = false;
      this.warningLabel.Visibility = Visibility.Collapsed;
    }

    public string TextInside
    {
      set => this.textBoxRounded.TextInside = value;
      get => this.textBoxRounded.TextInside;
    }

    private void UserControl_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/roundedtextboxandlabel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).IsEnabledChanged += new DependencyPropertyChangedEventHandler(this.UserControl_IsEnabledChanged);
          break;
        case 2:
          this.textBoxRounded = (RoundedTextBox) target;
          break;
        case 3:
          this.label = (Label) target;
          break;
        case 4:
          this.warningLabel = (Label) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
