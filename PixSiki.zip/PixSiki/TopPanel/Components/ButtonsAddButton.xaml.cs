﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Buttons.AddButton
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.Buttons
{
  public partial class AddButton : UserControl, IComponentConnector
  {
    internal Rectangle mainRectangleBtn;
    internal Image imageBtn;
    internal Label titleBtn;
    private bool _contentLoaded;

    public AddButton() => this.InitializeComponent();

    public event AddButton.ClickDelegate clickEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.clickEvent == null)
        return;
      this.clickEvent();
    }

    internal void SetImage(UserControl backIcon)
    {
    }

    private void Rectangle_MouseEnter(object sender, MouseEventArgs e)
    {
    }

    private void Rectangle_MouseLeave(object sender, MouseEventArgs e)
    {
    }

    public string titleButton
    {
      get => "s";
      set => this.titleBtn.Content = (object) value.ToUpper();
    }

    public void SetImage(AddButton.IcoType ico)
    {
      if (ico == AddButton.IcoType.Add)
        this.imageBtn.Source = (ImageSource) new BitmapImage(new Uri("Images/Add_ico.jpg", UriKind.Relative));
      else if (ico == AddButton.IcoType.Delete)
        ;
    }

    public void SetColor(AddButton.ColorType colorType)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/buttons/addbutton.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainRectangleBtn = (Rectangle) target;
          break;
        case 2:
          this.imageBtn = (Image) target;
          break;
        case 3:
          this.titleBtn = (Label) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ClickDelegate();

    public enum IcoType
    {
      Add,
      Delete,
      Refresh,
      Pdf,
      Csv,
    }

    public enum ColorType
    {
      red,
      white,
      blue,
    }
  }
}
