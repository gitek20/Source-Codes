﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.FaceButtons.SingleFace
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.FaceButtons
{
  public partial class SingleFace : UserControl, IComponentConnector
  {
    private UserAgeType userAgeType;
    private bool isSelected;
    internal Grid FaceGrid;
    internal Ellipse SelectionEllipse;
    private bool _contentLoaded;

    public SingleFace(UserControl face, UserAgeType userAgeType)
    {
      this.InitializeComponent();
      this.userAgeType = userAgeType;
      this.FaceGrid.Children.Insert(0, (UIElement) face);
      this.IsSelected = false;
    }

    public bool IsSelected
    {
      get => this.isSelected;
      set
      {
        this.isSelected = value;
        if (this.isSelected)
        {
          this.FaceGrid.Margin = new Thickness(0.0);
          this.FaceGrid.Opacity = 1.0;
          this.SelectionEllipse.Stroke = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue));
        }
        else
        {
          this.FaceGrid.Margin = new Thickness(8.0);
          this.FaceGrid.Opacity = 0.6;
          this.SelectionEllipse.Stroke = (Brush) new SolidColorBrush(Colors.Transparent);
        }
      }
    }

    internal UserAgeType UserAgeType => this.userAgeType;

    public event SingleFace.FaceSelected FaceSelectedEvent;

    private void Ellipse_MouseEnter(object sender, MouseEventArgs e)
    {
      if (this.isSelected)
        return;
      this.FaceGrid.Margin = new Thickness(6.0);
      this.FaceGrid.Opacity = 0.7;
      this.SelectionEllipse.Stroke = (Brush) new SolidColorBrush(Colors.Transparent);
    }

    private void Ellipse_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.IsSelected = true;
      if (this.FaceSelectedEvent == null)
        return;
      this.FaceSelectedEvent(this);
    }

    private void Ellipse_MouseUp(object sender, MouseButtonEventArgs e)
    {
    }

    private void Ellipse_MouseLeave(object sender, MouseEventArgs e)
    {
      if (this.isSelected)
        return;
      this.FaceGrid.Margin = new Thickness(8.0);
      this.FaceGrid.Opacity = 0.6;
      this.SelectionEllipse.Stroke = (Brush) new SolidColorBrush(Colors.Transparent);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/facebuttons/singleface.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
        {
          this.SelectionEllipse = (Ellipse) target;
          this.SelectionEllipse.MouseEnter += new MouseEventHandler(this.Ellipse_MouseEnter);
          this.SelectionEllipse.MouseDown += new MouseButtonEventHandler(this.Ellipse_MouseDown);
          this.SelectionEllipse.MouseUp += new MouseButtonEventHandler(this.Ellipse_MouseUp);
          this.SelectionEllipse.MouseLeave += new MouseEventHandler(this.Ellipse_MouseLeave);
        }
        else
          this._contentLoaded = true;
      }
      else
        this.FaceGrid = (Grid) target;
    }

    public delegate void FaceSelected(SingleFace face);
  }
}
