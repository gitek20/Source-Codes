﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.RoundedTextBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.TopPanel.Components.Basic
{
  public partial class RoundedTextBox : UserControl, IComponentConnector
  {
    private bool cancelCopyPastle;
    private bool isInWarningMode;
    private bool isInPasswordMode;
    internal Rectangle backRectange;
    internal Rectangle warningRect;
    internal Viewbox viewbox;
    internal Grid gridInViewBox;
    internal TextBox textBox;
    internal PasswordBox passwordBox;
    private bool _contentLoaded;

    public RoundedTextBox()
    {
      this.InitializeComponent();
      this.IsInWarningMode = false;
      this.IsInPasswordMode = false;
      this.Viewbox_SizeChanged((object) null, (SizeChangedEventArgs) null);
      DataObject.AddPastingHandler((DependencyObject) this.textBox, new DataObjectPastingEventHandler(this.OnCancelCommand));
      DataObject.AddCopyingHandler((DependencyObject) this.textBox, new DataObjectCopyingEventHandler(this.OnCancelCommand));
    }

    private void OnCancelCommand(object sender, DataObjectEventArgs e)
    {
      if (!this.cancelCopyPastle)
        return;
      e.CancelCommand();
    }

    public string TextInside
    {
      set
      {
        this.textBox.Text = value;
        this.passwordBox.Password = value;
      }
      get => this.isInPasswordMode ? this.passwordBox.Password : this.textBox.Text;
    }

    public bool IsInWarningMode
    {
      set
      {
        this.isInWarningMode = value;
        if (this.isInWarningMode)
          this.warningRect.Visibility = Visibility.Visible;
        else
          this.warningRect.Visibility = Visibility.Hidden;
      }
      get => this.isInWarningMode;
    }

    public bool IsInPasswordMode
    {
      set
      {
        this.isInPasswordMode = value;
        if (this.isInPasswordMode)
        {
          this.passwordBox.Visibility = Visibility.Visible;
          this.textBox.Visibility = Visibility.Collapsed;
        }
        else
        {
          this.textBox.Visibility = Visibility.Visible;
          this.passwordBox.Visibility = Visibility.Collapsed;
        }
      }
      get => this.isInPasswordMode;
    }

    public bool IsSearchTextbox
    {
      set
      {
        int num = value ? 1 : 0;
      }
    }

    public bool CancelCopyPastle
    {
      get => this.cancelCopyPastle;
      set => this.cancelCopyPastle = value;
    }

    public event RoundedTextBox.TextChanged textChangedEvent;

    private void textBox_TextChanged(object sender, TextChangedEventArgs e)
    {
      this.IsInWarningMode = false;
      if (this.textChangedEvent == null)
        return;
      this.textChangedEvent(this.textBox.Text);
    }

    private void backRectange_MouseEnter(object sender, MouseEventArgs e)
    {
    }

    private void backRectange_MouseLeave(object sender, MouseEventArgs e)
    {
    }

    private void textBox_MouseEnter(object sender, MouseEventArgs e)
    {
    }

    private void textBox_MouseLeave(object sender, MouseEventArgs e)
    {
    }

    private void textBox_GotFocus(object sender, RoutedEventArgs e) => this.backRectange.Stroke = (Brush) new SolidColorBrush(Colors.CornflowerBlue);

    private void textBox_LostFocus(object sender, RoutedEventArgs e) => this.backRectange.Stroke = (Brush) new SolidColorBrush(Colors.LightGray);

    private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
      this.IsInWarningMode = false;
      if (this.textChangedEvent == null)
        return;
      this.textChangedEvent(this.passwordBox.Password);
    }

    private void UserControl_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
      if (this.IsEnabled)
      {
        this.textBox.FontWeight = FontWeights.Normal;
        this.backRectange.Visibility = Visibility.Visible;
      }
      else
      {
        this.textBox.FontWeight = FontWeights.Bold;
        this.textBox.Foreground = (Brush) new SolidColorBrush(Colors.Black);
        this.backRectange.Visibility = Visibility.Collapsed;
      }
    }

    private void Viewbox_SizeChanged(object sender, SizeChangedEventArgs e)
    {
    }

    private void viewbox_Loaded(object sender, RoutedEventArgs e)
    {
    }

    private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      Grid gridInViewBox1 = this.gridInViewBox;
      double actualWidth = this.ActualWidth;
      Thickness margin1 = this.viewbox.Margin;
      double left = margin1.Left;
      margin1 = this.viewbox.Margin;
      double right = margin1.Right;
      double num1 = left + right;
      double num2 = (actualWidth - num1) / 3.0;
      gridInViewBox1.Width = num2;
      Grid gridInViewBox2 = this.gridInViewBox;
      double actualHeight = this.ActualHeight;
      Thickness margin2 = this.viewbox.Margin;
      double top = margin2.Top;
      margin2 = this.viewbox.Margin;
      double bottom = margin2.Bottom;
      double num3 = top + bottom;
      double num4 = (actualHeight - num3) / 3.0;
      gridInViewBox2.Height = num4;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/roundedtextbox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).IsEnabledChanged += new DependencyPropertyChangedEventHandler(this.UserControl_IsEnabledChanged);
          ((FrameworkElement) target).SizeChanged += new SizeChangedEventHandler(this.UserControl_SizeChanged);
          break;
        case 2:
          this.backRectange = (Rectangle) target;
          this.backRectange.MouseEnter += new MouseEventHandler(this.backRectange_MouseEnter);
          this.backRectange.MouseLeave += new MouseEventHandler(this.backRectange_MouseLeave);
          break;
        case 3:
          this.warningRect = (Rectangle) target;
          break;
        case 4:
          this.viewbox = (Viewbox) target;
          this.viewbox.SizeChanged += new SizeChangedEventHandler(this.Viewbox_SizeChanged);
          this.viewbox.Loaded += new RoutedEventHandler(this.viewbox_Loaded);
          break;
        case 5:
          this.gridInViewBox = (Grid) target;
          break;
        case 6:
          this.textBox = (TextBox) target;
          this.textBox.TextChanged += new TextChangedEventHandler(this.textBox_TextChanged);
          this.textBox.MouseEnter += new MouseEventHandler(this.textBox_MouseEnter);
          this.textBox.MouseLeave += new MouseEventHandler(this.textBox_MouseLeave);
          this.textBox.GotFocus += new RoutedEventHandler(this.textBox_GotFocus);
          this.textBox.LostFocus += new RoutedEventHandler(this.textBox_LostFocus);
          break;
        case 7:
          this.passwordBox = (PasswordBox) target;
          this.passwordBox.MouseEnter += new MouseEventHandler(this.textBox_MouseEnter);
          this.passwordBox.MouseLeave += new MouseEventHandler(this.textBox_MouseLeave);
          this.passwordBox.GotFocus += new RoutedEventHandler(this.textBox_GotFocus);
          this.passwordBox.LostFocus += new RoutedEventHandler(this.textBox_LostFocus);
          this.passwordBox.PasswordChanged += new RoutedEventHandler(this.PasswordBox_PasswordChanged);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void TextChanged(string text);
  }
}
