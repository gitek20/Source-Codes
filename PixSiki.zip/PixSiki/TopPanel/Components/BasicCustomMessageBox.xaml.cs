﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.Basic.CustomMessageBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PixBlocks.TopPanel.Components.Basic
{
  public partial class CustomMessageBox : UserControl, IComponentConnector
  {
    private static Grid localMainGrid;
    internal Grid insideGrid;
    internal Rectangle shadow2;
    internal Rectangle shadow1;
    internal Grid mainGrid;
    internal TextBlock message;
    internal RoundedButton closeButton;
    private bool _contentLoaded;

    private static Grid MainGrid => CustomMessageBox.localMainGrid;

    private CustomMessageBox() => this.InitializeComponent();

    private CustomMessageBox(string message, string buttonName = "OK")
    {
      this.InitializeComponent();
      this.message.Text = message;
      this.closeButton.Description = buttonName;
    }

    public static void StartWatching(Grid mainGrid)
    {
      CustomMessageBox.localMainGrid = mainGrid;
      DispatcherTimer dispatcherTimer = new DispatcherTimer();
      dispatcherTimer.Interval = TimeSpan.FromSeconds(1.0);
      dispatcherTimer.Tick += new EventHandler(CustomMessageBox.DispatcherTimer_Tick);
      dispatcherTimer.Start();
    }

    private static void DispatcherTimer_Tick(object sender, EventArgs e)
    {
      if (!ServerApi.errorOccuresAsync)
        return;
      Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, (Delegate) (() =>
      {
        ServerApi.errorOccuresAsync = false;
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
      }));
    }

    public static void Show(string message) => CustomMessageBox.MainGrid.Children.Add((UIElement) new CustomMessageBox(message));

    private void CloseButton_clickEvent()
    {
      CustomMessageBox.MainGrid.Children.Remove((UIElement) this);
      if (!UserMenager.procedureLoginInvoke)
        return;
      UserMenager.procedureLoginInvoke = false;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/basic/custommessagebox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.insideGrid = (Grid) target;
          break;
        case 2:
          this.shadow2 = (Rectangle) target;
          break;
        case 3:
          this.shadow1 = (Rectangle) target;
          break;
        case 4:
          this.mainGrid = (Grid) target;
          break;
        case 5:
          this.message = (TextBlock) target;
          break;
        case 6:
          this.closeButton = (RoundedButton) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
