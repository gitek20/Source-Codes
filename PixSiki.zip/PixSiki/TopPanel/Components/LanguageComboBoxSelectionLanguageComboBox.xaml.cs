﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.LanguageComboBox.SelectionLanguageComboBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.UserManagment;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.Components.LanguageComboBox
{
  public partial class SelectionLanguageComboBox : UserControl, IComponentConnector
  {
    private List<SimpleLanguageComboBoxItem> simpleComboBoxItems = new List<SimpleLanguageComboBoxItem>();
    private SimpleLanguageComboBoxItem polish;
    private SimpleLanguageComboBoxItem english;
    private SimpleLanguageComboBoxItem russian;
    private List<SimpleLanguageComboBoxItem> languagesItems = new List<SimpleLanguageComboBoxItem>();
    internal StackPanel mainStack;
    private bool _contentLoaded;

    public SelectionLanguageComboBox()
    {
      this.InitializeComponent();
      this.polish = new SimpleLanguageComboBoxItem(SimpleLanguageComboBoxItem.Languages.polish);
      this.mainStack.Children.Add((UIElement) this.polish);
      this.polish.selectedLanguageEvent += new SimpleLanguageComboBoxItem.SelectedLanguage(this.View_selectedItemeEvent);
      this.simpleComboBoxItems.Add(this.polish);
      this.languagesItems.Add(this.polish);
      this.english = new SimpleLanguageComboBoxItem(SimpleLanguageComboBoxItem.Languages.english);
      this.mainStack.Children.Add((UIElement) this.english);
      this.english.selectedLanguageEvent += new SimpleLanguageComboBoxItem.SelectedLanguage(this.View_selectedItemeEvent);
      this.simpleComboBoxItems.Add(this.english);
      this.languagesItems.Add(this.english);
      this.russian = new SimpleLanguageComboBoxItem(SimpleLanguageComboBoxItem.Languages.russian);
      this.mainStack.Children.Add((UIElement) this.russian);
      this.russian.selectedLanguageEvent += new SimpleLanguageComboBoxItem.SelectedLanguage(this.View_selectedItemeEvent);
      this.simpleComboBoxItems.Add(this.russian);
      this.languagesItems.Add(this.russian);
      this.Visibility = Visibility.Visible;
    }

    public void SelectCurrentLanguage()
    {
      SimpleLanguageComboBoxItem.Languages language = SimpleLanguageComboBoxItem.Languages.polish;
      if (UserMenager.LanguageKey == "PL")
        language = SimpleLanguageComboBoxItem.Languages.polish;
      if (UserMenager.LanguageKey == "EN")
        language = SimpleLanguageComboBoxItem.Languages.english;
      if (UserMenager.LanguageKey == "RU")
        language = SimpleLanguageComboBoxItem.Languages.russian;
      this.languagesItems.Where<SimpleLanguageComboBoxItem>((Func<SimpleLanguageComboBoxItem, bool>) (l => l.MyLanguage == language)).FirstOrDefault<SimpleLanguageComboBoxItem>().SelectAndInvokeEvent();
    }

    public event SimpleLanguageComboBoxItem.SelectedLanguage selectedLanguageEvent;

    private void View_selectedItemeEvent(SimpleLanguageComboBoxItem.Languages language)
    {
      foreach (SimpleLanguageComboBoxItem simpleComboBoxItem in this.simpleComboBoxItems)
      {
        if (simpleComboBoxItem.MyLanguage != language)
          simpleComboBoxItem.IsSelected = false;
      }
      if (this.selectedLanguageEvent == null)
        return;
      this.selectedLanguageEvent(language);
    }

    private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e) => this.Visibility = Visibility.Collapsed;

    internal void SelectFirstItem() => this.simpleComboBoxItems[0].SelectAndInvokeEvent();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/languagecombobox/selectionlanguagecombobox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.mainStack = (StackPanel) target;
        else
          this._contentLoaded = true;
      }
      else
        ((UIElement) target).PreviewMouseDown += new MouseButtonEventHandler(this.Grid_PreviewMouseDown);
    }
  }
}
