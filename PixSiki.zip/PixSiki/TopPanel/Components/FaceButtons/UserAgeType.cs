﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.FaceButtons.UserAgeType
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.TopPanel.Components.FaceButtons
{
  public enum UserAgeType
  {
    girl,
    girl1,
    girl2,
    girl3,
    boy,
    boy1,
    boy2,
    boy3,
    man,
    man1,
    man2,
    man3,
    woman,
    woman1,
    woman2,
    woman3,
  }
}
