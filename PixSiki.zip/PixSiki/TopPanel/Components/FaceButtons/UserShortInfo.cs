﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.FaceButtons.UserShortInfo
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.TopPanel.Components.FaceButtons
{
  public class UserShortInfo
  {
    private string name;
    private string surname;
    private string email;
    private string studentsClassName;

    public UserShortInfo(string name, string surname, string email, string studentsClassName)
    {
      this.name = name;
      this.surname = surname;
      this.email = email;
      this.studentsClassName = studentsClassName;
    }

    public string Name
    {
      get => this.name;
      set => this.name = value;
    }

    public string Surname
    {
      get => this.surname;
      set => this.surname = value;
    }

    public string Email
    {
      get => this.email;
      set => this.email = value;
    }

    public string StudentsClassName
    {
      get => this.studentsClassName;
      set => this.studentsClassName = value;
    }
  }
}
