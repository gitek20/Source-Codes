﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.Components.CountrySelectorComboBox.CountrySelector
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.Components.CountrySelectorComboBox
{
  public partial class CountrySelector : UserControl, IComponentConnector
  {
    internal Label CountryLabel;
    internal ComboBox CountryComboBox;
    private bool _contentLoaded;

    public void SetCountryId(int idCountry) => this.CountryComboBox.SelectedIndex = idCountry - 1;

    public int GetCountryId() => ((CountrySelector.ComboboxItem) this.CountryComboBox.SelectedItem).Id;

    public CountrySelector() => this.InitializeComponent();

    public void LoadCountries()
    {
      this.CountryLabel.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("countrySelect");
      CultureInfo installedUiCulture = CultureInfo.InstalledUICulture;
      List<Countrie> countrieList = new List<Countrie>();
      List<Countrie> allCountries = new ServerApi().GetAllCountries();
      foreach (Countrie countrie in allCountries)
        this.CountryComboBox.Items.Add((object) new CountrySelector.ComboboxItem(countrie.Id, countrie.Name, countrie.Code));
      string lang = installedUiCulture.TwoLetterISOLanguageName.ToUpper();
      if (allCountries.FirstOrDefault<Countrie>((Func<Countrie, bool>) (c => c.Code == lang)) == null)
        lang = "US";
      this.CountryComboBox.SelectedIndex = allCountries.FirstOrDefault<Countrie>((Func<Countrie, bool>) (c => c.Code == lang)).Id - 1;
    }

    private void CountryComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/components/countryselectorcombobox/countryselector.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
        {
          this.CountryComboBox = (ComboBox) target;
          this.CountryComboBox.SelectionChanged += new SelectionChangedEventHandler(this.CountryComboBox_SelectionChanged);
        }
        else
          this._contentLoaded = true;
      }
      else
        this.CountryLabel = (Label) target;
    }

    public class ComboboxItem
    {
      public ComboboxItem()
      {
      }

      public ComboboxItem(int id, string name, string code)
      {
        this.Id = id;
        this.Name = name;
        this.Code = (object) code;
      }

      public int Id { get; set; }

      public string Name { get; set; }

      public object Code { get; set; }

      public override string ToString() => this.Name;
    }
  }
}
