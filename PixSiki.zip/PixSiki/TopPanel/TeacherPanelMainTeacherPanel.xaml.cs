﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.TeacherPanel.MainTeacherPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.TeacherPanel.Models;
using PixBlocks.TopPanel.TeacherPanel.Models.CategoriesVisibility;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers;
using PixBlocks.TopPanel.TeacherPanel.Models.PanelsControllers.LearningResultsPanels;
using PixBlocks.TopPanel.TeacherPanel.Views.ActionPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.LeftPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.MainPanelComponents;
using PixBlocks.TopPanel.TeacherPanel.Views.TopStackComponents;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.TeacherPanel
{
  public partial class MainTeacherPanel : UserControl, ITeacherPanelController, IComponentConnector
  {
    private RefreshEvent eventController;
    private ActionPanel actionPanel;
    private LeftPanel leftPanel;
    private MainPanel mainPanel;
    private TopStackPanel topStackPanel;
    private ISubPanelOnStackController currentPanel;
    private GenericPopUp genericPopUp;
    internal Grid mainGrid;
    internal Grid topStackGrid;
    internal Grid leftPanelGrid;
    internal Grid actionPanelGrid;
    internal Grid mainPanelGrid;
    private bool _contentLoaded;

    public MainTeacherPanel()
    {
      this.InitializeComponent();
      this.eventController = new RefreshEvent();
      this.actionPanel = new ActionPanel();
      this.actionPanelGrid.Children.Add((UIElement) this.actionPanel);
      this.leftPanel = new LeftPanel();
      this.leftPanel.backButtonClickedEvent += new LeftPanel.BackButtonClicked(this.LeftPanel_backButtonClickedEvent);
      this.leftPanelGrid.Children.Add((UIElement) this.leftPanel);
      this.mainPanel = new MainPanel(this.eventController);
      this.mainPanelGrid.Children.Add((UIElement) this.mainPanel);
      this.topStackPanel = new TopStackPanel((ITeacherPanelController) this);
      this.topStackGrid.Children.Add((UIElement) this.topStackPanel);
      this.SetListOfStudentsClassesPanel(CurrentUserInfo.CurrentUser.Id.Value);
    }

    private void LeftPanel_backButtonClickedEvent() => this.topStackPanel.BackButton_clickEvent();

    public ActionPanel ActionPanel => this.actionPanel;

    public LeftPanel LeftPanel => this.leftPanel;

    public MainPanel MainPanel => this.mainPanel;

    public TopStackPanel TopStackPanel => this.topStackPanel;

    ISubPanelOnStackController ITeacherPanelController.CurrentPanel
    {
      get => this.currentPanel;
      set => this.currentPanel = value;
    }

    public void SetExamPanel(Exam exam) => this.currentPanel = (ISubPanelOnStackController) new ExamPanel(exam, (ITeacherPanelController) this);

    public void SetListOfStudentsClassesPanel(int teacherID) => this.currentPanel = (ISubPanelOnStackController) new ListOfStudentsClasses(teacherID, (ITeacherPanelController) this);

    public void SetStudentsClassPanel(int studentsClassID) => this.currentPanel = (ISubPanelOnStackController) new StudentsClassPanel(studentsClassID, (ITeacherPanelController) this, this.eventController);

    public void SetUserPanel(StudentsClass studentsClass, User user) => this.currentPanel = (ISubPanelOnStackController) new UserPanel(studentsClass, user, (ITeacherPanelController) this);

    public void SetLearningResultPanel(int studentsClassID, StatisticInputData statisticInputData) => this.currentPanel = (ISubPanelOnStackController) new LearningResultsPanel(studentsClassID, statisticInputData, (ITeacherPanelController) this);

    public void SetSingleCoursePanel(StudentsClass studentsClass, string courseGuid) => this.currentPanel = (ISubPanelOnStackController) new CourseController(studentsClass, (ITeacherPanelController) this, courseGuid);

    public void ShowPopupWindow(
      UserControl newUserControl,
      bool showCloseButton,
      bool showFullWidthPopUp)
    {
      this.genericPopUp = new GenericPopUp();
      this.genericPopUp.AddComponent(newUserControl);
      this.genericPopUp.IsCloseButton(showCloseButton);
      this.genericPopUp.IsFullWidth(showFullWidthPopUp);
      this.genericPopUp.ShowBlueBackground = true;
      this.mainGrid.Children.Add((UIElement) this.genericPopUp);
      this.genericPopUp.closePopUpEvent += new GenericPopUp.ClosePopUp(this.GenericPopUp_closePopUpEvent);
      if (!(newUserControl is IClosableUserControl))
        return;
      (newUserControl as IClosableUserControl).ParentPopUp = this.genericPopUp;
      (newUserControl as IClosableUserControl).closePopUpEvent += new ClosePopUpDelegate.ClosePopUp(this.GenericPopUp_closePopUpEvent);
    }

    private void GenericPopUp_closePopUpEvent(GenericPopUp genericPopUp)
    {
      this.mainGrid.Children.Remove((UIElement) genericPopUp);
      if (this.currentPanel == null)
        return;
      this.currentPanel.RefreshView();
    }

    public void ClosePopUp()
    {
      if (!this.mainGrid.Children.Contains((UIElement) this.genericPopUp))
        return;
      this.GenericPopUp_closePopUpEvent(this.genericPopUp);
    }

    public void DisposeAllElements()
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/teacherpanel/mainteacherpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.topStackGrid = (Grid) target;
          break;
        case 3:
          this.leftPanelGrid = (Grid) target;
          break;
        case 4:
          this.actionPanelGrid = (Grid) target;
          break;
        case 5:
          this.mainPanelGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
