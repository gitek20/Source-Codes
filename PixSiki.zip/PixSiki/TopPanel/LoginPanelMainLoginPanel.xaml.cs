﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.TopPanel.LoginPanel.MainLoginPanel
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.LoginPanel.Models;
using PixBlocks.TopPanel.LoginPanel.Views;
using PixBlocks.UpdaterFTP.Views;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.TopPanel.LoginPanel
{
  public partial class MainLoginPanel : UserControl, ILoginPanelController, IComponentConnector
  {
    private GenericPopUp popUp;
    private StartLoginPanel startLogin;
    internal Grid mainGrid;
    internal Label labelVersion;
    private bool _contentLoaded;

    public MainLoginPanel()
    {
      this.InitializeComponent();
      this.popUp = new GenericPopUp();
      this.popUp.IsCloseButton(false);
      this.mainGrid.Children.Add((UIElement) this.popUp);
      this.ShowLoginView();
      this.startLogin.CheckUpdatesMSI();
      if (PixBlocks.Version.isMSIVersion)
        this.labelVersion.Content = (object) ("v. " + PixBlocks.Version.currentVersion.ToString() + "m");
      else
        this.labelVersion.Content = (object) ("v. " + PixBlocks.Version.currentVersion.ToString() + "c");
    }

    public void ShowNewestVersionMSIAvaiable(string url, string fileName) => this.popUp.AddComponent((UserControl) new ShowNewVersion(url, fileName, (ILoginPanelController) this));

    public void ShowRegistrationView() => this.popUp.AddComponent((UserControl) new RegisterPanel((ILoginPanelController) this));

    public void ShowLoginView()
    {
      this.startLogin = new StartLoginPanel((ILoginPanelController) this);
      this.popUp.AddComponent((UserControl) this.startLogin);
      this.startLogin.loginSucesfullEvent += new MainLoginPanel.LoginSucessfull(this.LoginPanel_loginSucesfullEvent);
    }

    public void ShowResendPasswordView() => this.popUp.AddComponent((UserControl) new ForgetPasswordReminderPanel((ILoginPanelController) this));

    public void ShowConfirmRegistrationView(string email) => this.popUp.AddComponent((UserControl) new SendRegistationEmailInfo((ILoginPanelController) this, email));

    public void ShowNoActivationEmailInfo(string email) => this.popUp.AddComponent((UserControl) new NoActivationEmailInfo((ILoginPanelController) this, email));

    public void ShowInternetConnectionError() => this.popUp.AddComponent((UserControl) new InternetConnectionError((ILoginPanelController) this));

    public event MainLoginPanel.LoginSucessfull loginSucesfullEvent;

    public void ShowDemoVersionInformation()
    {
      DemoVersionInformation versionInformation = new DemoVersionInformation((ILoginPanelController) this);
      this.popUp.AddComponent((UserControl) versionInformation);
      versionInformation.loginSucesfullEvent += new MainLoginPanel.LoginSucessfull(this.LoginPanel_loginSucesfullEvent);
    }

    private void LoginPanel_loginSucesfullEvent()
    {
      if (this.loginSucesfullEvent == null)
        return;
      this.loginSucesfullEvent();
    }

    public void ShowEnterPinPanel() => this.popUp.AddComponent((UserControl) new EnterPinPanel((ILoginPanelController) this));

    public void ShowPasswordResetPanel() => this.popUp.AddComponent((UserControl) new PasswordResetPanel((ILoginPanelController) this));

    public void ShowConfirmRegistrationView() => throw new NotImplementedException();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/toppanel/loginpanel/mainloginpanel.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.labelVersion = (Label) target;
        else
          this._contentLoaded = true;
      }
      else
        this.mainGrid = (Grid) target;
    }

    public delegate void LoginSucessfull();
  }
}
