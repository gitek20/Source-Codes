﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UpdaterFTP.Controllers.StarterUpdater
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.LoginPanel.Models;
using System;
using System.Net;

namespace PixBlocks.UpdaterFTP.Controllers
{
  public class StarterUpdater
  {
    private ILoginPanelController mainController;

    public StarterUpdater(ILoginPanelController mainController) => this.mainController = mainController;

    public byte[] GetFileViaHttp(string url)
    {
      using (WebClient webClient = new WebClient())
        return webClient.DownloadData(url);
    }

    public bool CheckUpdateMSI()
    {
      try
      {
        ServicePointManager.Expect100Continue = true;
        ServicePointManager.SecurityProtocol = (SecurityProtocolType) 3072;
        int num = int.Parse(new WebClient().DownloadString("http://pixblocks.com/application/version.txt"));
        if (PixBlocks.Version.currentVersion < num)
        {
          this.mainController.ShowNewestVersionMSIAvaiable("http://pixblocks.com/application/PixBlocks_Setup_v" + num.ToString() + ".msi", "PixBlocks_Setup_v" + num.ToString() + ".msi");
          return true;
        }
      }
      catch (Exception ex)
      {
        return false;
      }
      return false;
    }
  }
}
