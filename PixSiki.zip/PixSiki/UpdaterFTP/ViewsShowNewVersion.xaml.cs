﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UpdaterFTP.Views.ShowNewVersion
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.LoginPanel.Models;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.UpdaterFTP.Views
{
  public partial class ShowNewVersion : UserControl, IComponentConnector
  {
    private string urlToDownload;
    private string instalatorPath;
    private ILoginPanelController mainController;
    internal BigCaption bigCaption;
    internal SmallInfoText instruction;
    internal SmallInfoText downloadinfInfo;
    internal ProgressBar progressBar;
    internal ActionButtons actionButtons;
    private bool _contentLoaded;

    public ShowNewVersion(
      string urlToDownload,
      string fileName,
      ILoginPanelController mainController)
    {
      this.InitializeComponent();
      this.urlToDownload = urlToDownload;
      this.mainController = mainController;
      string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
      if (!Directory.Exists(folderPath + "\\PixBlocks_setups_msi"))
        Directory.CreateDirectory(folderPath + "\\PixBlocks_setups_msi");
      this.instalatorPath = folderPath + "\\PixBlocks_setups_msi\\" + fileName;
      this.bigCaption.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("newVersion");
      this.instruction.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("newVersionText");
      this.actionButtons.abort.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("cancel");
      this.actionButtons.confirm.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("download");
      this.actionButtons.abort.clickEvent += new RoundedButton.ClickDelegate(this.Abort_clickEvent);
      this.actionButtons.confirm.clickEvent += new RoundedButton.ClickDelegate(this.Confirm_clickEvent);
    }

    private void Abort_clickEvent() => this.mainController.ShowLoginView();

    private void Confirm_clickEvent()
    {
      this.progressBar.Visibility = Visibility.Visible;
      this.downloadinfInfo.Visibility = Visibility.Visible;
      this.downloadFile();
      this.actionButtons.Visibility = Visibility.Collapsed;
      this.instruction.Visibility = Visibility.Collapsed;
    }

    private void downloadFile()
    {
      using (WebClient webClient = new WebClient())
      {
        webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(this.wc_DownloadProgressChanged);
        webClient.DownloadFileCompleted += new AsyncCompletedEventHandler(this.wc_DownloadFileCompleted);
        try
        {
          webClient.DownloadFileAsync(new Uri(this.urlToDownload), this.instalatorPath);
        }
        catch
        {
          int num = (int) MessageBox.Show("async error");
          webClient.DownloadFile(new Uri(this.urlToDownload), this.instalatorPath);
        }
      }
    }

    private void wc_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
    {
      this.progressBar.Value = (double) e.ProgressPercentage;
      this.downloadinfInfo.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("downloadingStatus") + string.Format(" {0}% - {1} mb", (object) e.ProgressPercentage, (object) (e.BytesReceived / 1024L / 1024L));
    }

    private void wc_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
    {
      if (e.Cancelled)
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("downloadingCancel"));
      else if (e.Error != null)
      {
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("downloadingError"));
      }
      else
      {
        Process.Start(this.instalatorPath);
        Application.Current.Shutdown();
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/updaterftp/views/shownewversion.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.bigCaption = (BigCaption) target;
          break;
        case 2:
          this.instruction = (SmallInfoText) target;
          break;
        case 3:
          this.downloadinfInfo = (SmallInfoText) target;
          break;
        case 4:
          this.progressBar = (ProgressBar) target;
          break;
        case 5:
          this.actionButtons = (ActionButtons) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
