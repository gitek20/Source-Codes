﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.ProcedureView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Views.CodeElements.BasicBlocks;
using PixBlocks.Views.DragDropController;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.CodeElements
{
  public partial class ProcedureView : UserControl, IUCWithICodeElement, IComponentConnector
  {
    private Procedure procedure;
    internal Rectangle mainGrid;
    internal VariableView BackgroudVariable;
    internal StackPanel stackValues;
    private bool _contentLoaded;

    public ProcedureView(Procedure procedure)
    {
      this.InitializeComponent();
      StaticDragController.Instance.dragingTypeChanged += new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.procedure = procedure;
      this.BackgroudVariable.SetValueTypeView(procedure.GetRetunType(), procedure);
      if (procedure.ProcedureType == ProceduresTypes.GetR)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new ColorView(Colors.Red));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.GetG)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new ColorView(Colors.Green));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.GetB)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new ColorView(Colors.Blue));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.GetColorFromRGB)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new ColorView(Colors.Red));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new VerySmallMargin());
        this.stackValues.Children.Add((UIElement) new ColorView(Colors.Green));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new VerySmallMargin());
        this.stackValues.Children.Add((UIElement) new ColorView(Colors.Blue));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[2]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.GetPutPixel || procedure.ProcedureType == ProceduresTypes.GetPutImage)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new PixelIcon());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new SmallVerticalLine());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.PutRectangleInColor)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new SquarIcon());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new SmallVerticalLine());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[2]));
        this.stackValues.Children.Add((UIElement) new SmallVerticalLine());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[3]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.GetNumberOfColorsInRectangle)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new SquarIcon());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new SmallVerticalLine());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[2]));
        this.stackValues.Children.Add((UIElement) new SmallVerticalLine());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[3]));
        this.stackValues.Children.Add((UIElement) new TextBlockView("#"));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[4]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.GetNumberOfColorsInX)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new TextBlockView("X="));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new TextBlockView("#"));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.GetNumberOfColorsInY)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new TextBlockView("Y="));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new TextBlockView("#"));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.MathDiv)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new TextBlockView("/"));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1])
        {
          CannotBeZero = true
        });
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.MathMinus)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new TextBlockView("-"));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.MathMod)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new TextBlockView("%"));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1])
        {
          CannotBeZero = true
        });
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.MathMulti)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new TextBlockView("*"));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.MathPlus)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[0]));
        this.stackValues.Children.Add((UIElement) new TextBlockView("+"));
        this.stackValues.Children.Add((UIElement) new VariableView((Variable) procedure.ProcedureParams[1]));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.TurtleX)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new RabbitIcon2());
        (this.stackValues.Children[this.stackValues.Children.Count - 1] as RabbitIcon2).Height = 35.0;
        (this.stackValues.Children[this.stackValues.Children.Count - 1] as RabbitIcon2).Width = 35.0;
        this.stackValues.Children.Add((UIElement) new TextBlockView("X"));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType == ProceduresTypes.TurtleY)
      {
        this.stackValues.Children.Add((UIElement) new SmallMargin());
        this.stackValues.Children.Add((UIElement) new RabbitIcon2());
        (this.stackValues.Children[this.stackValues.Children.Count - 1] as RabbitIcon2).Height = 35.0;
        (this.stackValues.Children[this.stackValues.Children.Count - 1] as RabbitIcon2).Width = 35.0;
        this.stackValues.Children.Add((UIElement) new TextBlockView("Y"));
        this.stackValues.Children.Add((UIElement) new SmallMargin());
      }
      if (procedure.ProcedureType != ProceduresTypes.TurtleSee)
        return;
      this.stackValues.Children.Add((UIElement) new SmallMargin());
      this.stackValues.Children.Add((UIElement) new RabbitIcon2());
      (this.stackValues.Children[this.stackValues.Children.Count - 1] as RabbitIcon2).Height = 35.0;
      (this.stackValues.Children[this.stackValues.Children.Count - 1] as RabbitIcon2).Width = 35.0;
      this.stackValues.Children.Add((UIElement) new SmallMargin());
    }

    public bool RecursivelyIsSomeChildDropping(VariableView parent)
    {
      foreach (object child in this.stackValues.Children)
      {
        if (child is VariableView && ((VariableView) child).RecursivelyIsSomeChildDropping(parent))
          return true;
      }
      return false;
    }

    public ProcedureView()
    {
      this.InitializeComponent();
      this.BackgroudVariable.SetValueTypeView(PixBlocks.DataModels.Code.ValueType.Color, (Procedure) null);
    }

    private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None || !this.procedure.GetIsTemplateElement())
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
      StaticDragController.Instance.StartDragingFromTemplate((UserControl) this);
    }

    private void Instance_dragingTypeChanged(StaticDragController.DraggingType draggingType)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(Colors.Transparent);
    }

    public ICodeElement GetCodeElement() => (ICodeElement) this.procedure;

    public void DisposeAll()
    {
      StaticDragController.Instance.dragingTypeChanged -= new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      for (int index = 0; index < this.stackValues.Children.Count; ++index)
      {
        if (this.stackValues.Children[index] is IUCWithICodeElement)
          (this.stackValues.Children[index] as IUCWithICodeElement).DisposeAll();
      }
      this.stackValues.Children.Clear();
      this.mainGrid = (Rectangle) null;
      this.procedure = (Procedure) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/codeelements/procedureview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          break;
        case 2:
          this.mainGrid = (Rectangle) target;
          break;
        case 3:
          this.BackgroudVariable = (VariableView) target;
          break;
        case 4:
          this.stackValues = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
