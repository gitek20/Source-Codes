﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.VariableView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Tools.ColorTransformation;
using PixBlocks.Views.CodeElements.BasicBlocks;
using PixBlocks.Views.DragDropController;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.CodeElements
{
  public partial class VariableView : UserControl, IUCWithICodeElement, IComponentConnector
  {
    private Variable variable;
    private ProcedureView pv;
    private bool canDroppToThis = true;
    private bool cannotBeZero;
    private bool sometchingIsDroppingOnIt;
    internal Rectangle mainGrid;
    internal Grid GridBackImage;
    internal Rectangle mainRectangle;
    internal Rectangle colorTypeRect1;
    internal Rectangle colorTypeRect2;
    internal Rectangle mainRectangle2;
    internal Grid GridBackImage2;
    internal Label variableName;
    internal Ellipse colorValue;
    internal Grid GridFrontImage;
    internal Rectangle Imagerec;
    internal Grid BlockImage;
    internal Label ImageVariableLabel;
    internal Grid gridTop;
    private bool _contentLoaded;

    public VariableView(Variable variable)
    {
      this.variable = variable;
      this.InitializeComponent();
      StaticDragController.Instance.dragingTypeChanged += new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.RefreshView();
      variable.refreshingViewEvent += new Variable.RefreshView(this.Variable_refreshingViewEvent);
    }

    private void Variable_refreshingViewEvent() => this.RefreshView();

    public void SetValueTypeView(PixBlocks.DataModels.Code.ValueType valueType, Procedure procedure)
    {
      if (valueType == PixBlocks.DataModels.Code.ValueType.Image)
      {
        this.GridBackImage.Visibility = Visibility.Collapsed;
        this.GridBackImage2.Visibility = Visibility.Collapsed;
        this.ImageVariableLabel.Visibility = Visibility.Collapsed;
        this.Imagerec.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 241, (byte) 241, (byte) 241));
        this.Imagerec.Height = 52.0;
      }
      if (valueType != PixBlocks.DataModels.Code.ValueType.Image)
        this.GridFrontImage.Visibility = Visibility.Collapsed;
      this.variableName.Visibility = Visibility.Collapsed;
      this.colorValue.Visibility = Visibility.Collapsed;
      if (valueType == PixBlocks.DataModels.Code.ValueType.Number)
      {
        this.colorTypeRect1.Visibility = Visibility.Collapsed;
        this.colorTypeRect2.Visibility = Visibility.Collapsed;
      }
      SolidColorBrush solidColorBrush = new SolidColorBrush(Color.FromRgb((byte) 241, (byte) 241, (byte) 241));
      this.colorTypeRect1.Fill = (Brush) solidColorBrush;
      this.colorTypeRect2.Fill = (Brush) solidColorBrush;
      this.mainRectangle.Fill = (Brush) solidColorBrush;
      this.mainRectangle2.Fill = (Brush) solidColorBrush;
    }

    public VariableView() => this.InitializeComponent();

    private void RenderProcedure()
    {
      this.GridFrontImage.Visibility = Visibility.Collapsed;
      this.mainRectangle.Visibility = Visibility.Collapsed;
      this.mainRectangle2.Visibility = Visibility.Collapsed;
      this.colorTypeRect1.Visibility = Visibility.Collapsed;
      this.colorTypeRect2.Visibility = Visibility.Collapsed;
      this.variableName.Visibility = Visibility.Collapsed;
      this.colorValue.Visibility = Visibility.Collapsed;
      this.gridTop.Children.Clear();
      this.pv = new ProcedureView(this.variable.InnerProcedure);
      this.gridTop.Children.Add((UIElement) this.pv);
      this.Height = this.pv.Height;
      this.Width = this.pv.Width;
    }

    private void RefreshView()
    {
      if (this.variable.VariableType == VariableType.procedure)
        this.RenderProcedure();
      else if (this.variable.ValueType == PixBlocks.DataModels.Code.ValueType.Image)
      {
        this.gridTop.Children.Clear();
        this.Height = 50.0;
        this.Width = 75.0;
        this.GridBackImage.Visibility = Visibility.Collapsed;
        this.GridBackImage2.Visibility = Visibility.Collapsed;
        this.GridFrontImage.Visibility = Visibility.Visible;
        this.BlockImage.Children.Clear();
        this.Imagerec.Fill = (Brush) new SolidColorBrush(Colors.White);
        if (this.variable.VariableType == VariableType.constant)
        {
          this.BlockImage.Children.Add((UIElement) PixBlocks.BlocksManager.BlocksManager.GetUCOfBlock(this.variable.RunInnerCode((Value) null, (CodeInOut) null).ImageName));
          this.ImageVariableLabel.Visibility = Visibility.Collapsed;
        }
        else
          this.ImageVariableLabel.Visibility = Visibility.Visible;
      }
      else
      {
        this.GridFrontImage.Visibility = Visibility.Collapsed;
        this.mainRectangle.Visibility = Visibility.Visible;
        this.mainRectangle2.Visibility = Visibility.Visible;
        this.Height = 50.0;
        this.Width = 75.0;
        this.colorTypeRect1.Visibility = Visibility.Visible;
        this.colorTypeRect2.Visibility = Visibility.Visible;
        this.variableName.Visibility = Visibility.Visible;
        this.colorValue.Visibility = Visibility.Visible;
        this.gridTop.Children.Clear();
        if (this.variable.ValueType == PixBlocks.DataModels.Code.ValueType.Number)
        {
          this.colorTypeRect1.Visibility = Visibility.Collapsed;
          this.colorTypeRect2.Visibility = Visibility.Collapsed;
        }
        if (this.variable.VariableType == VariableType.epty || this.variable.VariableType == VariableType.imageHeight || this.variable.VariableType == VariableType.imageWidth || this.variable.VariableType == VariableType.constant && this.variable.ValueType == PixBlocks.DataModels.Code.ValueType.Color)
          this.variableName.Visibility = Visibility.Collapsed;
        if (this.variable.VariableType == VariableType.constant && this.variable.ValueType == PixBlocks.DataModels.Code.ValueType.Color)
        {
          Color colorFromValue = ColorTransorm.GetColorFromValue(this.variable.RunInnerCode((Value) null, (CodeInOut) null));
          this.colorValue.Fill = (Brush) new SolidColorBrush(colorFromValue);
          this.colorValue.StrokeThickness = 0.0;
          if (colorFromValue == Colors.White)
            this.colorValue.StrokeThickness = 2.0;
        }
        else
          this.colorValue.Visibility = Visibility.Collapsed;
        if (this.variable.VariableType == VariableType.variable)
        {
          this.variableName.Content = (object) this.variable.Name;
          this.variableName.FontWeight = FontWeight.FromOpenTypeWeight(999);
        }
        if (this.variable.VariableType == VariableType.constant && this.variable.ValueType == PixBlocks.DataModels.Code.ValueType.Number)
        {
          this.variableName.FontWeight = FontWeight.FromOpenTypeWeight(1);
          this.variableName.Content = (object) this.variable.RunInnerCode((Value) null, (CodeInOut) null).Number;
        }
        if (this.variable.VariableType == VariableType.imageHeight)
          this.gridTop.Children.Add((UIElement) new HeightIcon());
        if (this.variable.VariableType != VariableType.imageWidth)
          return;
        this.gridTop.Children.Add((UIElement) new WidthIcon());
      }
    }

    private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.variable == null || !this.variable.GetIsTemplateElement() || (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None || this.variable.GetParent() != null))
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
      this.mainGrid.Stroke = (Brush) new SolidColorBrush(Colors.Red);
      this.mainGrid.Visibility = Visibility.Visible;
      StaticDragController.Instance.StartDragingFromTemplate((UserControl) this);
    }

    private void Instance_dragingTypeChanged(StaticDragController.DraggingType draggingType)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(Colors.Transparent);
      this.mainGrid.Stroke = (Brush) new SolidColorBrush(Colors.Transparent);
      this.mainGrid.Visibility = Visibility.Hidden;
    }

    private bool CanDropElementOnThis()
    {
      if (this.variable != null && StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None && StaticDragController.Instance.UcToDrag != this)
      {
        ICodeElement codeElement = ((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement();
        if (this.cannotBeZero)
          return codeElement is Variable && ((codeElement as Variable).VariableType == VariableType.constant && (codeElement as Variable).RunInnerCode((Value) null, (CodeInOut) null).Number > 0L || ((codeElement as Variable).VariableType == VariableType.imageHeight || (codeElement as Variable).VariableType == VariableType.imageWidth));
        if (this.variable.CanDragAndDropElement(codeElement))
          return true;
      }
      return false;
    }

    public void RecursivelySetCanDropToParents(bool canDrop)
    {
      FrameworkElement parent = (FrameworkElement) this.Parent;
      for (int index = 0; index < 1000 && parent != null; ++index)
      {
        if (parent is VariableView)
        {
          VariableView variableView = (VariableView) parent;
          variableView.CanDroppToThis = false;
          variableView.RecursivelySetCanDropToParents(canDrop);
          break;
        }
        parent = (FrameworkElement) parent.Parent;
      }
    }

    public bool CanDroppToThis
    {
      get => this.canDroppToThis;
      set
      {
        if (!value)
        {
          this.mainGrid.Fill = (Brush) new SolidColorBrush(Colors.Red);
        }
        else
        {
          this.canDroppToThis = value;
          if (this.CanDropElementOnThis())
            this.mainGrid.Fill = (Brush) new SolidColorBrush(Colors.Blue);
        }
        this.canDroppToThis = value;
      }
    }

    public bool SometchingIsDroppingOnIt
    {
      get => this.sometchingIsDroppingOnIt;
      set => this.sometchingIsDroppingOnIt = value;
    }

    public bool CannotBeZero
    {
      set => this.cannotBeZero = value;
    }

    public bool RecursivelyIsSomeChildDropping(VariableView parent)
    {
      if (this.sometchingIsDroppingOnIt && parent != this)
        return true;
      return this.variable.VariableType == VariableType.procedure && this.pv != null && this.pv.RecursivelyIsSomeChildDropping(parent);
    }

    private void Grid_MouseEnter(object sender, MouseEventArgs e)
    {
    }

    private void UserControl_MouseLeave(object sender, MouseEventArgs e)
    {
      if (e.LeftButton != MouseButtonState.Released || e.RightButton != MouseButtonState.Released)
        this.SometchingIsDroppingOnIt = false;
      if (StaticDragController.Instance.UcToDrag == this)
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(Colors.Transparent);
      this.mainGrid.Stroke = (Brush) new SolidColorBrush(Colors.Transparent);
      this.mainGrid.Visibility = Visibility.Hidden;
    }

    private void UserControl_MouseUp(object sender, MouseButtonEventArgs e)
    {
      if (this.CanDropElementOnThis() && this.canDroppToThis && this.SometchingIsDroppingOnIt)
        this.variable.ReplaceThisVariableBy(((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement());
      this.SometchingIsDroppingOnIt = false;
    }

    public ICodeElement GetCodeElement() => (ICodeElement) this.variable;

    private void UserControl_MouseMove(object sender, MouseEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType == StaticDragController.DraggingType.None || !this.CanDropElementOnThis())
        return;
      if (!this.RecursivelyIsSomeChildDropping(this))
      {
        this.mainGrid.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
        this.mainGrid.Stroke = (Brush) new SolidColorBrush(Colors.Red);
        this.mainGrid.Visibility = Visibility.Visible;
        this.SometchingIsDroppingOnIt = true;
      }
      else
      {
        this.mainGrid.Fill = (Brush) new SolidColorBrush(Colors.Transparent);
        this.mainGrid.Stroke = (Brush) new SolidColorBrush(Colors.Transparent);
        this.mainGrid.Visibility = Visibility.Hidden;
        this.SometchingIsDroppingOnIt = false;
      }
    }

    private void UserControl_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
    }

    public void DisposeAll()
    {
      StaticDragController.Instance.dragingTypeChanged -= new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.variable.refreshingViewEvent -= new Variable.RefreshView(this.Variable_refreshingViewEvent);
      if (this.pv != null)
        this.pv.DisposeAll();
      this.pv = (ProcedureView) null;
      this.variable = (Variable) null;
      this.BlockImage.Children.Clear();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/codeelements/variableview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.UserControl_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.UserControl_MouseUp);
          ((UIElement) target).MouseMove += new MouseEventHandler(this.UserControl_MouseMove);
          ((UIElement) target).PreviewMouseUp += new MouseButtonEventHandler(this.UserControl_PreviewMouseUp);
          break;
        case 2:
          this.mainGrid = (Rectangle) target;
          break;
        case 3:
          this.GridBackImage = (Grid) target;
          break;
        case 4:
          this.mainRectangle = (Rectangle) target;
          break;
        case 5:
          this.colorTypeRect1 = (Rectangle) target;
          break;
        case 6:
          this.colorTypeRect2 = (Rectangle) target;
          break;
        case 7:
          this.mainRectangle2 = (Rectangle) target;
          break;
        case 8:
          this.GridBackImage2 = (Grid) target;
          break;
        case 9:
          this.variableName = (Label) target;
          break;
        case 10:
          this.colorValue = (Ellipse) target;
          break;
        case 11:
          this.GridFrontImage = (Grid) target;
          break;
        case 12:
          this.Imagerec = (Rectangle) target;
          break;
        case 13:
          this.BlockImage = (Grid) target;
          break;
        case 14:
          this.ImageVariableLabel = (Label) target;
          break;
        case 15:
          this.gridTop = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
