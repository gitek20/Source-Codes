﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.StaticVariables.VariableColorNumber
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.CodeInputOutput.Variables;
using PixBlocks.Tools.ColorTransformation;
using PixBlocks.Views.CodeElements.BasicBlocks;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.StaticVariables
{
  public partial class VariableColorNumber : UserControl, IComponentConnector
  {
    private StaticVariable var;
    private AdditionalVariableType variableType;
    private CodeInOut codeInOut;
    private PixBlocks.CodeRunner.CodeRunner codeRunner;
    private AdditionalVariableType numberOfInstructions;
    public static int c;
    internal Grid mainGrid;
    internal RabbitIcon2 rabbitIcon;
    internal WidthIcon iconWidth;
    internal HeightIcon iconHeight;
    internal Image timeIcon;
    internal Label variableName;
    internal Label equalsLabel;
    internal TextBlock variableValue;
    internal Grid ImageVariableGrid;
    internal Rectangle Imagerec;
    internal Grid ImageVariableGridInside;
    internal StackPanel colorsStackPanel;
    internal Rectangle rectColor;
    internal TextBlock variableRed;
    internal TextBlock variableGreen;
    internal TextBlock variableBlue;
    private bool _contentLoaded;

    public VariableColorNumber() => this.InitializeComponent();

    public VariableColorNumber(CodeInOut codeInOut, AdditionalVariableType variableType)
    {
      this.variableType = variableType;
      this.codeInOut = codeInOut;
      this.InitializeComponent();
      this.rabbitIcon.Visibility = Visibility.Collapsed;
      this.iconWidth.Visibility = Visibility.Collapsed;
      this.iconHeight.Visibility = Visibility.Collapsed;
      this.colorsStackPanel.Visibility = Visibility.Collapsed;
      this.variableValue.Visibility = Visibility.Visible;
      this.variableName.Visibility = Visibility.Collapsed;
      this.timeIcon.Visibility = Visibility.Collapsed;
      if (variableType == AdditionalVariableType.ImageHeight)
      {
        this.iconHeight.Visibility = Visibility.Visible;
        this.variableValue.Text = codeInOut.Image.GetHeight().ToString() ?? "";
      }
      if (variableType == AdditionalVariableType.ImageWidth)
      {
        this.iconWidth.Visibility = Visibility.Visible;
        this.variableValue.Text = codeInOut.Image.GetWidth().ToString() ?? "";
      }
      int num;
      if (variableType == AdditionalVariableType.TurtleX)
      {
        this.rabbitIcon.Visibility = Visibility.Visible;
        this.variableName.Visibility = Visibility.Visible;
        this.variableName.Content = (object) "X";
        TextBlock variableValue = this.variableValue;
        num = codeInOut.TurtleX;
        string str = num.ToString() ?? "";
        variableValue.Text = str;
        codeInOut.turleChangedEvent += new CodeInOut.TurtlePositionChanged(this.CodeStaticVariables_turleChangedEvent);
      }
      if (variableType != AdditionalVariableType.TurtleY)
        return;
      this.rabbitIcon.Visibility = Visibility.Visible;
      this.variableName.Visibility = Visibility.Visible;
      this.variableName.Content = (object) "Y";
      TextBlock variableValue1 = this.variableValue;
      num = codeInOut.TurtleY;
      string str1 = num.ToString() ?? "";
      variableValue1.Text = str1;
      codeInOut.turleChangedEvent += new CodeInOut.TurtlePositionChanged(this.CodeStaticVariables_turleChangedEvent);
    }

    private void CodeStaticVariables_turleChangedEvent()
    {
      if (this.variableType == AdditionalVariableType.TurtleX)
        this.variableValue.Text = this.codeInOut.TurtleX.ToString() ?? "";
      if (this.variableType != AdditionalVariableType.TurtleY)
        return;
      this.variableValue.Text = this.codeInOut.TurtleY.ToString() ?? "";
    }

    public VariableColorNumber(StaticVariable var)
    {
      this.InitializeComponent();
      this.var = var;
      var.staticValueChangedEvent += new StaticVariable.StaticValueChanged(this.Var_staticValueChangedEvent);
      this.rabbitIcon.Visibility = Visibility.Collapsed;
      this.iconWidth.Visibility = Visibility.Collapsed;
      this.iconHeight.Visibility = Visibility.Collapsed;
      this.timeIcon.Visibility = Visibility.Collapsed;
      this.variableName.Content = (object) var.Name;
      if (var.Val.ValType == PixBlocks.DataModels.Code.ValueType.Color)
      {
        this.colorsStackPanel.Visibility = Visibility.Visible;
        this.variableValue.Visibility = Visibility.Collapsed;
        this.ImageVariableGrid.Visibility = Visibility.Collapsed;
      }
      if (var.Val.ValType == PixBlocks.DataModels.Code.ValueType.Number)
      {
        this.colorsStackPanel.Visibility = Visibility.Collapsed;
        this.variableValue.Visibility = Visibility.Visible;
        this.ImageVariableGrid.Visibility = Visibility.Collapsed;
      }
      if (var.Val.ValType == PixBlocks.DataModels.Code.ValueType.Image)
      {
        this.colorsStackPanel.Visibility = Visibility.Collapsed;
        this.variableValue.Visibility = Visibility.Collapsed;
        this.ImageVariableGrid.Visibility = Visibility.Visible;
      }
      this.RefreshView();
    }

    public VariableColorNumber(PixBlocks.CodeRunner.CodeRunner codeRunner, AdditionalVariableType numberOfInstructions)
    {
      this.codeRunner = codeRunner;
      this.numberOfInstructions = numberOfInstructions;
      this.InitializeComponent();
      this.rabbitIcon.Visibility = Visibility.Collapsed;
      this.iconWidth.Visibility = Visibility.Collapsed;
      this.iconHeight.Visibility = Visibility.Collapsed;
      this.colorsStackPanel.Visibility = Visibility.Collapsed;
      this.variableValue.Visibility = Visibility.Visible;
      this.variableName.Visibility = Visibility.Collapsed;
      if (numberOfInstructions != AdditionalVariableType.NumberOfInstructions)
        return;
      this.variableValue.Text = 1.ToString() ?? "";
      codeRunner.iterationStepChangedEvent += new PixBlocks.CodeRunner.CodeRunner.IterationStepChanged(this.CodeRunner_iterationStepChangedEvent);
    }

    internal void DisposeAll()
    {
      if (this.numberOfInstructions == AdditionalVariableType.NumberOfInstructions)
        this.codeRunner.iterationStepChangedEvent -= new PixBlocks.CodeRunner.CodeRunner.IterationStepChanged(this.CodeRunner_iterationStepChangedEvent);
      this.mainGrid = (Grid) null;
    }

    private void CodeRunner_iterationStepChangedEvent(int step) => this.variableValue.Text = step.ToString() ?? "";

    private void Var_staticValueChangedEvent(StaticVariable var) => this.RefreshView();

    private void RefreshView()
    {
      if (this.var.Val.ValType == PixBlocks.DataModels.Code.ValueType.Color)
      {
        this.rectColor.Fill = (Brush) new SolidColorBrush(ColorTransorm.GetColorFromValue(this.var.Val));
        TextBlock variableBlue = this.variableBlue;
        int num = this.var.Val.B;
        string str1 = num.ToString() ?? "";
        variableBlue.Text = str1;
        TextBlock variableRed = this.variableRed;
        num = this.var.Val.R;
        string str2 = num.ToString() ?? "";
        variableRed.Text = str2;
        TextBlock variableGreen = this.variableGreen;
        num = this.var.Val.G;
        string str3 = num.ToString() ?? "";
        variableGreen.Text = str3;
      }
      if (this.var.Val.ValType == PixBlocks.DataModels.Code.ValueType.Number)
        this.variableValue.Text = this.var.Val.Number.ToString() ?? "";
      if (this.var.Val.ValType != PixBlocks.DataModels.Code.ValueType.Image)
        return;
      this.ImageVariableGridInside.Children.Clear();
      this.ImageVariableGridInside.Children.Add((UIElement) PixBlocks.BlocksManager.BlocksManager.GetUCOfBlock(this.var.Val.ImageName));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/staticvariables/variablecolornumber.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.rabbitIcon = (RabbitIcon2) target;
          break;
        case 3:
          this.iconWidth = (WidthIcon) target;
          break;
        case 4:
          this.iconHeight = (HeightIcon) target;
          break;
        case 5:
          this.timeIcon = (Image) target;
          break;
        case 6:
          this.variableName = (Label) target;
          break;
        case 7:
          this.equalsLabel = (Label) target;
          break;
        case 8:
          this.variableValue = (TextBlock) target;
          break;
        case 9:
          this.ImageVariableGrid = (Grid) target;
          break;
        case 10:
          this.Imagerec = (Rectangle) target;
          break;
        case 11:
          this.ImageVariableGridInside = (Grid) target;
          break;
        case 12:
          this.colorsStackPanel = (StackPanel) target;
          break;
        case 13:
          this.rectColor = (Rectangle) target;
          break;
        case 14:
          this.variableRed = (TextBlock) target;
          break;
        case 15:
          this.variableGreen = (TextBlock) target;
          break;
        case 16:
          this.variableBlue = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
