﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.DragDropController.StaticDragController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.Tools;
using PixBlocks.Views.CodeElements;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PixBlocks.Views.DragDropController
{
  internal class StaticDragController
  {
    private static StaticDragController instance;
    private StaticDragController.DraggingType draggingType = StaticDragController.DraggingType.None;
    private UserControl ucToDrag;
    public bool CanStopDragging = true;

    private StaticDragController()
    {
    }

    public static StaticDragController Instance
    {
      get
      {
        if (StaticDragController.instance == null)
          StaticDragController.instance = new StaticDragController();
        return StaticDragController.instance;
      }
    }

    public StaticDragController.DraggingType GetDraggingType => this.draggingType;

    public UserControl UcToDrag => this.ucToDrag;

    public Image GetDragElemetAsImage()
    {
      RenderTargetBitmap image1 = UserControlToBitmapRenderer.GetImage(StaticDragController.Instance.UcToDrag);
      Image image2 = new Image();
      image2.Source = (ImageSource) image1;
      ICodeElement codeElement = (StaticDragController.Instance.UcToDrag as IUCWithICodeElement).GetCodeElement();
      int num = 0;
      switch (codeElement)
      {
        case RepeatNTimes _:
        case IfThenInstruction _:
          if (!codeElement.GetIsTemplateElement())
          {
            num = 30;
            break;
          }
          break;
      }
      image2.MinWidth = StaticDragController.Instance.UcToDrag.ActualWidth + 6.0;
      image2.MinHeight = StaticDragController.Instance.UcToDrag.ActualHeight + 6.0 + (double) num;
      image2.MaxWidth = StaticDragController.Instance.UcToDrag.ActualWidth + 6.0;
      image2.MaxHeight = StaticDragController.Instance.UcToDrag.ActualHeight + 6.0 + (double) num;
      image2.Margin = new Thickness(0.0, 0.0, 0.0, (double) (-num - 3));
      image2.VerticalAlignment = VerticalAlignment.Center;
      image2.HorizontalAlignment = HorizontalAlignment.Left;
      return image2;
    }

    public event StaticDragController.Dropping droppingEvent;

    public event StaticDragController.DragingTypeChanged dragingTypeChanged;

    public void StartDragingFromTemplate(UserControl ucToDrag)
    {
      this.ucToDrag = ucToDrag;
      this.draggingType = StaticDragController.DraggingType.FromTemplate;
      if (this.dragingTypeChanged == null)
        return;
      this.dragingTypeChanged(this.draggingType);
    }

    public void StartDragingFromCode(UserControl ucToDrag)
    {
      this.ucToDrag = ucToDrag;
      this.draggingType = StaticDragController.DraggingType.InsideCode;
      if (this.dragingTypeChanged == null)
        return;
      this.dragingTypeChanged(this.draggingType);
    }

    public void StopDragging()
    {
      if (!this.CanStopDragging)
        return;
      this.ucToDrag = (UserControl) null;
      this.draggingType = StaticDragController.DraggingType.None;
      if (this.dragingTypeChanged == null)
        return;
      this.dragingTypeChanged(this.draggingType);
    }

    public void TryToDroppToInstruction(UserControl ucToDropp)
    {
    }

    public enum DraggingType
    {
      FromTemplate,
      InsideCode,
      None,
    }

    public delegate void Dropping();

    public delegate void DragingTypeChanged(StaticDragController.DraggingType draggingType);
  }
}
