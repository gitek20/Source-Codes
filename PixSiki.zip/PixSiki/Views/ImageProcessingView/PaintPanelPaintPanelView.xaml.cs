﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.ImageProcessingView.PaintPanel.PaintPanelView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Tools.ColorTransformation;
using PixBlocks.Views.CodeElements;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.Views.ImageProcessingView.PaintPanel
{
  public partial class PaintPanelView : UserControl, IComponentConnector
  {
    internal WrapPanel wrappanel;
    private bool _contentLoaded;

    public PaintPanelView(bool blocksCoding)
    {
      this.InitializeComponent();
      if (!blocksCoding)
      {
        List<Variable> variableList = new List<Variable>();
        int maxValue = (int) sbyte.MaxValue;
        List<Color> colorList = new List<Color>();
        colorList.Add(Colors.Black);
        colorList.Add(Colors.White);
        colorList.Add(Colors.Red);
        colorList.Add(Color.FromRgb((byte) 0, byte.MaxValue, (byte) 0));
        colorList.Add(Colors.Blue);
        colorList.Add(Colors.Yellow);
        colorList.Add(Colors.Cyan);
        colorList.Add(Colors.Magenta);
        colorList.Add(Color.FromRgb(byte.MaxValue, (byte) 180, (byte) 180));
        colorList.Add(Color.FromRgb((byte) 180, byte.MaxValue, (byte) 180));
        colorList.Add(Color.FromRgb((byte) 180, (byte) 180, byte.MaxValue));
        for (int index1 = 1; index1 <= (int) byte.MaxValue; index1 += maxValue)
        {
          for (int index2 = 1; index2 <= (int) byte.MaxValue; index2 += maxValue)
          {
            for (int index3 = 1; index3 <= (int) byte.MaxValue; index3 += maxValue)
            {
              Color c1 = Color.FromArgb(byte.MaxValue, (byte) index1, (byte) index2, (byte) index3);
              bool flag = false;
              foreach (Color c2 in colorList)
              {
                if (ColorTransorm.GetValueFromColor(c1).IsEqual(ColorTransorm.GetValueFromColor(c2)))
                  flag = true;
              }
              if (!flag)
                colorList.Add(c1);
            }
          }
        }
        foreach (Color c in colorList)
          variableList.Add(new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(c)));
        foreach (Variable variable in variableList)
          this.wrappanel.Children.Add((UIElement) new VariableView(variable));
      }
      else
      {
        foreach (string namesOfBlock in PixBlocks.BlocksManager.BlocksManager.NamesOfBlocks)
          this.wrappanel.Children.Add((UIElement) new VariableView(new Variable(VariableType.constant, namesOfBlock)));
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/imageprocessingview/paintpanel/paintpanelview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.wrappanel = (WrapPanel) target;
      else
        this._contentLoaded = true;
    }
  }
}
