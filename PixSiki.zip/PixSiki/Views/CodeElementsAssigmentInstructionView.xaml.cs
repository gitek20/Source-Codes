﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.AssigmentInstructionView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.PythonIron.Views.images;
using PixBlocks.Views.CodeElements.BasicBlocks;
using PixBlocks.Views.CodeElements.BlockOfCode;
using PixBlocks.Views.DragDropController;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.CodeElements
{
  public partial class AssigmentInstructionView : UserControl, IUCWithICodeElement, IUCWitchCodeBlockParent, IComponentConnector
  {
    private CodeBlock codeBlockParent;
    private AssigmentInstruction assigmentInstruction;
    internal Grid mainGrid;
    internal Rectangle dropRectangle;
    internal Rectangle rectangleHighlight;
    internal Rectangle rectangleDebug1;
    internal Rectangle rectangleDebug2;
    internal Rectangle mainRect1;
    internal Rectangle mainRect2;
    internal StackPanel stackPanel;
    private bool _contentLoaded;

    public AssigmentInstructionView() => this.InitializeComponent();

    public CodeBlock CodeBlockParent
    {
      get => this.codeBlockParent;
      set => this.codeBlockParent = value;
    }

    public AssigmentInstructionView(AssigmentInstruction assigmentInstruction)
    {
      this.InitializeComponent();
      StaticDragController.Instance.dragingTypeChanged += new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.assigmentInstruction = assigmentInstruction;
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.PlaySound)
      {
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SoundIconWhite());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new VariableView((Variable) assigmentInstruction.InputElement));
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
      }
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentColor || assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentNumber || assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage2Image)
      {
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new VariableView((Variable) assigmentInstruction.OutputElement));
        this.stackPanel.Children.Add((UIElement) new AssignIcon());
        this.stackPanel.Children.Add((UIElement) new VariableView((Variable) assigmentInstruction.InputElement));
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
      }
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage)
      {
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new VariableView((Variable) assigmentInstruction.OutputElement));
        this.stackPanel.Children.Add((UIElement) new AssignIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new RabbitIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new LookIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
      }
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.DrawTurtleColor || assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.DrawTurtleImage)
      {
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new RabbitIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new PenIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new VariableView((Variable) assigmentInstruction.InputElement));
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
      }
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.TurtleDown)
      {
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new RabbitIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new GoDownIcon());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
      }
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.TurtleLeft)
      {
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new RabbitIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new GoLeftIcon());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
      }
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.TurtleRight)
      {
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new RabbitIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new GoRightIcon());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
      }
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.TurtleTop)
      {
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new RabbitIcon());
        this.stackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new GoTopIcon());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new SmallMargin());
      }
      if (assigmentInstruction.TypeOfAssigment == AssigmentInstructionType.BreakAll)
      {
        this.mainRect1.Fill = (Brush) new SolidColorBrush(Colors.Orange);
        this.mainRect2.Fill = (Brush) new SolidColorBrush(Colors.Orange);
        for (int index = 0; index < 5; ++index)
          this.stackPanel.Children.Add((UIElement) new SmallMargin());
        this.stackPanel.Children.Add((UIElement) new CancelWhite());
        for (int index = 0; index < 5; ++index)
          this.stackPanel.Children.Add((UIElement) new SmallMargin());
      }
      assigmentInstruction.codeRunningStatusChanged += new CodeElementRunningStatus(this.AssigmentInstruction_codeRunningStatusChanged);
      this.rectangleDebug1.Fill = (Brush) new SolidColorBrush(ConfigColors.DebugingColor);
      this.rectangleDebug1.Visibility = Visibility.Hidden;
      this.rectangleDebug2.Fill = (Brush) new SolidColorBrush(ConfigColors.DebugingColor);
      this.rectangleDebug2.Visibility = Visibility.Hidden;
    }

    private void AssigmentInstruction_codeRunningStatusChanged(RunningStatus runningStatus)
    {
      if (runningStatus == RunningStatus.StartRuning)
      {
        this.rectangleDebug1.Visibility = Visibility.Visible;
        this.rectangleDebug2.Visibility = Visibility.Visible;
      }
      if (runningStatus != RunningStatus.StopRuning)
        return;
      this.rectangleDebug1.Visibility = Visibility.Hidden;
      this.rectangleDebug2.Visibility = Visibility.Hidden;
    }

    private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.rectangleHighlight.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
      StaticDragController.Instance.StartDragingFromTemplate((UserControl) this);
    }

    private void Instance_dragingTypeChanged(StaticDragController.DraggingType draggingType)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.rectangleHighlight.Fill = (Brush) new SolidColorBrush(Colors.Transparent);
    }

    public ICodeElement GetCodeElement() => (ICodeElement) this.assigmentInstruction;

    private void UserControl_MouseEnter(object sender, MouseEventArgs e)
    {
      this.dropRectangle.Visibility = Visibility.Hidden;
      if (this.assigmentInstruction.GetIsTemplateElement() || (IUCWithICodeElement) StaticDragController.Instance.UcToDrag == null || !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().IsInstruction())
        return;
      this.dropRectangle.Visibility = Visibility.Visible;
      this.dropRectangle.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
    }

    private void UserControl_MouseLeave(object sender, MouseEventArgs e) => this.dropRectangle.Visibility = Visibility.Hidden;

    private void UserControl_MouseUp(object sender, MouseButtonEventArgs e)
    {
      this.dropRectangle.Visibility = Visibility.Hidden;
      if (this.assigmentInstruction.GetIsTemplateElement() || StaticDragController.Instance.GetDraggingType == StaticDragController.DraggingType.None || ((IUCWithICodeElement) StaticDragController.Instance.UcToDrag == null || !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().IsInstruction()))
        return;
      this.codeBlockParent.AddUserControlBefore(StaticDragController.Instance.UcToDrag, (UserControl) this);
    }

    public void DisposeAll()
    {
      StaticDragController.Instance.dragingTypeChanged -= new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.assigmentInstruction.codeRunningStatusChanged -= new CodeElementRunningStatus(this.AssigmentInstruction_codeRunningStatusChanged);
      for (int index = 0; index < this.stackPanel.Children.Count; ++index)
      {
        if (this.stackPanel.Children[index] is IUCWithICodeElement)
          (this.stackPanel.Children[index] as IUCWithICodeElement).DisposeAll();
      }
      this.stackPanel.Children.Clear();
      this.mainGrid = (Grid) null;
      this.codeBlockParent = (CodeBlock) null;
      this.assigmentInstruction = (AssigmentInstruction) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/codeelements/assigmentinstructionview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.UserControl_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.UserControl_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.UserControl_MouseUp);
          break;
        case 2:
          this.mainGrid = (Grid) target;
          break;
        case 3:
          this.dropRectangle = (Rectangle) target;
          break;
        case 4:
          this.rectangleHighlight = (Rectangle) target;
          break;
        case 5:
          this.rectangleDebug1 = (Rectangle) target;
          break;
        case 6:
          this.rectangleDebug2 = (Rectangle) target;
          break;
        case 7:
          this.mainRect1 = (Rectangle) target;
          break;
        case 8:
          this.mainRect2 = (Rectangle) target;
          break;
        case 9:
          this.stackPanel = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
