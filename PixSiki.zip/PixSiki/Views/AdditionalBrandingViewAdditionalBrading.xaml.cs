﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.AdditionalBrandingView.AdditionalBrading
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PixBlocks.Views.AdditionalBrandingView
{
  public partial class AdditionalBrading : UserControl, IComponentConnector
  {
    internal Image image;
    private bool _contentLoaded;

    public AdditionalBrading()
    {
      this.InitializeComponent();
      AdditionalBrandingManager.imageWasChangedEvent += new AdditionalBrandingManager.imageChange(this.AdditionalBrandingManager_imageWasChangedEvent);
      this.AdditionalBrandingManager_imageWasChangedEvent();
    }

    private void AdditionalBrandingManager_imageWasChangedEvent()
    {
      if (AdditionalBrandingManager.CurrentImage == null)
      {
        this.image.MaxHeight = 0.0;
        this.image.MaxWidth = 0.0;
      }
      else
      {
        this.image.MaxHeight = 100000.0;
        this.image.MaxWidth = 100000.0;
        this.image.Source = (ImageSource) this.LoadImage(AdditionalBrandingManager.CurrentImage);
      }
    }

    private BitmapImage LoadImage(string base64Image)
    {
      byte[] buffer = Convert.FromBase64String(base64Image);
      if (buffer == null || buffer.Length == 0)
        return (BitmapImage) null;
      BitmapImage bitmapImage = new BitmapImage();
      using (MemoryStream memoryStream = new MemoryStream(buffer))
      {
        memoryStream.Position = 0L;
        bitmapImage.BeginInit();
        bitmapImage.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
        bitmapImage.UriSource = (Uri) null;
        bitmapImage.StreamSource = (Stream) memoryStream;
        bitmapImage.EndInit();
      }
      bitmapImage.Freeze();
      return bitmapImage;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/additionalbrandingview/additionalbrading.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId == 1)
        this.image = (Image) target;
      else
        this._contentLoaded = true;
    }
  }
}
