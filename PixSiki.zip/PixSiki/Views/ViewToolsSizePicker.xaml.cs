﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.ViewTools.SizePicker
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Tools.ColorTransformation;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.ViewTools
{
  public partial class SizePicker : Window, IComponentConnector
  {
    private bool programaticClosing;
    public Color fillColor = Colors.Black;
    public int NewWidth;
    public int NewHeight;
    internal TextBox textBox;
    internal TextBox textBox1;
    internal Button button;
    internal Label label;
    internal Label label1;
    internal WrapPanel wrapPanel;
    internal Ellipse ellipse;
    private bool _contentLoaded;

    public SizePicker()
    {
      this.InitializeComponent();
      int maxValue = (int) sbyte.MaxValue;
      List<Color> colorList = new List<Color>();
      colorList.Add(Colors.Black);
      colorList.Add(Colors.White);
      colorList.Add(Colors.Red);
      colorList.Add(Color.FromRgb((byte) 0, byte.MaxValue, (byte) 0));
      colorList.Add(Colors.Blue);
      colorList.Add(Colors.Yellow);
      colorList.Add(Colors.Cyan);
      colorList.Add(Colors.Magenta);
      colorList.Add(ColorTransorm.GetColorFromValue(ColorTransorm.GetValueFromColor(Color.FromRgb(byte.MaxValue, (byte) 180, (byte) 180))));
      colorList.Add(ColorTransorm.GetColorFromValue(ColorTransorm.GetValueFromColor(Color.FromRgb((byte) 180, byte.MaxValue, (byte) 180))));
      colorList.Add(ColorTransorm.GetColorFromValue(ColorTransorm.GetValueFromColor(Color.FromRgb((byte) 180, (byte) 180, byte.MaxValue))));
      for (int index1 = 1; index1 <= (int) byte.MaxValue; index1 += maxValue)
      {
        for (int index2 = 1; index2 <= (int) byte.MaxValue; index2 += maxValue)
        {
          for (int index3 = 1; index3 <= (int) byte.MaxValue; index3 += maxValue)
          {
            Color colorFromValue = ColorTransorm.GetColorFromValue(ColorTransorm.GetValueFromColor(Color.FromArgb(byte.MaxValue, (byte) index1, (byte) index2, (byte) index3)));
            bool flag = false;
            foreach (Color c in colorList)
            {
              if (ColorTransorm.GetValueFromColor(colorFromValue).IsEqual(ColorTransorm.GetValueFromColor(c)))
                flag = true;
            }
            if (!flag)
              colorList.Add(colorFromValue);
          }
        }
      }
      foreach (Color color in colorList)
      {
        Button button = new Button();
        button.Width = 40.0;
        button.Height = 40.0;
        button.Margin = new Thickness(4.0);
        button.Background = (Brush) new SolidColorBrush(color);
        button.Click += new RoutedEventHandler(this.B_Click);
        this.wrapPanel.Children.Add((UIElement) button);
      }
      this.fillColor = Colors.Black;
      this.ellipse.Fill = (Brush) new SolidColorBrush(this.fillColor);
    }

    private void B_Click(object sender, RoutedEventArgs e)
    {
      this.fillColor = ((SolidColorBrush) ((Control) sender).Background).Color;
      this.ellipse.Fill = (Brush) new SolidColorBrush(this.fillColor);
    }

    private void button_Click(object sender, RoutedEventArgs e)
    {
      this.NewWidth = int.Parse(this.textBox.Text);
      this.NewHeight = int.Parse(this.textBox1.Text);
      this.programaticClosing = true;
      this.Close();
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      if (this.programaticClosing)
        return;
      this.NewWidth = 0;
      this.NewHeight = 0;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/viewtools/sizepicker.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((Window) target).Closing += new CancelEventHandler(this.Window_Closing);
          break;
        case 2:
          this.textBox = (TextBox) target;
          break;
        case 3:
          this.textBox1 = (TextBox) target;
          break;
        case 4:
          this.button = (Button) target;
          this.button.Click += new RoutedEventHandler(this.button_Click);
          break;
        case 5:
          this.label = (Label) target;
          break;
        case 6:
          this.label1 = (Label) target;
          break;
        case 7:
          this.wrapPanel = (WrapPanel) target;
          break;
        case 8:
          this.ellipse = (Ellipse) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
