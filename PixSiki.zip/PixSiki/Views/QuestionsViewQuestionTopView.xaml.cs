﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.QuestionTopView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.CodeRunner.CodeRunnerViewElements.Images;
using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.UserMenagment.ToyShopMenager;
using PixBlocks.Views.AdditionalBrandingView;
using PixBlocks.Views.QuestionsView.CategoryViewer;
using PixBlocks.Views.QuestionsView.CategoryViewer.CategoryTopPatch;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.QuestionsView
{
  public partial class QuestionTopView : UserControl, IComponentConnector
  {
    private CategoryTopPathView categoryTopViewer;
    private QuestionVerticalView questionVerticalV;
    internal Grid logoCenter;
    internal Grid logoPartner;
    internal StackPanel topRow;
    internal Rectangle highlightRectangleTeacher;
    internal Rectangle HighlightRect;
    internal Label UserName;
    internal Label NumberOfPoints2;
    internal Grid spaceGrid;
    internal Label NumberOfAllPoints;
    internal Grid minimaliseGrid;
    internal Grid normalWindowGrid;
    internal Grid rightGrid;
    private bool _contentLoaded;

    public QuestionTopView() => this.InitializeComponent();

    public QuestionTopView(QuestionVerticalView questionVerticalV)
    {
      this.InitializeComponent();
      if (UserMenager.UserIsSuperAdmin())
        this.logoCenter.Visibility = Visibility.Collapsed;
      this.logoPartner.Children.Add((UIElement) AdditionalBrandingManager.GetBranding());
      this.questionVerticalV = questionVerticalV;
      questionVerticalV.categoryWasSelectedEvent += new QuestionVerticalView.CategoryWasSelected(this.QuestionVerticalV_categoryWasSelectedEvent);
      questionVerticalV.CategoriesViewer.questioinSelectedEvent += new CategoriesListView.QuestionSelected(this.CategoriesViewer_questioinSelectedEvent);
      this.categoryTopViewer = new CategoryTopPathView(questionVerticalV.CategoriesViewer.CurrentCategory);
      this.categoryTopViewer.categoryWasSelectedEvent += new CategoryTopPathView.CategoryWasSelected(this.Ctpv_categoryWasSelectedEvent);
      this.categoryTopViewer.questionWasSelectedEvent += new CategoryTopPathView.QuestionSelected(this.CategoryTopViewer_questionWasSelectedEvent);
      this.topRow.Children.Add((UIElement) this.categoryTopViewer);
      this.QuestionsPointsCounter_questionPointsModifyEvent((QuestionPoint) null);
      this.UserName.Content = (object) UserMenager.GetCurrentUserName();
      if (UserMenager.UserIsSuperAdmin())
        this.UserName.Content = (object) "";
      QuestionsPointsCounter.questionPointsModifyEvent += new QuestionsPointsCounter.QuestionPointsModify(this.QuestionsPointsCounter_questionPointsModifyEvent);
      this.NumberOfAllPoints.Content = (object) ("(" + QuestionCategoryLoaderAndSever.ClassicQuestionsInCategory(QuestionCategoryLoaderAndSever.GetMainCategory().UniquePath).Count.ToString() + ")");
      CircleButton circleButton1 = new CircleButton((UserControl) new MinimaliseIconWindow(), Colors.White, CircleButton.VisualParam.noFrame);
      circleButton1.buttonClickedEvent += new CircleButton.ButtonClicker(this.Minimalise_buttonClickedEvent);
      this.minimaliseGrid.Children.Add((UIElement) circleButton1);
      CircleButton circleButton2 = new CircleButton((UserControl) new MaximaliseWindowIcon(), Colors.White, CircleButton.VisualParam.noFrame);
      circleButton2.buttonClickedEvent += new CircleButton.ButtonClicker(this.NormalWindow_buttonClickedEvent);
      this.normalWindowGrid.Children.Add((UIElement) circleButton2);
      CircleButton circleButton3 = new CircleButton((UserControl) new CloseIcon(), Colors.Red, CircleButton.VisualParam.noFrame);
      circleButton3.buttonClickedEvent += new CircleButton.ButtonClicker(this.Close_buttonClickedEvent);
      this.rightGrid.Children.Add((UIElement) circleButton3);
      this.HighlightRect.Opacity = 0.001;
      this.highlightRectangleTeacher.Opacity = 0.001;
    }

    private void NormalWindow_buttonClickedEvent()
    {
      if (this.navigationButtonEvent == null)
        return;
      this.navigationButtonEvent(QuestionTopView.NavigationType.normalWindow);
    }

    private void Minimalise_buttonClickedEvent()
    {
      if (this.navigationButtonEvent == null)
        return;
      this.navigationButtonEvent(QuestionTopView.NavigationType.minimalise);
    }

    public event QuestionTopView.QuestionSelected questionWasSelectedEvent;

    private void CategoryTopViewer_questionWasSelectedEvent(Question question)
    {
      if (this.questionWasSelectedEvent == null)
        return;
      this.questionWasSelectedEvent(question);
    }

    private void ToysInfos_roomMoneyChangedEvent() => this.NumberOfPoints2.Content = (object) (QuestionsPointsCounter.GetPointsForCurrentUser() + StaticToyManager.ToysInfos.GetTotalMoneyInRoom() - 6);

    private void Close_buttonClickedEvent()
    {
      if (this.navigationButtonEvent == null)
        return;
      this.navigationButtonEvent(QuestionTopView.NavigationType.close);
    }

    private void CategoriesViewer_questioinSelectedEvent(Question q) => this.CategoryTopViewer.QuestionWasSelected(q);

    private void QuestionVerticalV_categoryWasSelectedEvent(QuestionCategory category) => this.CategoryTopViewer.AddNewCategoryToStack(category);

    private void QuestionsPointsCounter_questionPointsModifyEvent(QuestionPoint questionPoint) => this.NumberOfPoints2.Content = (object) (QuestionsPointsCounter.GetPointsForCurrentUser() + StaticToyManager.ToysInfos.GetTotalMoneyInRoom() - 6);

    public CategoryTopPathView CategoryTopViewer => this.categoryTopViewer;

    public event QuestionTopView.CategoryWasSelected categoryWasSelectedEvent;

    private void Ctpv_categoryWasSelectedEvent(QuestionCategory category)
    {
      if (this.categoryWasSelectedEvent == null)
        return;
      this.categoryWasSelectedEvent(category);
    }

    private void GridSplitter_DragDelta(object sender, DragDeltaEventArgs e)
    {
    }

    public event QuestionTopView.NavigationButtonPressed navigationButtonEvent;

    internal void ShowNavigatonsButtons(bool showNavigations)
    {
      if (showNavigations)
      {
        this.minimaliseGrid.Visibility = Visibility.Visible;
        this.normalWindowGrid.Visibility = Visibility.Visible;
        this.rightGrid.Visibility = Visibility.Visible;
      }
      else
      {
        this.minimaliseGrid.Visibility = Visibility.Collapsed;
        this.normalWindowGrid.Visibility = Visibility.Collapsed;
        this.rightGrid.Visibility = Visibility.Collapsed;
      }
    }

    public event QuestionTopView.UserProfileClicked userProfileClickedEvent;

    private void UserName_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.spaceGrid.Height = 200.0;
      if (this.userProfileClickedEvent == null)
        return;
      this.userProfileClickedEvent();
    }

    private void HighlightRect_MouseEnter(object sender, MouseEventArgs e) => this.HighlightRect.Opacity = 0.2;

    private void HighlightRect_MouseLeave(object sender, MouseEventArgs e) => this.HighlightRect.Opacity = 0.001;

    internal void RefreshUserInfo()
    {
      this.QuestionsPointsCounter_questionPointsModifyEvent((QuestionPoint) null);
      this.UserName.Content = (object) UserMenager.GetCurrentUserName();
      if (!UserMenager.UserIsSuperAdmin())
        return;
      this.UserName.Content = (object) "";
    }

    private void highlightRectangleTeacher_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.userProfileClickedEvent == null)
        return;
      this.userProfileClickedEvent();
    }

    private void highlightRectangleTeacher_MouseEnter(object sender, MouseEventArgs e) => this.highlightRectangleTeacher.Opacity = 0.2;

    private void highlightRectangleTeacher_MouseLeave(object sender, MouseEventArgs e) => this.highlightRectangleTeacher.Opacity = 0.001;

    internal void SelectMainCategory() => this.categoryTopViewer.SelectMainCategory();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/questiontopview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.logoCenter = (Grid) target;
          break;
        case 2:
          this.logoPartner = (Grid) target;
          break;
        case 3:
          this.topRow = (StackPanel) target;
          break;
        case 4:
          this.highlightRectangleTeacher = (Rectangle) target;
          this.highlightRectangleTeacher.MouseDown += new MouseButtonEventHandler(this.highlightRectangleTeacher_MouseDown);
          this.highlightRectangleTeacher.MouseEnter += new MouseEventHandler(this.highlightRectangleTeacher_MouseEnter);
          this.highlightRectangleTeacher.MouseLeave += new MouseEventHandler(this.highlightRectangleTeacher_MouseLeave);
          break;
        case 5:
          this.HighlightRect = (Rectangle) target;
          this.HighlightRect.MouseDown += new MouseButtonEventHandler(this.UserName_MouseDown);
          this.HighlightRect.MouseEnter += new MouseEventHandler(this.HighlightRect_MouseEnter);
          this.HighlightRect.MouseLeave += new MouseEventHandler(this.HighlightRect_MouseLeave);
          break;
        case 6:
          this.UserName = (Label) target;
          break;
        case 7:
          this.NumberOfPoints2 = (Label) target;
          break;
        case 8:
          this.spaceGrid = (Grid) target;
          break;
        case 9:
          this.NumberOfAllPoints = (Label) target;
          break;
        case 10:
          this.minimaliseGrid = (Grid) target;
          break;
        case 11:
          this.normalWindowGrid = (Grid) target;
          break;
        case 12:
          this.rightGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void QuestionSelected(Question question);

    public delegate void CategoryWasSelected(QuestionCategory category);

    public enum NavigationType
    {
      close,
      minimalise,
      normalWindow,
    }

    public delegate void NavigationButtonPressed(QuestionTopView.NavigationType navigationType);

    public delegate void UserProfileClicked();
  }
}
