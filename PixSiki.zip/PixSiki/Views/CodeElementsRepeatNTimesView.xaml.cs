﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.RepeatNTimesView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Views.CodeElements.BasicBlocks;
using PixBlocks.Views.CodeElements.BlockOfCode;
using PixBlocks.Views.DragDropController;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.CodeElements
{
  public partial class RepeatNTimesView : UserControl, IUCWithICodeElement, IUCWitchCodeBlockParent, IComponentConnector
  {
    private RepeatNTimes repeatNTimes;
    private CodeBlock codeBlockParent;
    private TextBlockView textOfIterations;
    private CodeBlock codBlockInside;
    internal Rectangle dropRectangle;
    internal Rectangle mainGrid;
    internal Grid topGrid;
    internal Rectangle rectangleDebug1;
    internal Rectangle rectangleDebug2;
    internal StackPanel argsStackPanel;
    internal Grid gridToCodeBlock;
    internal Image image;
    private bool _contentLoaded;

    public CodeBlock CodeBlockParent
    {
      get => this.codeBlockParent;
      set => this.codeBlockParent = value;
    }

    public RepeatNTimesView(RepeatNTimes repeatNTimes)
    {
      this.InitializeComponent();
      StaticDragController.Instance.dragingTypeChanged += new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.repeatNTimes = repeatNTimes;
      repeatNTimes.iteratorChangedEvent += new RepeatNTimes.IteratorChanged(this.RepeatNTimes_iteratorChangedEvent);
      this.argsStackPanel.Children.Add((UIElement) new SmallMargin());
      this.argsStackPanel.Children.Add((UIElement) new RepeatIcon());
      this.argsStackPanel.Children.Add((UIElement) new VerySmallMargin());
      this.argsStackPanel.Children.Add((UIElement) new VariableView((Variable) repeatNTimes.NumberOfIteration));
      if (repeatNTimes.RepeatNTimesType == RepeatNTimesType.loopAndStep)
      {
        this.argsStackPanel.Children.Add((UIElement) new StepsIcon());
        this.argsStackPanel.Children.Add((UIElement) new VariableView((Variable) repeatNTimes.StepVariable));
      }
      this.textOfIterations = new TextBlockView("");
      this.textOfIterations.label.Foreground = (Brush) new SolidColorBrush(Colors.White);
      this.argsStackPanel.Children.Add((UIElement) this.textOfIterations);
      this.argsStackPanel.Children.Add((UIElement) new VerySmallMargin());
      repeatNTimes.codeRunningStatusChanged += new CodeElementRunningStatus(this.RepeatNTimes_codeRunningStatusChanged);
      if (!repeatNTimes.GetIsTemplateElement())
        this.AddCodeBlock();
      this.rectangleDebug1.Fill = (Brush) new SolidColorBrush(ConfigColors.DebugingColor);
      this.rectangleDebug1.Visibility = Visibility.Hidden;
      this.rectangleDebug2.Fill = (Brush) new SolidColorBrush(ConfigColors.DebugingColor);
      this.rectangleDebug2.Visibility = Visibility.Hidden;
    }

    private void RepeatNTimes_iteratorChangedEvent()
    {
      if (this.repeatNTimes.IteratorN == 0)
        this.textOfIterations.SetText("");
      else
        this.textOfIterations.SetText(" " + this.repeatNTimes.IteratorN.ToString() + "/" + this.repeatNTimes.MaxNumberOfIteration.ToString());
    }

    private void RepeatNTimes_codeRunningStatusChanged(RunningStatus runningStatus)
    {
      if (runningStatus == RunningStatus.StartRuning)
      {
        this.rectangleDebug1.Visibility = Visibility.Visible;
        this.rectangleDebug2.Visibility = Visibility.Visible;
      }
      if (runningStatus != RunningStatus.StopRuning)
        return;
      this.rectangleDebug1.Visibility = Visibility.Hidden;
      this.rectangleDebug2.Visibility = Visibility.Hidden;
    }

    public RepeatNTimesView() => this.InitializeComponent();

    private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
      StaticDragController.Instance.StartDragingFromTemplate((UserControl) this);
    }

    private void Instance_dragingTypeChanged(StaticDragController.DraggingType draggingType)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(Colors.Transparent);
    }

    public ICodeElement GetCodeElement() => (ICodeElement) this.repeatNTimes;

    public CodeBlock CodBlockInside => this.codBlockInside;

    internal void AddCodeBlock()
    {
      this.codBlockInside = new CodeBlock((ICodeInstructionBlock) this.repeatNTimes, false);
      this.gridToCodeBlock.Children.Add((UIElement) this.codBlockInside);
    }

    private void topGrid_MouseEnter(object sender, MouseEventArgs e)
    {
      this.dropRectangle.Visibility = Visibility.Hidden;
      if (this.repeatNTimes.GetIsTemplateElement() || (IUCWithICodeElement) StaticDragController.Instance.UcToDrag == null || !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().IsInstruction())
        return;
      this.dropRectangle.Visibility = Visibility.Visible;
      this.dropRectangle.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
    }

    private void topGrid_MouseLeave(object sender, MouseEventArgs e) => this.dropRectangle.Visibility = Visibility.Hidden;

    private void topGrid_MouseUp(object sender, MouseButtonEventArgs e)
    {
      this.dropRectangle.Visibility = Visibility.Hidden;
      if (this.repeatNTimes.GetIsTemplateElement() || StaticDragController.Instance.GetDraggingType == StaticDragController.DraggingType.None || ((IUCWithICodeElement) StaticDragController.Instance.UcToDrag == null || !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().IsInstruction()))
        return;
      this.codeBlockParent.AddUserControlBefore(StaticDragController.Instance.UcToDrag, (UserControl) this);
    }

    public void DisposeAll()
    {
      StaticDragController.Instance.dragingTypeChanged -= new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.repeatNTimes.iteratorChangedEvent -= new RepeatNTimes.IteratorChanged(this.RepeatNTimes_iteratorChangedEvent);
      this.repeatNTimes.codeRunningStatusChanged -= new CodeElementRunningStatus(this.RepeatNTimes_codeRunningStatusChanged);
      for (int index = 0; index < this.argsStackPanel.Children.Count; ++index)
      {
        if (this.argsStackPanel.Children is IUCWithICodeElement)
          (this.argsStackPanel.Children as IUCWithICodeElement).DisposeAll();
      }
      this.argsStackPanel.Children.Clear();
      this.repeatNTimes = (RepeatNTimes) null;
      if (this.codBlockInside != null)
        this.codBlockInside.DisposeAllElements();
      this.codBlockInside = (CodeBlock) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/codeelements/repeatntimesview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.dropRectangle = (Rectangle) target;
          break;
        case 2:
          this.mainGrid = (Rectangle) target;
          break;
        case 3:
          this.topGrid = (Grid) target;
          break;
        case 4:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.topGrid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.topGrid_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.topGrid_MouseUp);
          break;
        case 5:
          this.rectangleDebug1 = (Rectangle) target;
          break;
        case 6:
          this.rectangleDebug2 = (Rectangle) target;
          break;
        case 7:
          this.argsStackPanel = (StackPanel) target;
          break;
        case 8:
          this.gridToCodeBlock = (Grid) target;
          break;
        case 9:
          this.image = (Image) target;
          break;
        case 10:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
