﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.IfThenInstructionView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Views.CodeElements.BasicBlocks;
using PixBlocks.Views.CodeElements.BlockOfCode;
using PixBlocks.Views.DragDropController;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.CodeElements
{
  public partial class IfThenInstructionView : UserControl, IUCWithICodeElement, IUCWitchCodeBlockParent, IComponentConnector
  {
    private IfThenInstruction ifThenInstruction;
    private CodeBlock codeBlockParent;
    private CodeBlock codBlockInside;
    internal Rectangle dropRectangle;
    internal Rectangle mainGrid;
    internal Rectangle rectangleDebug1;
    internal Rectangle rectangleDebug2;
    internal StackPanel argsStackPanel;
    internal Grid gridToCodeBlock;
    private bool _contentLoaded;

    public CodeBlock CodeBlockParent
    {
      get => this.codeBlockParent;
      set => this.codeBlockParent = value;
    }

    public IfThenInstructionView(IfThenInstruction ifThenInstruction)
    {
      this.InitializeComponent();
      StaticDragController.Instance.dragingTypeChanged += new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.ifThenInstruction = ifThenInstruction;
      if (ifThenInstruction.IfThenInstructionType == IfThenInstructionType.TurtleSeeColor || ifThenInstruction.IfThenInstructionType == IfThenInstructionType.TurtleSeeImage)
      {
        this.argsStackPanel.Children.Add((UIElement) new SmallMargin());
        this.argsStackPanel.Children.Add((UIElement) new RabbitIcon());
        this.argsStackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.argsStackPanel.Children.Add((UIElement) new LookIcon());
        this.argsStackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.argsStackPanel.Children.Add((UIElement) new VariableView((Variable) ifThenInstruction.Arguments[0]));
        this.argsStackPanel.Children.Add((UIElement) new VerySmallMargin());
      }
      else
      {
        this.argsStackPanel.Children.Add((UIElement) new VerySmallMargin());
        this.argsStackPanel.Children.Add((UIElement) new VariableView((Variable) ifThenInstruction.Arguments[0]));
        if (ifThenInstruction.IfThenInstructionType == IfThenInstructionType.EqualsColors || ifThenInstruction.IfThenInstructionType == IfThenInstructionType.EqualsNumbers || ifThenInstruction.IfThenInstructionType == IfThenInstructionType.EqualsImages)
          this.argsStackPanel.Children.Add((UIElement) new IfEqualsIcon());
        if (ifThenInstruction.IfThenInstructionType == IfThenInstructionType.NotEqualsColors || ifThenInstruction.IfThenInstructionType == IfThenInstructionType.NotEqualsNumbers || ifThenInstruction.IfThenInstructionType == IfThenInstructionType.NotEqualsImages)
          this.argsStackPanel.Children.Add((UIElement) new IfNotEqualsIcon());
        if (ifThenInstruction.IfThenInstructionType == IfThenInstructionType.Greater)
          this.argsStackPanel.Children.Add((UIElement) new IfGreaterIcon());
        if (ifThenInstruction.IfThenInstructionType == IfThenInstructionType.GreaterEquals)
          this.argsStackPanel.Children.Add((UIElement) new IfGeaterEqualIcon());
        if (ifThenInstruction.IfThenInstructionType == IfThenInstructionType.Less)
          this.argsStackPanel.Children.Add((UIElement) new IfLessIcon());
        if (ifThenInstruction.IfThenInstructionType == IfThenInstructionType.LessEqals)
          this.argsStackPanel.Children.Add((UIElement) new IfLessEquals());
        this.argsStackPanel.Children.Add((UIElement) new VariableView((Variable) ifThenInstruction.Arguments[1]));
        this.argsStackPanel.Children.Add((UIElement) new VerySmallMargin());
      }
      ifThenInstruction.codeRunningStatusChanged += new CodeElementRunningStatus(this.IfThenInstruction_codeRunningStatusChanged);
      if (!ifThenInstruction.GetIsTemplateElement())
        this.AddCodeBlock();
      this.rectangleDebug1.Fill = (Brush) new SolidColorBrush(ConfigColors.DebugingColor);
      this.rectangleDebug1.Visibility = Visibility.Hidden;
      this.rectangleDebug2.Fill = (Brush) new SolidColorBrush(ConfigColors.DebugingColor);
      this.rectangleDebug2.Visibility = Visibility.Hidden;
    }

    private void IfThenInstruction_codeRunningStatusChanged(RunningStatus runningStatus)
    {
      if (runningStatus == RunningStatus.StartRuning)
      {
        this.rectangleDebug1.Visibility = Visibility.Visible;
        this.rectangleDebug2.Visibility = Visibility.Visible;
      }
      if (runningStatus != RunningStatus.StopRuning)
        return;
      this.rectangleDebug1.Visibility = Visibility.Hidden;
      this.rectangleDebug2.Visibility = Visibility.Hidden;
    }

    public IfThenInstructionView() => this.InitializeComponent();

    private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
      StaticDragController.Instance.StartDragingFromTemplate((UserControl) this);
    }

    private void Instance_dragingTypeChanged(StaticDragController.DraggingType draggingType)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.mainGrid.Fill = (Brush) new SolidColorBrush(Colors.Transparent);
    }

    public ICodeElement GetCodeElement() => (ICodeElement) this.ifThenInstruction;

    public CodeBlock CodBlockInside => this.codBlockInside;

    internal void AddCodeBlock()
    {
      this.codBlockInside = new CodeBlock((ICodeInstructionBlock) this.ifThenInstruction, false);
      this.gridToCodeBlock.Children.Add((UIElement) this.codBlockInside);
    }

    private void Grid_MouseEnter(object sender, MouseEventArgs e)
    {
      this.dropRectangle.Visibility = Visibility.Hidden;
      if (this.ifThenInstruction.GetIsTemplateElement() || (IUCWithICodeElement) StaticDragController.Instance.UcToDrag == null || !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().IsInstruction())
        return;
      this.dropRectangle.Visibility = Visibility.Visible;
      this.dropRectangle.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
    }

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.dropRectangle.Visibility = Visibility.Hidden;

    private void Grid_MouseUp(object sender, MouseButtonEventArgs e)
    {
      this.dropRectangle.Visibility = Visibility.Hidden;
      if (this.ifThenInstruction.GetIsTemplateElement() || StaticDragController.Instance.GetDraggingType == StaticDragController.DraggingType.None || ((IUCWithICodeElement) StaticDragController.Instance.UcToDrag == null || !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().IsInstruction()))
        return;
      this.codeBlockParent.AddUserControlBefore(StaticDragController.Instance.UcToDrag, (UserControl) this);
    }

    public void DisposeAll()
    {
      StaticDragController.Instance.dragingTypeChanged -= new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.ifThenInstruction.codeRunningStatusChanged -= new CodeElementRunningStatus(this.IfThenInstruction_codeRunningStatusChanged);
      for (int index = 0; index < this.argsStackPanel.Children.Count; ++index)
      {
        if (this.argsStackPanel.Children[index] is IUCWithICodeElement)
          (this.argsStackPanel.Children[index] as IUCWithICodeElement).DisposeAll();
      }
      this.argsStackPanel.Children.Clear();
      this.mainGrid = (Rectangle) null;
      this.ifThenInstruction = (IfThenInstruction) null;
      if (this.codBlockInside == null)
        return;
      this.codBlockInside.DisposeAllElements();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/codeelements/iftheninstructionview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.dropRectangle = (Rectangle) target;
          break;
        case 2:
          this.mainGrid = (Rectangle) target;
          break;
        case 3:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.Grid_MouseUp);
          break;
        case 4:
          this.rectangleDebug1 = (Rectangle) target;
          break;
        case 5:
          this.rectangleDebug2 = (Rectangle) target;
          break;
        case 6:
          this.argsStackPanel = (StackPanel) target;
          break;
        case 7:
          this.gridToCodeBlock = (Grid) target;
          break;
        case 8:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.UserControl_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
