﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.GameControllerView.GameController
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Tools.TurtleMoveStatic;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.Views.GameControllerView
{
  public partial class GameController : UserControl, IComponentConnector
  {
    private GameController.Direction d;
    private PixBlocks.CodeRunner.CodeRunner codeRunner;
    private MainWindow mainWindow;
    internal Ellipse ellipse;
    internal Ellipse ellipse1;
    internal Ellipse ellipse2;
    internal Image goRight;
    internal Image goLeft;
    internal Image goTop;
    internal Image goDown;
    private bool _contentLoaded;

    public GameController() => this.InitializeComponent();

    public GameController(MainWindow mainWindow)
    {
      this.mainWindow = mainWindow;
      mainWindow.PreviewKeyDown += new KeyEventHandler(this.TopGrid_PreviewKeyDown);
      mainWindow.PreviewKeyUp += new KeyEventHandler(this.TopGrid_PreviewKeyUp);
      this.InitializeComponent();
    }

    private void TopGrid_PreviewKeyUp(object sender, KeyEventArgs e)
    {
      if (this.Visibility != Visibility.Visible || e.Key != Key.Left && e.Key != Key.Right && (e.Key != Key.Up && e.Key != Key.Down))
        return;
      if (!Keyboard.IsKeyDown(Key.Down) && !Keyboard.IsKeyDown(Key.Up) && (!Keyboard.IsKeyDown(Key.Left) && !Keyboard.IsKeyDown(Key.Right)))
      {
        this.d = GameController.Direction.non;
        TurtleMoveStaticManager.KeyIsPressed = false;
        this.RefreshView();
      }
      else
      {
        if (Keyboard.IsKeyDown(Key.Down))
          this.d = GameController.Direction.down;
        if (Keyboard.IsKeyDown(Key.Up))
          this.d = GameController.Direction.top;
        if (Keyboard.IsKeyDown(Key.Left))
          this.d = GameController.Direction.left;
        if (Keyboard.IsKeyDown(Key.Right))
          this.d = GameController.Direction.right;
        TurtleMoveStaticManager.KeyIsPressed = true;
        this.MoveTurtle();
        this.RefreshView();
      }
      e.Handled = true;
    }

    private void TopGrid_PreviewKeyDown(object sender, KeyEventArgs e)
    {
      if (this.Visibility != Visibility.Visible)
        return;
      if (e.Key == Key.Left)
      {
        this.d = GameController.Direction.left;
        TurtleMoveStaticManager.KeyIsPressed = true;
        this.MoveTurtle();
        this.RefreshView();
      }
      if (e.Key == Key.Right)
      {
        this.d = GameController.Direction.right;
        TurtleMoveStaticManager.KeyIsPressed = true;
        this.MoveTurtle();
        this.RefreshView();
      }
      if (e.Key == Key.Up)
      {
        this.d = GameController.Direction.top;
        TurtleMoveStaticManager.KeyIsPressed = true;
        this.MoveTurtle();
        this.RefreshView();
      }
      if (e.Key == Key.Down)
      {
        this.d = GameController.Direction.down;
        TurtleMoveStaticManager.KeyIsPressed = true;
        this.MoveTurtle();
        this.RefreshView();
      }
      e.Handled = true;
    }

    private void MoveTurtle()
    {
      if (this.d == GameController.Direction.down)
      {
        TurtleMoveStaticManager.DeltaY = -1;
        TurtleMoveStaticManager.DeltaX = 0;
      }
      if (this.d == GameController.Direction.top)
      {
        TurtleMoveStaticManager.DeltaY = 1;
        TurtleMoveStaticManager.DeltaX = 0;
      }
      if (this.d == GameController.Direction.left)
      {
        TurtleMoveStaticManager.DeltaX = -1;
        TurtleMoveStaticManager.DeltaY = 0;
      }
      if (this.d == GameController.Direction.right)
      {
        TurtleMoveStaticManager.DeltaX = 1;
        TurtleMoveStaticManager.DeltaY = 0;
      }
      if (this.d != GameController.Direction.non)
        return;
      TurtleMoveStaticManager.DeltaX = 0;
      TurtleMoveStaticManager.DeltaY = 0;
    }

    private void Ellipse_MouseDown(object sender, MouseButtonEventArgs e)
    {
      TurtleMoveStaticManager.KeyIsPressed = true;
      this.ellipse_MouseMove(sender, (MouseEventArgs) e);
      this.MoveTurtle();
    }

    private void Ellipse_MouseEnter(object sender, MouseEventArgs e)
    {
      if (Mouse.LeftButton == MouseButtonState.Pressed || Mouse.RightButton == MouseButtonState.Pressed)
        TurtleMoveStaticManager.KeyIsPressed = true;
      this.ellipse_MouseMove(sender, e);
    }

    private void ellipse_MouseMove(object sender, MouseEventArgs e)
    {
      Point point = e.GetPosition((IInputElement) this.ellipse);
      point = new Point(point.X - this.ellipse.ActualHeight / 2.0, point.Y - this.ellipse.ActualWidth / 2.0);
      if (point.Y >= point.X && point.Y >= -point.X)
        this.d = GameController.Direction.down;
      if (point.Y < point.X && point.Y < -point.X)
        this.d = GameController.Direction.top;
      if (point.Y < point.X && point.Y >= -point.X)
        this.d = GameController.Direction.right;
      if (point.Y >= point.X && point.Y < -point.X)
        this.d = GameController.Direction.left;
      this.RefreshView();
    }

    private void RefreshView()
    {
      double num = 0.3;
      if (Mouse.LeftButton == MouseButtonState.Pressed || Mouse.RightButton == MouseButtonState.Pressed)
      {
        num = 0.0;
        this.MoveTurtle();
      }
      if (this.d == GameController.Direction.left)
        this.goLeft.Opacity = num;
      else
        this.goLeft.Opacity = 1.0;
      if (this.d == GameController.Direction.right)
        this.goRight.Opacity = num;
      else
        this.goRight.Opacity = 1.0;
      if (this.d == GameController.Direction.down)
        this.goDown.Opacity = num;
      else
        this.goDown.Opacity = 1.0;
      if (this.d == GameController.Direction.top)
        this.goTop.Opacity = num;
      else
        this.goTop.Opacity = 1.0;
    }

    private void ellipse_MouseLeave(object sender, MouseEventArgs e)
    {
      TurtleMoveStaticManager.KeyIsPressed = false;
      this.d = GameController.Direction.non;
      this.RefreshView();
    }

    private void ellipse_MouseUp(object sender, MouseButtonEventArgs e)
    {
      TurtleMoveStaticManager.KeyIsPressed = false;
      this.ellipse_MouseMove(sender, (MouseEventArgs) e);
    }

    internal void SetCodeRunner(PixBlocks.CodeRunner.CodeRunner codeRunner) => this.codeRunner = codeRunner;

    private void UserControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
      if (this.Visibility == Visibility.Visible)
        return;
      TurtleMoveStaticManager.KeyIsPressed = false;
      this.d = GameController.Direction.non;
      this.RefreshView();
      this.MoveTurtle();
      if (this.codeRunner == null || this.codeRunner.CodeInOut == null)
        return;
      this.codeRunner.CodeInOut.TurtleX = 1;
      this.codeRunner.CodeInOut.TurtleY = 1;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/gamecontrollerview/gamecontroller.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).IsVisibleChanged += new DependencyPropertyChangedEventHandler(this.UserControl_IsVisibleChanged);
          break;
        case 2:
          this.ellipse = (Ellipse) target;
          this.ellipse.MouseDown += new MouseButtonEventHandler(this.Ellipse_MouseDown);
          this.ellipse.MouseEnter += new MouseEventHandler(this.Ellipse_MouseEnter);
          this.ellipse.MouseMove += new MouseEventHandler(this.ellipse_MouseMove);
          this.ellipse.MouseLeave += new MouseEventHandler(this.ellipse_MouseLeave);
          this.ellipse.MouseUp += new MouseButtonEventHandler(this.ellipse_MouseUp);
          break;
        case 3:
          this.ellipse1 = (Ellipse) target;
          this.ellipse1.MouseDown += new MouseButtonEventHandler(this.Ellipse_MouseDown);
          this.ellipse1.MouseEnter += new MouseEventHandler(this.Ellipse_MouseEnter);
          this.ellipse1.MouseMove += new MouseEventHandler(this.ellipse_MouseMove);
          this.ellipse1.MouseLeave += new MouseEventHandler(this.ellipse_MouseLeave);
          this.ellipse1.MouseUp += new MouseButtonEventHandler(this.ellipse_MouseUp);
          break;
        case 4:
          this.ellipse2 = (Ellipse) target;
          this.ellipse2.MouseDown += new MouseButtonEventHandler(this.Ellipse_MouseDown);
          this.ellipse2.MouseEnter += new MouseEventHandler(this.Ellipse_MouseEnter);
          this.ellipse2.MouseMove += new MouseEventHandler(this.ellipse_MouseMove);
          this.ellipse2.MouseLeave += new MouseEventHandler(this.ellipse_MouseLeave);
          this.ellipse2.MouseUp += new MouseButtonEventHandler(this.ellipse_MouseUp);
          break;
        case 5:
          this.goRight = (Image) target;
          break;
        case 6:
          this.goLeft = (Image) target;
          break;
        case 7:
          this.goTop = (Image) target;
          break;
        case 8:
          this.goDown = (Image) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public enum Direction
    {
      non,
      left,
      right,
      top,
      down,
    }
  }
}
