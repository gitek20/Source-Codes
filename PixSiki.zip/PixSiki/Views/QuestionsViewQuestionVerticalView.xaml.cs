﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.QuestionVerticalView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.Views.QuestionsView.CategoryViewer;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.QuestionsView
{
  public partial class QuestionVerticalView : UserControl, IComponentConnector
  {
    private QuestionCategory mainCategory;
    private CircleButton minimaliseButton;
    private CategoriesListView categoriesViewer;
    internal Grid backGrid;
    internal Grid mainGridTop;
    internal Rectangle selectionRectangle;
    internal Label labelText;
    internal Grid mainGrid;
    internal Grid categoryManagment;
    internal Grid bottonPanel;
    internal Grid leftIcon;
    internal Grid rightIcon;
    internal Rectangle shadowRight2;
    internal Grid shadowRight;
    internal Grid shadowBack;
    private bool _contentLoaded;

    public QuestionCategory MainCategory => this.mainCategory;

    public QuestionVerticalView()
    {
      this.InitializeComponent();
      this.labelText.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");
      UserMenager.languageKeyChangedEvet += new UserMenager.LanguageKeyChangedEvet(this.UserMenager_languageKeyChangedEvet);
      this.mainCategory = QuestionCategoryLoaderAndSever.GetMainCategory();
      this.categoriesViewer = new CategoriesListView(this.mainCategory);
      this.categoriesViewer.categorySelectedEvent += new CategoriesListView.CategorySelected(this.SelectCategory);
      this.CategoriesViewer.questioinSelectedEvent += new CategoriesListView.QuestionSelected(this.Cv_questioinSelectedEvent);
      this.categoryManagment.Children.Add((UIElement) this.CategoriesViewer);
      this.minimaliseButton = new CircleButton((UserControl) new MinimaliseIcon(), Color.FromRgb((byte) 40, (byte) 120, (byte) 245), CircleButton.VisualParam.circle);
      this.minimaliseButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.MinimaliseButton_buttonClickedEvent);
      this.leftIcon.Children.Add((UIElement) this.minimaliseButton);
      this.rightIcon.Width = 0.0;
    }

    private void UserMenager_languageKeyChangedEvet() => this.labelText.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("back");

    public event QuestionVerticalView.MinimaliseButtonClicked minimaliseButtonEventClicked;

    private void MinimaliseButton_buttonClickedEvent()
    {
      if (this.minimaliseButtonEventClicked == null)
        return;
      this.minimaliseButtonEventClicked();
    }

    public event QuestionVerticalView.CategoryWasSelected categoryWasSelectedEvent;

    public void SelectCategory(QuestionCategory category)
    {
      if (category == QuestionCategoryLoaderAndSever.GetMainCategory())
      {
        this.backGrid.Visibility = Visibility.Collapsed;
        this.mainGrid.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
        this.shadowBack.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.backGrid.Visibility = Visibility.Visible;
        this.mainGrid.Margin = new Thickness(0.0, 66.0, 8.0, 0.0);
        this.shadowBack.Visibility = Visibility.Visible;
      }
      if (category.SubQuestionsGuids.Count > 0 || category.IsChampionship || category.IsExam)
      {
        this.leftIcon.Visibility = Visibility.Collapsed;
        this.rightIcon.Visibility = Visibility.Collapsed;
        Grid shadowRight = this.shadowRight;
        Thickness margin = this.shadowRight.Margin;
        double left1 = margin.Left;
        margin = this.shadowRight.Margin;
        double right1 = margin.Right;
        margin = this.shadowRight.Margin;
        double bottom1 = margin.Bottom;
        Thickness thickness1 = new Thickness(left1, 70.0, right1, bottom1);
        shadowRight.Margin = thickness1;
        Rectangle shadowRight2 = this.shadowRight2;
        margin = this.shadowRight2.Margin;
        double left2 = margin.Left;
        margin = this.shadowRight2.Margin;
        double right2 = margin.Right;
        margin = this.shadowRight2.Margin;
        double bottom2 = margin.Bottom;
        Thickness thickness2 = new Thickness(left2, 70.0, right2, bottom2);
        shadowRight2.Margin = thickness2;
        this.mainGridTop.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 249, (byte) 249, (byte) 249));
      }
      else
      {
        this.leftIcon.Visibility = Visibility.Collapsed;
        this.rightIcon.Visibility = Visibility.Collapsed;
        this.mainGridTop.Background = (Brush) new SolidColorBrush(Colors.Transparent);
        Rectangle shadowRight2 = this.shadowRight2;
        Thickness margin = this.shadowRight2.Margin;
        double left1 = margin.Left;
        margin = this.shadowRight2.Margin;
        double right1 = margin.Right;
        margin = this.shadowRight2.Margin;
        double bottom1 = margin.Bottom;
        Thickness thickness1 = new Thickness(left1, 0.0, right1, bottom1);
        shadowRight2.Margin = thickness1;
        Grid shadowRight = this.shadowRight;
        margin = this.shadowRight.Margin;
        double left2 = margin.Left;
        margin = this.shadowRight.Margin;
        double right2 = margin.Right;
        margin = this.shadowRight.Margin;
        double bottom2 = margin.Bottom;
        Thickness thickness2 = new Thickness(left2, 0.0, right2, bottom2);
        shadowRight.Margin = thickness2;
      }
      this.categoriesViewer.LoadCategory(category);
      if (this.categoryWasSelectedEvent != null)
        this.categoryWasSelectedEvent(category);
      if (category.SubQuestionsGuids.Count <= 0 && !category.IsExam)
        return;
      this.SelectFirstQuestion();
    }

    private void Cv_questioinSelectedEvent(Question q)
    {
      this.leftIcon.Visibility = Visibility.Visible;
      this.rightIcon.Visibility = Visibility.Visible;
      if (q.Description == null)
        return;
      int length = q.Description.Length;
    }

    internal void SelectFirstQuestion() => this.categoriesViewer.SelectFirstQuestion();

    public CategoriesListView CategoriesViewer => this.categoriesViewer;

    private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
    {
    }

    private void Rectangle_MouseEnter(object sender, MouseEventArgs e) => this.selectionRectangle.Visibility = Visibility.Visible;

    private void Rectangle_MouseLeave(object sender, MouseEventArgs e) => this.selectionRectangle.Visibility = Visibility.Collapsed;

    public event QuestionVerticalView.BackButtonClicked backButtonClickedEvent;

    private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.backButtonClickedEvent == null)
        return;
      this.backButtonClickedEvent();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/questionverticalview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((FrameworkElement) target).SizeChanged += new SizeChangedEventHandler(this.UserControl_SizeChanged);
          break;
        case 2:
          this.backGrid = (Grid) target;
          break;
        case 3:
          this.mainGridTop = (Grid) target;
          break;
        case 4:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Rectangle_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Rectangle_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Rectangle_MouseDown);
          break;
        case 5:
          this.selectionRectangle = (Rectangle) target;
          break;
        case 6:
          this.labelText = (Label) target;
          break;
        case 7:
          this.mainGrid = (Grid) target;
          break;
        case 8:
          this.categoryManagment = (Grid) target;
          break;
        case 9:
          this.bottonPanel = (Grid) target;
          break;
        case 10:
          this.leftIcon = (Grid) target;
          break;
        case 11:
          this.rightIcon = (Grid) target;
          break;
        case 12:
          this.shadowRight2 = (Rectangle) target;
          break;
        case 13:
          this.shadowRight = (Grid) target;
          break;
        case 14:
          this.shadowBack = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void MinimaliseButtonClicked();

    public delegate void CategoryWasSelected(QuestionCategory category);

    public delegate void BackButtonClicked();
  }
}
