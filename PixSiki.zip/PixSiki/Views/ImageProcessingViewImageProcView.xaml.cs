﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.ImageProcessingView.ImageProcView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.BlocksManager;
using PixBlocks.CodeRunner;
using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.CodeRunner.CodeRunnerViewElements.Images;
using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.CodeParser;
using PixBlocks.Tools.ColorTransformation;
using PixBlocks.UserMenagment.StaticEditedCodeMenager;
using PixBlocks.Views.CodeElements;
using PixBlocks.Views.CodeElements.BasicBlocks;
using PixBlocks.Views.DragDropController;
using PixBlocks.Views.ImageProcessingView.PaintPanel;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PixBlocks.Views.ImageProcessingView
{
  public partial class ImageProcView : UserControl, IComponentConnector
  {
    private PixBlocks.CodeRunner.CodeRunner codeRunner;
    private PixBlocks.CodeRunner.CodeRunner codePatter;
    private Question question;
    private bool inBitmapIsSubsetOfOutBmp;
    private bool icContainsBlocks;
    private BlocksVisual patternBlocksVisual;
    private BlocksVisual runnerBlocksVisual;
    private CodeRunView codeRunView;
    private CircleButton zoomInButton;
    private CircleButton zoomOutButton;
    private int MouseMoveX;
    private int MouseMoveY;
    private int prevx = -1;
    private int prevy = -1;
    internal Grid mainGrid;
    internal Grid gridToPaint;
    internal Grid frozenPaint;
    internal Grid bottonPanel;
    internal StackPanel colorsStackPanel;
    internal StackPanel colorPickerPanel;
    internal Rectangle rectColor;
    internal Label variableRed;
    internal Label variableGreen;
    internal Label variableBlue;
    internal Label variableXY;
    internal StackPanel zoomIcons;
    internal Grid gridAndImage;
    internal Image image;
    internal Grid blocksGridRunner;
    internal Grid blocksGridPattern;
    internal Rectangle rectImageProcessing;
    internal RabbitIcon2 rabbitIcon;
    internal Image imagePattern;
    internal Rectangle rectHoriz;
    internal Rectangle rectVert;
    internal Grid runParams;
    private bool _contentLoaded;

    public ImageProcView(PixBlocks.CodeRunner.CodeRunner codeRunner, PixBlocks.CodeRunner.CodeRunner codePatter, Question question)
    {
      this.question = question;
      this.InitializeComponent();
      this.codeRunner = codeRunner;
      this.codePatter = codePatter;
      this.imagePattern.Visibility = Visibility.Hidden;
      this.blocksGridPattern.Visibility = Visibility.Hidden;
      this.image.Source = (ImageSource) codeRunner.CodeInOut.Image.BitmapIO;
      if (codePatter != null)
      {
        this.imagePattern.Source = (ImageSource) codePatter.CodeInOut.Image.BitmapIO;
        codePatter.codeeRunnerStatusChangedEvent += new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodePatter_codeeRunnerStatusChangedEvent);
        codePatter.CodeInOut.Image.imageLoaded += new IOImage.ImageLoadedFromFile(this.ImagePattern_imageLoaded);
      }
      else
      {
        this.imagePattern.Visibility = Visibility.Collapsed;
        this.blocksGridPattern.Visibility = Visibility.Collapsed;
      }
      codeRunner.codeeRunnerStatusChangedEvent += new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodeRunner_codeeRunnerStatusChangedEvent);
      codeRunner.CodeInOut.Image.imageLoaded += new IOImage.ImageLoadedFromFile(this.ImageRunner_imageLoaded);
      codeRunner.CodeInOut.Image.rectModificationEvent += new IOImage.RectWasModified(this.Image_rectModificationEvent);
      codeRunner.iterationStepChangedEvent += new PixBlocks.CodeRunner.CodeRunner.IterationStepChanged(this.CodeRunner_iterationStepChangedEvent);
      codeRunner.CodeInOut.turleChangedEvent += new CodeInOut.TurtlePositionChanged(this.CodeInOut_turleChangedEvent);
      this.rectHoriz.Visibility = Visibility.Hidden;
      this.rectVert.Visibility = Visibility.Hidden;
      this.colorsStackPanel.Visibility = Visibility.Collapsed;
      this.codeRunView = new CodeRunView(codeRunner, codePatter, question);
      this.runParams.Children.Add((UIElement) this.codeRunView);
      this.codeRunView.solutionMatchResultEvent += new CodeRunView.SolutionsMatchingResult(this.CodeRunView_solutionMatchResultEvent);
      this.zoomInButton = new CircleButton((UserControl) new PlusZoom(), Color.FromRgb((byte) 40, (byte) 120, (byte) 245), CircleButton.VisualParam.circle);
      this.zoomOutButton = new CircleButton((UserControl) new minusZoom(), Color.FromRgb((byte) 40, (byte) 120, (byte) 245), CircleButton.VisualParam.circle);
      this.zoomIcons.Children.Add((UIElement) this.zoomOutButton);
      this.zoomIcons.Children.Add((UIElement) this.zoomInButton);
      this.rectImageProcessing.Visibility = Visibility.Collapsed;
      this.CreateBlocksGridIfNotExists();
      this.inBitmapIsSubsetOfOutBmp = false;
      if (this.icContainsBlocks)
      {
        this.image.Visibility = Visibility.Collapsed;
        this.imagePattern.Visibility = Visibility.Collapsed;
        this.inBitmapIsSubsetOfOutBmp = this.CheckIfInBitmapIsSubsetOfOutBitmap();
        this.colorPickerPanel.Visibility = Visibility.Collapsed;
      }
      else
        this.colorPickerPanel.Visibility = Visibility.Visible;
      if (this.inBitmapIsSubsetOfOutBmp)
      {
        this.blocksGridPattern.Visibility = Visibility.Visible;
        this.patternBlocksVisual.SetTransparency(true);
      }
      if (!question.CanEditBitmap && !UserMenager.UserIsSuperAdmin())
        return;
      this.gridToPaint.Children.Add((UIElement) new PaintPanelView(this.icContainsBlocks));
    }

    public bool CheckIfInBitmapIsSubsetOfOutBitmap()
    {
      if (this.question == null || this.question.QuestionType != QuestionType.ClassicQuestionType || this.codePatter == null)
        return false;
      WriteableBitmap bmp = this.codePatter.CodeInOut.Image.BitmapIO.Clone();
      for (int index = 0; index < int.MaxValue; ++index)
      {
        this.codePatter.RunNextInstruction();
        if (this.codePatter.CurrentInstruction == null)
          break;
      }
      this.codePatter.SendResetEvent();
      WriteableBitmap bitmapIo = this.codePatter.CodeInOut.Image.BitmapIO;
      WriteableBitmap writeableBitmap;
      for (int x = 0; (double) x < bitmapIo.Width; ++x)
      {
        for (int y = 0; (double) y < bitmapIo.Height; ++y)
        {
          Color pixel = bmp.GetPixel(x, y);
          if (!pixel.Equals(Colors.Black) && !pixel.Equals(bitmapIo.GetPixel(x, y)))
          {
            writeableBitmap = (WriteableBitmap) null;
            return false;
          }
        }
      }
      writeableBitmap = (WriteableBitmap) null;
      return true;
    }

    private void CreateBlocksGridIfNotExists()
    {
      if (this.ContainsBlocksCode())
      {
        this.icContainsBlocks = true;
        if (this.blocksGridRunner.Children.Count != 0)
          return;
        if (this.codeRunner != null)
        {
          this.runnerBlocksVisual = new BlocksVisual(this.codeRunner);
          this.blocksGridRunner.Children.Add((UIElement) this.runnerBlocksVisual);
        }
        if (this.codePatter == null)
          return;
        this.patternBlocksVisual = new BlocksVisual(this.codePatter);
        this.blocksGridPattern.Children.Add((UIElement) this.patternBlocksVisual);
      }
      else
      {
        this.icContainsBlocks = false;
        this.blocksGridRunner.Children.Clear();
        this.blocksGridPattern.Children.Clear();
      }
    }

    private bool ContainsBlocksCode()
    {
      if (this.codeRunner != null)
      {
        foreach (ICodeElement innerCodeElement in this.codeRunner.RootElement.InnerCodeElements())
        {
          if (innerCodeElement is AssigmentInstruction && ((innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.DrawTurtleImage || (innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage || (innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage2Image) || innerCodeElement is IfThenInstruction && ((innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.EqualsImages || (innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.NotEqualsImages || (innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.TurtleSeeImage))
            return true;
        }
      }
      if (this.codePatter != null)
      {
        foreach (ICodeElement innerCodeElement in this.codePatter.RootElement.InnerCodeElements())
        {
          if (innerCodeElement is AssigmentInstruction && ((innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.DrawTurtleImage || (innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage || (innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage2Image) || innerCodeElement is IfThenInstruction && ((innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.EqualsImages || (innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.NotEqualsImages || (innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.TurtleSeeImage))
            return true;
        }
      }
      if (this.question.QuestionType == QuestionType.FreeCodeType)
      {
        foreach (ICodeElement innerCodeElement in CodeStringParser.GenerateModelFromCode(this.question.Code).InnerCodeElements())
        {
          if (innerCodeElement is AssigmentInstruction && ((innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.DrawTurtleImage || (innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage || (innerCodeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage2Image) || innerCodeElement is IfThenInstruction && ((innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.EqualsImages || (innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.NotEqualsImages || (innerCodeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.TurtleSeeImage))
            return true;
        }
      }
      return false;
    }

    private void CodeRunner_iterationStepChangedEvent(int step) => this.rectImageProcessing.Visibility = Visibility.Collapsed;

    public event ImageProcView.SolutionsMatchingResult solutionMatchResultEvent;

    private void CodeRunView_solutionMatchResultEvent(CodeRunningResult matchStatus)
    {
      if (this.solutionMatchResultEvent == null)
        return;
      this.solutionMatchResultEvent(matchStatus);
    }

    private void Image_rectModificationEvent(IOImage.ModificationRectangle modRect)
    {
      this.rectImageProcessing.Visibility = Visibility.Visible;
      this.rectImageProcessing.Width = (double) modRect.Width;
      this.rectImageProcessing.Height = (double) modRect.Height;
      this.rectImageProcessing.Margin = new Thickness((double) modRect.XLeft, 0.0, 0.0, (double) modRect.YBotton);
      if (modRect.IsWriting)
        this.rectImageProcessing.Fill = (Brush) new SolidColorBrush(Colors.Red);
      else
        this.rectImageProcessing.Fill = (Brush) new SolidColorBrush(Colors.Blue);
    }

    internal void DisposeAllElements()
    {
      if (this.codeRunView != null)
        this.codeRunView.DisposeAllElements();
      if (this.codeRunner != null)
      {
        this.codeRunner.codeeRunnerStatusChangedEvent -= new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodeRunner_codeeRunnerStatusChangedEvent);
        this.codeRunner.CodeInOut.Image.imageLoaded -= new IOImage.ImageLoadedFromFile(this.ImageRunner_imageLoaded);
        this.codeRunner.CodeInOut.Image.rectModificationEvent -= new IOImage.RectWasModified(this.Image_rectModificationEvent);
        this.codeRunner.iterationStepChangedEvent -= new PixBlocks.CodeRunner.CodeRunner.IterationStepChanged(this.CodeRunner_iterationStepChangedEvent);
        this.codeRunner.CodeInOut.turleChangedEvent -= new CodeInOut.TurtlePositionChanged(this.CodeInOut_turleChangedEvent);
        this.codeRunner.CodeInOut.Image.BitmapIO.Clear();
      }
      if (this.codePatter != null)
      {
        this.codePatter.codeeRunnerStatusChangedEvent -= new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodePatter_codeeRunnerStatusChangedEvent);
        this.codePatter.CodeInOut.Image.imageLoaded -= new IOImage.ImageLoadedFromFile(this.ImagePattern_imageLoaded);
        this.codePatter.CodeInOut.Image.BitmapIO.Clear();
      }
      this.codeRunView.solutionMatchResultEvent -= new CodeRunView.SolutionsMatchingResult(this.CodeRunView_solutionMatchResultEvent);
      if (this.patternBlocksVisual != null)
        this.patternBlocksVisual.DisposeAll();
      if (this.runnerBlocksVisual != null)
        this.runnerBlocksVisual.DisposeAll();
      this.image = (Image) null;
      this.imagePattern = (Image) null;
      this.rectImageProcessing = (Rectangle) null;
      this.codeRunView = (CodeRunView) null;
    }

    public CircleButton ZoomInButton => this.zoomInButton;

    public CircleButton ZoomOutButton => this.zoomOutButton;

    private void ImagePattern_imageLoaded() => this.imagePattern.Source = (ImageSource) this.codePatter.CodeInOut.Image.BitmapIO;

    private void ImageRunner_imageLoaded() => this.image.Source = (ImageSource) this.codeRunner.CodeInOut.Image.BitmapIO;

    private void CodeRunner_codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status)
    {
      if (status != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped)
      {
        this.gridToPaint.Opacity = 0.4;
        this.frozenPaint.Visibility = Visibility.Visible;
      }
      else
      {
        this.gridToPaint.Opacity = 1.0;
        this.frozenPaint.Visibility = Visibility.Collapsed;
      }
      if (status != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
        this.rectImageProcessing.Visibility = Visibility.Collapsed;
      if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing || status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
      {
        this.codeRunner.CodeInOut.Image.InvokeEvents = true;
        this.CreateBlocksGridIfNotExists();
        if (this.icContainsBlocks)
          this.colorPickerPanel.Visibility = Visibility.Collapsed;
        else
          this.colorPickerPanel.Visibility = Visibility.Visible;
        this.mainGrid.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 0, (byte) 100, byte.MaxValue));
        if (!this.inBitmapIsSubsetOfOutBmp)
          this.blocksGridPattern.Visibility = Visibility.Hidden;
        else
          this.patternBlocksVisual.SetTransparency(true);
        this.imagePattern.Visibility = Visibility.Hidden;
        this.rabbitIcon.Visibility = Visibility.Visible;
      }
      else
      {
        if (this.question.QuestionType == QuestionType.ClassicQuestionType)
          this.rabbitIcon.Visibility = Visibility.Collapsed;
        if (this.patternBlocksVisual != null)
        {
          if (this.inBitmapIsSubsetOfOutBmp)
            this.patternBlocksVisual.SetTransparency(true);
          else
            this.patternBlocksVisual.SetTransparency(false);
        }
        this.blocksGridPattern.Visibility = Visibility.Visible;
        if (!this.icContainsBlocks)
          this.imagePattern.Visibility = Visibility.Visible;
        this.mainGrid.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 100, (byte) 100, (byte) 130));
      }
    }

    private void CodePatter_codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status)
    {
      if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped)
      {
        this.mainGrid.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 100, (byte) 100, (byte) 130));
        if (!this.inBitmapIsSubsetOfOutBmp)
          this.blocksGridPattern.Visibility = Visibility.Hidden;
        this.imagePattern.Visibility = Visibility.Hidden;
        this.rabbitIcon.Visibility = Visibility.Visible;
      }
      else
      {
        this.mainGrid.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 0, byte.MaxValue, (byte) 0));
        if (!this.icContainsBlocks)
          this.imagePattern.Visibility = Visibility.Visible;
        if (this.question.QuestionType == QuestionType.ClassicQuestionType)
          this.rabbitIcon.Visibility = Visibility.Collapsed;
        if (this.patternBlocksVisual != null)
        {
          if (this.inBitmapIsSubsetOfOutBmp)
          {
            if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Ended)
              this.patternBlocksVisual.SetTransparency(false);
            else
              this.patternBlocksVisual.SetTransparency(true);
          }
          else
            this.patternBlocksVisual.SetTransparency(false);
        }
        this.blocksGridPattern.Visibility = Visibility.Visible;
      }
    }

    private void CodeInOut_turleChangedEvent() => this.rabbitIcon.Margin = new Thickness((double) (this.codeRunner.CodeInOut.TurtleX - 1), 0.0, 0.0, (double) (this.codeRunner.CodeInOut.TurtleY - 1));

    private void Grid_MouseEnter(object sender, MouseEventArgs e)
    {
      this.rectHoriz.Visibility = Visibility.Visible;
      this.rectVert.Visibility = Visibility.Visible;
      this.colorsStackPanel.Visibility = Visibility.Visible;
    }

    private void Grid_MouseLeave(object sender, MouseEventArgs e)
    {
      this.rectHoriz.Visibility = Visibility.Hidden;
      this.rectVert.Visibility = Visibility.Hidden;
      this.colorsStackPanel.Visibility = Visibility.Hidden;
    }

    private void Grid_MouseMove(object sender, MouseEventArgs e)
    {
      this.codeRunner.CodeInOut.Image.InvokeEvents = false;
      int x1 = (int) e.GetPosition((IInputElement) this.gridAndImage).X;
      int y1 = (int) e.GetPosition((IInputElement) this.gridAndImage).Y;
      int num1 = Math.Max(0, Math.Min(x1, this.codeRunner.CodeInOut.Image.GetWidth() - 1));
      int num2 = Math.Max(0, Math.Min(y1, this.codeRunner.CodeInOut.Image.GetHeight() - 1));
      this.rectHoriz.Margin = new Thickness((double) num1, 0.0, 0.0, 0.0);
      this.rectVert.Margin = new Thickness(0.0, (double) num2, 0.0, 0.0);
      int x2 = num1 + 1;
      this.MouseMoveX = x2;
      int y2 = this.codeRunner.CodeInOut.Image.GetHeight() - num2;
      this.MouseMoveY = y2;
      if (x2 < 10)
        this.variableXY.Content = (object) (" X=" + x2.ToString() + "  Y=" + y2.ToString());
      else
        this.variableXY.Content = (object) (" X=" + x2.ToString() + " Y=" + y2.ToString());
      Value pixelColor = this.codeRunner.CodeInOut.Image.GetPixelColor(x2, y2);
      if (this.imagePattern != null && this.imagePattern.Visibility == Visibility.Visible && this.codePatter != null)
        pixelColor = this.codePatter.CodeInOut.Image.GetPixelColor(x2, y2);
      this.rectColor.Fill = (Brush) new SolidColorBrush(ColorTransorm.GetColorFromValue(pixelColor));
      this.variableBlue.Content = (object) pixelColor.B;
      if (pixelColor.B != 10)
      {
        Label variableBlue = this.variableBlue;
        variableBlue.Content = (object) (variableBlue.Content?.ToString() + " ");
      }
      this.variableGreen.Content = (object) pixelColor.G;
      if (pixelColor.G != 10)
      {
        Label variableGreen = this.variableGreen;
        variableGreen.Content = (object) (variableGreen.Content?.ToString() + " ");
      }
      this.variableRed.Content = (object) pixelColor.R;
      if (pixelColor.R != 10)
      {
        Label variableRed = this.variableRed;
        variableRed.Content = (object) (variableRed.Content?.ToString() + " ");
      }
      this.codeRunner.CodeInOut.Image.InvokeEvents = true;
      if (Mouse.LeftButton != MouseButtonState.Pressed && Mouse.RightButton != MouseButtonState.Pressed || this.prevx == x2 && this.prevy == y2 || StaticDragController.Instance.CanStopDragging || (this.question == null || this.question.QuestionType != QuestionType.FreeCodeType && this.question.QuestionType != QuestionType.InfoType || !this.question.CanEditBitmap) && !UserMenager.UserIsSuperAdmin() || (StaticDragController.Instance.UcToDrag == null || !(StaticDragController.Instance.UcToDrag is VariableView)))
        return;
      this.prevx = x2;
      this.prevy = y2;
      StaticDragController.Instance.CanStopDragging = false;
      Variable codeElement = (StaticDragController.Instance.UcToDrag as VariableView).GetCodeElement() as Variable;
      if (codeElement.VariableType != VariableType.constant || codeElement.ValueType != PixBlocks.DataModels.Code.ValueType.Color && codeElement.ValueType != PixBlocks.DataModels.Code.ValueType.Image)
        return;
      this.codeRunner.CodeInOut.Image.PutPixel(this.MouseMoveX, this.MouseMoveY, codeElement.RunInnerCode((Value) null, (CodeInOut) null));
      this.rectImageProcessing.Visibility = Visibility.Hidden;
      UserMenager.UserIsSuperAdmin();
    }

    internal void ActForNumberOfCodeLines(int numberOfCodeLines) => this.codeRunView.ActForNumberOfCodeLines(numberOfCodeLines);

    private void gridAndImage_MouseUp(object sender, MouseButtonEventArgs e)
    {
      if ((this.question == null || this.question.QuestionType != QuestionType.FreeCodeType && this.question.QuestionType != QuestionType.InfoType || !this.question.CanEditBitmap) && !UserMenager.UserIsSuperAdmin() || (StaticDragController.Instance.UcToDrag == null || !(StaticDragController.Instance.UcToDrag is VariableView)))
        return;
      StaticDragController.Instance.CanStopDragging = false;
      Variable codeElement = (StaticDragController.Instance.UcToDrag as VariableView).GetCodeElement() as Variable;
      if (codeElement.VariableType != VariableType.constant || codeElement.ValueType != PixBlocks.DataModels.Code.ValueType.Color && codeElement.ValueType != PixBlocks.DataModels.Code.ValueType.Image)
        return;
      this.codeRunner.CodeInOut.Image.PutPixel(this.MouseMoveX, this.MouseMoveY, codeElement.RunInnerCode((Value) null, (CodeInOut) null));
      this.rectImageProcessing.Visibility = Visibility.Hidden;
    }

    private void Grid_MouseLeave_1(object sender, MouseEventArgs e)
    {
      this.prevx = -1;
      this.prevy = -1;
      if (StaticDragController.Instance.CanStopDragging)
        return;
      StaticDragController.Instance.CanStopDragging = true;
      StaticDragController.Instance.StopDragging();
      string base64 = this.codeRunner.CodeInOut.Image.ConvertToBase64();
      this.codeRunner.CodeInOut.Image.LoadFromBase64(base64, this.question.ImageWidth, this.question.ImageHeight);
      if (this.question.CanEditBitmap && this.question.QuestionType == QuestionType.FreeCodeType)
        QuestionsCodesManager.AddEditedImageInBase64(this.question, base64);
      if (!UserMenager.UserIsSuperAdmin())
        return;
      this.question.ImageInBase64 = base64;
    }

    internal void ProgramaticlyClickStopButton() => this.codeRunView.ProgramaticlyClickStopButton();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/imageprocessingview/imageprocview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.gridToPaint = (Grid) target;
          break;
        case 3:
          this.frozenPaint = (Grid) target;
          break;
        case 4:
          this.bottonPanel = (Grid) target;
          break;
        case 5:
          this.colorsStackPanel = (StackPanel) target;
          break;
        case 6:
          this.colorPickerPanel = (StackPanel) target;
          break;
        case 7:
          this.rectColor = (Rectangle) target;
          break;
        case 8:
          this.variableRed = (Label) target;
          break;
        case 9:
          this.variableGreen = (Label) target;
          break;
        case 10:
          this.variableBlue = (Label) target;
          break;
        case 11:
          this.variableXY = (Label) target;
          break;
        case 12:
          this.zoomIcons = (StackPanel) target;
          break;
        case 13:
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave_1);
          break;
        case 14:
          this.gridAndImage = (Grid) target;
          this.gridAndImage.MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          this.gridAndImage.MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          this.gridAndImage.MouseMove += new MouseEventHandler(this.Grid_MouseMove);
          this.gridAndImage.MouseUp += new MouseButtonEventHandler(this.gridAndImage_MouseUp);
          break;
        case 15:
          this.image = (Image) target;
          break;
        case 16:
          this.blocksGridRunner = (Grid) target;
          break;
        case 17:
          this.blocksGridPattern = (Grid) target;
          break;
        case 18:
          this.rectImageProcessing = (Rectangle) target;
          break;
        case 19:
          this.rabbitIcon = (RabbitIcon2) target;
          break;
        case 20:
          this.imagePattern = (Image) target;
          break;
        case 21:
          this.rectHoriz = (Rectangle) target;
          break;
        case 22:
          this.rectVert = (Rectangle) target;
          break;
        case 23:
          this.runParams = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void SolutionsMatchingResult(CodeRunningResult matchStatus);
  }
}
