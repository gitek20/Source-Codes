﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.StaticVariables.StaticVariablesView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.CodeInputOutput.Variables;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.Views.StaticVariables
{
  public partial class StaticVariablesView : UserControl, IComponentConnector
  {
    private PixBlocks.CodeRunner.CodeRunner codeRunner;
    public CircleButton maximaliseButton;
    public CircleButton minimaliseButton;
    internal Grid mainGrid;
    internal StackPanel stackPanel;
    internal Grid maximaliseButtonGrid;
    private bool _contentLoaded;

    public StaticVariablesView(PixBlocks.CodeRunner.CodeRunner codeRunner)
    {
      this.InitializeComponent();
      this.codeRunner = codeRunner;
      codeRunner.codeeRunnerStatusChangedEvent += new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodeRunner_codeeRunnerStatusChangedEvent);
      this.maximaliseButton = new CircleButton((UserControl) new MaximaliseIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.maximaliseButtonGrid.Children.Add((UIElement) this.maximaliseButton);
      this.minimaliseButton = new CircleButton((UserControl) new MinimaliseIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.maximaliseButtonGrid.Children.Add((UIElement) this.minimaliseButton);
      this.ShowMaximaliseButton(false);
    }

    public void ShowMaximaliseButton(bool show)
    {
      if (show)
      {
        this.maximaliseButton.Visibility = Visibility.Visible;
        this.minimaliseButton.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.maximaliseButton.Visibility = Visibility.Collapsed;
        this.minimaliseButton.Visibility = Visibility.Visible;
      }
    }

    private void CodeRunner_codeeRunnerStatusChangedEvent(PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus status)
    {
      if (status == PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Stopped)
        this.stackPanel.Children.Clear();
      if (status != PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatus.Plaing)
        return;
      this.BuildView();
    }

    private void BuildView()
    {
      List<ICodeElement> codeElementList = this.codeRunner.RootElement.InnerCodeElements();
      bool flag = false;
      foreach (ICodeElement codeElement in codeElementList)
      {
        if (codeElement.GetUniqueName().ToLower().Contains("turtle"))
          flag = true;
        if (codeElement is AssigmentInstruction && ((codeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.DrawTurtleColor || (codeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.TurtleDown || ((codeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.TurtleLeft || (codeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.TurtleRight) || ((codeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.TurtleTop || (codeElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage)))
          flag = true;
        if (codeElement is IfThenInstruction && ((codeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.TurtleSeeColor || (codeElement as IfThenInstruction).IfThenInstructionType == IfThenInstructionType.TurtleSeeImage))
          flag = true;
      }
      this.stackPanel.Children.Add((UIElement) new VariableColorNumber(this.codeRunner, AdditionalVariableType.NumberOfInstructions));
      this.stackPanel.Children.Add((UIElement) new VariableColorNumber(this.codeRunner.CodeInOut, AdditionalVariableType.ImageWidth));
      this.stackPanel.Children.Add((UIElement) new VariableColorNumber(this.codeRunner.CodeInOut, AdditionalVariableType.ImageHeight));
      if (flag)
      {
        this.stackPanel.Children.Add((UIElement) new VariableColorNumber(this.codeRunner.CodeInOut, AdditionalVariableType.TurtleX));
        this.stackPanel.Children.Add((UIElement) new VariableColorNumber(this.codeRunner.CodeInOut, AdditionalVariableType.TurtleY));
      }
      List<string> stringList = new List<string>();
      foreach (ICodeElement codeElement in codeElementList)
      {
        if (codeElement is Variable && (codeElement as Variable).VariableType == VariableType.variable)
        {
          string name = (codeElement as Variable).Name;
          if (!stringList.Contains(name))
            stringList.Add(name);
        }
      }
      foreach (StaticVariable variable in this.codeRunner.CodeInOut.CodeStaticVariables.Variables)
      {
        if (stringList.Contains(variable.Name))
          this.stackPanel.Children.Add((UIElement) new VariableColorNumber(variable));
      }
    }

    internal void DisposeAllElements()
    {
      this.codeRunner.codeeRunnerStatusChangedEvent -= new PixBlocks.CodeRunner.CodeRunner.CodeRunnerStatusChanged(this.CodeRunner_codeeRunnerStatusChangedEvent);
      for (int index = 0; index < this.stackPanel.Children.Count; ++index)
      {
        if (this.stackPanel.Children[index] is VariableColorNumber)
          (this.stackPanel.Children[index] as VariableColorNumber).DisposeAll();
      }
      this.stackPanel.Children.Clear();
      this.stackPanel = (StackPanel) null;
      this.mainGrid = (Grid) null;
      this.maximaliseButton = (CircleButton) null;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/staticvariables/staticvariablesview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.stackPanel = (StackPanel) target;
          break;
        case 3:
          this.maximaliseButtonGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
