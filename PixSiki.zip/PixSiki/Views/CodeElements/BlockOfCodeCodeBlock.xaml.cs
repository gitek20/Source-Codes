﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.BlockOfCode.CodeBlock
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.TemplateElementsGenerator;
using PixBlocks.Views.DragDropController;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.Views.CodeElements.BlockOfCode
{
  public partial class CodeBlock : UserControl, IComponentConnector
  {
    private ICodeInstructionBlock instructionBlock;
    private AddNewBlock addBlock;
    internal StackPanel stackPanel;
    internal Grid addInstructionGrid;
    private bool _contentLoaded;

    public CodeBlock(ICodeInstructionBlock instructionBlock, bool isMainINstruction)
    {
      this.InitializeComponent();
      this.instructionBlock = instructionBlock;
      if (instructionBlock is RepeatNTimes && isMainINstruction)
        this.addInstructionGrid.MinHeight = 200.0;
      foreach (ICodeElement blockElement in instructionBlock.GetBlockElements())
      {
        if (blockElement is IfThenInstruction)
        {
          IfThenInstructionView thenInstructionView = new IfThenInstructionView((IfThenInstruction) blockElement);
          thenInstructionView.HorizontalAlignment = HorizontalAlignment.Left;
          this.stackPanel.Children.Add((UIElement) thenInstructionView);
          thenInstructionView.CodeBlockParent = this;
          if (thenInstructionView.CodBlockInside != null)
            thenInstructionView.CodBlockInside.numberOfInstructionsChange += new CodeBlock.NumberOfInstructionsChanged(this.CodBlockInside_numberOfInstructionsChange);
        }
        if (blockElement is RepeatNTimes)
        {
          RepeatNTimesView repeatNtimesView = new RepeatNTimesView((RepeatNTimes) blockElement);
          repeatNtimesView.HorizontalAlignment = HorizontalAlignment.Left;
          this.stackPanel.Children.Add((UIElement) repeatNtimesView);
          repeatNtimesView.CodeBlockParent = this;
          if (repeatNtimesView.CodBlockInside != null)
            repeatNtimesView.CodBlockInside.numberOfInstructionsChange += new CodeBlock.NumberOfInstructionsChanged(this.CodBlockInside_numberOfInstructionsChange);
        }
        if (blockElement is Variable)
          this.stackPanel.Children.Add((UIElement) new VariableView((Variable) blockElement));
        if (blockElement is Procedure)
          this.stackPanel.Children.Add((UIElement) new ProcedureView((Procedure) blockElement));
        if (blockElement is AssigmentInstruction)
        {
          AssigmentInstructionView assigmentInstructionView = new AssigmentInstructionView((AssigmentInstruction) blockElement);
          assigmentInstructionView.HorizontalAlignment = HorizontalAlignment.Left;
          this.stackPanel.Children.Add((UIElement) assigmentInstructionView);
          assigmentInstructionView.CodeBlockParent = this;
        }
      }
      this.addBlock = new AddNewBlock(this);
      this.stackPanel.Children.Add((UIElement) this.addBlock);
      if (this.numberOfInstructionsChange == null)
        return;
      this.numberOfInstructionsChange();
    }

    internal void DisposeAllElements()
    {
      for (int index = 0; index < this.stackPanel.Children.Count; ++index)
      {
        if (this.stackPanel.Children[index] is RepeatNTimesView && (this.stackPanel.Children[index] as RepeatNTimesView).CodBlockInside != null)
        {
          (this.stackPanel.Children[index] as RepeatNTimesView).CodBlockInside.numberOfInstructionsChange -= new CodeBlock.NumberOfInstructionsChanged(this.CodBlockInside_numberOfInstructionsChange);
          (this.stackPanel.Children[index] as RepeatNTimesView).CodBlockInside.DisposeAllElements();
        }
        if (this.stackPanel.Children[index] is IfThenInstructionView && (this.stackPanel.Children[index] as IfThenInstructionView).CodBlockInside != null)
        {
          (this.stackPanel.Children[index] as IfThenInstructionView).CodBlockInside.numberOfInstructionsChange -= new CodeBlock.NumberOfInstructionsChanged(this.CodBlockInside_numberOfInstructionsChange);
          (this.stackPanel.Children[index] as IfThenInstructionView).CodBlockInside.DisposeAllElements();
        }
        if (this.stackPanel.Children[index] is IUCWithICodeElement)
          (this.stackPanel.Children[index] as IUCWithICodeElement).DisposeAll();
      }
      this.stackPanel.Children.Clear();
    }

    private void CodBlockInside_numberOfInstructionsChange()
    {
      if (this.numberOfInstructionsChange == null)
        return;
      this.numberOfInstructionsChange();
    }

    public event CodeBlock.NumberOfInstructionsChanged numberOfInstructionsChange;

    public AddNewBlock AddBlock => this.addBlock;

    public CodeBlock() => this.InitializeComponent();

    public bool IsUCnewPatentOf(FrameworkElement ucnew, FrameworkElement ucReference)
    {
      if (ucReference == null)
        return false;
      return ucnew == ucReference || this.IsUCnewPatentOf(ucnew, (FrameworkElement) ucReference.Parent);
    }

    internal void AddUserControlBefore(UserControl uc, UserControl ucReference)
    {
      if (this.IsUCnewPatentOf((FrameworkElement) uc, (FrameworkElement) ucReference) || uc == ucReference)
        return;
      UserControl uc1 = new UserControl();
      ICodeElement codeElement1 = ((IUCWithICodeElement) uc).GetCodeElement();
      if (codeElement1.IsInstruction())
      {
        if (codeElement1.GetIsTemplateElement())
        {
          TemplateModelsGenerator templateModelsGenerator = new TemplateModelsGenerator();
          ICodeElement elementOfName = templateModelsGenerator.GetElementOFName(codeElement1.GetUniqueName());
          elementOfName.PutIsTemplateElement(false);
          uc1 = templateModelsGenerator.GetUserControlFromICodeElement(elementOfName, false);
        }
        else
        {
          uc1 = uc;
          ((IUCWitchCodeBlockParent) uc1).CodeBlockParent.RemoveChild(uc1);
        }
      }
      uc1.HorizontalAlignment = HorizontalAlignment.Left;
      for (int index1 = 0; index1 < this.stackPanel.Children.Count; ++index1)
      {
        if (this.stackPanel.Children[index1] == ucReference)
        {
          this.stackPanel.Children.Insert(index1, (UIElement) uc1);
          List<ICodeElement> blockElements = this.instructionBlock.GetBlockElements();
          ICodeElement codeElement2 = ((IUCWithICodeElement) uc1).GetCodeElement();
          int index2 = index1;
          ICodeElement codeElement3 = codeElement2;
          blockElements.Insert(index2, codeElement3);
          codeElement2.SetParent(this.instructionBlock as ICodeElement);
          if (this.numberOfInstructionsChange != null)
            this.numberOfInstructionsChange();
          if (uc1 is AssigmentInstructionView)
            ((AssigmentInstructionView) uc1).CodeBlockParent = this;
          if (uc1 is RepeatNTimesView)
          {
            ((RepeatNTimesView) uc1).CodeBlockParent = this;
            if (((RepeatNTimesView) uc1).CodBlockInside != null)
              ((RepeatNTimesView) uc1).CodBlockInside.numberOfInstructionsChange += new CodeBlock.NumberOfInstructionsChanged(this.CodBlockInside_numberOfInstructionsChange);
          }
          if (!(uc1 is IfThenInstructionView))
            break;
          ((IfThenInstructionView) uc1).CodeBlockParent = this;
          if (((IfThenInstructionView) uc1).CodBlockInside == null)
            break;
          ((IfThenInstructionView) uc1).CodBlockInside.numberOfInstructionsChange += new CodeBlock.NumberOfInstructionsChanged(this.CodBlockInside_numberOfInstructionsChange);
          break;
        }
      }
    }

    private void Grid_MouseEnter(object sender, MouseEventArgs e) => this.addBlock.UserControl_MouseEnter(sender, e);

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.addBlock.UserControl_MouseLeave(sender, e);

    private void Grid_MouseUp(object sender, MouseButtonEventArgs e)
    {
      if (StaticDragController.Instance.UcToDrag == null || !(StaticDragController.Instance.UcToDrag as IUCWithICodeElement).GetCodeElement().IsInstruction())
        return;
      this.addBlock.UserControl_MouseUp(sender, e);
    }

    internal void RemoveChild(UserControl uc)
    {
      for (int index1 = 0; index1 < this.stackPanel.Children.Count; ++index1)
      {
        if (this.stackPanel.Children[index1] == uc)
        {
          if (uc is RepeatNTimesView && ((RepeatNTimesView) uc).CodBlockInside != null)
            ((RepeatNTimesView) uc).CodBlockInside.numberOfInstructionsChange -= new CodeBlock.NumberOfInstructionsChanged(this.CodBlockInside_numberOfInstructionsChange);
          if (uc is IfThenInstructionView && ((IfThenInstructionView) uc).CodBlockInside != null)
            ((IfThenInstructionView) uc).CodBlockInside.numberOfInstructionsChange -= new CodeBlock.NumberOfInstructionsChanged(this.CodBlockInside_numberOfInstructionsChange);
          this.stackPanel.Children.RemoveAt(index1);
          List<ICodeElement> blockElements = this.instructionBlock.GetBlockElements();
          ICodeElement codeElement = ((IUCWithICodeElement) uc).GetCodeElement();
          for (int index2 = 0; index2 < blockElements.Count; ++index2)
          {
            if (blockElements[index2] == codeElement)
              blockElements.RemoveAt(index2);
          }
          if (this.numberOfInstructionsChange == null)
            break;
          this.numberOfInstructionsChange();
          break;
        }
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/codeelements/blockofcode/codeblock.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
        {
          this.addInstructionGrid = (Grid) target;
          this.addInstructionGrid.MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          this.addInstructionGrid.MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          this.addInstructionGrid.MouseUp += new MouseButtonEventHandler(this.Grid_MouseUp);
        }
        else
          this._contentLoaded = true;
      }
      else
        this.stackPanel = (StackPanel) target;
    }

    public delegate void NumberOfInstructionsChanged();
  }
}
