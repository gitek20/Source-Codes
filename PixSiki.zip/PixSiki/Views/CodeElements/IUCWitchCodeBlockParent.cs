﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.IUCWitchCodeBlockParent
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Views.CodeElements.BlockOfCode;

namespace PixBlocks.Views.CodeElements
{
  public interface IUCWitchCodeBlockParent
  {
    CodeBlock CodeBlockParent { get; set; }
  }
}
