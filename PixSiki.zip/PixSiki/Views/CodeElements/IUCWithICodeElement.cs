﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.IUCWithICodeElement
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;

namespace PixBlocks.Views.CodeElements
{
  public interface IUCWithICodeElement
  {
    ICodeElement GetCodeElement();

    void DisposeAll();
  }
}
