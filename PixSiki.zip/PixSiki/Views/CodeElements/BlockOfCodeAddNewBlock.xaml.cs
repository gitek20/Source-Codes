﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.BlockOfCode.AddNewBlock
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Views.DragDropController;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.CodeElements.BlockOfCode
{
  public partial class AddNewBlock : UserControl, IComponentConnector
  {
    private CodeBlock parentBlock;
    internal Rectangle dropRectangle;
    private bool _contentLoaded;

    public AddNewBlock(CodeBlock parentBlock)
    {
      this.parentBlock = parentBlock;
      this.InitializeComponent();
      this.dropRectangle.Visibility = Visibility.Hidden;
    }

    public void UserControl_MouseEnter(object sender, MouseEventArgs e)
    {
      this.dropRectangle.Visibility = Visibility.Hidden;
      if ((IUCWithICodeElement) StaticDragController.Instance.UcToDrag == null || !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().IsInstruction())
        return;
      this.dropRectangle.Visibility = Visibility.Visible;
      this.dropRectangle.Fill = (Brush) new SolidColorBrush(ConfigColors.DraggingColor);
    }

    public void UserControl_MouseLeave(object sender, MouseEventArgs e) => this.dropRectangle.Visibility = Visibility.Hidden;

    public void UserControl_MouseUp(object sender, MouseButtonEventArgs e)
    {
      this.dropRectangle.Visibility = Visibility.Hidden;
      if (StaticDragController.Instance.GetDraggingType == StaticDragController.DraggingType.None || (IUCWithICodeElement) StaticDragController.Instance.UcToDrag == null || !((IUCWithICodeElement) StaticDragController.Instance.UcToDrag).GetCodeElement().IsInstruction())
        return;
      this.parentBlock.AddUserControlBefore(StaticDragController.Instance.UcToDrag, (UserControl) this);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/codeelements/blockofcode/addnewblock.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.dropRectangle = (Rectangle) target;
        else
          this._contentLoaded = true;
      }
      else
      {
        ((UIElement) target).MouseEnter += new MouseEventHandler(this.UserControl_MouseEnter);
        ((UIElement) target).MouseLeave += new MouseEventHandler(this.UserControl_MouseLeave);
        ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.UserControl_MouseUp);
      }
    }
  }
}
