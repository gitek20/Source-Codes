﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CodeElements.BlockOfCode.DroppingGridView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner;
using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.CodeParser;
using PixBlocks.UserMenagment.StaticEditedCodeMenager;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.Views.CodeElements.BlockOfCode.images;
using PixBlocks.Views.CongratulationsView;
using PixBlocks.Views.DragDropController;
using PixBlocks.Views.HelpView;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;

namespace PixBlocks.Views.CodeElements.BlockOfCode
{
  public partial class DroppingGridView : UserControl, IComponentConnector
  {
    private RepeatNTimes rootCodeElement;
    private RepeatNTimes rootCodePattern;
    private CodeBlock cb;
    private Question question;
    private DispatcherTimer timerAutoScroller;
    private MainWindowMessageBox messageBox;
    private int linesOfCodeInPattern = int.MaxValue;
    private int myScore;
    private Point clickPoint = new Point(-100.0, -100.0);
    private double svVerticalOffset;
    private double svHorizontalOffset;
    private bool clickMakeStop;
    internal Grid mainGrid;
    internal Grid BottonGrid;
    internal TextBlock textBlock;
    internal TextBlock textBotton;
    internal Image image;
    internal Image blue1;
    internal Image gray1;
    internal Image redStar;
    internal StackPanel buttonLook;
    internal Grid tooManyInstructionMessageGrid;
    internal ScrollViewer mainScroll;
    internal Grid backColor;
    internal Grid elementsGrid;
    internal Grid freezGrid;
    private bool _contentLoaded;

    public DroppingGridView(
      RepeatNTimes rootCodeElement,
      RepeatNTimes rootCodePattern,
      Question question)
    {
      this.question = question;
      this.InitializeComponent();
      this.rootCodeElement = rootCodeElement;
      this.rootCodePattern = rootCodePattern;
      int num = -1;
      if (rootCodePattern != null)
      {
        foreach (ICodeElement innerCodeElement in rootCodePattern.InnerCodeElements())
        {
          if (innerCodeElement.IsInstruction())
            ++num;
        }
      }
      if (question == null || question.QuestionType == QuestionType.ClassicQuestionType)
      {
        this.linesOfCodeInPattern = num;
        if (UserMenager.UserIsSuperAdmin())
          this.linesOfCodeInPattern = 100;
      }
      this.textBotton.Text = num == -1 ? "" : "(" + num.ToString() + ")";
      if (question != null)
        this.ShowScore(QuestionsPointsCounter.GetQuestionPoints(question));
      else
        this.ShowScore(0);
      this.cb = new CodeBlock((ICodeInstructionBlock) rootCodeElement, true);
      this.cb.numberOfInstructionsChange += new CodeBlock.NumberOfInstructionsChanged(this.Cb_numberOfInstructionsChange);
      this.elementsGrid.Children.Add((UIElement) this.cb);
      this.ShowNumberOfCodesLines();
      if (question != null && question.QuestionType != QuestionType.ClassicQuestionType)
      {
        this.blue1.Visibility = Visibility.Collapsed;
        this.gray1.Visibility = Visibility.Collapsed;
        this.redStar.Visibility = Visibility.Collapsed;
        if (question.QuestionType != QuestionType.FreeCodeType)
          this.SetFreez(true);
        else
          this.SetFreez(false);
      }
      else
        this.SetFreez(false);
      if (!question.ExamID.HasValue && UserMenager.UserCanSeeSolutions() && (question != null && question.QuestionType == QuestionType.ClassicQuestionType))
      {
        CircleButton circleButton1 = new CircleButton((UserControl) new ShowSolutionIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
        this.buttonLook.Children.Add((UIElement) circleButton1);
        circleButton1.buttonClickedEvent += new CircleButton.ButtonClicker(this.LookButton_buttonClickedEvent);
        if (!UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Teacher_isTeacher)
        {
          CircleButton circleButton2 = new CircleButton((UserControl) new TrashIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
          this.buttonLook.Children.Add((UIElement) circleButton2);
          circleButton2.buttonClickedEvent += new CircleButton.ButtonClicker(this.DeleteCode_buttonClickedEvent);
        }
      }
      this.timerAutoScroller = new DispatcherTimer();
      this.timerAutoScroller.Interval = new TimeSpan(0, 0, 0, 0, 10);
      this.timerAutoScroller.Tick += new EventHandler(this.TimerAutoScroller_Tick);
      this.timerAutoScroller.Start();
    }

    private void TimerAutoScroller_Tick(object sender, EventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType == StaticDragController.DraggingType.None)
        return;
      Point position = Mouse.GetPosition((IInputElement) this.mainScroll);
      if (position.Y > 9.0 * this.mainScroll.ActualHeight / 10.0)
        this.mainScroll.ScrollToVerticalOffset(this.mainScroll.VerticalOffset + (position.Y - 9.0 * this.mainScroll.ActualHeight / 10.0) / (this.mainScroll.ActualHeight / 10.0) * 7.0);
      if (position.Y >= this.mainScroll.ActualHeight / 10.0)
        return;
      this.mainScroll.ScrollToVerticalOffset(this.mainScroll.VerticalOffset - (this.mainScroll.ActualHeight / 10.0 - position.Y) / (this.mainScroll.ActualHeight / 10.0) * 7.0);
    }

    private void DeleteCode_buttonClickedEvent()
    {
      this.rootCodeElement.GetBlockElements().Clear();
      this.cb = (CodeBlock) null;
      this.cb = new CodeBlock((ICodeInstructionBlock) this.rootCodeElement, true);
      this.cb.numberOfInstructionsChange += new CodeBlock.NumberOfInstructionsChanged(this.Cb_numberOfInstructionsChange);
      this.elementsGrid.Children.Clear();
      this.elementsGrid.Children.Add((UIElement) this.cb);
      this.ShowNumberOfCodesLines();
    }

    private void LookButton_buttonClickedEvent()
    {
      if (!UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Teacher_isTeacher)
        this.Accept_buttonClickedEvent();
      else if (QuestionsPointsCounter.GetQuestionPoints(this.question) == 0)
      {
        this.messageBox = new MainWindowMessageBox();
        MainWindowStaticController.mainWindow.mainGrid.Children.Add((UIElement) this.messageBox);
        this.messageBox.accept.buttonClickedEvent += new CircleButton.ButtonClicker(this.Accept_buttonClickedEvent);
        this.messageBox.close.buttonClickedEvent += new CircleButton.ButtonClicker(this.Close_buttonClickedEvent);
      }
      else
        this.Accept_buttonClickedEvent();
    }

    private void Close_buttonClickedEvent() => MainWindowStaticController.mainWindow.mainGrid.Children.Remove((UIElement) this.messageBox);

    private void Accept_buttonClickedEvent()
    {
      if (MainWindowStaticController.mainWindow.mainGrid.Children.Contains((UIElement) this.messageBox))
        MainWindowStaticController.mainWindow.mainGrid.Children.Remove((UIElement) this.messageBox);
      if (!UserMenager.IsOffLineUser && CurrentUserInfo.CurrentUser.Teacher_isTeacher)
      {
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) <= 0)
        {
          QuestionsPointsCounter.SetQuestionPoints(this.question, 1);
          this.blue1.Visibility = Visibility.Visible;
          this.gray1.Visibility = Visibility.Collapsed;
          this.redStar.Visibility = Visibility.Collapsed;
        }
      }
      else
      {
        CongratulationsStaticManager.GreesStarShow = false;
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) <= 0)
        {
          QuestionsPointsCounter.SetQuestionPoints(this.question, -1);
          this.blue1.Visibility = Visibility.Collapsed;
          this.gray1.Visibility = Visibility.Collapsed;
          this.redStar.Visibility = Visibility.Visible;
        }
      }
      CongratulationsStaticManager.ShowCongratulations();
      RepeatNTimes modelFromCode = CodeStringParser.GenerateModelFromCode(this.question.Code);
      this.rootCodeElement.NumberOfIteration = modelFromCode.NumberOfIteration;
      this.rootCodeElement.GetBlockElements().Clear();
      foreach (ICodeElement blockElement in modelFromCode.GetBlockElements())
      {
        if (blockElement is AssigmentInstruction)
        {
          if ((blockElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.BreakAll)
            break;
        }
        this.rootCodeElement.GetBlockElements().Add(blockElement);
        blockElement.SetParent((ICodeElement) this.rootCodeElement);
      }
      this.cb = (CodeBlock) null;
      this.cb = new CodeBlock((ICodeInstructionBlock) this.rootCodeElement, true);
      this.cb.numberOfInstructionsChange += new CodeBlock.NumberOfInstructionsChanged(this.Cb_numberOfInstructionsChange);
      this.elementsGrid.Children.Clear();
      this.elementsGrid.Children.Add((UIElement) this.cb);
      this.ShowNumberOfCodesLines();
    }

    public void SetFreez(bool isFreez)
    {
      if (isFreez)
      {
        this.backColor.Background = (Brush) new SolidColorBrush(Color.FromRgb((byte) 251, (byte) 251, (byte) 251));
        this.tooManyInstructionMessageGrid.Visibility = Visibility.Collapsed;
        this.freezGrid.Visibility = Visibility.Visible;
        this.buttonLook.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.buttonLook.Visibility = Visibility.Visible;
        if (this.textBlock.FontWeight == FontWeights.Bold)
        {
          this.backColor.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 230, (byte) 200));
          this.tooManyInstructionMessageGrid.Visibility = Visibility.Visible;
        }
        else
        {
          this.backColor.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));
          this.tooManyInstructionMessageGrid.Visibility = Visibility.Collapsed;
        }
        this.freezGrid.Visibility = Visibility.Hidden;
      }
    }

    public event DroppingGridView.NumberOfCodeLinesChanged numberOfCodeLinesChangedEvent;

    public void ShowNumberOfCodesLines()
    {
      int numberOfCodeLines = -1;
      foreach (ICodeElement innerCodeElement in this.rootCodeElement.InnerCodeElements())
      {
        if (innerCodeElement.IsInstruction())
          ++numberOfCodeLines;
      }
      this.textBlock.Text = numberOfCodeLines.ToString() ?? "";
      if (this.numberOfCodeLinesChangedEvent != null)
      {
        if (numberOfCodeLines > this.linesOfCodeInPattern)
          this.numberOfCodeLinesChangedEvent(0);
        else
          this.numberOfCodeLinesChangedEvent(numberOfCodeLines);
      }
      if (numberOfCodeLines > this.linesOfCodeInPattern)
      {
        if (this.linesOfCodeInPattern < 0)
          return;
        this.backColor.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 230, (byte) 200));
        this.tooManyInstructionMessageGrid.Visibility = Visibility.Visible;
        this.textBlock.FontWeight = FontWeights.Bold;
        this.textBlock.Foreground = (Brush) new SolidColorBrush(Colors.OrangeRed);
      }
      else
      {
        if (this.myScore > 0)
        {
          this.backColor.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));
          this.tooManyInstructionMessageGrid.Visibility = Visibility.Collapsed;
        }
        else
        {
          this.backColor.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));
          this.tooManyInstructionMessageGrid.Visibility = Visibility.Collapsed;
        }
        this.textBlock.FontWeight = FontWeights.Normal;
        this.textBlock.Foreground = (Brush) new SolidColorBrush(Colors.Black);
      }
    }

    private void Cb_numberOfInstructionsChange()
    {
      if (QuestionsPointsCounter.GetQuestionPoints(this.question) >= 0 && this.question != null)
      {
        int questionType = (int) this.question.QuestionType;
      }
      this.ShowNumberOfCodesLines();
    }

    internal void DisposeAllElements()
    {
      if (this.timerAutoScroller != null)
      {
        this.timerAutoScroller.Tick -= new EventHandler(this.TimerAutoScroller_Tick);
        this.timerAutoScroller.Stop();
        this.timerAutoScroller = (DispatcherTimer) null;
      }
      if (this.question != null && this.question.QuestionType != QuestionType.InfoType)
        QuestionsCodesManager.AddCode(this.question, this.rootCodeElement);
      if (this.question != null)
      {
        int num = this.question.CanEditBitmap ? 1 : 0;
      }
      if (this.cb != null)
      {
        this.cb.DisposeAllElements();
        this.cb.numberOfInstructionsChange -= new CodeBlock.NumberOfInstructionsChanged(this.Cb_numberOfInstructionsChange);
      }
      this.elementsGrid.Children.Remove((UIElement) this.cb);
      this.cb = (CodeBlock) null;
      this.rootCodeElement = (RepeatNTimes) null;
      this.rootCodePattern = (RepeatNTimes) null;
    }

    public void ShowScore(int score)
    {
      this.myScore = score;
      if (this.question != null && this.question.QuestionType == QuestionType.FreeCodeType)
        return;
      if (score == 0)
      {
        if (this.textBlock.FontWeight == FontWeights.Bold)
        {
          this.backColor.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 230, (byte) 200));
          this.tooManyInstructionMessageGrid.Visibility = Visibility.Visible;
        }
        else
        {
          this.backColor.Background = (Brush) new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));
          this.tooManyInstructionMessageGrid.Visibility = Visibility.Collapsed;
        }
        this.blue1.Visibility = Visibility.Collapsed;
        this.redStar.Visibility = Visibility.Collapsed;
        this.gray1.Visibility = Visibility.Visible;
      }
      if (score >= 1)
      {
        this.blue1.Visibility = Visibility.Visible;
        this.redStar.Visibility = Visibility.Collapsed;
        this.gray1.Visibility = Visibility.Collapsed;
      }
      if (score >= 0)
        return;
      this.blue1.Visibility = Visibility.Collapsed;
      this.redStar.Visibility = Visibility.Visible;
      this.gray1.Visibility = Visibility.Collapsed;
    }

    internal void ShowMatchStatus(CodeRunningResult matchStatus)
    {
      if (!matchStatus.CodesMatch)
      {
        this.SetFreez(true);
      }
      else
      {
        int num = 1;
        CongratulationsStaticManager.GreesStarShow = true;
        if (QuestionsPointsCounter.GetQuestionPoints(this.question) < 0)
        {
          CongratulationsStaticManager.GreesStarShow = false;
          num = -1;
        }
        this.ShowScore(num);
        if (this.question != null && this.question.QuestionType == QuestionType.ClassicQuestionType)
          QuestionsPointsCounter.SetQuestionPoints(this.question, num);
        CongratulationsStaticManager.ShowCongratulations();
      }
    }

    private void elementsGrid_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
      if (StaticDragController.Instance.UcToDrag == null || this.question == null)
        return;
      int questionType = (int) this.question.QuestionType;
    }

    private void Grid_MouseMove(object sender, MouseEventArgs e)
    {
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      Point position = e.GetPosition((IInputElement) this);
      if (this.clickPoint.Y == -100.0)
        return;
      this.mainScroll.ScrollToVerticalOffset(this.svVerticalOffset - position.Y + this.clickPoint.Y);
      this.mainScroll.ScrollToHorizontalOffset(this.svHorizontalOffset - position.X + this.clickPoint.X);
    }

    public bool ClickMakeStop
    {
      get => this.clickMakeStop;
      set => this.clickMakeStop = value;
    }

    public event DroppingGridView.MakeStopByClick makeStopByClickEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.clickMakeStop && this.makeStopByClickEvent != null)
        this.makeStopByClickEvent();
      this.svVerticalOffset = this.mainScroll.VerticalOffset;
      this.svHorizontalOffset = this.mainScroll.HorizontalOffset;
      if (StaticDragController.Instance.GetDraggingType != StaticDragController.DraggingType.None)
        return;
      this.clickPoint = e.GetPosition((IInputElement) this);
    }

    private void Grid_MouseUp(object sender, MouseButtonEventArgs e) => this.clickPoint = new Point(-100.0, -100.0);

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.clickPoint = new Point(-100.0, -100.0);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/codeelements/blockofcode/droppinggridview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.BottonGrid = (Grid) target;
          break;
        case 3:
          this.textBlock = (TextBlock) target;
          break;
        case 4:
          this.textBotton = (TextBlock) target;
          break;
        case 5:
          this.image = (Image) target;
          break;
        case 6:
          this.blue1 = (Image) target;
          break;
        case 7:
          this.gray1 = (Image) target;
          break;
        case 8:
          this.redStar = (Image) target;
          break;
        case 9:
          this.buttonLook = (StackPanel) target;
          break;
        case 10:
          this.tooManyInstructionMessageGrid = (Grid) target;
          break;
        case 11:
          this.mainScroll = (ScrollViewer) target;
          break;
        case 12:
          this.backColor = (Grid) target;
          this.backColor.PreviewMouseUp += new MouseButtonEventHandler(this.elementsGrid_PreviewMouseUp);
          this.backColor.MouseMove += new MouseEventHandler(this.Grid_MouseMove);
          this.backColor.MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          this.backColor.MouseUp += new MouseButtonEventHandler(this.Grid_MouseUp);
          this.backColor.MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          break;
        case 13:
          this.elementsGrid = (Grid) target;
          this.elementsGrid.PreviewMouseUp += new MouseButtonEventHandler(this.elementsGrid_PreviewMouseUp);
          this.elementsGrid.MouseMove += new MouseEventHandler(this.Grid_MouseMove);
          this.elementsGrid.MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          this.elementsGrid.MouseUp += new MouseButtonEventHandler(this.Grid_MouseUp);
          this.elementsGrid.MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          break;
        case 14:
          this.freezGrid = (Grid) target;
          this.freezGrid.PreviewMouseUp += new MouseButtonEventHandler(this.elementsGrid_PreviewMouseUp);
          this.freezGrid.MouseMove += new MouseEventHandler(this.Grid_MouseMove);
          this.freezGrid.MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          this.freezGrid.MouseUp += new MouseButtonEventHandler(this.Grid_MouseUp);
          this.freezGrid.MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void NumberOfCodeLinesChanged(int numberOfCodeLines);

    public delegate void MakeStopByClick();
  }
}
