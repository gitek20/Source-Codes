﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.HelpView.MainWindowHelpView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Views.ImageProcessingView;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.Views.HelpView
{
  public partial class MainWindowHelpView : UserControl, IComponentConnector
  {
    private QuestionCategory currentCategory;
    private Question currentQuestion;
    private ImageProcView imageProcess;
    private MainWindow mainWindow;
    private bool programaticallyEnded;
    internal Grid mainGrid;
    internal Image image;
    internal Grid mediaGrid;
    internal TextBlock content;
    private bool _contentLoaded;

    public MainWindowHelpView(MainWindow mainWindow)
    {
      this.InitializeComponent();
      this.mainWindow = mainWindow;
    }

    public void ShowDescription(
      Question currentQuestion,
      QuestionCategory currentCategory,
      ImageProcView imageProcess)
    {
      this.currentQuestion = currentQuestion;
      this.currentCategory = currentCategory;
      this.imageProcess = imageProcess;
      string str1 = (string) null;
      this.mediaGrid.Visibility = Visibility.Collapsed;
      this.content.MinWidth = 0.0;
      this.content.MaxWidth = 940.0;
      string input = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateQuestionID(currentQuestion.QuestionGuid());
      if (currentQuestion != null)
      {
        string str2 = ((IEnumerable<string>) input.Split(" "[0])).First<string>();
        if (str2.Contains("http"))
          str1 = str2;
      }
      if (currentQuestion != null)
      {
        if (str1 != null)
          input = input.Replace(str1 + " ", "");
        this.TransformToBoldedText(input);
      }
      if ((input == null || input.Length < 2) && currentQuestion.ExamID.HasValue)
        this.TransformToBoldedText(currentQuestion.Description);
      if (UserMenager.UserIsSuperAdmin())
        this.TransformToBoldedText(currentQuestion.Description + " (superADMIN)");
      if (input != null && input.Length >= 2 || (currentQuestion.ExamID.HasValue || !CurrentUserInfo.CurrentUser.Admin_isAdmin))
        return;
      this.TransformToBoldedText(currentQuestion.Description + " (AD)");
    }

    public void TransformToBoldedText(string input)
    {
      if (input != null && input.Length > 2 && (!this.currentQuestion.IsPremiumQuestion || !this.currentQuestion.IsIronPython || UserMenager.IsCurrentUserPremiumPython()) && (!this.currentQuestion.IsPremiumQuestion || this.currentQuestion.IsIronPython || UserMenager.IsCurrentUserPremiumBlocks()))
      {
        this.Visibility = Visibility.Visible;
        if (input == null)
          return;
        this.content.Text = "";
        this.content.Inlines.Clear();
        string[] strArray = input.Split("$"[0]);
        for (int index = 0; index < strArray.Length; ++index)
        {
          if (index % 2 == 0)
          {
            this.content.Inlines.Add(strArray[index]);
          }
          else
          {
            InlineCollection inlines = this.content.Inlines;
            Run run = new Run(strArray[index].TrimStart(" "[0]).TrimEnd(" "[0]));
            run.FontWeight = FontWeights.Bold;
            run.FontFamily = new FontFamily("Consolas");
            inlines.Add((Inline) run);
          }
        }
      }
      else
        this.Visibility = Visibility.Collapsed;
    }

    public void ShowDescription(string text)
    {
      this.content.Text = text;
      this.Visibility = Visibility.Visible;
    }

    public event MainWindowHelpView.HelpClose helpCloseEvent;

    private void mainGrid_MouseDown(object sender, MouseButtonEventArgs e) => this.Visibility = Visibility.Collapsed;

    public void HideHelpView()
    {
      this.Visibility = Visibility.Collapsed;
      this.programaticallyEnded = true;
    }

    private void mediaElement_MediaOpened(object sender, RoutedEventArgs e)
    {
      this.mediaGrid.Visibility = Visibility.Visible;
      this.mediaGrid.MaxHeight = this.mainWindow.mainGrid.Height / 1.6;
      this.mediaGrid.MinHeight = this.mainWindow.mainGrid.Height / 1.6;
      this.content.MinWidth = 0.0;
      this.content.MaxWidth = 16.0 * this.mediaGrid.MinHeight / 9.0 - 60.0;
    }

    private void mediaElement_MediaEnded(object sender, RoutedEventArgs e)
    {
      int num = this.programaticallyEnded ? 1 : 0;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/helpview/mainwindowhelpview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          break;
        case 3:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          break;
        case 4:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          break;
        case 5:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          break;
        case 6:
          this.image = (Image) target;
          break;
        case 7:
          this.mediaGrid = (Grid) target;
          break;
        case 8:
          this.content = (TextBlock) target;
          this.content.MouseDown += new MouseButtonEventHandler(this.mainGrid_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void HelpClose();
  }
}
