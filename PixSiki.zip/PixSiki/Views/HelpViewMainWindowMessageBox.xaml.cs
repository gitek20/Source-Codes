﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.HelpView.MainWindowMessageBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.Views.HelpView
{
  public partial class MainWindowMessageBox : UserControl, IComponentConnector
  {
    public CircleButton close;
    public CircleButton accept;
    internal TextBlock info;
    internal StackPanel StackForButton;
    private bool _contentLoaded;

    public MainWindowMessageBox()
    {
      this.InitializeComponent();
      this.info.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("sureLook");
      this.close = new CircleButton((UserControl) new CancelWhite(), Colors.Red, CircleButton.VisualParam.longwidth);
      this.close.Margin = new Thickness(0.0, 0.0, 50.0, 0.0);
      this.accept = new CircleButton((UserControl) new OKIconWhite(), Colors.Green, CircleButton.VisualParam.longwidth);
      this.StackForButton.Children.Add((UIElement) this.close);
      this.StackForButton.Children.Add((UIElement) this.accept);
    }

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e) => this.close.ProgramaticlyClick();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/helpview/mainwindowmessagebox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 2:
          this.info = (TextBlock) target;
          break;
        case 3:
          this.StackForButton = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
