﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.PaymentView.PaymentView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.PreferencesPanel.Models;
using PixBlocks.TopPanel.PreferencesPanel.Views;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace PixBlocks.Views.PaymentView
{
  public partial class PaymentView : UserControl, IPreferencePanelController, IComponentConnector
  {
    internal Grid LicenceKeyPanelGrid;
    internal StackPanel mainStack;
    internal Label unlockPremiumAccount;
    internal Label buyFullAccesLabel;
    internal ButtonLink linkToPixStore;
    internal RoundedButton buyFullAcces;
    internal Label haveYouShoppedKey;
    internal RoundedButton activateLicenceKey;
    internal TextBlock teacherPromotionInfo;
    private bool _contentLoaded;

    public PaymentView()
    {
      this.InitializeComponent();
      UserMenager.languageKeyChangedEvet += new UserMenager.LanguageKeyChangedEvet(this.UserMenager_languageKeyChangedEvet);
      UserMenager.userDataChangedEvent += new UserMenager.UserDataChangedEvent(this.UserMenager_languageKeyChangedEvet);
      this.UserMenager_languageKeyChangedEvet();
      this.linkToPixStore.clickEvent += new ButtonLink.ClickDelegate(this.LinkToPixStore_clickEvent);
      this.buyFullAcces.clickEvent += new RoundedButton.ClickDelegate(this.LinkToPixStore_clickEvent);
      this.activateLicenceKey.clickEvent += new RoundedButton.ClickDelegate(this.ActivateLicenceKey_clickEvent);
      this.linkToPixStore.buttonText.FontSize = 23.0;
    }

    private void UserMenager_languageKeyChangedEvet()
    {
      if (UserMenager.IsOffLineUser)
      {
        this.unlockPremiumAccount.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("offlineContent");
        this.teacherPromotionInfo.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("goToOnlineContent");
        this.buyFullAccesLabel.Visibility = Visibility.Collapsed;
        this.linkToPixStore.Visibility = Visibility.Collapsed;
        this.buyFullAcces.Visibility = Visibility.Collapsed;
        this.haveYouShoppedKey.Visibility = Visibility.Collapsed;
        this.activateLicenceKey.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.buyFullAccesLabel.Visibility = Visibility.Visible;
        this.linkToPixStore.Visibility = Visibility.Visible;
        this.buyFullAcces.Visibility = Visibility.Visible;
        this.haveYouShoppedKey.Visibility = Visibility.Visible;
        this.activateLicenceKey.Visibility = Visibility.Visible;
        this.unlockPremiumAccount.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("unlockPremiumAccount");
        this.teacherPromotionInfo.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("askForFreeAccesForTeacher");
        this.buyFullAccesLabel.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("buyFullAccesAt");
        this.linkToPixStore.Description = "www.pixblocks-store.com";
        this.buyFullAcces.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("buyLecenceKey");
        this.haveYouShoppedKey.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("haveYouBuyedLecenceKey");
        this.activateLicenceKey.Description = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("acctivateKey");
      }
    }

    private void ActivateLicenceKey_clickEvent()
    {
      LicenseKeyPanelView licenseKeyPanelView = new LicenseKeyPanelView((IPreferencePanelController) this);
      this.mainStack.Visibility = Visibility.Collapsed;
      this.LicenceKeyPanelGrid.Children.Clear();
      this.LicenceKeyPanelGrid.Children.Add((UIElement) licenseKeyPanelView);
    }

    private void LinkToPixStore_clickEvent() => Process.Start("https:\\www.pixblocks-store.com");

    private void freeApplyForPublicTeachers_Loaded(object sender, RoutedEventArgs e)
    {
    }

    private void activateLicenceKey_Loaded(object sender, RoutedEventArgs e)
    {
    }

    public void ShowProfileEditPanel() => throw new NotImplementedException();

    public void ShowStartPreferencePanel()
    {
      this.mainStack.Visibility = Visibility.Visible;
      this.LicenceKeyPanelGrid.Children.Clear();
    }

    public void ShowPasswordEditPanel() => throw new NotImplementedException();

    public void ShowAssignToClassPanel() => throw new NotImplementedException();

    public void ShowUnassignFromClassPanel() => throw new NotImplementedException();

    public void ShowSetEmailPanel() => throw new NotImplementedException();

    public void ShowEnterPinPanel(string email) => throw new NotImplementedException();

    public void ShowRemoveAccountPanel() => throw new NotImplementedException();

    public void ShowRemoveAccountInfo() => throw new NotImplementedException();

    public void ShowBecomeTeacherPanel() => throw new NotImplementedException();

    public void ShowPasswordChangedInfo() => throw new NotImplementedException();

    public void ShowBecomeTeacherInfo() => throw new NotImplementedException();

    public void ShowImportFromOfflineProfile() => throw new NotImplementedException();

    public void ShowUnassignFromClassInfo() => throw new NotImplementedException();

    public void ShowEditSchool(School school) => throw new NotImplementedException();

    public void ShowEnterLicenseKeyPanel() => throw new NotImplementedException();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/paymentview/paymentview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.LicenceKeyPanelGrid = (Grid) target;
          break;
        case 2:
          this.mainStack = (StackPanel) target;
          break;
        case 3:
          this.unlockPremiumAccount = (Label) target;
          break;
        case 4:
          this.buyFullAccesLabel = (Label) target;
          break;
        case 5:
          this.linkToPixStore = (ButtonLink) target;
          break;
        case 6:
          this.buyFullAcces = (RoundedButton) target;
          break;
        case 7:
          this.haveYouShoppedKey = (Label) target;
          break;
        case 8:
          this.activateLicenceKey = (RoundedButton) target;
          break;
        case 9:
          this.teacherPromotionInfo = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
