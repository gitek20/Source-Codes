﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.AdditionalBrandingView.AdditionalBrandingManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Windows.Controls;

namespace PixBlocks.Views.AdditionalBrandingView
{
  internal class AdditionalBrandingManager
  {
    private static string currentImage;

    public static UserControl GetBranding() => (UserControl) new AdditionalBrading();

    public static event AdditionalBrandingManager.imageChange imageWasChangedEvent;

    public static string CurrentImage => AdditionalBrandingManager.currentImage;

    public static void SetNewPartnerImage(string imageInBase64)
    {
      AdditionalBrandingManager.currentImage = imageInBase64;
      AdditionalBrandingManager.imageChange imageWasChangedEvent = AdditionalBrandingManager.imageWasChangedEvent;
      if (imageWasChangedEvent == null)
        return;
      imageWasChangedEvent();
    }

    internal delegate void imageChange();
  }
}
