﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.CongratulationsView.CongratulationsStaticManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.Views.CongratulationsView
{
  internal class CongratulationsStaticManager
  {
    public static bool GreesStarShow = true;

    public static event CongratulationsStaticManager.CongratilationViewStatusChanged congratilationViewStatusChangedEvent;

    public static void ShowCongratulations()
    {
      if (CongratulationsStaticManager.congratilationViewStatusChangedEvent == null)
        return;
      CongratulationsStaticManager.congratilationViewStatusChangedEvent(CongratulationsStaticManager.CongratulationsStatus.started);
    }

    public static void HideCongratulations()
    {
      if (CongratulationsStaticManager.congratilationViewStatusChangedEvent == null)
        return;
      CongratulationsStaticManager.congratilationViewStatusChangedEvent(CongratulationsStaticManager.CongratulationsStatus.ended);
    }

    public enum CongratulationsStatus
    {
      started,
      ended,
    }

    public delegate void CongratilationViewStatusChanged(
      CongratulationsStaticManager.CongratulationsStatus statuc);
  }
}
