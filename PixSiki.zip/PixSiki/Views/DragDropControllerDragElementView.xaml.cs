﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.DragDropController.DragElementView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.Tools;
using PixBlocks.Views.CodeElements;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.DragDropController
{
  public partial class DragElementView : UserControl, IComponentConnector
  {
    private static DragElementView instance;
    private bool removeElement;
    internal Grid mainGrid;
    internal Rectangle deleteRectagle;
    internal Image image;
    private bool _contentLoaded;

    public static DragElementView Instance
    {
      get
      {
        if (DragElementView.instance == null)
          DragElementView.instance = new DragElementView();
        return DragElementView.instance;
      }
    }

    public bool RemoveElement
    {
      get => this.removeElement;
      set
      {
        if (value)
          this.deleteRectagle.Visibility = Visibility.Visible;
        else
          this.deleteRectagle.Visibility = Visibility.Hidden;
        this.removeElement = value;
      }
    }

    private DragElementView()
    {
      this.InitializeComponent();
      StaticDragController.Instance.dragingTypeChanged += new StaticDragController.DragingTypeChanged(this.Instance_dragingTypeChanged);
      this.Visibility = Visibility.Hidden;
    }

    public event DragElementView.DragingChanged dragChangedEvent;

    private void Instance_dragingTypeChanged(StaticDragController.DraggingType draggingType)
    {
      if (draggingType != StaticDragController.DraggingType.None)
      {
        this.Visibility = Visibility.Visible;
        this.image.Source = (ImageSource) UserControlToBitmapRenderer.GetImage(StaticDragController.Instance.UcToDrag);
        ICodeElement codeElement = (StaticDragController.Instance.UcToDrag as IUCWithICodeElement).GetCodeElement();
        int num = 0;
        switch (codeElement)
        {
          case RepeatNTimes _:
          case IfThenInstruction _:
            if (!codeElement.GetIsTemplateElement())
            {
              num = 30;
              break;
            }
            break;
        }
        this.image.MinWidth = StaticDragController.Instance.UcToDrag.ActualWidth + 6.0;
        this.image.MinHeight = StaticDragController.Instance.UcToDrag.ActualHeight + 6.0 + (double) num;
        this.image.MaxWidth = StaticDragController.Instance.UcToDrag.ActualWidth + 6.0;
        this.image.MaxHeight = StaticDragController.Instance.UcToDrag.ActualHeight + 6.0 + (double) num;
        this.image.Margin = new Thickness(0.0, 0.0, 0.0, (double) (-num - 3));
      }
      else
        this.Visibility = Visibility.Hidden;
      if (this.dragChangedEvent == null)
        return;
      this.dragChangedEvent();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/dragdropcontroller/dragelementview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.mainGrid = (Grid) target;
          break;
        case 2:
          this.deleteRectagle = (Rectangle) target;
          break;
        case 3:
          this.image = (Image) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void DragingChanged();
  }
}
