﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.SelectionComboBox.TestWindow
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.Views.QuestionsView.SelectionComboBox
{
  public partial class TestWindow : Window, IComponentConnector
  {
    internal ExtendedComboBox extendedComboBox;
    private bool _contentLoaded;

    public TestWindow() => this.InitializeComponent();

    private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e) => this.extendedComboBox.CollapseComboBox();

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/selectioncombobox/testwindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler) => Delegate.CreateDelegate(delegateType, (object) this, handler);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.extendedComboBox = (ExtendedComboBox) target;
        else
          this._contentLoaded = true;
      }
      else
        ((UIElement) target).PreviewMouseDown += new MouseButtonEventHandler(this.Grid_PreviewMouseDown);
    }
  }
}
