﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.SelectionComboBox.ExtendedComboBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.UserMenagment.ToyShopMenager;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace PixBlocks.Views.QuestionsView.SelectionComboBox
{
  public partial class ExtendedComboBox : UserControl, IComponentConnector
  {
    private bool isClicked;
    private bool isEntered;
    internal Rectangle shadow;
    internal Rectangle HighlightRect;
    internal Image boy;
    internal Image man;
    internal Image womain;
    internal Image girl;
    internal Image boy1;
    internal Image man1;
    internal Image womain1;
    internal Image girl1;
    internal Image boy2;
    internal Image man2;
    internal Image womain2;
    internal Image girl2;
    internal Image boy3;
    internal Image man3;
    internal Image womain3;
    internal Image girl3;
    internal TextBlock UserNameLabel;
    internal Label offlineAlert;
    internal Label NumberOfPointsTextBox;
    internal Grid spaceGrid;
    internal Label NumberOfAllPoints;
    internal PixBlocks.Views.QuestionsView.SelectionComboBox.SelectionComboBox SelectionComboBox;
    private bool _contentLoaded;

    public ExtendedComboBox()
    {
      this.InitializeComponent();
      this.SelectionComboBox.selectedItemeEvent += new SimpleComboBoxItem.SelectedItem(this.SelectionComboBox_selectedItemeEvent);
      this.SelectionComboBox_selectedItemeEvent(SimpleComboBoxItem.ActionType.lessonsView);
      this.SelectionComboBox.Visibility = Visibility.Collapsed;
      QuestionsPointsCounter.questionPointsModifyEvent += new QuestionsPointsCounter.QuestionPointsModify(this.QuestionsPointsCounter_questionPointsModifyEvent);
      this.QuestionsPointsCounter_questionPointsModifyEvent((QuestionPoint) null);
      UserMenager.userDataChangedEvent += new UserMenager.UserDataChangedEvent(this.UserMenager_userDataChangedEvent);
      this.UserMenager_userDataChangedEvent();
    }

    public void UserMenager_userDataChangedEvent()
    {
      this.UserName = UserMenager.GetCurrentUserName();
      this.girl.Visibility = Visibility.Collapsed;
      this.boy.Visibility = Visibility.Collapsed;
      this.man.Visibility = Visibility.Collapsed;
      this.womain.Visibility = Visibility.Collapsed;
      this.girl1.Visibility = Visibility.Collapsed;
      this.boy1.Visibility = Visibility.Collapsed;
      this.man1.Visibility = Visibility.Collapsed;
      this.womain1.Visibility = Visibility.Collapsed;
      this.girl2.Visibility = Visibility.Collapsed;
      this.boy2.Visibility = Visibility.Collapsed;
      this.man2.Visibility = Visibility.Collapsed;
      this.womain2.Visibility = Visibility.Collapsed;
      this.girl3.Visibility = Visibility.Collapsed;
      this.boy3.Visibility = Visibility.Collapsed;
      this.man3.Visibility = Visibility.Collapsed;
      this.womain3.Visibility = Visibility.Collapsed;
      if (UserMenager.UserAgeType == UserAgeType.girl)
        this.girl.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.boy)
        this.boy.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.man)
        this.man.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.woman)
        this.womain.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.girl1)
        this.girl1.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.boy1)
        this.boy1.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.man1)
        this.man1.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.woman1)
        this.womain1.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.girl2)
        this.girl2.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.boy2)
        this.boy2.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.man2)
        this.man2.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.woman2)
        this.womain2.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.girl3)
        this.girl3.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.boy3)
        this.boy3.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.man3)
        this.man3.Visibility = Visibility.Visible;
      if (UserMenager.UserAgeType == UserAgeType.woman3)
        this.womain3.Visibility = Visibility.Visible;
      this.RefreshItemsVisibilities();
    }

    private void QuestionsPointsCounter_questionPointsModifyEvent(QuestionPoint questionPoint) => this.NumberOfPoints = QuestionsPointsCounter.GetPointsForCurrentUser() + StaticToyManager.ToysInfos.GetTotalMoneyInRoom() - 6;

    public void CollapseComboBox()
    {
      this.isClicked = false;
      if (!this.isEntered)
        this.HighlightRect.Opacity = 0.001;
      this.SelectionComboBox.Visibility = Visibility.Collapsed;
    }

    public event SimpleComboBoxItem.SelectedItem selectedItemeEvent;

    private void SelectionComboBox_selectedItemeEvent(SimpleComboBoxItem.ActionType actionType)
    {
      this.isClicked = false;
      this.HighlightRect.Opacity = 0.001;
      this.SelectionComboBox.Visibility = Visibility.Collapsed;
      if (this.selectedItemeEvent == null)
        return;
      this.selectedItemeEvent(actionType);
    }

    public string UserName
    {
      set => this.UserNameLabel.Text = value;
    }

    public int NumberOfPoints
    {
      set => this.NumberOfPointsTextBox.Content = (object) (value.ToString() ?? "");
    }

    public bool CanSeeTeacherPanel
    {
      set
      {
      }
    }

    public event ExtendedComboBox.ComboBoxClicked comboBoxClickedEvent;

    public void HighlightRect_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.comboBoxClickedEvent != null)
        this.comboBoxClickedEvent();
      this.isEntered = true;
      if (this.SelectionComboBox.Visibility == Visibility.Visible)
      {
        this.SelectionComboBox.Visibility = Visibility.Collapsed;
        this.isClicked = false;
      }
      else
      {
        this.SelectionComboBox.Visibility = Visibility.Visible;
        this.isClicked = true;
      }
    }

    private void HighlightRect_MouseEnter(object sender, MouseEventArgs e)
    {
      this.isEntered = true;
      if (this.isClicked)
        return;
      this.HighlightRect.Opacity = 0.2;
    }

    private void HighlightRect_MouseLeave(object sender, MouseEventArgs e)
    {
      this.isEntered = false;
      if (this.isClicked)
        return;
      this.HighlightRect.Opacity = 0.001;
    }

    internal void SelectFirstItem() => this.SelectionComboBox.SelectFirstItem();

    internal void RefreshItemsVisibilities()
    {
      if (!UserMenager.IsOffLineUser)
        this.offlineAlert.Visibility = Visibility.Collapsed;
      else
        this.offlineAlert.Visibility = Visibility.Visible;
      this.SelectionComboBox.RefreshItemsVisibilities();
    }

    private void SelectionComboBox_Loaded(object sender, RoutedEventArgs e)
    {
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/selectioncombobox/extendedcombobox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.shadow = (Rectangle) target;
          this.shadow.MouseDown += new MouseButtonEventHandler(this.HighlightRect_MouseDown);
          this.shadow.MouseEnter += new MouseEventHandler(this.HighlightRect_MouseEnter);
          this.shadow.MouseLeave += new MouseEventHandler(this.HighlightRect_MouseLeave);
          break;
        case 2:
          this.HighlightRect = (Rectangle) target;
          this.HighlightRect.MouseDown += new MouseButtonEventHandler(this.HighlightRect_MouseDown);
          this.HighlightRect.MouseEnter += new MouseEventHandler(this.HighlightRect_MouseEnter);
          this.HighlightRect.MouseLeave += new MouseEventHandler(this.HighlightRect_MouseLeave);
          break;
        case 3:
          this.boy = (Image) target;
          break;
        case 4:
          this.man = (Image) target;
          break;
        case 5:
          this.womain = (Image) target;
          break;
        case 6:
          this.girl = (Image) target;
          break;
        case 7:
          this.boy1 = (Image) target;
          break;
        case 8:
          this.man1 = (Image) target;
          break;
        case 9:
          this.womain1 = (Image) target;
          break;
        case 10:
          this.girl1 = (Image) target;
          break;
        case 11:
          this.boy2 = (Image) target;
          break;
        case 12:
          this.man2 = (Image) target;
          break;
        case 13:
          this.womain2 = (Image) target;
          break;
        case 14:
          this.girl2 = (Image) target;
          break;
        case 15:
          this.boy3 = (Image) target;
          break;
        case 16:
          this.man3 = (Image) target;
          break;
        case 17:
          this.womain3 = (Image) target;
          break;
        case 18:
          this.girl3 = (Image) target;
          break;
        case 19:
          this.UserNameLabel = (TextBlock) target;
          break;
        case 20:
          this.offlineAlert = (Label) target;
          break;
        case 21:
          this.NumberOfPointsTextBox = (Label) target;
          break;
        case 22:
          this.spaceGrid = (Grid) target;
          break;
        case 23:
          this.NumberOfAllPoints = (Label) target;
          break;
        case 24:
          this.SelectionComboBox = (PixBlocks.Views.QuestionsView.SelectionComboBox.SelectionComboBox) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void ComboBoxClicked();
  }
}
