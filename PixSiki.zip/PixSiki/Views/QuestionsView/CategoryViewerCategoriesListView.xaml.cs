﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.CategoryViewer.CategoriesListView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Championsships;
using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.TopPanel.Components.PopUp;
using PixBlocks.TopPanel.TeacherPanel.Views.PopUpComponents;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.Views.QuestionsView.CategoryViewer
{
  public partial class CategoriesListView : UserControl, IComponentConnector
  {
    private QuestionCategory category;
    private List<QuestionInListView> views = new List<QuestionInListView>();
    private NoExamsInClassInfo noExamsInClassInfo;
    private NoExamsInClassInfo noHomeWorksClassInfo;
    private NoExamsInClassInfo noChampionshipsClassInfo;
    private CategoryInListView championshipsCategoryView;
    private ConnectToChampionship connectToChampionship;
    private GenericPopUp genericPopUp;
    private CategoryInListView allExamsCategory;
    private CategoryInListView allHomeWorksCategory;
    private Point clickPoint = new Point(-100.0, -100.0);
    private double svVerticalOffset;
    private double svHorizontalOffset;
    internal ScrollViewer scroll;
    internal StackPanel mainStack;
    private bool _contentLoaded;

    public QuestionCategory CurrentCategory => this.category;

    public CategoriesListView(QuestionCategory category)
    {
      this.InitializeComponent();
      if (category != null)
        this.LoadCategory(category);
      UserMenager.languageKeyChangedEvet += new UserMenager.LanguageKeyChangedEvet(this.UserMenager_languageKeyChangedEvet);
      UserMenager.refreshStatusConnectToChampionshipEvent += new UserMenager.UserConnectToChampionshipEventHandler(this.UpdateStatusChampionship_refreshStatusConnectToChampionshipEvent);
    }

    private void UserMenager_languageKeyChangedEvet()
    {
      if (this.allExamsCategory != null && this.allHomeWorksCategory != null)
      {
        this.allExamsCategory.SetCaption(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("tests"));
        this.allHomeWorksCategory.SetCaption(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("homeworks"));
      }
      if (this.noExamsInClassInfo != null)
        this.noExamsInClassInfo.SetCaption(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noExam"));
      if (this.noHomeWorksClassInfo == null)
        return;
      this.noHomeWorksClassInfo.SetCaption(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noHomework"));
    }

    private void DisposeAllSubElements()
    {
      foreach (object child in this.mainStack.Children)
      {
        if (child is CategoryInListView)
          (child as CategoryInListView).categorySelectedEvent -= new CategoryInListView.CategorySelected(this.Csv_categorySelectedEvent);
        if (child is QuestionInListView)
          (child as QuestionInListView).questioinSelectedEvent -= new QuestionInListView.QuestionSelected(this.Qlv_questioinSelectedEvent);
      }
    }

    public void LoadCategory(QuestionCategory category)
    {
      try
      {
        PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.onExamChange -= new Action<int, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState>(this.Instance_examChangeEvent);
        this.category = category;
        this.mainStack.Children.Clear();
        if (category.IsListOfExams || category.IsListOfAllHomeworks || category.IsChampionship)
        {
          List<Exam> examList1 = new List<Exam>();
          List<Exam> examList2 = new List<Exam>();
          try
          {
            User currentUser = CurrentUserInfo.CurrentUser;
            examList2 = new ServerApi().GetAllActiveExamsForStudent(currentUser, new AuthorizeData(currentUser));
            PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.onExamChange += new Action<int, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState>(this.Instance_examChangeEvent);
            PixBlocks.Tools.ExamsWatcher.ExamsWatcher.Instance.StartWatching(examList2);
          }
          catch
          {
            CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
          }
          List<Exam> examList3 = !category.IsChampionship ? (!category.IsListOfExams ? examList2.Where<Exam>((Func<Exam, bool>) (e => e.IsHomework && !e.ChampionshipId.HasValue)).ToList<Exam>() : examList2.Where<Exam>((Func<Exam, bool>) (e => !e.IsHomework && !e.ChampionshipId.HasValue)).ToList<Exam>()) : examList2.Where<Exam>((Func<Exam, bool>) (e => e.ChampionshipId.HasValue)).ToList<Exam>();
          foreach (Exam exam in examList3)
          {
            QuestionCategory category1 = new QuestionCategory(exam);
            CategoryInListView categoryInListView = new CategoryInListView(category1, category1.CategoryUserFriendlyName);
            this.mainStack.Children.Add((UIElement) categoryInListView);
            categoryInListView.categorySelectedEvent += new CategoryInListView.CategorySelected(this.Csv_categorySelectedEvent);
          }
          if (examList3.Count == 0)
          {
            if (category.IsListOfExams || category.IsChampionship)
            {
              if (category.IsListOfExams)
              {
                this.noExamsInClassInfo = new NoExamsInClassInfo(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noExam"));
                this.mainStack.Children.Add((UIElement) this.noExamsInClassInfo);
              }
              else if (category.IsChampionship)
              {
                this.noExamsInClassInfo = new NoExamsInClassInfo(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noExamChampionship"));
                this.mainStack.Children.Add((UIElement) this.noExamsInClassInfo);
              }
            }
            else
            {
              this.noHomeWorksClassInfo = new NoExamsInClassInfo(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("noHomework"));
              this.mainStack.Children.Add((UIElement) this.noHomeWorksClassInfo);
            }
          }
          RefreshExamList refreshExamList = new RefreshExamList();
          refreshExamList.refreshButton.clickEvent += new RoundedButton.ClickDelegate(this.RefreshButton_clickEvent);
          this.mainStack.Children.Add((UIElement) refreshExamList);
          refreshExamList.Visibility = Visibility.Collapsed;
        }
        else
        {
          this.views.Clear();
          if (category.IsExam)
          {
            User currentUser = CurrentUserInfo.CurrentUser;
            List<ExamQuestion> list = new ServerApi().GetAllQuestionsInExam(category.GetExam(), new AuthorizeData(currentUser)).Where<ExamQuestion>((Func<ExamQuestion, bool>) (e => QuestionCategoryLoaderAndSever.ContainsQuestionGuid(e.QuestionGuid))).ToList<ExamQuestion>();
            List<Question> questions = new List<Question>();
            foreach (ExamQuestion examQuestion in list)
            {
              Question deepCopyForExam = QuestionCategoryLoaderAndSever.QuestionOfGuid(examQuestion.QuestionGuid).GetDeepCopyForExam(category.GetExam());
              questions.Add(deepCopyForExam);
            }
            QuestionCategoryLoaderAndSever.SetCaptions(questions);
            foreach (Question question in questions)
            {
              QuestionInListView questionInListView = new QuestionInListView(question, question.CaptionInCategory, category);
              this.views.Add(questionInListView);
              this.mainStack.Children.Add((UIElement) questionInListView);
              questionInListView.questioinSelectedEvent += new QuestionInListView.QuestionSelected(this.Qlv_questioinSelectedEvent);
            }
          }
          else
          {
            if (category == QuestionCategoryLoaderAndSever.GetMainCategory())
            {
              if (CurrentUserInfo.CurrenChampionship != null && !UserMenager.IsOffLineUser)
                this.AddChampionshipCategory();
              this.AddAllExamsCategory();
            }
            for (int index = 0; index < category.SubcategoriesUniquePaths.Count; ++index)
            {
              QuestionCategory category1 = QuestionCategoryLoaderAndSever.LoadCategory(category.SubcategoriesUniquePaths[index]);
              CategoryInListView categoryInListView = new CategoryInListView(category1, category1.CategoryUserFriendlyName);
              if (category.UniquePath.Contains("_create"))
              {
                SolidColorBrush solidColorBrush = (SolidColorBrush) null;
                if (index == 0 || index == 1)
                  solidColorBrush = new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue));
                if (index == 2)
                  solidColorBrush = new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 205, (byte) 122));
                if (index == 3)
                  solidColorBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 142, (byte) 15));
                if (index == 4)
                  solidColorBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 0, (byte) 0));
                categoryInListView.colorRect.Fill = (Brush) solidColorBrush;
              }
              this.mainStack.Children.Add((UIElement) categoryInListView);
              categoryInListView.categorySelectedEvent += new CategoryInListView.CategorySelected(this.Csv_categorySelectedEvent);
            }
            this.views.Clear();
            for (int index = 0; index < category.SubQuestionsGuids.Count; ++index)
            {
              Question question = QuestionCategoryLoaderAndSever.QuestionOfGuid(category.SubQuestionsGuids[index]);
              QuestionInListView questionInListView = new QuestionInListView(question, question.CaptionInCategory, category);
              this.views.Add(questionInListView);
              this.mainStack.Children.Add((UIElement) questionInListView);
              questionInListView.questioinSelectedEvent += new QuestionInListView.QuestionSelected(this.Qlv_questioinSelectedEvent);
            }
            this.scroll.ScrollToHome();
          }
        }
      }
      catch
      {
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
      }
    }

    private void UpdateStatusChampionship_refreshStatusConnectToChampionshipEvent()
    {
      if (CurrentUserInfo.CurrentUser.ChampionshipDateAdd.HasValue && CurrentUserInfo.CurrentUser.ChampionshipId.HasValue)
        this.championshipsCategoryView.SetChampionshipStatus(false);
      else
        this.championshipsCategoryView.SetChampionshipStatus(true);
    }

    private void AddChampionshipCategory()
    {
      this.championshipsCategoryView = new CategoryInListView(new QuestionCategory()
      {
        IsChampionship = true
      }, CurrentUserInfo.CurrenChampionship.Name);
      this.championshipsCategoryView.categorySelectedEvent += new CategoryInListView.CategorySelected(this.Csv_categorySelectedEvent);
      this.mainStack.Children.Add((UIElement) this.championshipsCategoryView);
      if (CurrentUserInfo.CurrentUser.ChampionshipDateAdd.HasValue && CurrentUserInfo.CurrentUser.ChampionshipId.HasValue)
        this.championshipsCategoryView.SetChampionshipStatus(false);
      else
        this.championshipsCategoryView.SetChampionshipStatus(true);
    }

    private void Instance_examChangeEvent(int examID, PixBlocks.Tools.ExamsWatcher.ExamsWatcher.ExamState examState) => this.RefreshButton_clickEvent();

    private void RefreshButton_clickEvent() => this.LoadCategory(this.category);

    internal void ScorllTo(Question q)
    {
      int num = this.category.SubcategoriesUniquePaths.Count * 50;
      foreach (QuestionInListView view in this.views)
      {
        num += 50;
        if (view.Question.UniqueGuid == q.UniqueGuid)
          break;
      }
      this.scroll.ScrollToTop();
      this.scroll.ScrollToVerticalOffset((double) (num - 50));
    }

    public event CategoriesListView.CategorySelected categorySelectedEvent;

    private void Csv_categorySelectedEvent(QuestionCategory category)
    {
      if (category.IsChampionship && (!CurrentUserInfo.CurrentUser.ChampionshipId.HasValue || CurrentUserInfo.CurrentUser.ChampionshipId.Value != CurrentUserInfo.CurrenChampionship.Id))
      {
        if (CurrentUserInfo.CurrentUser.Teacher_isTeacher)
        {
          this.ConnectToChampionshipMethodAsTeacher(category);
        }
        else
        {
          this.genericPopUp = new GenericPopUp();
          this.genericPopUp.ShowBlueBackground = true;
          this.connectToChampionship = new ConnectToChampionship(CurrentUserInfo.CurrenChampionship, CurrentUserInfo.CurrentUser, (StudentsClass) null);
          this.connectToChampionship.ParentPopUp = this.genericPopUp;
          this.connectToChampionship.closePopUpEvent += new ClosePopUpDelegate.ClosePopUp(this.GenericPopUp_closePopUpEvent);
          this.genericPopUp.AddComponent((UserControl) this.connectToChampionship);
          (Application.Current.MainWindow as MainWindow).mainGrid.Children.Add((UIElement) this.genericPopUp);
        }
      }
      else
      {
        if (this.categorySelectedEvent == null)
          return;
        this.categorySelectedEvent(category);
      }
    }

    public void ConnectToChampionshipMethodAsTeacher(QuestionCategory category)
    {
      ServerApi serverApi = new ServerApi();
      User currentUser = CurrentUserInfo.CurrentUser;
      Championship currenChampionship = CurrentUserInfo.CurrenChampionship;
      currentUser.ChampionshipId = new int?(currenChampionship.Id);
      User user = currentUser;
      AuthorizeData authorizeData = CurrentUserInfo.AuthorizeData;
      CurrentUserInfo.CurrentUser = serverApi.UpdateOrDeleteUser(user, authorizeData);
      UserMenager.InvokeEventChampionship();
      if (this.categorySelectedEvent == null)
        return;
      this.categorySelectedEvent(category);
    }

    private void GenericPopUp_closePopUpEvent(GenericPopUp genericPopUp)
    {
      this.connectToChampionship.closePopUpEvent -= new ClosePopUpDelegate.ClosePopUp(this.GenericPopUp_closePopUpEvent);
      (Application.Current.MainWindow as MainWindow).mainGrid.Children.Remove((UIElement) genericPopUp);
    }

    internal void AddAllExamsCategory()
    {
      User currentUser = CurrentUserInfo.CurrentUser;
      if (currentUser.Student_isStudent && currentUser.Student_isAcceptedToStudentsClass.HasValue && currentUser.Student_isAcceptedToStudentsClass.Value)
      {
        if (this.allExamsCategory == null)
        {
          this.allExamsCategory = new CategoryInListView(new QuestionCategory()
          {
            IsListOfExams = true
          }, PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("tests"));
          this.allExamsCategory.categorySelectedEvent += new CategoryInListView.CategorySelected(this.Csv_categorySelectedEvent);
          this.allHomeWorksCategory = new CategoryInListView(new QuestionCategory()
          {
            IsListOfAllHomeworks = true
          }, PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("homeworks"));
          this.allHomeWorksCategory.categorySelectedEvent += new CategoryInListView.CategorySelected(this.Csv_categorySelectedEvent);
        }
        if (this.mainStack.Children.Contains((UIElement) this.allExamsCategory))
          return;
        this.mainStack.Children.Add((UIElement) this.allHomeWorksCategory);
        this.mainStack.Children.Add((UIElement) this.allExamsCategory);
      }
      else
      {
        if (this.allExamsCategory == null || !this.mainStack.Children.Contains((UIElement) this.allExamsCategory))
          return;
        this.mainStack.Children.Remove((UIElement) this.allExamsCategory);
        this.mainStack.Children.Remove((UIElement) this.allHomeWorksCategory);
      }
    }

    public event CategoriesListView.QuestionSelected questioinSelectedEvent;

    private void Qlv_questioinSelectedEvent(Question q)
    {
      foreach (QuestionInListView view in this.views)
      {
        if (view.Question != q)
          view.SetSelected(false);
      }
      if (this.questioinSelectedEvent == null)
        return;
      this.questioinSelectedEvent(q);
    }

    internal void SelectFirstQuestion()
    {
      if (this.views.Count <= 0)
        return;
      this.views[0].SetSelected(true);
      if (this.questioinSelectedEvent == null)
        return;
      this.questioinSelectedEvent(this.views[0].Question);
    }

    private void scroll_SizeChanged(object sender, SizeChangedEventArgs e)
    {
    }

    private void Grid_MouseMove(object sender, MouseEventArgs e)
    {
      Point position = e.GetPosition((IInputElement) this);
      if (this.clickPoint.Y == -100.0)
        return;
      this.scroll.ScrollToVerticalOffset(this.svVerticalOffset - position.Y + this.clickPoint.Y);
      this.scroll.ScrollToHorizontalOffset(this.svHorizontalOffset - position.X + this.clickPoint.X);
    }

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.svVerticalOffset = this.scroll.VerticalOffset;
      this.svHorizontalOffset = this.scroll.HorizontalOffset;
      this.clickPoint = e.GetPosition((IInputElement) this);
    }

    private void Grid_MouseUp(object sender, MouseButtonEventArgs e) => this.clickPoint = new Point(-100.0, -100.0);

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.clickPoint = new Point(-100.0, -100.0);

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/categoryviewer/categorieslistview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.scroll = (ScrollViewer) target;
          this.scroll.SizeChanged += new SizeChangedEventHandler(this.scroll_SizeChanged);
          break;
        case 2:
          ((UIElement) target).MouseMove += new MouseEventHandler(this.Grid_MouseMove);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.Grid_MouseUp);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 3:
          this.mainStack = (StackPanel) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void CategorySelected(QuestionCategory category);

    public delegate void QuestionSelected(Question q);
  }
}
