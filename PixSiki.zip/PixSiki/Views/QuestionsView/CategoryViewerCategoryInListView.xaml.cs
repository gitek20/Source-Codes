﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.CategoryViewer.CategoryInListView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.QuestionsView.CategoryViewer
{
  public partial class CategoryInListView : UserControl, IComponentConnector
  {
    private QuestionCategory category;
    public static SolidColorBrush currentColor = new SolidColorBrush(Color.FromRgb((byte) 0, (byte) 0, (byte) 0));
    private bool selected;
    internal Rectangle colorRect;
    internal Rectangle colorRect2;
    internal Rectangle backRect;
    internal Rectangle HighlightRect;
    internal Label labelText;
    internal TextBlock CategoryDescription;
    internal Ellipse championshipConnectStatus;
    internal Image imageGame;
    internal Image imageEmplyLesson;
    internal Image penPink;
    internal Image examImage;
    internal Image homeWorkImage;
    internal Image championships;
    internal Image star00;
    internal Image star01;
    internal Image star02;
    internal Image star03;
    internal Image star04;
    internal Image star05;
    internal Image star06;
    internal Image star07;
    internal Rectangle disableRec;
    private bool _contentLoaded;

    public CategoryInListView() => this.InitializeComponent();

    public void SetCaption(string caption) => this.labelText.Content = (object) caption;

    public void SetChampionshipStatus(bool status)
    {
      SolidColorBrush solidColorBrush1 = new SolidColorBrush();
      solidColorBrush1.Color = Color.FromRgb((byte) 204, (byte) 204, (byte) 204);
      SolidColorBrush solidColorBrush2 = new SolidColorBrush();
      solidColorBrush2.Color = Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue);
      if (status)
        this.championshipConnectStatus.Fill = (Brush) solidColorBrush1;
      else
        this.championshipConnectStatus.Fill = (Brush) solidColorBrush2;
    }

    public CategoryInListView(QuestionCategory category, string caption)
    {
      this.InitializeComponent();
      if (category.IsExam || category.IsChampionship || (category.IsListOfAllHomeworks || category.IsListOfExams) || PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.Instance.IsCategoryVisible(category.UniquePath))
        this.disableRec.Visibility = Visibility.Collapsed;
      else
        this.disableRec.Visibility = Visibility.Visible;
      this.category = category;
      this.labelText.Content = (object) caption;
      int r1 = (int) CategoryInListView.currentColor.Color.R;
      Color color = CategoryInListView.currentColor.Color;
      int g1 = (int) color.G;
      color = CategoryInListView.currentColor.Color;
      int b1 = (int) color.B;
      SolidColorBrush solidColorBrush = new SolidColorBrush(Color.FromRgb((byte) r1, (byte) g1, (byte) b1));
      if (category.IsListOfAllHomeworks || category.IsListOfExams || (category.SubcategoriesUniquePaths.Count > 0 || category.IsChampionship))
      {
        CategoryInListView.currentColor = new SolidColorBrush(Color.FromRgb((byte) 252, (byte) 252, (byte) 252));
        if (caption.Contains(" 1") || caption.Contains(" 2") || (caption.Contains(" 3") || caption.Contains(" 4")) || caption.Contains(" 5"))
          CategoryInListView.currentColor = new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue));
        if (caption.Contains(" 6") || caption.Contains(" 7") || (caption.Contains(" 8") || caption.Contains(" 9")))
          CategoryInListView.currentColor = new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 205, (byte) 122));
        if (caption.Contains(" 10") || caption.Contains(" 11") || (caption.Contains(" 12") || caption.Contains(" 13")))
          CategoryInListView.currentColor = new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 142, (byte) 15));
        if (caption.Contains(" 14") || caption.Contains(" 15") || (caption.Contains(" 16") || caption.Contains(" 17")) || (caption.Contains(" 18") || caption.Contains(" 19") || caption.Contains(" 20")))
          CategoryInListView.currentColor = new SolidColorBrush(Color.FromRgb(byte.MaxValue, (byte) 0, (byte) 0));
      }
      this.colorRect.Fill = (Brush) CategoryInListView.currentColor;
      color = solidColorBrush.Color;
      int r2 = (int) color.R;
      color = CategoryInListView.currentColor.Color;
      int r3 = (int) color.R;
      if (r2 == r3)
      {
        color = solidColorBrush.Color;
        int g2 = (int) color.G;
        color = CategoryInListView.currentColor.Color;
        int g3 = (int) color.G;
        if (g2 == g3)
        {
          color = solidColorBrush.Color;
          int b2 = (int) color.B;
          color = CategoryInListView.currentColor.Color;
          int b3 = (int) color.B;
          if (b2 == b3)
            goto label_17;
        }
      }
      color = CategoryInListView.currentColor.Color;
      if (color.R != (byte) 235)
        this.colorRect2.Fill = (Brush) CategoryInListView.currentColor;
label_17:
      SolidColorBrush currentColor = CategoryInListView.currentColor;
      if (category.IsListOfExams || category.IsListOfAllHomeworks)
      {
        this.CategoryDescription.Text = "";
        if (category.IsListOfExams)
          this.examImage.Visibility = Visibility.Visible;
        else
          this.homeWorkImage.Visibility = Visibility.Visible;
      }
      else if (category.IsChampionship)
      {
        this.championships.Visibility = Visibility.Visible;
        this.championshipConnectStatus.Visibility = Visibility.Visible;
        this.CategoryDescription.Text = "";
      }
      else if (category.IsExam)
      {
        this.CategoryDescription.Text = category.GetExam().Description;
        if (category.GetExam().IsChampionship)
          this.championships.Visibility = Visibility.Visible;
        else if (category.GetExam().IsHomework)
          this.homeWorkImage.Visibility = Visibility.Visible;
        else
          this.examImage.Visibility = Visibility.Visible;
      }
      else
      {
        if (category.SubcategoriesUniquePaths.Count == 0)
        {
          this.imageEmplyLesson.Visibility = Visibility.Visible;
          this.imageGame.Visibility = Visibility.Visible;
        }
        else
        {
          this.imageEmplyLesson.Visibility = Visibility.Visible;
          this.imageGame.Visibility = Visibility.Visible;
        }
        this.labelText.Content = (object) caption;
        if (PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateCategoryID(category.UniquePath) != "NULL!" || UserMenager.UserIsSuperAdmin())
        {
          this.CategoryDescription.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateCategoryID(category.UniquePath);
          if (category.UniquePath.Contains("course200"))
          {
            this.labelText.Content = (object) this.CategoryDescription.Text;
            this.CategoryDescription.Text = "";
          }
        }
        else
          this.CategoryDescription.Text = "";
        this.ShowStarts();
        if (category.IsTeatcherOnlyVisible() && !UserMenager.UserIsTeacher)
          this.Visibility = Visibility.Collapsed;
        if (!category.IsAdminOnlyVisible() || UserMenager.UserIsModerator())
          return;
        this.Visibility = Visibility.Collapsed;
      }
    }

    private void ShowStarts()
    {
      if (this.category.UniquePath.Contains("_create"))
      {
        this.imageEmplyLesson.Visibility = Visibility.Collapsed;
        this.imageGame.Visibility = Visibility.Collapsed;
        this.penPink.Visibility = Visibility.Visible;
        this.CategoryDescription.Text = "";
        this.labelText.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateCategoryID(this.category.UniquePath);
      }
      if (QuestionCategoryLoaderAndSever.IsCategoryGameOnly(this.category.UniquePath))
      {
        this.imageEmplyLesson.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.imageGame.Visibility = Visibility.Collapsed;
        List<Question> questions = QuestionCategoryLoaderAndSever.ClassicQuestionsInCategory(this.category.UniquePath);
        int num1 = QuestionsPointsCounter.CountPointsInQuestions(questions);
        int count = questions.Count;
        if (count <= 0)
          return;
        this.imageGame.Visibility = Visibility.Collapsed;
        this.imageEmplyLesson.Visibility = Visibility.Collapsed;
        if (num1 == 0)
          this.star00.Visibility = Visibility.Visible;
        else if (num1 == count)
        {
          this.star07.Visibility = Visibility.Visible;
        }
        else
        {
          double num2 = (double) num1 * 6.0 / ((double) count * 1.0);
          if (0.0 < num2 && num2 <= 1.0)
            this.star01.Visibility = Visibility.Visible;
          else if (1.0 < num2 && num2 <= 2.0)
            this.star02.Visibility = Visibility.Visible;
          else if (2.0 < num2 && num2 <= 3.0)
            this.star03.Visibility = Visibility.Visible;
          else if (3.0 < num2 && num2 <= 4.0)
            this.star04.Visibility = Visibility.Visible;
          else if (4.0 < num2 && num2 <= 5.0)
          {
            this.star05.Visibility = Visibility.Visible;
          }
          else
          {
            if (5.0 >= num2 || num2 > 6.0)
              return;
            this.star06.Visibility = Visibility.Visible;
          }
        }
      }
    }

    private void Grid_MouseEnter(object sender, MouseEventArgs e)
    {
      if (this.selected)
        return;
      this.HighlightRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 200, (byte) 200, (byte) 200));
    }

    private void Grid_MouseLeave(object sender, MouseEventArgs e)
    {
      if (this.selected)
        return;
      this.HighlightRect.Fill = (Brush) new SolidColorBrush(Colors.White);
    }

    public event CategoryInListView.CategorySelected categorySelectedEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.categorySelectedEvent == null)
        return;
      CategoryInListView.currentColor = this.colorRect.Fill as SolidColorBrush;
      this.categorySelectedEvent(this.category);
    }

    public void SetSelected(bool selected)
    {
      this.selected = selected;
      if (selected)
      {
        this.HighlightRect.Fill = (Brush) new SolidColorBrush(Colors.Yellow);
        this.HighlightRect.Opacity = 1.0;
      }
      else
        this.HighlightRect.Fill = (Brush) new SolidColorBrush(Colors.White);
    }

    private void disableRec_MouseEnter(object sender, MouseEventArgs e) => this.disableRec.Opacity = 0.8;

    private void disableRec_MouseLeave(object sender, MouseEventArgs e) => this.disableRec.Opacity = 0.9;

    private void disableRec_MouseDown(object sender, MouseButtonEventArgs e) => CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("coursesVisibilityInfoStudent"));

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/categoryviewer/categoryinlistview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          break;
        case 2:
          this.colorRect = (Rectangle) target;
          break;
        case 3:
          this.colorRect2 = (Rectangle) target;
          break;
        case 4:
          this.backRect = (Rectangle) target;
          break;
        case 5:
          this.HighlightRect = (Rectangle) target;
          break;
        case 6:
          this.labelText = (Label) target;
          break;
        case 7:
          this.CategoryDescription = (TextBlock) target;
          break;
        case 8:
          this.championshipConnectStatus = (Ellipse) target;
          break;
        case 9:
          this.imageGame = (Image) target;
          break;
        case 10:
          this.imageEmplyLesson = (Image) target;
          break;
        case 11:
          this.penPink = (Image) target;
          break;
        case 12:
          this.examImage = (Image) target;
          break;
        case 13:
          this.homeWorkImage = (Image) target;
          break;
        case 14:
          this.championships = (Image) target;
          break;
        case 15:
          this.star00 = (Image) target;
          break;
        case 16:
          this.star01 = (Image) target;
          break;
        case 17:
          this.star02 = (Image) target;
          break;
        case 18:
          this.star03 = (Image) target;
          break;
        case 19:
          this.star04 = (Image) target;
          break;
        case 20:
          this.star05 = (Image) target;
          break;
        case 21:
          this.star06 = (Image) target;
          break;
        case 22:
          this.star07 = (Image) target;
          break;
        case 23:
          this.disableRec = (Rectangle) target;
          this.disableRec.MouseEnter += new MouseEventHandler(this.disableRec_MouseEnter);
          this.disableRec.MouseLeave += new MouseEventHandler(this.disableRec_MouseLeave);
          this.disableRec.MouseDown += new MouseButtonEventHandler(this.disableRec_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void CategorySelected(QuestionCategory category);
  }
}
