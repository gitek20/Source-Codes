﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.SelectionComboBox.SimpleComboBoxItem
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.UserManagment;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.QuestionsView.SelectionComboBox
{
  public partial class SimpleComboBoxItem : UserControl, IComponentConnector
  {
    private SimpleComboBoxItem.ActionType actionType;
    internal Rectangle selectedRectangle;
    internal Rectangle highlightRectangle;
    internal TextBlock textBox;
    internal Image logoutIcon;
    internal Image toolsIcon;
    internal Image teacherIcon;
    internal Image studentIcon;
    private bool _contentLoaded;

    public SimpleComboBoxItem(SimpleComboBoxItem.ActionType actionType)
    {
      this.actionType = actionType;
      this.InitializeComponent();
      this.highlightRectangle.Opacity = 0.001;
      UserMenager.languageKeyChangedEvet += new UserMenager.LanguageKeyChangedEvet(this.UserMenager_languageKeyChangedEvet);
      this.UserMenager_languageKeyChangedEvet();
    }

    private void UserMenager_languageKeyChangedEvet()
    {
      if (this.actionType == SimpleComboBoxItem.ActionType.lessonsView)
      {
        this.textBox.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("courseView");
        this.studentIcon.Visibility = Visibility.Visible;
      }
      if (this.actionType == SimpleComboBoxItem.ActionType.logout)
      {
        this.textBox.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("logout");
        this.logoutIcon.Visibility = Visibility.Visible;
      }
      if (this.actionType == SimpleComboBoxItem.ActionType.preferences)
      {
        this.textBox.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("preferences");
        this.toolsIcon.Visibility = Visibility.Visible;
      }
      if (this.actionType != SimpleComboBoxItem.ActionType.teacherPanel)
        return;
      this.textBox.Text = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("teacherPanel");
      this.teacherIcon.Visibility = Visibility.Visible;
    }

    public bool IsSelected
    {
      set
      {
        if (value)
        {
          this.selectedRectangle.Visibility = Visibility.Visible;
          this.textBox.Foreground = (Brush) new SolidColorBrush(Colors.White);
        }
        else
        {
          this.selectedRectangle.Visibility = Visibility.Collapsed;
          this.textBox.Foreground = (Brush) new SolidColorBrush(Color.FromRgb((byte) 51, (byte) 51, (byte) 51));
        }
      }
    }

    public SimpleComboBoxItem.ActionType MyActionType => this.actionType;

    public event SimpleComboBoxItem.SelectedItem selectedItemeEvent;

    private void highlightRectangle_MouseDown(object sender, MouseButtonEventArgs e) => this.SelectAndInvokeEvent();

    public void SelectAndInvokeEvent()
    {
      this.IsSelected = true;
      if (this.selectedItemeEvent == null)
        return;
      this.selectedItemeEvent(this.actionType);
    }

    private void highlightRectangle_MouseEnter(object sender, MouseEventArgs e) => this.highlightRectangle.Opacity = 0.2;

    private void highlightRectangle_MouseLeave(object sender, MouseEventArgs e) => this.highlightRectangle.Opacity = 0.001;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/selectioncombobox/simplecomboboxitem.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.selectedRectangle = (Rectangle) target;
          this.selectedRectangle.MouseDown += new MouseButtonEventHandler(this.highlightRectangle_MouseDown);
          this.selectedRectangle.MouseEnter += new MouseEventHandler(this.highlightRectangle_MouseEnter);
          this.selectedRectangle.MouseLeave += new MouseEventHandler(this.highlightRectangle_MouseLeave);
          break;
        case 2:
          this.highlightRectangle = (Rectangle) target;
          this.highlightRectangle.MouseDown += new MouseButtonEventHandler(this.highlightRectangle_MouseDown);
          this.highlightRectangle.MouseEnter += new MouseEventHandler(this.highlightRectangle_MouseEnter);
          this.highlightRectangle.MouseLeave += new MouseEventHandler(this.highlightRectangle_MouseLeave);
          break;
        case 3:
          this.textBox = (TextBlock) target;
          break;
        case 4:
          this.logoutIcon = (Image) target;
          break;
        case 5:
          this.toolsIcon = (Image) target;
          break;
        case 6:
          this.teacherIcon = (Image) target;
          break;
        case 7:
          this.studentIcon = (Image) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public enum ActionType
    {
      preferences,
      teacherPanel,
      logout,
      lessonsView,
    }

    public delegate void SelectedItem(SimpleComboBoxItem.ActionType actionType);
  }
}
