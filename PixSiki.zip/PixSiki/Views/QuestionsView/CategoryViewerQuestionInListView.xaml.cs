﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.CategoryViewer.QuestionInListView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.QuestionsView.CategoryViewer
{
  public partial class QuestionInListView : UserControl, IComponentConnector
  {
    private Question question;
    private string caption;
    private bool isMouseDownClicked;
    private bool selected;
    internal Rectangle back;
    internal Rectangle HighlightRect;
    internal Image blue1;
    internal Image gray1;
    internal Image redStar;
    internal Image image2;
    internal Image imagebird;
    internal Image penPink;
    internal Label labelText;
    internal Grid LockIcon;
    internal Image PenIcon;
    internal Grid GameIcon;
    internal Rectangle disableRec;
    private bool _contentLoaded;

    public Question Question => this.question;

    public QuestionInListView() => this.InitializeComponent();

    public QuestionInListView(Question question, string caption, QuestionCategory category)
    {
      this.InitializeComponent();
      if (category.IsExam || category.IsListOfAllHomeworks || (category.IsChampionship || PixBlocks.Tools.CoursesVisibilityWatcher.CoursesVisibilityWatcher.Instance.IsQuestionVisible(question.UniqueGuid)))
        this.disableRec.Visibility = Visibility.Collapsed;
      else
        this.disableRec.Visibility = Visibility.Visible;
      this.question = question;
      this.caption = caption;
      this.labelText.Content = (object) caption;
      this.InitializeComponent();
      if (question.QuestionType == QuestionType.FreeCodeType)
      {
        if (question.CanEditBitmap || question.IsIronPython)
        {
          this.imagebird.Visibility = Visibility.Collapsed;
          this.penPink.Visibility = Visibility.Visible;
        }
        else
        {
          this.penPink.Visibility = Visibility.Collapsed;
          this.imagebird.Visibility = Visibility.Visible;
        }
        this.image2.Visibility = Visibility.Collapsed;
        this.blue1.Visibility = Visibility.Collapsed;
        this.gray1.Visibility = Visibility.Collapsed;
        this.redStar.Visibility = Visibility.Collapsed;
      }
      if (question.QuestionType == QuestionType.InfoType)
      {
        this.penPink.Visibility = Visibility.Collapsed;
        this.imagebird.Visibility = Visibility.Collapsed;
        this.blue1.Visibility = Visibility.Collapsed;
        this.gray1.Visibility = Visibility.Collapsed;
        this.redStar.Visibility = Visibility.Collapsed;
      }
      if (question.QuestionType == QuestionType.ClassicQuestionType)
      {
        this.penPink.Visibility = Visibility.Collapsed;
        this.imagebird.Visibility = Visibility.Collapsed;
        this.image2.Visibility = Visibility.Collapsed;
        this.ShowScore(QuestionsPointsCounter.GetQuestionPoints(question));
        QuestionsPointsCounter.questionPointsModifyEvent += new QuestionsPointsCounter.QuestionPointsModify(this.QuestionsPointsCounter_questionPointsModifyEvent);
      }
      if (question.IsPremiumQuestion && !UserMenager.IsCurrentUserPremiumBlocks() && !question.IsIronPython || question.IsPremiumQuestion && !UserMenager.IsCurrentUserPremiumPython() && question.IsIronPython)
        this.LockIcon.Visibility = Visibility.Visible;
      else
        this.LockIcon.Visibility = Visibility.Collapsed;
      if (question.IsGame)
      {
        this.GameIcon.Visibility = Visibility.Visible;
        this.PenIcon.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.GameIcon.Visibility = Visibility.Collapsed;
        this.PenIcon.Visibility = Visibility.Visible;
      }
    }

    private void QuestionsPointsCounter_questionPointsModifyEvent(QuestionPoint questionPoint)
    {
      if (questionPoint == null || !(questionPoint.UniqueQuestionID == this.question.UniqueGuid))
        return;
      this.ShowScore(questionPoint.NumberOfPoints);
    }

    public void ShowScore(int score)
    {
      if (this.question.QuestionType != QuestionType.ClassicQuestionType)
        return;
      if (score == 0)
      {
        this.blue1.Visibility = Visibility.Collapsed;
        this.gray1.Visibility = Visibility.Visible;
        this.redStar.Visibility = Visibility.Collapsed;
      }
      if (score >= 1)
      {
        this.blue1.Visibility = Visibility.Visible;
        this.gray1.Visibility = Visibility.Collapsed;
        this.redStar.Visibility = Visibility.Collapsed;
      }
      if (score >= 0)
        return;
      this.blue1.Visibility = Visibility.Collapsed;
      this.gray1.Visibility = Visibility.Collapsed;
      this.redStar.Visibility = Visibility.Visible;
    }

    public event QuestionInListView.QuestionSelected questioinSelectedEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e) => this.isMouseDownClicked = true;

    public void SetSelected(bool selected)
    {
      this.selected = selected;
      if (selected)
      {
        this.HighlightRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 200, (byte) 200, (byte) 200));
        this.HighlightRect.Opacity = 0.35;
      }
      else
      {
        this.isMouseDownClicked = false;
        this.HighlightRect.Fill = (Brush) new SolidColorBrush(Colors.White);
        this.HighlightRect.Opacity = 0.15;
      }
    }

    private void Grid_MouseEnter(object sender, MouseEventArgs e)
    {
      if (this.selected)
        return;
      this.HighlightRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 200, (byte) 200, (byte) 200));
    }

    private void Grid_MouseLeave(object sender, MouseEventArgs e)
    {
      this.isMouseDownClicked = false;
      if (this.selected)
        return;
      this.HighlightRect.Fill = (Brush) new SolidColorBrush(Colors.White);
    }

    private void Grid_MouseUp(object sender, MouseButtonEventArgs e)
    {
      if (!this.isMouseDownClicked)
        return;
      if (this.questioinSelectedEvent != null)
      {
        this.question.CaptionInCategory = this.caption;
        this.questioinSelectedEvent(this.question);
      }
      this.SetSelected(true);
    }

    private void disableRec_MouseEnter(object sender, MouseEventArgs e) => this.disableRec.Opacity = 0.8;

    private void disableRec_MouseLeave(object sender, MouseEventArgs e) => this.disableRec.Opacity = 0.9;

    private void disableRec_MouseDown(object sender, MouseButtonEventArgs e) => CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("coursesVisibilityInfoStudent"));

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/categoryviewer/questioninlistview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseUp += new MouseButtonEventHandler(this.Grid_MouseUp);
          break;
        case 2:
          this.back = (Rectangle) target;
          break;
        case 3:
          this.HighlightRect = (Rectangle) target;
          break;
        case 4:
          this.blue1 = (Image) target;
          break;
        case 5:
          this.gray1 = (Image) target;
          break;
        case 6:
          this.redStar = (Image) target;
          break;
        case 7:
          this.image2 = (Image) target;
          break;
        case 8:
          this.imagebird = (Image) target;
          break;
        case 9:
          this.penPink = (Image) target;
          break;
        case 10:
          this.labelText = (Label) target;
          break;
        case 11:
          this.LockIcon = (Grid) target;
          break;
        case 12:
          this.PenIcon = (Image) target;
          break;
        case 13:
          this.GameIcon = (Grid) target;
          break;
        case 14:
          this.disableRec = (Rectangle) target;
          this.disableRec.MouseEnter += new MouseEventHandler(this.disableRec_MouseEnter);
          this.disableRec.MouseLeave += new MouseEventHandler(this.disableRec_MouseLeave);
          this.disableRec.MouseDown += new MouseButtonEventHandler(this.disableRec_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void QuestionSelected(Question q);
  }
}
