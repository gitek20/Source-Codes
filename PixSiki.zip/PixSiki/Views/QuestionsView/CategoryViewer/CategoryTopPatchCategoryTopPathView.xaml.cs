﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.CategoryViewer.CategoryTopPatch.CategoryTopPathView
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.CodeRunner.CodeRunnerViewElements;
using PixBlocks.DataModels.Questions;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools.QuestionsParser;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.Views.QuestionsView.CategoryViewer.images;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.QuestionsView.CategoryViewer.CategoryTopPatch
{
  public partial class CategoryTopPathView : UserControl, IComponentConnector
  {
    private QuestionCategory categoryOnTop;
    private SingleTopCategory cv;
    private CircleButton goBackButton;
    private CircleButton infoButton;
    private Question question;
    internal Grid smallLine;
    internal Grid BackButton;
    internal StackPanel stackPanel;
    internal Grid buttonsContainer;
    internal Rectangle HighlightRect;
    internal Image image;
    internal Image imagestar;
    internal Image imagestarRed;
    internal Image image2;
    internal Image imagebird;
    internal Label questionCaption;
    internal Grid infoButtonGrid;
    private bool _contentLoaded;

    public CategoryTopPathView(QuestionCategory category)
    {
      this.categoryOnTop = category;
      this.InitializeComponent();
      this.cv = new SingleTopCategory(category);
      this.cv.categoryWasSelectedEvent += new SingleTopCategory.CategoryWasSelected(this.Cv_categoryWasSelectedEvent);
      this.stackPanel.Children.Add((UIElement) this.cv);
      this.QuestionWasSelected((Question) null);
      this.goBackButton = new CircleButton((UserControl) new BackIconView(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.goBackButton.buttonClickedEvent += new CircleButton.ButtonClicker(this.GoBackButton_buttonClickedEvent);
      this.BackButton.Children.Add((UIElement) this.goBackButton);
      this.goBackButton.SetIsEnabled(false);
      this.goBackButton.Visibility = Visibility.Collapsed;
      this.cv.Visibility = Visibility.Collapsed;
      QuestionsPointsCounter.questionPointsModifyEvent += new QuestionsPointsCounter.QuestionPointsModify(this.QuestionsPointsCounter_questionPointsModifyEvent);
      this.infoButton = new CircleButton((UserControl) new HelpIcon(), Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue), CircleButton.VisualParam.circle);
      this.infoButtonGrid.Children.Add((UIElement) this.InfoButton);
      this.infoButton.MouseEnter += new MouseEventHandler(this.InfoButton_MouseEnter);
      this.infoButton.MouseLeave += new MouseEventHandler(this.InfoButton_MouseLeave);
    }

    private void InfoButton_MouseLeave(object sender, MouseEventArgs e) => this.HighlightRect.Fill = (Brush) new SolidColorBrush(Colors.Transparent);

    private void InfoButton_MouseEnter(object sender, MouseEventArgs e) => this.HighlightRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue));

    public void GoBackButton_buttonClickedEvent()
    {
      if (this.stackPanel.Children.Count <= 1)
        return;
      QuestionCategory category = (this.stackPanel.Children[this.stackPanel.Children.Count - 2] as SingleTopCategory).Category;
      this.QuestionWasSelected((Question) null);
      this.categoryOnTop = category;
      this.stackPanel.Children.RemoveAt(this.stackPanel.Children.Count - 1);
      if (this.categoryWasSelectedEvent != null)
        this.categoryWasSelectedEvent(category);
      if (this.stackPanel.Children.Count != 1)
        return;
      this.goBackButton.SetIsEnabled(false);
      this.goBackButton.Visibility = Visibility.Collapsed;
      this.cv.Visibility = Visibility.Collapsed;
    }

    private void QuestionsPointsCounter_questionPointsModifyEvent(QuestionPoint questionPoint)
    {
      if (this.question == null || questionPoint == null || !(questionPoint.UniqueQuestionID == this.question.UniqueGuid))
        return;
      if (questionPoint.NumberOfPoints > 0)
      {
        this.image.Visibility = Visibility.Collapsed;
        this.imagestar.Visibility = Visibility.Visible;
        this.imagestarRed.Visibility = Visibility.Collapsed;
      }
      if (questionPoint.NumberOfPoints == 0)
      {
        this.image.Visibility = Visibility.Visible;
        this.imagestar.Visibility = Visibility.Collapsed;
        this.imagestarRed.Visibility = Visibility.Collapsed;
      }
      if (questionPoint.NumberOfPoints >= 0)
        return;
      this.image.Visibility = Visibility.Collapsed;
      this.imagestar.Visibility = Visibility.Collapsed;
      this.imagestarRed.Visibility = Visibility.Visible;
    }

    public event CategoryTopPathView.CategoryWasSelected categoryWasSelectedEvent;

    private void ShowLine()
    {
      if (this.categoryOnTop == QuestionCategoryLoaderAndSever.GetMainCategory())
        this.smallLine.Visibility = Visibility.Collapsed;
      else
        this.smallLine.Visibility = Visibility.Visible;
    }

    private void Cv_categoryWasSelectedEvent(QuestionCategory category)
    {
      if (category != (this.stackPanel.Children[this.stackPanel.Children.Count - 1] as SingleTopCategory).Category)
      {
        this.QuestionWasSelected((Question) null);
        int num = 0;
        for (int index = 0; index < this.stackPanel.Children.Count; ++index)
        {
          if ((this.stackPanel.Children[index] as SingleTopCategory).Category == category)
          {
            num = index;
            break;
          }
        }
        this.categoryOnTop = category;
        this.stackPanel.Children.RemoveRange(num + 1, this.stackPanel.Children.Count - (num + 1));
        if (this.categoryWasSelectedEvent != null)
          this.categoryWasSelectedEvent(category);
      }
      else if (this.categoryWasSelectedEvent != null)
        this.categoryWasSelectedEvent((QuestionCategory) null);
      this.ShowLine();
    }

    internal void AddNewCategoryToStack(QuestionCategory category)
    {
      if (category != this.categoryOnTop)
      {
        this.categoryOnTop = category;
        this.QuestionWasSelected((Question) null);
        SingleTopCategory singleTopCategory = new SingleTopCategory(category);
        singleTopCategory.categoryWasSelectedEvent += new SingleTopCategory.CategoryWasSelected(this.Cv_categoryWasSelectedEvent);
        this.stackPanel.Children.Add((UIElement) singleTopCategory);
      }
      if (this.stackPanel.Children.Count <= 1)
      {
        this.goBackButton.SetIsEnabled(false);
        this.goBackButton.Visibility = Visibility.Collapsed;
        this.cv.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.goBackButton.SetIsEnabled(true);
        this.goBackButton.Visibility = Visibility.Visible;
        this.cv.Visibility = Visibility.Visible;
      }
      this.ShowLine();
    }

    public CircleButton InfoButton => this.infoButton;

    private void Grid_MouseEnter(object sender, MouseEventArgs e)
    {
      this.HighlightRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue));
      this.infoButton.PerformMouseEnter();
    }

    private void Grid_MouseLeave(object sender, MouseEventArgs e)
    {
      this.HighlightRect.Fill = (Brush) new SolidColorBrush(Colors.Transparent);
      this.infoButton.PerformMouseLeave();
    }

    public event CategoryTopPathView.QuestionSelected questionWasSelectedEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.question == null || this.questionWasSelectedEvent == null)
        return;
      this.questionWasSelectedEvent(this.question);
    }

    internal void QuestionWasSelected(Question q)
    {
      this.question = q;
      if (q == null)
      {
        this.buttonsContainer.Visibility = Visibility.Collapsed;
        this.image.Visibility = Visibility.Collapsed;
        this.image2.Visibility = Visibility.Collapsed;
        this.imagestar.Visibility = Visibility.Collapsed;
        this.imagestarRed.Visibility = Visibility.Collapsed;
        this.imagebird.Visibility = Visibility.Collapsed;
        this.questionCaption.Visibility = Visibility.Collapsed;
        this.infoButtonGrid.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.infoButtonGrid.Visibility = Visibility.Visible;
        this.buttonsContainer.Visibility = Visibility.Visible;
        this.image.Visibility = Visibility.Collapsed;
        this.image2.Visibility = Visibility.Collapsed;
        this.imagebird.Visibility = Visibility.Collapsed;
        this.imagestar.Visibility = Visibility.Collapsed;
        this.imagestarRed.Visibility = Visibility.Collapsed;
        this.questionCaption.Visibility = Visibility.Visible;
        this.questionCaption.Content = (object) q.CaptionInCategory;
        if (UserMenager.UserIsSuperAdmin())
          this.questionCaption.Content = (object) q.UserFriendlyName;
        if (q.QuestionType == QuestionType.ClassicQuestionType)
        {
          int questionPoints = QuestionsPointsCounter.GetQuestionPoints(q);
          if (questionPoints > 0)
          {
            this.image.Visibility = Visibility.Collapsed;
            this.imagestar.Visibility = Visibility.Visible;
            this.imagestarRed.Visibility = Visibility.Collapsed;
          }
          if (questionPoints == 0)
          {
            this.image.Visibility = Visibility.Visible;
            this.imagestar.Visibility = Visibility.Collapsed;
            this.imagestarRed.Visibility = Visibility.Collapsed;
          }
          if (questionPoints < 0)
          {
            this.image.Visibility = Visibility.Collapsed;
            this.imagestar.Visibility = Visibility.Collapsed;
            this.imagestarRed.Visibility = Visibility.Visible;
          }
        }
        if (q.QuestionType == QuestionType.FreeCodeType)
          this.imagebird.Visibility = Visibility.Visible;
        if (q.QuestionType == QuestionType.InfoType)
          this.image2.Visibility = Visibility.Visible;
      }
      this.ShowLine();
    }

    internal void SelectMainCategory()
    {
      this.stackPanel.Children.RemoveRange(1, this.stackPanel.Children.Count - 1);
      this.ShowLine();
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/categoryviewer/categorytoppatch/categorytoppathview.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.smallLine = (Grid) target;
          break;
        case 2:
          this.BackButton = (Grid) target;
          break;
        case 3:
          this.stackPanel = (StackPanel) target;
          break;
        case 4:
          this.buttonsContainer = (Grid) target;
          break;
        case 5:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 6:
          this.HighlightRect = (Rectangle) target;
          this.HighlightRect.MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          this.HighlightRect.MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          this.HighlightRect.MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 7:
          this.image = (Image) target;
          break;
        case 8:
          this.imagestar = (Image) target;
          break;
        case 9:
          this.imagestarRed = (Image) target;
          break;
        case 10:
          this.image2 = (Image) target;
          break;
        case 11:
          this.imagebird = (Image) target;
          break;
        case 12:
          this.questionCaption = (Label) target;
          break;
        case 13:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        case 14:
          this.infoButtonGrid = (Grid) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void CategoryWasSelected(QuestionCategory category);

    public delegate void QuestionSelected(Question question);
  }
}
