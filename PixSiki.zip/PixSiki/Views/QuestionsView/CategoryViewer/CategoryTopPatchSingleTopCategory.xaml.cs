﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.CategoryViewer.CategoryTopPatch.SingleTopCategory
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PixBlocks.Views.QuestionsView.CategoryViewer.CategoryTopPatch
{
  public partial class SingleTopCategory : UserControl, IComponentConnector
  {
    private QuestionCategory category;
    internal Rectangle HighlightRect;
    internal Image folder;
    internal Grid home;
    internal Image lesson;
    internal Label labelText;
    private bool _contentLoaded;

    public QuestionCategory Category => this.category;

    public SingleTopCategory(QuestionCategory category)
    {
      this.category = category;
      this.InitializeComponent();
      if (category != null)
      {
        if (category.CategoryUserFriendlyName == "start")
          this.labelText.Content = (object) PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("start");
        else
          this.labelText.Content = (object) category.CategoryUserFriendlyName;
      }
      if (category.SubcategoriesUniquePaths.Count == 0)
      {
        this.folder.Visibility = Visibility.Collapsed;
        this.home.Visibility = Visibility.Collapsed;
        this.lesson.Visibility = Visibility.Visible;
      }
      else if (category.CategoryUserFriendlyName == "start")
      {
        this.folder.Visibility = Visibility.Collapsed;
        this.home.Visibility = Visibility.Visible;
        this.lesson.Visibility = Visibility.Collapsed;
      }
      else
      {
        this.folder.Visibility = Visibility.Visible;
        this.home.Visibility = Visibility.Collapsed;
        this.lesson.Visibility = Visibility.Collapsed;
      }
    }

    private void Grid_MouseEnter(object sender, MouseEventArgs e) => this.HighlightRect.Fill = (Brush) new SolidColorBrush(Color.FromRgb((byte) 15, (byte) 142, byte.MaxValue));

    private void Grid_MouseLeave(object sender, MouseEventArgs e) => this.HighlightRect.Fill = (Brush) new SolidColorBrush(Colors.Transparent);

    public event SingleTopCategory.CategoryWasSelected categoryWasSelectedEvent;

    private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.categoryWasSelectedEvent == null)
        return;
      this.categoryWasSelectedEvent(this.category);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/categoryviewer/categorytoppatch/singletopcategory.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.HighlightRect = (Rectangle) target;
          break;
        case 2:
          this.folder = (Image) target;
          break;
        case 3:
          this.home = (Grid) target;
          break;
        case 4:
          this.lesson = (Image) target;
          break;
        case 5:
          this.labelText = (Label) target;
          break;
        case 6:
          ((UIElement) target).MouseEnter += new MouseEventHandler(this.Grid_MouseEnter);
          ((UIElement) target).MouseLeave += new MouseEventHandler(this.Grid_MouseLeave);
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Grid_MouseDown);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public delegate void CategoryWasSelected(QuestionCategory category);
  }
}
