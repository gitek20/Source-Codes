﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.QuestionSaveWindow.QuestionSaveWindow
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using Microsoft.Win32;
using PixBlocks.DataModels.Questions;
using PixBlocks.Tools.QuestionsParser;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace PixBlocks.Views.QuestionsView.QuestionSaveWindow
{
  public partial class QuestionSaveWindow : Window, IComponentConnector
  {
    private Question question = new Question();
    private PixBlocks.CodeRunner.CodeRunner codeRunner;
    internal TextBox textBoxDescription;
    internal Button button;
    internal Image image;
    internal RadioButton QuestionRadio;
    internal RadioButton Sample;
    internal RadioButton FreeCode;
    internal CheckBox GameCheckbox;
    internal Label label;
    internal CheckBox pythonCheckBox;
    internal CheckBox paintEnable;
    internal CheckBox ironPython;
    private bool _contentLoaded;

    public QuestionSaveWindow() => this.InitializeComponent();

    public QuestionSaveWindow(PixBlocks.CodeRunner.CodeRunner codeRunner, Question currentQuestion)
    {
      this.InitializeComponent();
      this.codeRunner = codeRunner;
      this.question.Code = codeRunner.RootElement.GetInternalCode("");
      this.image.Source = (ImageSource) codeRunner.CodeInOut.Image.BitmapIO;
      this.question.ImageInBase64 = codeRunner.CodeInOut.Image.ConvertToBase64();
      this.question.ImageWidth = (int) (codeRunner.CodeInOut.Image.BitmapIO.Width + 0.5);
      this.question.ImageHeight = (int) (codeRunner.CodeInOut.Image.BitmapIO.Height + 0.5);
      this.pythonCheckBox.IsChecked = new bool?(currentQuestion.PtyhonCode);
      this.question.PtyhonCode = currentQuestion.PtyhonCode;
      this.question.QuestionType = QuestionType.ClassicQuestionType;
      this.question.CanEditBitmap = currentQuestion.CanEditBitmap;
      this.QuestionRadio.IsChecked = new bool?(true);
      if (currentQuestion != null)
      {
        if (currentQuestion.QuestionType == QuestionType.ClassicQuestionType)
        {
          this.QuestionRadio.IsChecked = new bool?(true);
          if (currentQuestion.IsGame)
            this.Sample.IsChecked = new bool?(true);
        }
        if (currentQuestion.QuestionType == QuestionType.FreeCodeType)
          this.FreeCode.IsChecked = new bool?(true);
        if (currentQuestion.QuestionType == QuestionType.InfoType)
          this.Sample.IsChecked = new bool?(true);
        this.question.IsGame = currentQuestion.IsGame;
        this.GameCheckbox.IsChecked = new bool?(this.question.IsGame);
        this.question.UserFriendlyName = currentQuestion.UserFriendlyName;
        this.question.Description = currentQuestion.Description;
        this.paintEnable.IsChecked = new bool?(currentQuestion.CanEditBitmap);
        if (currentQuestion.IsGame)
          this.QuestionRadio.IsEnabled = false;
      }
      else
      {
        this.question.UserFriendlyName = "";
        this.question.Description = "";
      }
      this.textBoxDescription.Text = this.question.Description;
    }

    public QuestionSaveWindow(Question currentQuestion, string pythonCode)
    {
      this.InitializeComponent();
      this.question.ImageInBase64 = (string) null;
      this.question.ImageWidth = 0;
      this.question.ImageHeight = 0;
      this.question.InputIronPythonCode = currentQuestion.InputIronPythonCode;
      this.question.Code = pythonCode;
      this.pythonCheckBox.IsChecked = new bool?(false);
      this.question.IsIronPython = true;
      this.ironPython.IsChecked = new bool?(true);
      this.QuestionRadio.IsChecked = new bool?(true);
      if (currentQuestion != null)
      {
        if (currentQuestion.QuestionType == QuestionType.ClassicQuestionType)
        {
          this.QuestionRadio.IsChecked = new bool?(true);
          if (currentQuestion.IsGame)
            this.Sample.IsChecked = new bool?(true);
        }
        if (currentQuestion.QuestionType == QuestionType.FreeCodeType)
          this.FreeCode.IsChecked = new bool?(true);
        if (currentQuestion.QuestionType == QuestionType.InfoType)
          this.Sample.IsChecked = new bool?(true);
        this.question.IsGame = false;
        this.GameCheckbox.IsChecked = new bool?(false);
        this.question.UserFriendlyName = currentQuestion.UserFriendlyName;
        this.question.Description = currentQuestion.Description;
        this.paintEnable.IsChecked = new bool?(currentQuestion.CanEditBitmap);
        if (currentQuestion.IsGame)
          this.QuestionRadio.IsEnabled = false;
      }
      else
      {
        this.question.UserFriendlyName = "";
        this.question.Description = "";
      }
      this.textBoxDescription.Text = this.question.Description;
    }

    private void QuestionRadio_Checked(object sender, RoutedEventArgs e)
    {
      this.question.QuestionType = QuestionType.ClassicQuestionType;
      this.paintEnable.IsChecked = new bool?(false);
      this.paintEnable.IsEnabled = false;
    }

    private void Sample_Checked(object sender, RoutedEventArgs e)
    {
      this.question.QuestionType = QuestionType.InfoType;
      this.paintEnable.IsChecked = new bool?(false);
      this.paintEnable.IsEnabled = true;
    }

    private void FreeCode_Checked(object sender, RoutedEventArgs e)
    {
      this.question.QuestionType = QuestionType.FreeCodeType;
      this.paintEnable.IsEnabled = true;
    }

    private void button_Click(object sender, RoutedEventArgs e)
    {
      this.question.CanEditBitmap = this.paintEnable.IsChecked.Value;
      this.question.Description = this.textBoxDescription.Text;
      if (!this.question.IsIronPython)
        this.question.InputIronPythonCode = (string) null;
      this.question.UniqueGuid = Guid.NewGuid().ToString();
      this.question.SecretNumber = this.question.GenerateSecretNumber();
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.Filter = "Question(*.question)|*.question";
      SaveFileDialog saveFileDialog2 = saveFileDialog1;
      bool? nullable = saveFileDialog2.ShowDialog();
      bool flag = true;
      if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
        return;
      QuestionCategoryLoaderAndSever.SaveQuestion(this.question, saveFileDialog2.FileName);
      this.Close();
    }

    private void checkBox_Checked(object sender, RoutedEventArgs e) => this.question.IsGame = this.GameCheckbox.IsChecked.Value;

    private void pythonCheckBox_Checked(object sender, RoutedEventArgs e) => this.question.PtyhonCode = this.pythonCheckBox.IsChecked.Value;

    private void ironPython_Checked(object sender, RoutedEventArgs e) => this.question.IsIronPython = this.ironPython.IsChecked.Value;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/questionsavewindow/questionsavewindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.textBoxDescription = (TextBox) target;
          break;
        case 2:
          this.button = (Button) target;
          this.button.Click += new RoutedEventHandler(this.button_Click);
          break;
        case 3:
          this.image = (Image) target;
          break;
        case 4:
          this.QuestionRadio = (RadioButton) target;
          this.QuestionRadio.Checked += new RoutedEventHandler(this.QuestionRadio_Checked);
          break;
        case 5:
          this.Sample = (RadioButton) target;
          this.Sample.Checked += new RoutedEventHandler(this.Sample_Checked);
          break;
        case 6:
          this.FreeCode = (RadioButton) target;
          this.FreeCode.Checked += new RoutedEventHandler(this.FreeCode_Checked);
          break;
        case 7:
          this.GameCheckbox = (CheckBox) target;
          this.GameCheckbox.Checked += new RoutedEventHandler(this.checkBox_Checked);
          break;
        case 8:
          this.label = (Label) target;
          break;
        case 9:
          this.pythonCheckBox = (CheckBox) target;
          this.pythonCheckBox.Checked += new RoutedEventHandler(this.pythonCheckBox_Checked);
          break;
        case 10:
          this.paintEnable = (CheckBox) target;
          break;
        case 11:
          this.ironPython = (CheckBox) target;
          this.ironPython.Checked += new RoutedEventHandler(this.ironPython_Checked);
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
