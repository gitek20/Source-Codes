﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.Views.QuestionsView.SelectionComboBox.SelectionComboBox
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.UserManagment;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace PixBlocks.Views.QuestionsView.SelectionComboBox
{
  public partial class SelectionComboBox : UserControl, IComponentConnector
  {
    private List<SimpleComboBoxItem> simpleComboBoxItems = new List<SimpleComboBoxItem>();
    private SimpleComboBoxItem lessonsView;
    private SimpleComboBoxItem preferences;
    private SimpleComboBoxItem teacherPanel;
    private SimpleComboBoxItem logout;
    internal StackPanel mainStack;
    private bool _contentLoaded;

    public SelectionComboBox()
    {
      this.InitializeComponent();
      this.lessonsView = new SimpleComboBoxItem(SimpleComboBoxItem.ActionType.lessonsView);
      this.lessonsView.selectedItemeEvent += new SimpleComboBoxItem.SelectedItem(this.View_selectedItemeEvent);
      this.mainStack.Children.Add((UIElement) this.lessonsView);
      this.simpleComboBoxItems.Add(this.lessonsView);
      this.preferences = new SimpleComboBoxItem(SimpleComboBoxItem.ActionType.preferences);
      this.mainStack.Children.Add((UIElement) this.preferences);
      this.preferences.selectedItemeEvent += new SimpleComboBoxItem.SelectedItem(this.View_selectedItemeEvent);
      this.simpleComboBoxItems.Add(this.preferences);
      this.teacherPanel = new SimpleComboBoxItem(SimpleComboBoxItem.ActionType.teacherPanel);
      this.mainStack.Children.Add((UIElement) this.teacherPanel);
      this.teacherPanel.selectedItemeEvent += new SimpleComboBoxItem.SelectedItem(this.View_selectedItemeEvent);
      this.simpleComboBoxItems.Add(this.teacherPanel);
      this.logout = new SimpleComboBoxItem(SimpleComboBoxItem.ActionType.logout);
      this.mainStack.Children.Add((UIElement) this.logout);
      this.logout.selectedItemeEvent += new SimpleComboBoxItem.SelectedItem(this.View_selectedItemeEvent);
      this.simpleComboBoxItems.Add(this.logout);
      this.Visibility = Visibility.Visible;
    }

    public event SimpleComboBoxItem.SelectedItem selectedItemeEvent;

    private void View_selectedItemeEvent(SimpleComboBoxItem.ActionType actionType)
    {
      foreach (SimpleComboBoxItem simpleComboBoxItem in this.simpleComboBoxItems)
      {
        if (simpleComboBoxItem.MyActionType != actionType)
          simpleComboBoxItem.IsSelected = false;
      }
      if (this.selectedItemeEvent == null)
        return;
      this.selectedItemeEvent(actionType);
    }

    private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e) => this.Visibility = Visibility.Collapsed;

    internal void SelectFirstItem() => this.simpleComboBoxItems[0].SelectAndInvokeEvent();

    internal void RefreshItemsVisibilities()
    {
      if (UserMenager.IsOffLineUser)
      {
        this.lessonsView.Visibility = Visibility.Visible;
        this.preferences.Visibility = Visibility.Collapsed;
        this.teacherPanel.Visibility = Visibility.Collapsed;
        this.logout.Visibility = Visibility.Visible;
      }
      else if (UserMenager.UserIsTeacher)
      {
        this.lessonsView.Visibility = Visibility.Visible;
        this.preferences.Visibility = Visibility.Visible;
        this.teacherPanel.Visibility = Visibility.Visible;
        this.logout.Visibility = Visibility.Visible;
      }
      else
      {
        this.lessonsView.Visibility = Visibility.Visible;
        this.preferences.Visibility = Visibility.Visible;
        this.teacherPanel.Visibility = Visibility.Collapsed;
        this.logout.Visibility = Visibility.Visible;
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/PixBlocks;component/views/questionsview/selectioncombobox/selectioncombobox.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      if (connectionId != 1)
      {
        if (connectionId == 2)
          this.mainStack = (StackPanel) target;
        else
          this._contentLoaded = true;
      }
      else
        ((UIElement) target).PreviewMouseDown += new MouseButtonEventHandler(this.Grid_PreviewMouseDown);
    }
  }
}
