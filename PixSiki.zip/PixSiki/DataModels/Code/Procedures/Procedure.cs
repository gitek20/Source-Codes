﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.Procedures.Procedure
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Tools.CodeParser;
using PixBlocks.Tools.ColorTransformation;
using System;
using System.Collections.Generic;
using System.Windows.Media;

namespace PixBlocks.DataModels.Code.Procedures
{
  public class Procedure : ICodeElement
  {
    private List<ICodeElement> procedureParams = new List<ICodeElement>();
    private PixBlocks.DataModels.Code.ValueType returnType;
    private ProceduresTypes procedureType;
    private GetSetType getSetType;
    private ICodeElement parent;
    private bool isTemplateElement = true;
    private List<string> codeBlock;

    public List<ICodeElement> ProcedureParams => this.procedureParams;

    public ProceduresTypes ProcedureType => this.procedureType;

    public GetSetType GetSetType => this.getSetType;

    public Procedure(ProceduresTypes procedureType)
    {
      this.procedureParams = new List<ICodeElement>();
      this.procedureType = procedureType;
      if (procedureType == ProceduresTypes.GetR || procedureType == ProceduresTypes.GetG || procedureType == ProceduresTypes.GetB)
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Color, "C1"));
      if (procedureType == ProceduresTypes.GetColorFromRGB)
      {
        for (int index = 0; index < 3; ++index)
          this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(10L)));
      }
      if (procedureType == ProceduresTypes.MathDiv || procedureType == ProceduresTypes.MathMinus || (procedureType == ProceduresTypes.MathMod || procedureType == ProceduresTypes.MathMulti) || procedureType == ProceduresTypes.MathPlus)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(1L)));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(1L)));
      }
      if (procedureType == ProceduresTypes.PutRectangleInColor)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "X1"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "Y1"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "X2"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "Y2"));
      }
      if (procedureType == ProceduresTypes.GetPutPixel)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "X"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "Y"));
      }
      if (procedureType == ProceduresTypes.GetPutImage)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "X"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "Y"));
      }
      if (procedureType == ProceduresTypes.GetNumberOfColorsInRectangle)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "X1"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "Y1"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "X2"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "Y2"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Blue)));
      }
      if (procedureType == ProceduresTypes.GetNumberOfColorsInX)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "X"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Blue)));
      }
      if (procedureType == ProceduresTypes.GetNumberOfColorsInY)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "Y"));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Blue)));
      }
      if (procedureType == ProceduresTypes.BoolAND || procedureType == ProceduresTypes.BoolOR)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(true)));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(true)));
      }
      if (procedureType == ProceduresTypes.BoolEqual || procedureType == ProceduresTypes.BoolGreaterOrEqual || (procedureType == ProceduresTypes.BoolGreaterThan || procedureType == ProceduresTypes.BoolLessOrEqual) || (procedureType == ProceduresTypes.BoolLessThan || procedureType == ProceduresTypes.BoolNotEqual))
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(1L)));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(1L)));
      }
      if (procedureType == ProceduresTypes.BoolEqual)
      {
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(0, 0, 0)));
        this.procedureParams.Add((ICodeElement) new Variable(VariableType.constant, new Value(0, 0, 0)));
      }
      this.SetReturnTypeAdnGetSetType();
      foreach (ICodeElement procedureParam in this.procedureParams)
        procedureParam.SetParent((ICodeElement) this);
    }

    private void SetReturnTypeAdnGetSetType()
    {
      if (this.procedureType == ProceduresTypes.BoolAND || this.procedureType == ProceduresTypes.BoolEqual || (this.procedureType == ProceduresTypes.BoolGreaterOrEqual || this.procedureType == ProceduresTypes.BoolGreaterThan) || (this.procedureType == ProceduresTypes.BoolLessOrEqual || this.procedureType == ProceduresTypes.BoolLessThan || (this.procedureType == ProceduresTypes.BoolNotEqual || this.procedureType == ProceduresTypes.BoolOR)))
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Boolean;
        this.getSetType = GetSetType.Get;
      }
      if (this.procedureType == ProceduresTypes.GetR || this.procedureType == ProceduresTypes.GetG || this.procedureType == ProceduresTypes.GetB)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Number;
        this.getSetType = GetSetType.Get;
      }
      if (this.procedureType == ProceduresTypes.GetColorFromRGB)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Color;
        this.getSetType = GetSetType.Get;
      }
      if (this.procedureType == ProceduresTypes.MathDiv || this.procedureType == ProceduresTypes.MathMinus || (this.procedureType == ProceduresTypes.MathMod || this.procedureType == ProceduresTypes.MathMulti) || this.procedureType == ProceduresTypes.MathPlus)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Number;
        this.getSetType = GetSetType.Get;
      }
      if (this.procedureType == ProceduresTypes.PutRectangleInColor)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Color;
        this.getSetType = GetSetType.Set;
      }
      if (this.procedureType == ProceduresTypes.GetPutPixel)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Color;
        this.getSetType = GetSetType.GetSet;
      }
      if (this.procedureType == ProceduresTypes.GetPutImage)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Image;
        this.getSetType = GetSetType.GetSet;
      }
      if (this.procedureType == ProceduresTypes.GetNumberOfColorsInRectangle || this.procedureType == ProceduresTypes.GetNumberOfColorsInX || this.procedureType == ProceduresTypes.GetNumberOfColorsInY)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Number;
        this.getSetType = GetSetType.Get;
      }
      if (this.ProcedureType == ProceduresTypes.TurtleX)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Number;
        this.getSetType = GetSetType.GetSet;
      }
      if (this.ProcedureType == ProceduresTypes.TurtleY)
      {
        this.returnType = PixBlocks.DataModels.Code.ValueType.Number;
        this.getSetType = GetSetType.GetSet;
      }
      if (this.ProcedureType != ProceduresTypes.TurtleSee)
        return;
      this.returnType = PixBlocks.DataModels.Code.ValueType.Color;
      this.getSetType = GetSetType.Get;
    }

    public Procedure(List<string> codeBlock)
    {
      this.codeBlock = codeBlock;
      Enum.TryParse<ProceduresTypes>(codeBlock[2], out this.procedureType);
      this.SetReturnTypeAdnGetSetType();
      this.procedureParams = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeBlock));
      foreach (ICodeElement procedureParam in this.procedureParams)
        procedureParam.SetParent((ICodeElement) this);
      this.isTemplateElement = false;
    }

    public bool CanDragAndDropElement(ICodeElement element) => element.GetRetunType() == this.GetRetunType();

    public string GetInternalCode(string spaces)
    {
      string str = "" + spaces + "{\r\n" + spaces + this.GetType().ToString() + "\r\n" + spaces + this.procedureType.ToString() + "\r\n" + spaces + "{\r\n";
      foreach (ICodeElement procedureParam in this.procedureParams)
        str += procedureParam.GetInternalCode(spaces + "  ");
      return str + spaces + "}\r\n" + spaces + "}\r\n";
    }

    public ICodeElement GetNextInstructionAfter(
      ICodeElement instruction,
      CodeInOut inOut)
    {
      return this.GetParent().GetNextInstructionAfter(instruction, inOut);
    }

    public ICodeElement GetParent() => this.parent;

    public PixBlocks.DataModels.Code.ValueType GetRetunType() => this.returnType;

    public string GetUniqueName() => this.procedureType.ToString();

    public List<ICodeElement> InnerCodeElements()
    {
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      codeElementList.Add((ICodeElement) this);
      foreach (ICodeElement procedureParam in this.procedureParams)
        codeElementList.AddRange((IEnumerable<ICodeElement>) procedureParam.InnerCodeElements());
      return codeElementList;
    }

    public bool IsInstruction() => false;

    public bool IsVaildOK()
    {
      foreach (ICodeElement procedureParam in this.procedureParams)
      {
        if (!procedureParam.IsVaildOK())
          return false;
      }
      return true;
    }

    public int NumberOfInnerCodeLines() => 0;

    public Value RunInnerCode(Value v, CodeInOut inOut)
    {
      if (this.procedureType == ProceduresTypes.GetR)
      {
        if (v == null)
          return new Value((long) this.procedureParams[0].RunInnerCode(v, inOut).R);
        Value obj = this.procedureParams[0].RunInnerCode((Value) null, inOut);
        this.procedureParams[0].RunInnerCode(new Value((int) v.Number, obj.G, obj.B), inOut);
        return (Value) null;
      }
      if (this.procedureType == ProceduresTypes.GetG)
      {
        if (v == null)
          return new Value((long) this.procedureParams[0].RunInnerCode(v, inOut).G);
        Value obj = this.procedureParams[0].RunInnerCode((Value) null, inOut);
        this.procedureParams[0].RunInnerCode(new Value(obj.R, (int) v.Number, obj.B), inOut);
        return (Value) null;
      }
      if (this.procedureType == ProceduresTypes.GetB)
      {
        if (v == null)
          return new Value((long) this.procedureParams[0].RunInnerCode(v, inOut).B);
        Value obj = this.procedureParams[0].RunInnerCode((Value) null, inOut);
        this.procedureParams[0].RunInnerCode(new Value(obj.R, obj.G, (int) v.Number), inOut);
        return (Value) null;
      }
      if (this.procedureType == ProceduresTypes.GetColorFromRGB)
        return new Value((int) this.procedureParams[0].RunInnerCode(v, inOut).Number, (int) this.procedureParams[1].RunInnerCode(v, inOut).Number, (int) this.procedureParams[2].RunInnerCode(v, inOut).Number);
      if (this.procedureType == ProceduresTypes.GetNumberOfColorsInRectangle)
        return new Value((long) inOut.Image.GetNumberOfColorsInRectangle((int) this.procedureParams[0].RunInnerCode(v, inOut).Number, (int) this.procedureParams[1].RunInnerCode(v, inOut).Number, (int) this.procedureParams[2].RunInnerCode(v, inOut).Number, (int) this.procedureParams[3].RunInnerCode(v, inOut).Number, this.procedureParams[4].RunInnerCode(v, inOut)));
      if (this.procedureType == ProceduresTypes.GetNumberOfColorsInX)
        return new Value((long) inOut.Image.GetNumberOfColorsInRectangle((int) this.procedureParams[0].RunInnerCode(v, inOut).Number, 1, (int) this.procedureParams[0].RunInnerCode(v, inOut).Number, inOut.Image.GetHeight(), this.procedureParams[1].RunInnerCode(v, inOut)));
      if (this.procedureType == ProceduresTypes.GetNumberOfColorsInY)
        return new Value((long) inOut.Image.GetNumberOfColorsInRectangle(1, (int) this.procedureParams[0].RunInnerCode(v, inOut).Number, inOut.Image.GetWidth(), (int) this.procedureParams[0].RunInnerCode(v, inOut).Number, this.procedureParams[1].RunInnerCode(v, inOut)));
      if (this.procedureType == ProceduresTypes.PutRectangleInColor)
      {
        inOut.Image.PutRectangleInColor((int) this.procedureParams[0].RunInnerCode((Value) null, inOut).Number, (int) this.procedureParams[1].RunInnerCode((Value) null, inOut).Number, (int) this.procedureParams[2].RunInnerCode((Value) null, inOut).Number, (int) this.procedureParams[3].RunInnerCode((Value) null, inOut).Number, v);
        return (Value) null;
      }
      if (this.procedureType == ProceduresTypes.GetPutPixel)
      {
        if (v == null)
          return inOut.Image.GetPixelColor((int) this.procedureParams[0].RunInnerCode(v, inOut).Number, (int) this.procedureParams[1].RunInnerCode(v, inOut).Number);
        int number1 = (int) this.procedureParams[0].RunInnerCode((Value) null, inOut).Number;
        int number2 = (int) this.procedureParams[1].RunInnerCode((Value) null, inOut).Number;
        inOut.Image.PutPixel(number1, number2, v);
        return (Value) null;
      }
      if (this.procedureType == ProceduresTypes.GetPutImage)
      {
        if (v == null)
          return new Value(PixBlocks.BlocksManager.BlocksManager.NameFromColor(inOut.Image.GetPixelColor((int) this.procedureParams[0].RunInnerCode(v, inOut).Number, (int) this.procedureParams[1].RunInnerCode(v, inOut).Number)));
        int number1 = (int) this.procedureParams[0].RunInnerCode((Value) null, inOut).Number;
        int number2 = (int) this.procedureParams[1].RunInnerCode((Value) null, inOut).Number;
        inOut.Image.PutPixel(number1, number2, v);
        return (Value) null;
      }
      if (this.procedureType == ProceduresTypes.MathDiv)
        return this.procedureParams[1].RunInnerCode(v, inOut).Number == 0L ? new Value(4611686018427387903L) : new Value(this.procedureParams[0].RunInnerCode(v, inOut).Number / this.procedureParams[1].RunInnerCode(v, inOut).Number);
      if (this.procedureType == ProceduresTypes.MathMinus)
        return new Value(this.procedureParams[0].RunInnerCode(v, inOut).Number - this.procedureParams[1].RunInnerCode(v, inOut).Number);
      if (this.procedureType == ProceduresTypes.MathMod)
        return this.procedureParams[1].RunInnerCode(v, inOut).Number == 0L ? new Value(4611686018427387903L) : new Value(this.procedureParams[0].RunInnerCode(v, inOut).Number % this.procedureParams[1].RunInnerCode(v, inOut).Number);
      if (this.procedureType == ProceduresTypes.MathMulti)
        return new Value(this.procedureParams[0].RunInnerCode(v, inOut).Number * this.procedureParams[1].RunInnerCode(v, inOut).Number);
      if (this.procedureType == ProceduresTypes.MathPlus)
        return new Value(this.procedureParams[0].RunInnerCode(v, inOut).Number + this.procedureParams[1].RunInnerCode(v, inOut).Number);
      if (this.procedureType == ProceduresTypes.TurtleX)
      {
        if (v == null)
          return new Value((long) inOut.TurtleX);
        inOut.TurtleX = (int) v.Number;
        return (Value) null;
      }
      if (this.procedureType == ProceduresTypes.TurtleY)
      {
        if (v == null)
          return new Value((long) inOut.TurtleY);
        inOut.TurtleY = (int) v.Number;
        return (Value) null;
      }
      if (this.procedureType == ProceduresTypes.TurtleSee)
        return inOut.Image.GetPixelColor(inOut.TurtleX, inOut.TurtleY);
      if (this.procedureType == ProceduresTypes.BoolAND)
        return this.procedureParams[0].RunInnerCode(v, inOut).Bollean && this.procedureParams[1].RunInnerCode(v, inOut).Bollean ? new Value(true) : new Value(false);
      if (this.procedureType == ProceduresTypes.BoolEqual)
        return this.procedureParams[0].RunInnerCode(v, inOut).IsEqual(this.procedureParams[1].RunInnerCode(v, inOut)) ? new Value(true) : new Value(false);
      if (this.procedureType == ProceduresTypes.BoolNotEqual)
        return !this.procedureParams[0].RunInnerCode(v, inOut).IsEqual(this.procedureParams[1].RunInnerCode(v, inOut)) ? new Value(true) : new Value(false);
      if (this.procedureType == ProceduresTypes.BoolGreaterOrEqual)
        return this.procedureParams[0].RunInnerCode(v, inOut).Number >= this.procedureParams[1].RunInnerCode(v, inOut).Number ? new Value(true) : new Value(false);
      if (this.procedureType == ProceduresTypes.BoolGreaterThan)
        return this.procedureParams[0].RunInnerCode(v, inOut).Number > this.procedureParams[1].RunInnerCode(v, inOut).Number ? new Value(true) : new Value(false);
      if (this.procedureType == ProceduresTypes.BoolLessOrEqual)
        return this.procedureParams[0].RunInnerCode(v, inOut).Number <= this.procedureParams[1].RunInnerCode(v, inOut).Number ? new Value(true) : new Value(false);
      if (this.procedureType == ProceduresTypes.BoolLessThan)
        return this.procedureParams[0].RunInnerCode(v, inOut).Number < this.procedureParams[1].RunInnerCode(v, inOut).Number ? new Value(true) : new Value(false);
      if (this.procedureType != ProceduresTypes.BoolOR)
        return (Value) null;
      return this.procedureParams[0].RunInnerCode(v, inOut).Bollean || this.procedureParams[1].RunInnerCode(v, inOut).Bollean ? new Value(true) : new Value(false);
    }

    public void SetInternalCode(string code) => throw new NotImplementedException();

    public void SetParent(ICodeElement parent) => this.parent = parent;

    public event CodeElementRunningStatus codeRunningStatusChanged;

    public bool GetIsTemplateElement() => this.isTemplateElement;

    public void PutIsTemplateElement(bool isTemplateElement)
    {
      this.isTemplateElement = isTemplateElement;
      foreach (ICodeElement procedureParam in this.procedureParams)
        procedureParam.PutIsTemplateElement(isTemplateElement);
    }

    public void SendCodeRunningStatusStart()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StartRuning);
    }

    public void SendCodeRunningStatusStop()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StopRuning);
    }

    public string GetPythonCode(string spaces)
    {
      if (this.procedureType == ProceduresTypes.GetB)
        return "colors.getBlue(" + this.procedureParams[0].GetPythonCode("") + ")";
      if (this.procedureType == ProceduresTypes.GetR)
        return "colors.getRed(" + this.procedureParams[0].GetPythonCode("") + ")";
      if (this.procedureType == ProceduresTypes.GetG)
        return "colors.getGreen(" + this.procedureParams[0].GetPythonCode("") + ")";
      if (this.procedureType == ProceduresTypes.GetColorFromRGB)
        return "colors.fromRedGreenBlue(" + this.procedureParams[0].GetPythonCode("") + "," + this.procedureParams[1].GetPythonCode("") + "," + this.procedureParams[2].GetPythonCode("") + ")";
      if (this.ProcedureType == ProceduresTypes.GetNumberOfColorsInX)
        return "image.countColorInColumn(" + this.procedureParams[0].GetPythonCode("") + "," + this.procedureParams[1].GetPythonCode("") + ")";
      if (this.ProcedureType == ProceduresTypes.GetNumberOfColorsInY)
        return "image.countColorInRow(" + this.procedureParams[0].GetPythonCode("") + "," + this.procedureParams[1].GetPythonCode("") + ")";
      if (this.ProcedureType == ProceduresTypes.GetPutPixel)
        return "image.pixelColor(" + this.procedureParams[0].GetPythonCode("") + "," + this.procedureParams[1].GetPythonCode("") + ")";
      if (this.ProcedureType == ProceduresTypes.GetPutImage)
        return "PYTON not supptort Images";
      if (this.ProcedureType == ProceduresTypes.PutRectangleInColor)
        return "image.rectangleColor(" + this.procedureParams[0].GetPythonCode("") + "," + this.procedureParams[1].GetPythonCode("") + "," + this.procedureParams[2].GetPythonCode("") + "," + this.procedureParams[3].GetPythonCode("") + ")";
      string str1 = "";
      if (this.ProcedureType == ProceduresTypes.MathDiv)
        str1 = "/";
      if (this.ProcedureType == ProceduresTypes.MathMinus)
        str1 = "-";
      if (this.ProcedureType == ProceduresTypes.MathMod)
        str1 = "%";
      if (this.ProcedureType == ProceduresTypes.MathMulti)
        str1 = "*";
      if (this.ProcedureType == ProceduresTypes.MathPlus)
        str1 = "+";
      if (this.procedureType == ProceduresTypes.BoolEqual)
        str1 = "==";
      if (this.procedureType == ProceduresTypes.BoolGreaterOrEqual)
        str1 = ">=";
      if (this.procedureType == ProceduresTypes.BoolGreaterThan)
        str1 = ">";
      if (this.procedureType == ProceduresTypes.BoolLessOrEqual)
        str1 = "<=";
      if (this.procedureType == ProceduresTypes.BoolLessThan)
        str1 = "<";
      if (this.procedureType == ProceduresTypes.BoolNotEqual)
        str1 = "!=";
      if (this.procedureType == ProceduresTypes.BoolOR)
        str1 = " or ";
      if (this.procedureType == ProceduresTypes.BoolAND)
        str1 = " and ";
      if (str1 != "")
      {
        string str2 = this.procedureParams[0].GetPythonCode("") + str1 + this.procedureParams[1].GetPythonCode("");
        Procedure procedure = (Procedure) null;
        if (this.GetParent() != null && this.GetParent() is Procedure)
          procedure = this.GetParent() as Procedure;
        if (this.GetParent() != null && this.GetParent().GetParent() != null && this.GetParent().GetParent() is Procedure)
          procedure = this.GetParent().GetParent() as Procedure;
        return procedure != null && (procedure.ProcedureType == ProceduresTypes.MathDiv || procedure.ProcedureType == ProceduresTypes.MathMinus || (procedure.ProcedureType == ProceduresTypes.MathMod || procedure.ProcedureType == ProceduresTypes.MathMulti) || procedure.ProcedureType == ProceduresTypes.MathPlus) || procedure != null && (this.procedureType == ProceduresTypes.BoolAND || this.procedureType == ProceduresTypes.BoolOR) && (this.procedureType == ProceduresTypes.BoolAND || this.procedureType == ProceduresTypes.BoolOR) ? "(" + str2 + ")" : str2;
      }
      if (this.procedureType == ProceduresTypes.TurtleSee)
        return "rabbit.color";
      if (this.procedureType == ProceduresTypes.TurtleX)
        return "rabbit.x";
      return this.procedureType == ProceduresTypes.TurtleY ? "rabbit.y" : "NULL!!";
    }
  }
}
