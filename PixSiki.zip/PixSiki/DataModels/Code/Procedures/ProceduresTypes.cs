﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.Procedures.ProceduresTypes
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.DataModels.Code.Procedures
{
  public enum ProceduresTypes
  {
    GetPutPixel,
    GetPutImage,
    GetNumberOfColorsInRectangle,
    GetNumberOfColorsInX,
    GetNumberOfColorsInY,
    PutRectangleInColor,
    MathPlus,
    MathMinus,
    MathMulti,
    MathDiv,
    MathMod,
    GetColorFromRGB,
    GetR,
    GetG,
    GetB,
    TurtleX,
    TurtleY,
    TurtleSee,
    BoolAND,
    BoolOR,
    BoolEqual,
    BoolNotEqual,
    BoolLessThan,
    BoolLessOrEqual,
    BoolGreaterThan,
    BoolGreaterOrEqual,
  }
}
