﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.Value
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;

namespace PixBlocks.DataModels.Code
{
  public class Value
  {
    private long number;
    private bool boolean;
    private ValueType valueType;
    private int r;
    private int g;
    private int b;
    private string imageName;

    public long Number => this.number;

    public int R => this.r;

    public int G => this.g;

    public int B => this.b;

    public bool Bollean => this.boolean;

    public ValueType ValType => this.valueType;

    public string ImageName => this.imageName;

    internal void ResetValue()
    {
      this.number = 0L;
      this.r = 0;
      this.g = 0;
      this.b = 0;
      this.imageName = (string) null;
    }

    public Value(ValueType valueType) => this.valueType = valueType;

    public Value(Value input)
    {
      this.valueType = input.valueType;
      this.r = Math.Max(0, Math.Min(10, input.R));
      this.g = Math.Max(0, Math.Min(10, input.G));
      this.b = Math.Max(0, Math.Min(10, input.B));
      this.number = input.number;
      this.boolean = input.boolean;
      this.imageName = input.ImageName;
    }

    public Value() => this.valueType = ValueType.NULL;

    public Value(long n)
    {
      this.valueType = ValueType.Number;
      this.number = n;
    }

    public Value(int r, int g, int b)
    {
      this.valueType = ValueType.Color;
      this.r = r;
      this.g = g;
      this.b = b;
    }

    public Value(bool boolean)
    {
      this.valueType = ValueType.Boolean;
      this.boolean = boolean;
    }

    public bool IsEqual(Value v) => this.ValType == ValueType.Image || v.ValType == ValueType.Image ? this.R == v.R && this.G == v.G && this.B == v.B : this.ValType == v.ValType && (this.ValType == ValueType.Color && this.R == v.R && (this.G == v.G && this.B == v.B) || (this.ValType == ValueType.Number && this.Number == v.Number || this.ValType == ValueType.Boolean && this.boolean == v.boolean));

    public Value(string valToParse, ValueType valueType)
    {
      this.valueType = valueType;
      if (valueType == ValueType.Image)
      {
        this.imageName = valToParse;
        valueType = ValueType.Image;
        this.number = 0L;
        Value obj = PixBlocks.BlocksManager.BlocksManager.ColorFromBlockName(this.imageName);
        this.r = obj.R;
        this.g = obj.G;
        this.b = obj.B;
      }
      else if (valueType == ValueType.Boolean)
      {
        this.boolean = bool.Parse(valToParse);
      }
      else
      {
        string[] strArray = valToParse.Split("_"[0]);
        this.number = (long) int.Parse(strArray[0]);
        this.r = int.Parse(strArray[1]);
        this.g = int.Parse(strArray[2]);
        this.b = int.Parse(strArray[3]);
      }
    }

    public Value(string imageName)
    {
      this.imageName = imageName;
      this.valueType = ValueType.Image;
      this.number = 0L;
      Value obj = PixBlocks.BlocksManager.BlocksManager.ColorFromBlockName(imageName);
      this.r = obj.R;
      this.g = obj.G;
      this.b = obj.B;
    }

    internal string CovertToString()
    {
      if (this.valueType == ValueType.Image)
        return this.imageName;
      if (this.valueType == ValueType.Boolean)
        return this.boolean.ToString();
      return this.number.ToString() + "_" + this.r.ToString() + "_" + this.g.ToString() + "_" + this.b.ToString();
    }
  }
}
