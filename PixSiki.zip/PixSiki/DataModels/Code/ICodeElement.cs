﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.ICodeElement
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.CodeInputOutput;
using System.Collections.Generic;

namespace PixBlocks.DataModels.Code
{
  public interface ICodeElement
  {
    ValueType GetRetunType();

    Value RunInnerCode(Value v, CodeInOut inOut);

    ICodeElement GetParent();

    void SetParent(ICodeElement parent);

    string GetInternalCode(string spaces);

    string GetPythonCode(string spaces);

    void SetInternalCode(string code);

    bool IsInstruction();

    bool IsVaildOK();

    int NumberOfInnerCodeLines();

    List<ICodeElement> InnerCodeElements();

    ICodeElement GetNextInstructionAfter(ICodeElement instruction, CodeInOut inOut);

    string GetUniqueName();

    bool CanDragAndDropElement(ICodeElement element);

    bool GetIsTemplateElement();

    void PutIsTemplateElement(bool isTemplateElement);

    event CodeElementRunningStatus codeRunningStatusChanged;

    void SendCodeRunningStatusStart();

    void SendCodeRunningStatusStop();
  }
}
