﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.Variables.Variable
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Code.Procedures;
using PixBlocks.TemplateElementsGenerator;
using PixBlocks.Tools.CodeParser;
using System;
using System.Collections.Generic;

namespace PixBlocks.DataModels.Code.Variables
{
  public class Variable : ICodeElement
  {
    private Procedure innerProcedure;
    private VariableType variableType;
    private PixBlocks.DataModels.Code.ValueType valueType;
    private string name;
    private Value value;
    private ICodeElement parent;
    private bool isTemplateElement = true;
    private List<string> varCode;

    public Variable(VariableType variableType, PixBlocks.DataModels.Code.ValueType valueType)
    {
      this.variableType = variableType;
      this.valueType = valueType;
      this.value = new Value(valueType);
      this.name = "";
    }

    public Variable(VariableType variableType, PixBlocks.DataModels.Code.ValueType valueType, string name)
    {
      this.variableType = variableType;
      this.valueType = valueType;
      this.name = name.ToLower();
      this.value = new Value(valueType);
      name = "";
    }

    public Variable(VariableType variableType, Value value)
    {
      this.variableType = variableType;
      this.valueType = value.ValType;
      this.value = value;
      this.name = "";
    }

    public Variable(List<string> varCode)
    {
      this.varCode = varCode;
      Enum.TryParse<VariableType>(varCode[2], out this.variableType);
      Enum.TryParse<PixBlocks.DataModels.Code.ValueType>(varCode[3], out this.valueType);
      this.value = new Value(varCode[4], this.valueType);
      this.name = varCode[5].ToLower();
      List<ICodeElement> elementsList = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(varCode));
      if (elementsList.Count == 1)
        this.innerProcedure = (Procedure) elementsList[0];
      if (this.innerProcedure != null)
        this.innerProcedure.SetParent((ICodeElement) this);
      this.isTemplateElement = false;
    }

    public Variable(VariableType variableType, string imageName)
    {
      this.variableType = variableType;
      this.valueType = PixBlocks.DataModels.Code.ValueType.Image;
      this.value = new Value(imageName);
    }

    public string GetInternalCode(string spaces)
    {
      string str = "" + spaces + "{\r\n" + spaces + this.GetType().ToString() + "\r\n" + spaces + this.variableType.ToString() + "\r\n" + spaces + this.valueType.ToString() + "\r\n" + spaces + this.value.CovertToString() + "\r\n" + spaces + this.name + "\r\n" + spaces + "{\r\n";
      if (this.InnerProcedure != null)
        str += this.InnerProcedure.GetInternalCode(spaces + "  ");
      return str + spaces + "}\r\n" + spaces + "}\r\n";
    }

    public ICodeElement GetNextInstructionAfter(
      ICodeElement instruction,
      CodeInOut inOut)
    {
      return this.GetParent().GetNextInstructionAfter(instruction, inOut);
    }

    public ICodeElement GetParent() => this.parent;

    public PixBlocks.DataModels.Code.ValueType GetRetunType() => this.ValueType;

    public string GetUniqueName()
    {
      if (this.variableType == VariableType.constant)
      {
        if (this.valueType == PixBlocks.DataModels.Code.ValueType.Color)
          return "Color" + this.value.R.ToString() + "_" + this.value.G.ToString() + "_" + this.value.B.ToString();
        if (this.valueType == PixBlocks.DataModels.Code.ValueType.Number)
          return "Number" + this.value.Number.ToString();
        if (this.valueType == PixBlocks.DataModels.Code.ValueType.Image)
          return "Image" + this.value.ImageName;
      }
      return this.variableType == VariableType.variable ? "Variable_" + this.valueType.ToString() + this.name : this.variableType.ToString();
    }

    public List<ICodeElement> InnerCodeElements()
    {
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      codeElementList.Add((ICodeElement) this);
      if (this.InnerProcedure != null)
        codeElementList.AddRange((IEnumerable<ICodeElement>) this.InnerProcedure.InnerCodeElements());
      return codeElementList;
    }

    public bool IsInstruction() => false;

    public bool IsVaildOK()
    {
      if (this.VariableType == VariableType.epty)
        return false;
      return this.InnerProcedure == null || this.InnerProcedure.IsVaildOK();
    }

    public int NumberOfInnerCodeLines() => 0;

    public Value RunInnerCode(Value v, CodeInOut inOut)
    {
      if (this.VariableType == VariableType.procedure)
        return this.InnerProcedure.RunInnerCode(v, inOut);
      if (this.VariableType == VariableType.constant)
        return this.value;
      if (this.VariableType == VariableType.variable)
      {
        if (v == null)
          return inOut.CodeStaticVariables.GetVariableValue(this.Name);
        inOut.CodeStaticVariables.SetVariableValue(this.Name, v);
        return (Value) null;
      }
      if (this.VariableType == VariableType.epty)
        throw new Exception("cannot run empty variable!");
      if (this.VariableType == VariableType.imageHeight)
        return new Value((long) inOut.Image.GetHeight());
      return this.VariableType == VariableType.imageWidth ? new Value((long) inOut.Image.GetWidth()) : (Value) null;
    }

    public void SetInternalCode(string code) => throw new NotImplementedException();

    public VariableType VariableType => this.variableType;

    public PixBlocks.DataModels.Code.ValueType ValueType => this.valueType;

    public string Name => this.name;

    public Procedure InnerProcedure
    {
      get => this.innerProcedure;
      set => this.innerProcedure = value;
    }

    public void SetParent(ICodeElement parent) => this.parent = parent;

    public bool CanDragAndDropElement(ICodeElement element)
    {
      int variableType = (int) this.variableType;
      if (!element.GetIsTemplateElement() || this.GetIsTemplateElement())
        return false;
      switch (element)
      {
        case Variable _:
          Variable variable = (Variable) element;
          return variable.valueType == this.valueType && this.GetParent() != null && (!(this.GetParent() is AssigmentInstruction) || this != ((AssigmentInstruction) this.GetParent()).OutputElement || variable.VariableType == VariableType.variable) && (!(this.GetParent() is RepeatNTimes) || this != ((RepeatNTimes) this.GetParent()).StepVariable || variable.VariableType == VariableType.variable);
        case Procedure _:
          if (this.GetParent() is RepeatNTimes && this == ((RepeatNTimes) this.GetParent()).StepVariable || (element.GetRetunType() != this.GetRetunType() || this.GetParent() == null))
            return false;
          if (this.GetParent().IsInstruction())
          {
            if (this.GetParent() is AssigmentInstruction)
            {
              AssigmentInstruction parent = (AssigmentInstruction) this.GetParent();
              return (parent.OutputElement == null || parent.OutputElement != this || ((Procedure) element).GetSetType != GetSetType.Get) && (parent.InputElement == null || parent.InputElement != this || ((Procedure) element).GetSetType != GetSetType.Set);
            }
            return ((Procedure) element).GetSetType != GetSetType.Set;
          }
          return ((Procedure) element).GetSetType != GetSetType.Set;
        default:
          return false;
      }
    }

    public event Variable.RefreshView refreshingViewEvent;

    public event CodeElementRunningStatus codeRunningStatusChanged;

    internal void ReplaceThisVariableBy(ICodeElement codeElement)
    {
      if (codeElement is Variable)
      {
        Variable elementOfName = (Variable) new TemplateModelsGenerator().GetElementOFName(codeElement.GetUniqueName());
        elementOfName.PutIsTemplateElement(false);
        this.name = elementOfName.name;
        this.valueType = elementOfName.valueType;
        this.value = elementOfName.value;
        this.variableType = elementOfName.variableType;
        this.innerProcedure = elementOfName.innerProcedure;
        if (this.refreshingViewEvent != null)
          this.refreshingViewEvent();
      }
      if (!(codeElement is Procedure))
        return;
      Procedure procedure = (Procedure) codeElement;
      this.name = "";
      this.valueType = procedure.GetRetunType();
      this.value = new Value(this.valueType);
      this.variableType = VariableType.procedure;
      Procedure elementOfName1 = (Procedure) new TemplateModelsGenerator().GetElementOFName(procedure.GetUniqueName());
      elementOfName1.PutIsTemplateElement(false);
      this.innerProcedure = elementOfName1;
      if (this.refreshingViewEvent == null)
        return;
      this.refreshingViewEvent();
    }

    public bool GetIsTemplateElement() => this.isTemplateElement;

    public void PutIsTemplateElement(bool isTemplateElement) => this.isTemplateElement = isTemplateElement;

    public void SendCodeRunningStatusStart()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StartRuning);
    }

    public void SendCodeRunningStatusStop()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StopRuning);
    }

    public string GetPythonCode(string spaces)
    {
      if (this.variableType == VariableType.constant)
      {
        if (this.valueType == PixBlocks.DataModels.Code.ValueType.Color)
        {
          if (this.value.R == 0 && this.value.G == 0 && this.value.B == 0)
            return "colors.black";
          if (this.value.R == 10 && this.value.G == 10 && this.value.B == 10)
            return "colors.white";
          if (this.value.R == 10 && this.value.G == 0 && this.value.B == 0)
            return "colors.red";
          if (this.value.R == 0 && this.value.G == 10 && this.value.B == 0)
            return "colors.green";
          if (this.value.R == 0 && this.value.G == 0 && this.value.B == 10)
            return "colors.blue";
          if (this.value.R == 10 && this.value.G == 10 && this.value.B == 0)
            return "colors.yellow";
          if (this.value.R == 0 && this.value.G == 10 && this.value.B == 10)
            return "colors.cyan";
          if (this.value.R == 10 && this.value.G == 0 && this.value.B == 10)
            return "colors.magenta";
          return "colors.fromRedGreenBlue(" + this.value.R.ToString() + "," + this.value.G.ToString() + "," + this.value.B.ToString() + ")";
        }
        if (this.valueType == PixBlocks.DataModels.Code.ValueType.Number)
          return this.value.Number.ToString() ?? "";
      }
      if (this.variableType == VariableType.variable)
        return this.name;
      if (this.variableType == VariableType.imageHeight)
        return "image.height";
      if (this.variableType == VariableType.imageWidth)
        return "image.width";
      return this.variableType == VariableType.procedure ? this.innerProcedure.GetPythonCode("") : "NULL!!";
    }

    public delegate void RefreshView();
  }
}
