﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.Instructions.RepeatNTimes
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Tools.CodeParser;
using System;
using System.Collections.Generic;

namespace PixBlocks.DataModels.Code.Instructions
{
  public class RepeatNTimes : ICodeElement, ICodeInstructionBlock
  {
    private int iteratorN;
    private long maxNumberOfIteration;
    private RepeatNTimesType repeatNTimesType;
    private ICodeElement stepVariable;
    private ICodeElement numberOfIteration;
    private List<ICodeElement> blockInstructions = new List<ICodeElement>();
    private ICodeElement parent;
    private bool isTemplateElement = true;
    private List<string> codeLines;

    public long MaxNumberOfIteration => this.maxNumberOfIteration;

    public RepeatNTimes()
    {
      this.iteratorN = 0;
      this.numberOfIteration = (ICodeElement) new Variable(VariableType.constant, new Value(10L));
      this.numberOfIteration.SetParent((ICodeElement) this);
      this.RepeatNTimesType = RepeatNTimesType.classicLoop;
    }

    public RepeatNTimes(RepeatNTimesType repeatNTimesType)
    {
      this.iteratorN = 0;
      this.numberOfIteration = (ICodeElement) new Variable(VariableType.constant, new Value(10L));
      this.numberOfIteration.SetParent((ICodeElement) this);
      this.RepeatNTimesType = repeatNTimesType;
      if (repeatNTimesType != RepeatNTimesType.loopAndStep)
        return;
      this.stepVariable = (ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "A");
      this.stepVariable.SetParent((ICodeElement) this);
    }

    public RepeatNTimes(int N)
    {
      this.iteratorN = 0;
      this.numberOfIteration = (ICodeElement) new Variable(VariableType.constant, new Value((long) N));
      this.numberOfIteration.SetParent((ICodeElement) this);
      this.RepeatNTimesType = RepeatNTimesType.classicLoop;
    }

    public RepeatNTimes(List<string> codeLines)
    {
      this.codeLines = codeLines;
      if (Enum.TryParse<RepeatNTimesType>(codeLines[2], out this.repeatNTimesType))
      {
        this.stepVariable = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeLines))[0];
        this.stepVariable.SetParent((ICodeElement) this);
      }
      else
        this.repeatNTimesType = RepeatNTimesType.classicLoop;
      this.numberOfIteration = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeLines))[0];
      this.numberOfIteration.SetParent((ICodeElement) this);
      this.blockInstructions = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeLines));
      foreach (ICodeElement blockInstruction in this.blockInstructions)
        blockInstruction.SetParent((ICodeElement) this);
      this.isTemplateElement = false;
    }

    public void ResetIterator()
    {
      this.iteratorN = 0;
      if (this.iteratorChangedEvent == null)
        return;
      this.iteratorChangedEvent();
    }

    public bool CanDragAndDropElement(ICodeElement element) => false;

    public ICodeElement StepVariable
    {
      get => this.stepVariable;
      set => this.stepVariable = value;
    }

    public ICodeElement NumberOfIteration
    {
      get => this.numberOfIteration;
      set => this.numberOfIteration = value;
    }

    public event RepeatNTimes.IteratorChanged iteratorChangedEvent;

    public int IteratorN => this.iteratorN;

    public RepeatNTimesType RepeatNTimesType
    {
      get => this.repeatNTimesType;
      set => this.repeatNTimesType = value;
    }

    public string GetInternalCode(string spaces)
    {
      string str1 = "" + spaces + "{\r\n" + spaces + this.GetType().ToString() + "\r\n";
      if (this.repeatNTimesType == RepeatNTimesType.loopAndStep)
        str1 = str1 + spaces + this.repeatNTimesType.ToString() + "\r\n" + spaces + "{\r\n" + this.stepVariable.GetInternalCode(spaces + "  ") + spaces + "}\r\n";
      string str2 = str1 + spaces + "{\r\n" + this.numberOfIteration.GetInternalCode(spaces + "  ") + spaces + "}\r\n" + spaces + "{\r\n";
      foreach (ICodeElement blockInstruction in this.blockInstructions)
        str2 += blockInstruction.GetInternalCode(spaces + "  ");
      return str2 + spaces + "}\r\n" + spaces + "}\r\n";
    }

    public ICodeElement GetNextInstructionAfter(
      ICodeElement instruction,
      CodeInOut inOut)
    {
      if (this.iteratorN == 0)
        this.maxNumberOfIteration = this.numberOfIteration.RunInnerCode((Value) null, inOut).Number;
      if (this.maxNumberOfIteration <= 0L)
        return this.parent == null ? (ICodeElement) null : this.parent.GetNextInstructionAfter((ICodeElement) this, inOut);
      if (this.blockInstructions.Count == 0)
        return this.parent == null ? (ICodeElement) null : this.parent.GetNextInstructionAfter((ICodeElement) this, inOut);
      if (instruction == this)
      {
        this.iteratorN = 1;
        if (this.repeatNTimesType == RepeatNTimesType.loopAndStep)
          inOut.CodeStaticVariables.SetVariableValue((this.stepVariable as Variable).Name, new Value((long) this.iteratorN));
        if (this.iteratorChangedEvent != null)
          this.iteratorChangedEvent();
        return this.blockInstructions[0];
      }
      for (int index = 0; index < this.blockInstructions.Count; ++index)
      {
        if (this.blockInstructions[index] == instruction)
        {
          if (index < this.blockInstructions.Count - 1)
            return this.blockInstructions[index + 1];
          ++this.iteratorN;
          if (this.repeatNTimesType == RepeatNTimesType.loopAndStep)
            inOut.CodeStaticVariables.SetVariableValue((this.stepVariable as Variable).Name, new Value((long) this.iteratorN));
          if ((long) this.IteratorN <= this.maxNumberOfIteration)
          {
            if (this.iteratorChangedEvent != null)
              this.iteratorChangedEvent();
            return this.blockInstructions[0];
          }
          this.iteratorN = 0;
          if (this.repeatNTimesType == RepeatNTimesType.loopAndStep)
            inOut.CodeStaticVariables.SetVariableValue((this.stepVariable as Variable).Name, new Value((long) this.iteratorN));
          if (this.iteratorChangedEvent != null)
            this.iteratorChangedEvent();
          return this.parent == null ? (ICodeElement) null : this.parent.GetNextInstructionAfter((ICodeElement) this, inOut);
        }
      }
      return (ICodeElement) null;
    }

    public ICodeElement GetParent() => this.parent;

    public PixBlocks.DataModels.Code.ValueType GetRetunType() => PixBlocks.DataModels.Code.ValueType.NULL;

    public string GetUniqueName() => this.repeatNTimesType == RepeatNTimesType.classicLoop ? "repeatNtimes" : this.repeatNTimesType.ToString();

    public List<ICodeElement> InnerCodeElements()
    {
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      codeElementList.Add((ICodeElement) this);
      codeElementList.AddRange((IEnumerable<ICodeElement>) this.numberOfIteration.InnerCodeElements());
      if (this.repeatNTimesType == RepeatNTimesType.loopAndStep)
        codeElementList.AddRange((IEnumerable<ICodeElement>) this.stepVariable.InnerCodeElements());
      foreach (ICodeElement blockInstruction in this.blockInstructions)
        codeElementList.AddRange((IEnumerable<ICodeElement>) blockInstruction.InnerCodeElements());
      return codeElementList;
    }

    public bool IsInstruction() => true;

    public bool IsVaildOK()
    {
      if (!this.numberOfIteration.IsVaildOK())
        return false;
      foreach (ICodeElement blockInstruction in this.blockInstructions)
      {
        if (!blockInstruction.IsVaildOK())
          return false;
      }
      return true;
    }

    public int NumberOfInnerCodeLines()
    {
      int num = 1;
      foreach (ICodeElement blockInstruction in this.blockInstructions)
        num += blockInstruction.NumberOfInnerCodeLines();
      return num;
    }

    public Value RunInnerCode(Value v, CodeInOut inOut)
    {
      long number = this.numberOfIteration.RunInnerCode((Value) null, inOut).Number;
      for (int index = 0; (long) index < number; ++index)
      {
        foreach (ICodeElement blockInstruction in this.blockInstructions)
          blockInstruction.RunInnerCode((Value) null, inOut);
      }
      return (Value) null;
    }

    public void SetInternalCode(string code) => throw new NotImplementedException();

    public void SetParent(ICodeElement parent) => this.parent = parent;

    public List<ICodeElement> GetBlockElements() => this.blockInstructions;

    public event CodeElementRunningStatus codeRunningStatusChanged;

    public bool GetIsTemplateElement() => this.isTemplateElement;

    public void PutIsTemplateElement(bool isTemplateElement)
    {
      this.isTemplateElement = isTemplateElement;
      this.numberOfIteration.PutIsTemplateElement(isTemplateElement);
      if (this.repeatNTimesType != RepeatNTimesType.loopAndStep)
        return;
      this.stepVariable.PutIsTemplateElement(isTemplateElement);
    }

    public void SendCodeRunningStatusStart()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StartRuning);
    }

    public void SendCodeRunningStatusStop()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StopRuning);
    }

    public string GetPythonCode(string spaces)
    {
      string str1 = "" + spaces + "loop " + this.numberOfIteration.GetPythonCode("");
      if (this.repeatNTimesType == RepeatNTimesType.loopAndStep)
        str1 = str1 + " #" + this.stepVariable.GetPythonCode("");
      string str2 = str1 + ":" + "\r\n";
      foreach (ICodeElement blockInstruction in this.blockInstructions)
        str2 += blockInstruction.GetPythonCode(spaces + " ");
      return str2;
    }

    public bool TryToAddBlockElement(ICodeElement newBlockElement)
    {
      if (newBlockElement is AssigmentInstruction && (newBlockElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ElseSign)
        return false;
      this.GetBlockElements().Add(newBlockElement);
      return true;
    }

    public delegate void IteratorChanged();
  }
}
