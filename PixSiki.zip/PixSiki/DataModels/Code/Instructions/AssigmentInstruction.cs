﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.Instructions.AssigmentInstruction
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.SoundPlayer.SoundPlayer.Effects;
using PixBlocks.Tools.CodeParser;
using PixBlocks.Tools.ColorTransformation;
using System;
using System.Collections.Generic;
using System.Windows.Media;

namespace PixBlocks.DataModels.Code.Instructions
{
  public class AssigmentInstruction : ICodeElement
  {
    private ICodeElement inputElement;
    private ICodeElement outputElement;
    private AssigmentInstructionType type;
    private ICodeElement parent;
    private bool isTemplateElement = true;
    private List<string> codeBlock;

    public ICodeElement InputElement
    {
      get => this.inputElement;
      set => this.inputElement = value;
    }

    public ICodeElement OutputElement
    {
      get => this.outputElement;
      set => this.outputElement = value;
    }

    public AssigmentInstructionType TypeOfAssigment => this.type;

    public AssigmentInstruction(AssigmentInstructionType type)
    {
      this.type = type;
      if (type == AssigmentInstructionType.PlaySound)
        this.inputElement = (ICodeElement) new Variable(VariableType.constant, new Value(1L));
      if (type == AssigmentInstructionType.ClassicAssigmentColor)
      {
        this.inputElement = (ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Blue));
        this.outputElement = (ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Color, "C1");
      }
      if (type == AssigmentInstructionType.ClassicAssigmentImage)
        this.outputElement = (ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Image, "b1");
      if (type == AssigmentInstructionType.ClassicAssigmentImage2Image)
      {
        this.inputElement = (ICodeElement) new Variable(VariableType.constant, "cactus");
        this.outputElement = (ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Image, "b1");
      }
      if (type == AssigmentInstructionType.ClassicAssigmentNumber)
      {
        this.inputElement = (ICodeElement) new Variable(VariableType.constant, new Value(0L));
        this.outputElement = (ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "A");
      }
      if (type == AssigmentInstructionType.DrawTurtleColor)
        this.inputElement = (ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Blue));
      if (type == AssigmentInstructionType.DrawTurtleImage)
        this.inputElement = (ICodeElement) new Variable(VariableType.constant, "cactus");
      if (this.inputElement != null)
        this.inputElement.SetParent((ICodeElement) this);
      if (this.outputElement == null)
        return;
      this.outputElement.SetParent((ICodeElement) this);
    }

    public AssigmentInstruction(List<string> codeBlock)
    {
      this.codeBlock = codeBlock;
      Enum.TryParse<AssigmentInstructionType>(codeBlock[2], out this.type);
      List<ICodeElement> elementsList1 = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeBlock));
      if (elementsList1.Count == 1)
        this.inputElement = elementsList1[0];
      List<ICodeElement> elementsList2 = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeBlock));
      if (elementsList2.Count == 1)
        this.outputElement = elementsList2[0];
      if (this.inputElement != null)
        this.inputElement.SetParent((ICodeElement) this);
      if (this.outputElement != null)
        this.outputElement.SetParent((ICodeElement) this);
      this.isTemplateElement = false;
    }

    public string GetInternalCode(string spaces)
    {
      string str1 = "" + spaces + "{\r\n" + spaces + this.GetType().ToString() + "\r\n" + spaces + this.type.ToString() + "\r\n" + spaces + "{\r\n";
      if (this.inputElement != null)
        str1 += this.inputElement.GetInternalCode(spaces + "  ");
      string str2 = str1 + spaces + "}\r\n" + spaces + "{\r\n";
      if (this.outputElement != null)
        str2 += this.outputElement.GetInternalCode(spaces + "  ");
      return str2 + spaces + "}\r\n" + spaces + "}\r\n";
    }

    public ICodeElement GetNextInstructionAfter(
      ICodeElement instruction,
      CodeInOut inOut)
    {
      return this.TypeOfAssigment == AssigmentInstructionType.BreakAll ? (ICodeElement) null : this.GetParent().GetNextInstructionAfter((ICodeElement) this, inOut);
    }

    public void SetParent(ICodeElement parent)
    {
      this.parent = (ICodeElement) null;
      this.parent = parent;
    }

    public ICodeElement GetParent() => this.parent;

    public PixBlocks.DataModels.Code.ValueType GetRetunType() => PixBlocks.DataModels.Code.ValueType.NULL;

    public string GetUniqueName() => this.type.ToString();

    public List<ICodeElement> InnerCodeElements()
    {
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      codeElementList.Add((ICodeElement) this);
      if (this.outputElement != null)
        codeElementList.AddRange((IEnumerable<ICodeElement>) this.outputElement.InnerCodeElements());
      if (this.inputElement != null)
        codeElementList.AddRange((IEnumerable<ICodeElement>) this.inputElement.InnerCodeElements());
      return codeElementList;
    }

    public bool IsInstruction() => true;

    public bool IsVaildOK() => this.outputElement.IsVaildOK() && this.inputElement.IsVaildOK();

    public int NumberOfInnerCodeLines() => 1;

    public void SetInternalCode(string code) => throw new NotImplementedException();

    public Value RunInnerCode(Value v, CodeInOut inOut)
    {
      if (this.type == AssigmentInstructionType.ClassicAssigmentColor || this.type == AssigmentInstructionType.ClassicAssigmentNumber || this.type == AssigmentInstructionType.ClassicAssigmentImage2Image)
        return this.outputElement.RunInnerCode(this.inputElement.RunInnerCode((Value) null, inOut), inOut);
      if (this.type == AssigmentInstructionType.ClassicAssigmentImage)
        return this.outputElement.RunInnerCode(inOut.Image.GetPixelColor(inOut.TurtleX, inOut.TurtleY), inOut);
      if (this.type == AssigmentInstructionType.PlaySound)
        EffectsPlayer.Instance.PlayBlocksSound(this.inputElement.RunInnerCode((Value) null, inOut).Number);
      if (this.type == AssigmentInstructionType.TurtleDown)
        --inOut.TurtleY;
      if (this.type == AssigmentInstructionType.TurtleLeft)
        --inOut.TurtleX;
      if (this.type == AssigmentInstructionType.TurtleTop)
        ++inOut.TurtleY;
      if (this.type == AssigmentInstructionType.TurtleRight)
        ++inOut.TurtleX;
      if (this.type == AssigmentInstructionType.DrawTurtleColor || this.type == AssigmentInstructionType.DrawTurtleImage)
        inOut.Image.PutPixel(inOut.TurtleX, inOut.TurtleY, this.inputElement.RunInnerCode((Value) null, inOut));
      return (Value) null;
    }

    public bool CanDragAndDropElement(ICodeElement element) => false;

    public event CodeElementRunningStatus codeRunningStatusChanged;

    public bool GetIsTemplateElement() => this.isTemplateElement;

    public void PutIsTemplateElement(bool isTemplateElement)
    {
      this.isTemplateElement = isTemplateElement;
      if (this.inputElement != null)
        this.inputElement.PutIsTemplateElement(isTemplateElement);
      if (this.outputElement == null)
        return;
      this.outputElement.PutIsTemplateElement(isTemplateElement);
    }

    public void SendCodeRunningStatusStart()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StartRuning);
    }

    public void SendCodeRunningStatusStop()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StopRuning);
    }

    public string GetPythonCode(string spaces)
    {
      string str = "" + spaces;
      if (this.TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage || this.TypeOfAssigment == AssigmentInstructionType.DrawTurtleImage || this.TypeOfAssigment == AssigmentInstructionType.ClassicAssigmentImage2Image)
        return "IMAGES not supported in Python";
      if (this.TypeOfAssigment == AssigmentInstructionType.PlaySound)
        return "SOUND nod supported in Python";
      if (this.TypeOfAssigment == AssigmentInstructionType.BreakAll)
        return spaces + "return\r\n";
      if (this.TypeOfAssigment == AssigmentInstructionType.DrawTurtleColor)
        return spaces + "rabbit.color=" + this.inputElement.GetPythonCode("") + "\r\n";
      if (this.TypeOfAssigment == AssigmentInstructionType.TurtleDown)
        return spaces + "rabbit.goDown()\r\n";
      if (this.TypeOfAssigment == AssigmentInstructionType.TurtleTop)
        return spaces + "rabbit.goUp()\r\n";
      if (this.TypeOfAssigment == AssigmentInstructionType.TurtleLeft)
        return spaces + "rabbit.goLeft()\r\n";
      if (this.TypeOfAssigment == AssigmentInstructionType.TurtleRight)
        return spaces + "rabbit.goRight()\r\n";
      if (this.inputElement != null)
        str += this.outputElement.GetPythonCode("");
      if (this.outputElement != null)
        str = str + "=" + this.inputElement.GetPythonCode("");
      return str + "\r\n";
    }
  }
}
