﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.Instructions.IfThenInstruction
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.CodeInputOutput;
using PixBlocks.DataModels.Code.Variables;
using PixBlocks.Tools.CodeParser;
using PixBlocks.Tools.ColorTransformation;
using System;
using System.Collections.Generic;
using System.Windows.Media;

namespace PixBlocks.DataModels.Code.Instructions
{
  public class IfThenInstruction : ICodeElement, ICodeInstructionBlock
  {
    private IfThenInstructionType ifThenInstructionType;
    private List<ICodeElement> arguments = new List<ICodeElement>();
    private List<ICodeElement> instructionBlock = new List<ICodeElement>();
    private List<ICodeElement> elseInstructionBlock = new List<ICodeElement>();
    private ICodeElement parent;
    private bool? conditionIsOk;
    private bool isTemplateElement = true;
    private List<string> codeBlock;
    private int elseBlocksCounter;

    public IfThenInstructionType IfThenInstructionType => this.ifThenInstructionType;

    public List<ICodeElement> Arguments => this.arguments;

    public IfThenInstruction(IfThenInstructionType ifThenInstructionType)
    {
      this.arguments = new List<ICodeElement>();
      this.ifThenInstructionType = ifThenInstructionType;
      if (ifThenInstructionType == IfThenInstructionType.BooleanInstruction)
        this.arguments.Add((ICodeElement) new Variable(VariableType.constant, new Value(true)));
      if (ifThenInstructionType == IfThenInstructionType.TurtleSeeColor)
        this.arguments.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Blue)));
      if (ifThenInstructionType == IfThenInstructionType.TurtleSeeImage)
        this.arguments.Add((ICodeElement) new Variable(VariableType.constant, "cactus"));
      if (ifThenInstructionType == IfThenInstructionType.EqualsImages || ifThenInstructionType == IfThenInstructionType.NotEqualsImages)
      {
        this.arguments.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Image, "b1"));
        this.arguments.Add((ICodeElement) new Variable(VariableType.constant, "cactus"));
      }
      if (ifThenInstructionType == IfThenInstructionType.EqualsColors || ifThenInstructionType == IfThenInstructionType.NotEqualsColors)
      {
        this.arguments.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Color, "C1"));
        this.arguments.Add((ICodeElement) new Variable(VariableType.constant, ColorTransorm.GetValueFromColor(Colors.Blue)));
      }
      if (ifThenInstructionType == IfThenInstructionType.EqualsNumbers || ifThenInstructionType == IfThenInstructionType.NotEqualsNumbers || (ifThenInstructionType == IfThenInstructionType.Greater || ifThenInstructionType == IfThenInstructionType.GreaterEquals) || (ifThenInstructionType == IfThenInstructionType.Less || ifThenInstructionType == IfThenInstructionType.LessEqals))
      {
        this.arguments.Add((ICodeElement) new Variable(VariableType.variable, PixBlocks.DataModels.Code.ValueType.Number, "A"));
        this.arguments.Add((ICodeElement) new Variable(VariableType.constant, new Value(0L)));
      }
      foreach (ICodeElement codeElement in this.arguments)
        codeElement.SetParent((ICodeElement) this);
    }

    public IfThenInstruction(List<string> codeBlock)
    {
      this.codeBlock = codeBlock;
      Enum.TryParse<IfThenInstructionType>(codeBlock[2], out this.ifThenInstructionType);
      this.arguments = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeBlock));
      this.instructionBlock = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeBlock));
      foreach (ICodeElement codeElement in this.arguments)
        codeElement.SetParent((ICodeElement) this);
      foreach (ICodeElement codeElement in this.instructionBlock)
        codeElement.SetParent((ICodeElement) this);
      if (codeBlock.Count > 0)
      {
        this.elseInstructionBlock = CodeStringParser.GetElementsList(CodeStringParser.GetFirstChildBlockAndRemoveBlock(codeBlock));
        foreach (ICodeElement codeElement in this.elseInstructionBlock)
          codeElement.SetParent((ICodeElement) this);
      }
      else
        this.elseInstructionBlock = new List<ICodeElement>();
      this.isTemplateElement = false;
    }

    public bool CanDragAndDropElement(ICodeElement element) => element == this;

    public string GetInternalCode(string spaces)
    {
      string str1 = "" + spaces + "{\r\n" + spaces + this.GetType().ToString() + "\r\n" + spaces + this.ifThenInstructionType.ToString() + "\r\n" + spaces + "{\r\n";
      foreach (ICodeElement codeElement in this.arguments)
        str1 += codeElement.GetInternalCode(spaces + "  ");
      string str2 = str1 + spaces + "}\r\n" + spaces + "{\r\n";
      foreach (ICodeElement codeElement in this.instructionBlock)
        str2 += codeElement.GetInternalCode(spaces + "  ");
      string str3 = str2 + spaces + "}\r\n";
      if (this.elseInstructionBlock.Count > 0)
      {
        string str4 = str3 + spaces + "{\r\n";
        foreach (ICodeElement codeElement in this.elseInstructionBlock)
          str4 += codeElement.GetInternalCode(spaces + "  ");
        str3 = str4 + spaces + "}\r\n";
      }
      return str3 + spaces + "}\r\n";
    }

    public ICodeElement GetNextInstructionAfter(
      ICodeElement instruction,
      CodeInOut inOut)
    {
      if (instruction == this)
      {
        if (this.conditionIsOk.Value)
        {
          this.conditionIsOk = new bool?();
          return this.instructionBlock.Count > 0 ? this.instructionBlock[0] : this.parent.GetNextInstructionAfter((ICodeElement) this, inOut);
        }
        if (this.elseInstructionBlock.Count > 0)
        {
          this.conditionIsOk = new bool?();
          return this.elseInstructionBlock[0];
        }
        this.conditionIsOk = new bool?();
        return this.parent.GetNextInstructionAfter((ICodeElement) this, inOut);
      }
      for (int index = 0; index < this.instructionBlock.Count; ++index)
      {
        if (this.instructionBlock[index] == instruction)
          return index < this.instructionBlock.Count - 1 ? this.instructionBlock[index + 1] : this.parent.GetNextInstructionAfter((ICodeElement) this, inOut);
      }
      for (int index = 0; index < this.elseInstructionBlock.Count; ++index)
      {
        if (this.elseInstructionBlock[index] == instruction)
          return index < this.elseInstructionBlock.Count - 1 ? this.elseInstructionBlock[index + 1] : this.parent.GetNextInstructionAfter((ICodeElement) this, inOut);
      }
      throw new Exception("Cannot Find NextInstruction");
    }

    public void CheckIfConditionIsOK(CodeInOut inOut) => this.conditionIsOk = new bool?(this.IsIfThenConditionOK(inOut));

    private bool IsIfThenConditionOK(CodeInOut inOut)
    {
      if (this.ifThenInstructionType == IfThenInstructionType.BooleanInstruction)
      {
        if (this.arguments[0].GetRetunType() != PixBlocks.DataModels.Code.ValueType.Boolean)
          throw new Exception("ifelse nie ma boolowskiego typu argumentu!!");
        return this.arguments[0].RunInnerCode((Value) null, inOut).Bollean;
      }
      if (this.ifThenInstructionType == IfThenInstructionType.TurtleSeeColor || this.ifThenInstructionType == IfThenInstructionType.TurtleSeeImage)
        return inOut.Image.GetPixelColor(inOut.TurtleX, inOut.TurtleY).IsEqual(this.arguments[0].RunInnerCode((Value) null, inOut));
      Value obj = this.arguments[0].RunInnerCode((Value) null, inOut);
      Value v = this.arguments[1].RunInnerCode((Value) null, inOut);
      return this.ifThenInstructionType == IfThenInstructionType.EqualsColors || this.ifThenInstructionType == IfThenInstructionType.EqualsNumbers || this.IfThenInstructionType == IfThenInstructionType.EqualsImages ? obj.IsEqual(v) : (this.ifThenInstructionType == IfThenInstructionType.NotEqualsNumbers || this.ifThenInstructionType == IfThenInstructionType.NotEqualsColors || this.ifThenInstructionType == IfThenInstructionType.NotEqualsImages ? !obj.IsEqual(v) : (this.ifThenInstructionType == IfThenInstructionType.Less ? obj.Number < v.Number : (this.ifThenInstructionType == IfThenInstructionType.LessEqals ? obj.Number <= v.Number : (this.ifThenInstructionType == IfThenInstructionType.Greater ? obj.Number > v.Number : this.ifThenInstructionType == IfThenInstructionType.GreaterEquals && obj.Number >= v.Number))));
    }

    public ICodeElement GetParent() => this.parent;

    public PixBlocks.DataModels.Code.ValueType GetRetunType() => PixBlocks.DataModels.Code.ValueType.NULL;

    public string GetUniqueName() => this.ifThenInstructionType.ToString();

    public List<ICodeElement> InnerCodeElements()
    {
      List<ICodeElement> codeElementList = new List<ICodeElement>();
      codeElementList.Add((ICodeElement) this);
      foreach (ICodeElement codeElement in this.arguments)
        codeElementList.AddRange((IEnumerable<ICodeElement>) codeElement.InnerCodeElements());
      foreach (ICodeElement codeElement in this.instructionBlock)
        codeElementList.AddRange((IEnumerable<ICodeElement>) codeElement.InnerCodeElements());
      if (this.elseInstructionBlock.Count > 0 || this.elseBlocksCounter > 0)
        codeElementList.Add((ICodeElement) new AssigmentInstruction(AssigmentInstructionType.ElseSign));
      foreach (ICodeElement codeElement in this.elseInstructionBlock)
        codeElementList.AddRange((IEnumerable<ICodeElement>) codeElement.InnerCodeElements());
      return codeElementList;
    }

    public bool IsInstruction() => true;

    public bool IsVaildOK()
    {
      foreach (ICodeElement codeElement in this.arguments)
      {
        if (!codeElement.IsVaildOK())
          return false;
      }
      foreach (ICodeElement codeElement in this.instructionBlock)
      {
        if (!codeElement.IsVaildOK())
          return false;
      }
      foreach (ICodeElement codeElement in this.elseInstructionBlock)
      {
        if (!codeElement.IsVaildOK())
          return false;
      }
      return true;
    }

    public int NumberOfInnerCodeLines()
    {
      int num = 1;
      foreach (ICodeElement codeElement in this.instructionBlock)
        num += codeElement.NumberOfInnerCodeLines();
      foreach (ICodeElement codeElement in this.elseInstructionBlock)
        num += codeElement.NumberOfInnerCodeLines();
      if (this.elseInstructionBlock.Count > 0)
        ++num;
      return num;
    }

    public Value RunInnerCode(Value v, CodeInOut inOut)
    {
      if (this.IsIfThenConditionOK(inOut))
      {
        foreach (ICodeElement codeElement in this.instructionBlock)
          codeElement.RunInnerCode((Value) null, inOut);
      }
      else
      {
        foreach (ICodeElement codeElement in this.elseInstructionBlock)
          codeElement.RunInnerCode((Value) null, inOut);
      }
      return (Value) null;
    }

    public void SetInternalCode(string code) => throw new NotImplementedException();

    public void SetParent(ICodeElement parent) => this.parent = parent;

    public List<ICodeElement> GetBlockElements() => this.instructionBlock;

    public List<ICodeElement> GetElseBlockElements() => this.elseInstructionBlock;

    public event CodeElementRunningStatus codeRunningStatusChanged;

    public bool GetIsTemplateElement() => this.isTemplateElement;

    public void PutIsTemplateElement(bool isTemplateElement)
    {
      this.isTemplateElement = isTemplateElement;
      foreach (ICodeElement codeElement in this.instructionBlock)
        codeElement.PutIsTemplateElement(isTemplateElement);
      foreach (ICodeElement codeElement in this.elseInstructionBlock)
        codeElement.PutIsTemplateElement(isTemplateElement);
      foreach (ICodeElement codeElement in this.arguments)
        codeElement.PutIsTemplateElement(isTemplateElement);
    }

    public void SendCodeRunningStatusStart()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StartRuning);
    }

    public void SendCodeRunningStatusStop()
    {
      if (this.codeRunningStatusChanged == null)
        return;
      this.codeRunningStatusChanged(RunningStatus.StopRuning);
    }

    public string GetPythonCode(string spaces)
    {
      string str1 = "" + spaces + "if ";
      if (this.ifThenInstructionType == IfThenInstructionType.TurtleSeeImage || this.ifThenInstructionType == IfThenInstructionType.EqualsImages || this.ifThenInstructionType == IfThenInstructionType.NotEqualsImages)
        return "IMAGES not supported in Python";
      string str2;
      if (this.ifThenInstructionType == IfThenInstructionType.TurtleSeeColor || this.ifThenInstructionType == IfThenInstructionType.BooleanInstruction)
      {
        if (this.ifThenInstructionType == IfThenInstructionType.TurtleSeeColor)
          str1 += "rabbit.color == ";
        str2 = str1 + this.arguments[0].GetPythonCode("");
      }
      else
      {
        string str3 = str1 + this.arguments[0].GetPythonCode("");
        if (this.IfThenInstructionType == IfThenInstructionType.EqualsColors || this.IfThenInstructionType == IfThenInstructionType.EqualsNumbers)
          str3 += "==";
        if (this.IfThenInstructionType == IfThenInstructionType.NotEqualsColors || this.IfThenInstructionType == IfThenInstructionType.NotEqualsNumbers)
          str3 += "!=";
        if (this.IfThenInstructionType == IfThenInstructionType.Greater)
          str3 += ">";
        if (this.IfThenInstructionType == IfThenInstructionType.GreaterEquals)
          str3 += ">=";
        if (this.IfThenInstructionType == IfThenInstructionType.Less)
          str3 += "<";
        if (this.IfThenInstructionType == IfThenInstructionType.LessEqals)
          str3 += "<=";
        str2 = str3 + this.arguments[1].GetPythonCode("");
      }
      string str4 = str2 + ":" + "\r\n";
      foreach (ICodeElement codeElement in this.instructionBlock)
        str4 += codeElement.GetPythonCode(spaces + " ");
      if (this.elseInstructionBlock.Count > 0)
      {
        str4 = str4 + spaces + "else:\r\n";
        foreach (ICodeElement codeElement in this.elseInstructionBlock)
          str4 += codeElement.GetPythonCode(spaces + " ");
      }
      return str4;
    }

    public bool TryToAddBlockElement(ICodeElement newBlockElement)
    {
      if (newBlockElement is AssigmentInstruction && (newBlockElement as AssigmentInstruction).TypeOfAssigment == AssigmentInstructionType.ElseSign)
      {
        ++this.elseBlocksCounter;
        return this.elseBlocksCounter <= 1;
      }
      if (this.elseBlocksCounter == 0)
      {
        this.GetBlockElements().Add(newBlockElement);
        return true;
      }
      if (this.elseBlocksCounter != 1)
        return false;
      this.GetElseBlockElements().Add(newBlockElement);
      return true;
    }
  }
}
