﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.CodeElementRunningStatus
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.DataModels.Code
{
  public delegate void CodeElementRunningStatus(RunningStatus runningStatus);
}
