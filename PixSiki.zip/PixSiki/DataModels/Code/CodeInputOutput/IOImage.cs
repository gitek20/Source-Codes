﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.CodeInputOutput.IOImage
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Tools.ColorTransformation;
using System;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PixBlocks.DataModels.Code.CodeInputOutput
{
  public class IOImage
  {
    private WriteableBitmap bitmap;
    private Color fillColor;
    private int width;
    private int height;
    private bool imageIsReseted;
    private bool invokeEvents = true;
    private string fileName;
    private byte[] byteArray;

    public event IOImage.RectWasModified rectModificationEvent;

    public WriteableBitmap BitmapIO
    {
      get => this.bitmap;
      set => this.bitmap = value;
    }

    public IOImage(int width, int height, Color fillColor)
    {
      this.fillColor = fillColor;
      this.width = width;
      this.height = height;
      this.bitmap = BitmapFactory.New(width, height);
      this.ResetImage();
    }

    public int GetHeight() => this.height;

    public int GetWidth() => this.width;

    internal void ResetImage()
    {
      if (this.imageIsReseted)
        return;
      this.imageIsReseted = true;
      if (this.fileName != null)
        this.LoadFromFile(this.fileName);
      else if (this.byteArray != null)
      {
        this.bitmap.FromByteArray(this.byteArray);
      }
      else
      {
        Color fillColor = this.fillColor;
        this.bitmap.Clear(this.fillColor);
      }
    }

    internal int GetNumberOfColorsInRectangle(int x1, int y1, int x2, int y2, Value color)
    {
      int num1 = Math.Max(1, Math.Min(x1, x2));
      int num2 = Math.Min(this.width, Math.Max(x1, x2));
      int num3 = Math.Max(1, Math.Min(y1, y2));
      int num4 = Math.Min(this.height, Math.Max(y1, y2));
      if (num1 > num2 || num3 > num4)
        return 0;
      if (this.InvokeEvents && this.rectModificationEvent != null)
        this.rectModificationEvent(new IOImage.ModificationRectangle(false, num2 - num1 + 1, num4 - num3 + 1, num1 - 1, num3 - 1));
      this.InvokeEvents = false;
      int num5 = 0;
      for (int x = Math.Min(x1, x2); x <= Math.Max(x1, x2); ++x)
      {
        for (int y = Math.Min(y1, y2); y <= Math.Max(y1, y2); ++y)
        {
          if (color.IsEqual(this.GetPixelColor(x, y)))
            ++num5;
        }
      }
      this.InvokeEvents = true;
      return num5;
    }

    internal Value GetPixelColor(int x, int y)
    {
      --x;
      y = this.height - y;
      if (x < 0 || y < 0 || (y >= this.height || x >= this.width))
        return new Value(0, 0, 0);
      using (this.bitmap.GetBitmapContext())
      {
        if (this.InvokeEvents && this.rectModificationEvent != null)
          this.rectModificationEvent(new IOImage.ModificationRectangle(false, 1, 1, x, this.height - (y + 1)));
        return ColorTransorm.GetValueFromColor(this.bitmap.GetPixel(x, y));
      }
    }

    public bool InvokeEvents
    {
      get => this.invokeEvents;
      set => this.invokeEvents = value;
    }

    internal void PutPixel(int x, int y, Value v)
    {
      this.imageIsReseted = false;
      --x;
      y = this.height - y;
      if (x < 0 || y < 0 || (y >= this.height || x >= this.width))
        return;
      using (this.bitmap.GetBitmapContext())
      {
        this.bitmap.SetPixel(x, y, ColorTransorm.GetColorFromValue(v));
        if (!this.InvokeEvents || this.rectModificationEvent == null)
          return;
        this.rectModificationEvent(new IOImage.ModificationRectangle(true, 1, 1, x, this.height - (y + 1)));
      }
    }

    internal void PutRectangleInColor(int x1, int y1, int x2, int y2, Value color)
    {
      int num1 = Math.Max(1, Math.Min(x1, x2));
      int num2 = Math.Min(this.width, Math.Max(x1, x2));
      int num3 = Math.Max(1, Math.Min(y1, y2));
      int num4 = Math.Min(this.height, Math.Max(y1, y2));
      if (num1 > num2 || num3 > num4)
        return;
      if (this.InvokeEvents && this.rectModificationEvent != null)
        this.rectModificationEvent(new IOImage.ModificationRectangle(true, num2 - num1 + 1, num4 - num3 + 1, num1 - 1, num3 - 1));
      this.InvokeEvents = false;
      for (int x = Math.Min(x1, x2); x <= Math.Max(x1, x2); ++x)
      {
        for (int y = Math.Min(y1, y2); y <= Math.Max(y1, y2); ++y)
          this.PutPixel(x, y, color);
      }
      this.InvokeEvents = true;
    }

    internal bool IsSameAs(IOImage image)
    {
      this.InvokeEvents = false;
      image.InvokeEvents = false;
      for (int index1 = 0; index1 < this.width; ++index1)
      {
        for (int index2 = 0; index2 < this.height; ++index2)
        {
          if (!this.GetPixelColor(index1 + 1, index2 + 1).IsEqual(image.GetPixelColor(index1 + 1, index2 + 1)))
            return false;
        }
      }
      image.InvokeEvents = true;
      this.InvokeEvents = true;
      return true;
    }

    public event IOImage.ImageLoadedFromFile imageLoaded;

    public void TransformBitmapColors()
    {
      this.InvokeEvents = false;
      for (int index1 = 0; index1 < this.width; ++index1)
      {
        for (int index2 = 0; index2 < this.height; ++index2)
          this.PutPixel(index1 + 1, index2 + 1, this.GetPixelColor(index1 + 1, index2 + 1));
      }
      this.InvokeEvents = true;
    }

    public void LoadFromBase64(string base64, int width, int height)
    {
      this.imageIsReseted = true;
      this.width = width;
      this.height = height;
      this.InvokeEvents = false;
      this.bitmap = BitmapFactory.New(width, height);
      this.byteArray = Convert.FromBase64String(base64);
      this.bitmap.FromByteArray(this.byteArray);
      if (this.imageLoaded != null)
        this.imageLoaded();
      this.InvokeEvents = true;
    }

    public string ConvertToBase64() => Convert.ToBase64String(this.bitmap.ToByteArray());

    internal void LoadFromFile(string v)
    {
      this.InvokeEvents = false;
      this.fileName = v;
      this.bitmap = new WriteableBitmap((BitmapSource) new BitmapImage(new Uri(v, UriKind.Relative)));
      this.width = (int) (this.bitmap.Width + 0.5);
      this.height = (int) (this.bitmap.Height + 0.5);
      if (this.imageLoaded != null)
        this.imageLoaded();
      this.TransformBitmapColors();
      this.InvokeEvents = true;
    }

    public class ModificationRectangle
    {
      private bool isWriting;
      private int width;
      private int height;
      private int xLeft;
      private int yBotton;

      public ModificationRectangle(bool isWriting, int width, int height, int xLeft, int yBotton)
      {
        this.isWriting = isWriting;
        this.width = width;
        this.height = height;
        this.xLeft = xLeft;
        this.yBotton = yBotton;
      }

      public bool IsWriting => this.isWriting;

      public int Width => this.width;

      public int Height => this.height;

      public int XLeft => this.xLeft;

      public int YBotton => this.yBotton;
    }

    public delegate void RectWasModified(IOImage.ModificationRectangle modRect);

    public delegate void ImageLoadedFromFile();
  }
}
