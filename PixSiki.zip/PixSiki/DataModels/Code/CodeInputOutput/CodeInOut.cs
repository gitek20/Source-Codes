﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.CodeInputOutput.CodeInOut
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.CodeInputOutput.Variables;
using System;
using System.Windows.Media;

namespace PixBlocks.DataModels.Code.CodeInputOutput
{
  public class CodeInOut
  {
    private CodeStaticVariables codeStaticVariables;
    private IOImage image;
    private int turtleX = 1;
    private int turtleY = 1;

    public CodeInOut()
    {
      this.codeStaticVariables = new CodeStaticVariables();
      this.image = new IOImage(1, 1, Colors.Black);
    }

    internal CodeStaticVariables CodeStaticVariables => this.codeStaticVariables;

    internal IOImage Image => this.image;

    internal void ResetAll()
    {
      this.CodeStaticVariables.ResetAll();
      this.TurtleX = 1;
      this.TurtleY = 1;
      this.image.ResetImage();
    }

    public event CodeInOut.TurtlePositionChanged turleChangedEvent;

    public int TurtleX
    {
      get => this.turtleX;
      set
      {
        this.turtleX = Math.Max(1, Math.Min(this.image.GetWidth(), value));
        if (this.turleChangedEvent == null)
          return;
        this.turleChangedEvent();
      }
    }

    public int TurtleY
    {
      get => this.turtleY;
      set
      {
        this.turtleY = Math.Max(1, Math.Min(this.image.GetHeight(), value));
        if (this.turleChangedEvent == null)
          return;
        this.turleChangedEvent();
      }
    }

    public delegate void TurtlePositionChanged();
  }
}
