﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.CodeInputOutput.Variables.CodeStaticVariables
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System.Collections.Generic;

namespace PixBlocks.DataModels.Code.CodeInputOutput.Variables
{
  public class CodeStaticVariables
  {
    private string[] numberVariablesNames = new string[47]
    {
      "a",
      "b",
      "c",
      "d",
      "e",
      "f",
      "g",
      "h",
      "i",
      "j",
      "k",
      "l",
      "m",
      "n",
      "o",
      "p",
      "q",
      "r",
      "s",
      "t",
      "u",
      "v",
      "w",
      "x",
      "y",
      "z",
      "x0",
      "x1",
      "x2",
      "x3",
      "x4",
      "x5",
      "x6",
      "x7",
      "x8",
      "x9",
      "y0",
      "y1",
      "y2",
      "y3",
      "y4",
      "y5",
      "y6",
      "y7",
      "y8",
      "y9",
      "out"
    };
    private string[] colorVariablesNames = new string[10]
    {
      "c0",
      "c1",
      "c2",
      "c3",
      "c4",
      "c5",
      "c6",
      "c7",
      "c8",
      "c9"
    };
    private int turtleX;
    private int turtleY;
    private List<StaticVariable> variables = new List<StaticVariable>();

    internal List<StaticVariable> Variables => this.variables;

    internal void ResetAll()
    {
      foreach (StaticVariable variable in this.variables)
        variable.ResetValue();
    }

    public string[] NumberVariablesNames => this.numberVariablesNames;

    public string[] ColorVariablesNames => this.colorVariablesNames;

    internal StaticVariable GetVariabeOfName(string name)
    {
      foreach (StaticVariable variable in this.Variables)
      {
        if (variable.Name == name)
          return variable;
      }
      return (StaticVariable) null;
    }

    public CodeStaticVariables()
    {
      foreach (string numberVariablesName in this.NumberVariablesNames)
        this.Variables.Add(new StaticVariable(numberVariablesName, new Value(0L)));
      foreach (string colorVariablesName in this.ColorVariablesNames)
        this.Variables.Add(new StaticVariable(colorVariablesName, new Value(0, 0, 0)));
      this.Variables.Add(new StaticVariable("b1", new Value(ValueType.Image)));
    }

    public Value GetVariableValue(string variableName)
    {
      foreach (StaticVariable variable in this.Variables)
      {
        if (variable.Name == variableName)
          return variable.Val;
      }
      return (Value) null;
    }

    public void SetVariableValue(string variableName, Value v)
    {
      foreach (StaticVariable variable in this.Variables)
      {
        if (variable.Name == variableName)
        {
          if (variable.Val.ValType == ValueType.Image)
          {
            string imageName = PixBlocks.BlocksManager.BlocksManager.NameFromColor(v);
            variable.Val = new Value(imageName);
          }
          else
            variable.Val = v;
        }
      }
    }
  }
}
