﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Code.CodeInputOutput.Variables.StaticVariable
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

namespace PixBlocks.DataModels.Code.CodeInputOutput.Variables
{
  public class StaticVariable
  {
    private string name;
    private Value val;

    public StaticVariable(string name, Value v)
    {
      this.name = name;
      this.val = v;
    }

    public string Name => this.name;

    public event StaticVariable.StaticValueChanged staticValueChangedEvent;

    internal Value Val
    {
      get => new Value(this.val);
      set
      {
        this.val = new Value(value);
        if (this.staticValueChangedEvent == null)
          return;
        this.staticValueChangedEvent(this);
      }
    }

    internal void ResetValue()
    {
      this.val.ResetValue();
      if (this.staticValueChangedEvent == null)
        return;
      this.staticValueChangedEvent(this);
    }

    public delegate void StaticValueChanged(StaticVariable var);
  }
}
