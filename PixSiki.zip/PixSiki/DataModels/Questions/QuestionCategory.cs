﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Questions.QuestionCategory
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.Server.DataModels.DataModels.Interfaces;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;
using System.Collections.Generic;

namespace PixBlocks.DataModels.Questions
{
  [Serializable]
  public class QuestionCategory : ICategoryData, IListItem
  {
    private bool isListOfExams;
    private bool isListOfAllHomeworks;
    private bool isChampionship;
    private bool isExam;
    private Exam exam;
    private string categoryUserFriendlyName;
    private List<string> subCategoriesUiniquePaths = new List<string>();
    private List<string> subQuestionsGuids = new List<string>();
    private string uniquePath;

    public QuestionCategory()
    {
    }

    public QuestionCategory(Exam exam)
    {
      this.isExam = true;
      this.exam = exam;
      this.categoryUserFriendlyName = exam.Name;
    }

    public string CategoryUserFriendlyName
    {
      get => this.categoryUserFriendlyName;
      set => this.categoryUserFriendlyName = value;
    }

    public List<string> SubcategoriesUniquePaths
    {
      get => this.subCategoriesUiniquePaths;
      set => this.subCategoriesUiniquePaths = value;
    }

    public List<string> SubQuestionsGuids
    {
      get => this.subQuestionsGuids;
      set => this.subQuestionsGuids = value;
    }

    public bool IsTeatcherOnlyVisible() => this.UniquePath.Contains("_teacher") && !this.UniquePath.Contains("_teacher\\");

    public bool IsMyCreation() => this.UniquePath.Contains("_create") && !this.UniquePath.Contains("_create\\");

    public bool IsAdminOnlyVisible() => this.UniquePath.Contains("_admin") && !this.UniquePath.Contains("_admin\\");

    public string UniquePath
    {
      get => this.uniquePath;
      set => this.uniquePath = value;
    }

    public string UniqueGuid() => this.UniquePath;

    public string TranslatedName() => this.CategoryUserFriendlyName;

    public string TranslatedDescription() => PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateCategoryID(this.UniquePath);

    public bool ListNameAndDescriptionContainsText(string text) => this.TranslatedDescription().Contains(text) || this.TranslatedName().Contains(text);

    public bool IsCourse() => this.subCategoriesUiniquePaths.Count > 0;

    public bool IsLesson() => this.subCategoriesUiniquePaths.Count == 0;

    public string TypeName => "Kurs";

    public string ListName => this.TranslatedName();

    public List<ListProperty> Properties => new List<ListProperty>()
    {
      new ListProperty("Opis", this.TranslatedDescription())
    };

    public bool IsListOfExams
    {
      get => this.isListOfExams;
      set
      {
        this.isListOfExams = value;
        this.categoryUserFriendlyName = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("exams");
      }
    }

    public bool IsExam
    {
      get => this.isExam;
      set => this.isExam = value;
    }

    public Exam GetExam() => this.exam;

    public bool IsListOfAllHomeworks
    {
      get => this.isListOfAllHomeworks;
      set
      {
        this.categoryUserFriendlyName = PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("homeworks");
        this.isListOfAllHomeworks = value;
      }
    }

    public bool IsChampionship
    {
      get => this.isChampionship;
      set
      {
        if (value)
          this.categoryUserFriendlyName = CurrentUserInfo.CurrenChampionship.Name;
        this.isChampionship = value;
      }
    }

    public ICategoryData ParenCategory => throw new NotImplementedException();
  }
}
