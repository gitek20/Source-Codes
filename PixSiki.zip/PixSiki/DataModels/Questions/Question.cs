﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.DataModels.Questions.Question
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels.ExamInfo;
using PixBlocks.TopPanel.TeacherPanel.Models.LearningResulsModels;
using System;

namespace PixBlocks.DataModels.Questions
{
  [Serializable]
  public class Question : IQuestionData
  {
    private bool isExamQuestion;
    private Exam exam;
    private string userFriendlyName;
    private string description = "";
    private string uniqueGuid;
    private QuestionType questionType;
    private string captionInCategory;
    private bool isPremiumQuestion;
    private int secretNumber;
    private int imageWidth;
    private int imageHeight;
    private string code;
    private string imageInBase64;
    private bool isGame;
    private bool ptyhonCode;
    private bool canEditBitmap;
    private string codeCompressed;
    private string inputIronPythonCode;
    private bool isIronPython;
    private string imageInBase64Compressed;
    private QuestionCategory category;
    private QuestionCategory lesson;

    public string UserFriendlyName
    {
      get => this.userFriendlyName;
      set => this.userFriendlyName = value;
    }

    public string GetUniqueDictName() => this.isExamQuestion ? this.UniqueGuid + "_" + this.exam.Id.ToString() : this.UniqueGuid;

    public string Description
    {
      get => this.description;
      set => this.description = value;
    }

    public string UniqueGuid
    {
      get => this.uniqueGuid;
      set => this.uniqueGuid = value;
    }

    public QuestionType QuestionType
    {
      get => this.questionType;
      set => this.questionType = value;
    }

    public string CaptionInCategory
    {
      get => this.captionInCategory;
      set => this.captionInCategory = value;
    }

    public bool IsPremiumQuestion
    {
      get => this.isPremiumQuestion;
      set => this.isPremiumQuestion = value;
    }

    public int SecretNumber
    {
      get => this.secretNumber;
      set => this.secretNumber = value;
    }

    public int ImageWidth
    {
      get => this.imageWidth;
      set => this.imageWidth = value;
    }

    public int ImageHeight
    {
      get => this.imageHeight;
      set => this.imageHeight = value;
    }

    public string Code
    {
      get
      {
        if (this.code == null && this.CodeCompressed != null)
          this.code = PixBlocks.Tools.StringCompressor.StringCompressor.DecompressString(this.CodeCompressed);
        return this.code;
      }
      set => this.code = value;
    }

    public string ImageInBase64
    {
      get
      {
        if (this.imageInBase64 == null && this.ImageInBase64Compressed != null)
          this.imageInBase64 = PixBlocks.Tools.StringCompressor.StringCompressor.DecompressString(this.ImageInBase64Compressed);
        return this.imageInBase64;
      }
      set => this.imageInBase64 = value;
    }

    internal Question GetDeepCopyForExam(Exam exam) => new Question()
    {
      canEditBitmap = this.canEditBitmap,
      captionInCategory = this.captionInCategory,
      category = this.category,
      code = this.code,
      codeCompressed = this.codeCompressed,
      description = this.description,
      imageHeight = this.imageHeight,
      imageInBase64 = this.imageInBase64,
      imageInBase64Compressed = this.imageInBase64Compressed,
      imageWidth = this.imageWidth,
      isGame = this.isGame,
      isPremiumQuestion = this.isPremiumQuestion,
      lesson = this.lesson,
      ptyhonCode = this.ptyhonCode,
      questionType = this.questionType,
      secretNumber = this.secretNumber,
      uniqueGuid = this.uniqueGuid,
      userFriendlyName = this.userFriendlyName,
      exam = exam,
      isExamQuestion = true,
      isIronPython = this.isIronPython,
      inputIronPythonCode = this.inputIronPythonCode
    };

    public void CompressCodeAndBitmap()
    {
      this.CodeCompressed = PixBlocks.Tools.StringCompressor.StringCompressor.CompressString(this.Code);
      this.code = (string) null;
      this.ImageInBase64Compressed = PixBlocks.Tools.StringCompressor.StringCompressor.CompressString(this.ImageInBase64);
      this.imageInBase64 = (string) null;
    }

    public bool IsGame
    {
      get => this.isGame;
      set => this.isGame = value;
    }

    public bool PtyhonCode
    {
      get => this.ptyhonCode;
      set => this.ptyhonCode = value;
    }

    public bool CanEditBitmap
    {
      get => this.canEditBitmap;
      set => this.canEditBitmap = value;
    }

    public string CodeCompressed
    {
      get => this.codeCompressed;
      set => this.codeCompressed = value;
    }

    public string ImageInBase64Compressed
    {
      get => this.imageInBase64Compressed;
      set => this.imageInBase64Compressed = value;
    }

    public ICategoryData ParenCategory => (ICategoryData) this.category;

    public ICategoryData ParenLesson => (ICategoryData) this.lesson;

    public Exam GetExam() => this.exam;

    public bool IsExamQuestion => this.isExamQuestion;

    public int? ExamID => this.IsExamQuestion ? new int?(this.exam.Id) : new int?();

    public bool IsIronPython
    {
      get => this.isIronPython;
      set => this.isIronPython = value;
    }

    public string InputIronPythonCode
    {
      get => this.inputIronPythonCode;
      set => this.inputIronPythonCode = value;
    }

    internal int GenerateSecretNumber() => (this.uniqueGuid + this.isPremiumQuestion.ToString() + this.questionType.ToString() + this.description).GetHashCode();

    public bool IsClassicQuestion() => this.QuestionType == QuestionType.ClassicQuestionType;

    public bool IsSample() => this.QuestionType == QuestionType.InfoType;

    bool IQuestionData.IsGame() => this.IsGame;

    public bool IsFree() => this.QuestionType == QuestionType.FreeCodeType;

    public string QuestionGuid() => this.UniqueGuid;

    public string UserFriendlyDescription() => this.captionInCategory;

    public string GetQuestionContent() => PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateQuestionID(this.uniqueGuid);

    internal void SetQuestionCategoryAndLesson(QuestionCategory category, QuestionCategory lesson)
    {
      this.category = category;
      this.lesson = lesson;
    }
  }
}
