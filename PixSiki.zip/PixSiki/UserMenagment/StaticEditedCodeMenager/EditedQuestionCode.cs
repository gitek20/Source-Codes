﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.StaticEditedCodeMenager.EditedQuestionCode
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using System;

namespace PixBlocks.UserMenagment.StaticEditedCodeMenager
{
  [Serializable]
  public class EditedQuestionCode
  {
    private bool isExamQuestion;
    private int? examID;
    private string uniqueQuestionName;
    private string editedImageBase64;
    private string questionCode;
    private string codeCompressed;
    private string imageInBase64Compressed;

    public string GetUniqueDictName() => this.isExamQuestion ? this.uniqueQuestionName + "_" + this.examID.ToString() : this.uniqueQuestionName;

    public bool IsEqualToQuestion(Question question)
    {
      if (this.uniqueQuestionName != question.UniqueGuid || this.isExamQuestion != question.IsExamQuestion)
        return false;
      if (question.IsExamQuestion)
      {
        int id = question.GetExam().Id;
        int? examId = this.examID;
        int valueOrDefault = examId.GetValueOrDefault();
        if (!(id == valueOrDefault & examId.HasValue))
          return false;
      }
      return true;
    }

    internal bool IsEqualToEditedQuestionCode(EditedQuestionCode editedQuestionCode)
    {
      if (this.uniqueQuestionName != editedQuestionCode.uniqueQuestionName || this.isExamQuestion != editedQuestionCode.isExamQuestion)
        return false;
      int? examId1 = editedQuestionCode.examID;
      int? examId2 = this.examID;
      return examId1.GetValueOrDefault() == examId2.GetValueOrDefault() & examId1.HasValue == examId2.HasValue;
    }

    public EditedQuestionCode()
    {
    }

    public EditedQuestionCode(Question question, string questionCode)
      : this(question)
      => this.questionCode = questionCode;

    public EditedQuestionCode(Question question)
    {
      this.uniqueQuestionName = question.UniqueGuid;
      this.isExamQuestion = question.IsExamQuestion;
      if (!this.IsExamQuestion)
        return;
      this.examID = new int?(question.GetExam().Id);
    }

    public string UniqueQuestionName
    {
      get => this.uniqueQuestionName;
      set => this.uniqueQuestionName = value;
    }

    public void SetQuestionCode(string questionCode) => this.questionCode = questionCode;

    public string GetQuestionCode()
    {
      if (this.questionCode == null && this.CodeCompressed != null)
        this.questionCode = PixBlocks.Tools.StringCompressor.StringCompressor.DecompressString(this.CodeCompressed);
      return this.questionCode;
    }

    public string EditedImageBase64
    {
      get
      {
        if (this.editedImageBase64 == null && this.ImageInBase64Compressed != null)
          this.editedImageBase64 = PixBlocks.Tools.StringCompressor.StringCompressor.DecompressString(this.ImageInBase64Compressed);
        return this.editedImageBase64;
      }
      set => this.editedImageBase64 = value;
    }

    public void CompressCodeAndBitmap()
    {
      if (this.questionCode != null)
      {
        this.CodeCompressed = PixBlocks.Tools.StringCompressor.StringCompressor.CompressString(this.questionCode);
        this.questionCode = (string) null;
      }
      if (this.editedImageBase64 == null)
        return;
      this.ImageInBase64Compressed = PixBlocks.Tools.StringCompressor.StringCompressor.CompressString(this.editedImageBase64);
      this.editedImageBase64 = (string) null;
    }

    public string CodeCompressed
    {
      get => this.codeCompressed;
      set => this.codeCompressed = value;
    }

    public string ImageInBase64Compressed
    {
      get => this.imageInBase64Compressed;
      set => this.imageInBase64Compressed = value;
    }

    public bool IsExamQuestion
    {
      get => this.isExamQuestion;
      set => this.isExamQuestion = value;
    }

    public int? ExamID
    {
      get => this.examID;
      set => this.examID = value;
    }
  }
}
