﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.StaticEditedCodeMenager.QuestionsCodesManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Code.Instructions;
using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools;
using PixBlocks.Tools.CodeParser;
using PixBlocks.TopPanel.GlobalProgressBar;
using System;
using System.Collections.Generic;

namespace PixBlocks.UserMenagment.StaticEditedCodeMenager
{
  internal class QuestionsCodesManager
  {
    private static List<EditedQuestionCode> questionsCodes = new List<EditedQuestionCode>();
    private static Dictionary<string, EditedQuestionCode> questionsDict;
    public static string lastEditedImageQuestionName = (string) null;

    public static List<EditedQuestionCode> QuestionsCodes
    {
      get => QuestionsCodesManager.questionsCodes;
      set
      {
        QuestionsCodesManager.questionsCodes = value;
        QuestionsCodesManager.questionsDict = (Dictionary<string, EditedQuestionCode>) null;
      }
    }

    private static void RebuildDictStructure()
    {
      if (QuestionsCodesManager.questionsDict != null)
        return;
      QuestionsCodesManager.questionsDict = new Dictionary<string, EditedQuestionCode>();
      foreach (EditedQuestionCode questionsCode in QuestionsCodesManager.questionsCodes)
      {
        if (!QuestionsCodesManager.questionsDict.ContainsKey(questionsCode.GetUniqueDictName()))
          QuestionsCodesManager.questionsDict.Add(questionsCode.GetUniqueDictName(), questionsCode);
      }
    }

    public static EditedQuestionCode GetEditedQuestionCode(Question question)
    {
      QuestionsCodesManager.RebuildDictStructure();
      EditedQuestionCode editedQuestionCode = (EditedQuestionCode) null;
      QuestionsCodesManager.questionsDict.TryGetValue(question.GetUniqueDictName(), out editedQuestionCode);
      return editedQuestionCode;
    }

    public static string GetPythonCodeFormQuestion(Question question)
    {
      QuestionsCodesManager.RebuildDictStructure();
      EditedQuestionCode editedQuestionCode = (EditedQuestionCode) null;
      QuestionsCodesManager.questionsDict.TryGetValue(question.GetUniqueDictName(), out editedQuestionCode);
      return editedQuestionCode?.GetQuestionCode();
    }

    public static string GetImageBase64FormQuestion(Question question)
    {
      QuestionsCodesManager.RebuildDictStructure();
      EditedQuestionCode editedQuestionCode = (EditedQuestionCode) null;
      QuestionsCodesManager.questionsDict.TryGetValue(question.GetUniqueDictName(), out editedQuestionCode);
      return editedQuestionCode?.EditedImageBase64;
    }

    public static RepeatNTimes GetCodeFormQuestion(Question question)
    {
      QuestionsCodesManager.RebuildDictStructure();
      EditedQuestionCode editedQuestionCode = (EditedQuestionCode) null;
      QuestionsCodesManager.questionsDict.TryGetValue(question.GetUniqueDictName(), out editedQuestionCode);
      if (editedQuestionCode != null)
      {
        string questionCode = editedQuestionCode.GetQuestionCode();
        if (questionCode != null && questionCode != "")
          return CodeStringParser.GenerateModelFromCode(questionCode);
      }
      return (RepeatNTimes) null;
    }

    internal static void AddEditedQuestionCodeFromOfflineProfile(
      EditedQuestionCode editedQuestionCode)
    {
      if (UserMenager.IsTeacherLogin)
        return;
      QuestionsCodesManager.RebuildDictStructure();
      EditedQuestionCode editedQuestionCode1 = (EditedQuestionCode) null;
      QuestionsCodesManager.questionsDict.TryGetValue(editedQuestionCode.GetUniqueDictName(), out editedQuestionCode1);
      if (editedQuestionCode1 != null)
      {
        editedQuestionCode.CompressCodeAndBitmap();
        QuestionsCodesManager.SaveQuestionCodeToServer(editedQuestionCode);
        editedQuestionCode1.EditedImageBase64 = editedQuestionCode.EditedImageBase64;
        editedQuestionCode1.SetQuestionCode(editedQuestionCode.GetQuestionCode());
        editedQuestionCode1.CompressCodeAndBitmap();
      }
      else
      {
        editedQuestionCode.CompressCodeAndBitmap();
        QuestionsCodesManager.SaveQuestionCodeToServer(editedQuestionCode);
        QuestionsCodesManager.QuestionsCodes.Add(editedQuestionCode);
        QuestionsCodesManager.questionsDict.Add(editedQuestionCode.GetUniqueDictName(), editedQuestionCode);
      }
    }

    public static void AddEditedImageInBase64(Question question, string editedImageBase64)
    {
      if (UserMenager.IsTeacherLogin || editedImageBase64 == null)
        return;
      QuestionsCodesManager.RebuildDictStructure();
      EditedQuestionCode editedQuestionCode1 = (EditedQuestionCode) null;
      QuestionsCodesManager.questionsDict.TryGetValue(question.GetUniqueDictName(), out editedQuestionCode1);
      if (editedQuestionCode1 != null)
      {
        if (!(editedQuestionCode1.EditedImageBase64 != editedImageBase64))
          return;
        editedQuestionCode1.EditedImageBase64 = editedImageBase64;
        QuestionsCodesManager.lastEditedImageQuestionName = question.UniqueGuid;
      }
      else
      {
        if (editedImageBase64 == "")
          return;
        EditedQuestionCode editedQuestionCode2 = new EditedQuestionCode(question);
        editedQuestionCode2.EditedImageBase64 = editedImageBase64;
        QuestionsCodesManager.QuestionsCodes.Add(editedQuestionCode2);
        QuestionsCodesManager.questionsDict.Add(question.GetUniqueDictName(), editedQuestionCode2);
        QuestionsCodesManager.lastEditedImageQuestionName = question.UniqueGuid;
      }
    }

    public static void AddPythonCode(Question question, string pythonCode)
    {
      if (UserMenager.IsTeacherLogin || pythonCode == null || question.QuestionType == QuestionType.InfoType)
        return;
      string internlCode = pythonCode;
      QuestionsCodesManager.RebuildDictStructure();
      EditedQuestionCode eqc = (EditedQuestionCode) null;
      QuestionsCodesManager.questionsDict.TryGetValue(question.GetUniqueDictName(), out eqc);
      if (eqc != null)
      {
        if (!(eqc.GetQuestionCode() != internlCode) && !(QuestionsCodesManager.lastEditedImageQuestionName == question.UniqueGuid))
          return;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          QuestionsCodesManager.SaveQuestionCodeToServer(new EditedQuestionCode(question, internlCode)
          {
            EditedImageBase64 = eqc.EditedImageBase64
          });
          eqc.SetQuestionCode(internlCode);
          QuestionsCodesManager.lastEditedImageQuestionName = (string) null;
        }));
      }
      else
      {
        if (!(internlCode != ""))
          return;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          EditedQuestionCode editedQuestionCode = new EditedQuestionCode(question, internlCode);
          QuestionsCodesManager.SaveQuestionCodeToServer(editedQuestionCode);
          QuestionsCodesManager.QuestionsCodes.Add(editedQuestionCode);
          try
          {
            QuestionsCodesManager.questionsDict.Add(question.GetUniqueDictName(), editedQuestionCode);
          }
          catch
          {
          }
        }));
      }
    }

    public static void AddCode(Question question, RepeatNTimes rootElement)
    {
      if (UserMenager.IsTeacherLogin || rootElement == null)
        return;
      string internlCode = rootElement.GetInternalCode("");
      QuestionsCodesManager.RebuildDictStructure();
      EditedQuestionCode eqc = (EditedQuestionCode) null;
      QuestionsCodesManager.questionsDict.TryGetValue(question.GetUniqueDictName(), out eqc);
      if (eqc != null)
      {
        if (!(eqc.GetQuestionCode() != internlCode) && (eqc.GetQuestionCode() == null || internlCode == null || !(eqc.GetQuestionCode().Replace("\r\n", "\n") != internlCode.Replace("\r\n", "\n"))) && !(QuestionsCodesManager.lastEditedImageQuestionName == question.UniqueGuid))
          return;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          QuestionsCodesManager.SaveQuestionCodeToServer(new EditedQuestionCode(question, internlCode)
          {
            EditedImageBase64 = eqc.EditedImageBase64
          });
          eqc.SetQuestionCode(internlCode);
          QuestionsCodesManager.lastEditedImageQuestionName = (string) null;
        }));
      }
      else
      {
        string internalCode1 = new RepeatNTimes(1).GetInternalCode("");
        string internalCode2 = new RepeatNTimes(int.MaxValue).GetInternalCode("");
        string str = internlCode;
        if (!(internalCode1 != str) || !(internalCode2 != internlCode))
          return;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          EditedQuestionCode editedQuestionCode = new EditedQuestionCode(question, internlCode);
          QuestionsCodesManager.SaveQuestionCodeToServer(editedQuestionCode);
          QuestionsCodesManager.QuestionsCodes.Add(editedQuestionCode);
          try
          {
            QuestionsCodesManager.questionsDict.Add(question.GetUniqueDictName(), editedQuestionCode);
          }
          catch
          {
          }
        }));
      }
    }

    public static void SaveQuestionCodeToServer(EditedQuestionCode editedQuestionCode)
    {
      if (UserMenager.IsOffLineUser)
        return;
      editedQuestionCode.CompressCodeAndBitmap();
      string str = PixBlocks.Tools.StringCompressor.StringCompressor.CompressString(XmlUtil.ToXml((object) editedQuestionCode, false));
      new ServerApi().AddOrUpdateEditedQuestionCode(new PixBlocks.Server.DataModels.DataModels.UserProfileInfo.EditedQuestionCode()
      {
        CreationTime = new DateTime?(DateTime.Now),
        ExamId = editedQuestionCode.ExamID,
        IsExamQuestion = editedQuestionCode.IsExamQuestion,
        UserId = CurrentUserInfo.CurrentUser.Id.Value,
        UpdateTime = new DateTime?(DateTime.Now),
        QeditedQuesionCodeBase64 = str,
        QuesionGuid = editedQuestionCode.UniqueQuestionName
      }, CurrentUserInfo.CurrentUser, new AuthorizeData(CurrentUserInfo.CurrentUser));
    }

    public static void Handle()
    {
    }
  }
}
