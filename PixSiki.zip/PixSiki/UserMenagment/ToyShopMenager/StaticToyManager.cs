﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.ToyShopMenager.StaticToyManager
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ServerFasade.UserManagment;
using System.Collections.Generic;
using System.Windows;

namespace PixBlocks.UserMenagment.ToyShopMenager
{
  internal class StaticToyManager
  {
    private static ToysInfos toysInfos;

    public static ToysInfos ToysInfos
    {
      get
      {
        if (StaticToyManager.toysInfos == null)
        {
          StaticToyManager.toysInfos = new ToysInfos();
          StaticToyManager.toysInfos.ActiveToys = new List<ToyInfo>();
          StaticToyManager.toysInfos.DeletedToys = new List<ToyInfo>();
          if (UserMenager.UserAgeType == UserAgeType.boy)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_boy", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.girl)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_girl", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.man)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_man", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.woman)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_woman", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.boy1)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_boy1", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.girl1)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_girl1", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.man1)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_man1", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.woman1)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_woman1", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.boy2)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_boy2", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.girl2)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_girl2", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.man2)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_man2", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.woman2)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_woman2", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.boy3)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_boy3", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.girl3)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_girl3", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.man3)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_man3", new Point(765.0, 432.0), 0));
          if (UserMenager.UserAgeType == UserAgeType.woman3)
            StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("table_woman3", new Point(765.0, 432.0), 0));
          StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("item_polka_1", new Point(169.0, 395.0), 1));
          StaticToyManager.toysInfos.ActiveToys.Add(new ToyInfo("item_kwiatek1_5", new Point(273.0, 235.0), 5));
        }
        foreach (ToyInfo activeToy in StaticToyManager.toysInfos.ActiveToys)
        {
          if (activeToy.UniqueName.Contains("table_"))
          {
            if (UserMenager.UserAgeType == UserAgeType.boy)
              activeToy.UniqueName = "table_boy";
            if (UserMenager.UserAgeType == UserAgeType.girl)
              activeToy.UniqueName = "table_girl";
            if (UserMenager.UserAgeType == UserAgeType.man)
              activeToy.UniqueName = "table_man";
            if (UserMenager.UserAgeType == UserAgeType.woman)
              activeToy.UniqueName = "table_woman";
            if (UserMenager.UserAgeType == UserAgeType.boy1)
              activeToy.UniqueName = "table_boy1";
            if (UserMenager.UserAgeType == UserAgeType.girl1)
              activeToy.UniqueName = "table_girl1";
            if (UserMenager.UserAgeType == UserAgeType.man1)
              activeToy.UniqueName = "table_man1";
            if (UserMenager.UserAgeType == UserAgeType.woman1)
              activeToy.UniqueName = "table_woman1";
            if (UserMenager.UserAgeType == UserAgeType.boy2)
              activeToy.UniqueName = "table_boy2";
            if (UserMenager.UserAgeType == UserAgeType.girl2)
              activeToy.UniqueName = "table_girl2";
            if (UserMenager.UserAgeType == UserAgeType.man2)
              activeToy.UniqueName = "table_man2";
            if (UserMenager.UserAgeType == UserAgeType.woman2)
              activeToy.UniqueName = "table_woman2";
            if (UserMenager.UserAgeType == UserAgeType.boy3)
              activeToy.UniqueName = "table_boy3";
            if (UserMenager.UserAgeType == UserAgeType.girl3)
              activeToy.UniqueName = "table_girl3";
            if (UserMenager.UserAgeType == UserAgeType.man3)
              activeToy.UniqueName = "table_man3";
            if (UserMenager.UserAgeType == UserAgeType.woman3)
              activeToy.UniqueName = "table_woman3";
          }
        }
        return StaticToyManager.toysInfos;
      }
      set => StaticToyManager.toysInfos = value;
    }
  }
}
