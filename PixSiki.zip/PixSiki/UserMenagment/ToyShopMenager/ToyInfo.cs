﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.ToyShopMenager.ToyInfo
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using System;
using System.Windows;

namespace PixBlocks.UserMenagment.ToyShopMenager
{
  [Serializable]
  public class ToyInfo
  {
    private string uniqueName;
    private Point position;
    private int price;

    public ToyInfo()
    {
    }

    public ToyInfo(string uniqueName, Point position, int price)
    {
      this.uniqueName = uniqueName;
      this.position = position;
      this.price = price;
    }

    public string UniqueName
    {
      get => this.uniqueName;
      set => this.uniqueName = value;
    }

    public Point Position
    {
      get => this.position;
      set => this.position = value;
    }

    public int Price
    {
      get => this.price;
      set => this.price = value;
    }
  }
}
