﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.ToyShopMenager.ToysInfos
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.ToyShop.Views;
using System;
using System.Collections.Generic;
using System.Windows;

namespace PixBlocks.UserMenagment.ToyShopMenager
{
  [Serializable]
  public class ToysInfos
  {
    private List<ToyInfo> activeToys;
    private List<ToyInfo> deletedToys;

    public int GetTotalMoneyInRoom()
    {
      int num = 0;
      foreach (ToyInfo activeToy in this.activeToys)
        num += activeToy.Price;
      return num;
    }

    public void RefreshActiveToys(List<DropableElement> elements)
    {
      this.activeToys.Clear();
      elements.Sort();
      elements.Reverse();
      foreach (DropableElement element in elements)
      {
        Point position = new Point(element.Margin.Left, element.Margin.Top);
        int priceOfName = this.GetPriceOfName(element.UniqueName);
        this.activeToys.Add(new ToyInfo(element.UniqueName, position, priceOfName));
      }
    }

    public int GetPriceOfName(string name)
    {
      if (!name.Contains("_"))
        return 0;
      string s = name.Substring(name.LastIndexOf("_") + 1);
      int num = 0;
      ref int local = ref num;
      return int.TryParse(s, out local) ? num : 0;
    }

    public void AddToDeletedToy(string name)
    {
    }

    public List<ToyInfo> ActiveToys
    {
      get => this.activeToys;
      set => this.activeToys = value;
    }

    public List<ToyInfo> DeletedToys
    {
      get => new List<ToyInfo>();
      set => this.deletedToys = value;
    }
  }
}
