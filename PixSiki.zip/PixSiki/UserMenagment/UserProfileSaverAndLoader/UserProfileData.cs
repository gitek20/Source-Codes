﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.UserProfileSaverAndLoader.UserProfileData
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.UserMenagment.StaticEditedCodeMenager;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.UserMenagment.ToyShopMenager;
using System;
using System.Collections.Generic;

namespace PixBlocks.UserMenagment.UserProfileSaverAndLoader
{
  [Serializable]
  public class UserProfileData
  {
    private string userName;
    private ToysInfos toysInfos;
    private List<QuestionPoint> questionPoints = new List<QuestionPoint>();
    private List<EditedQuestionCode> questionsCodes = new List<EditedQuestionCode>();

    public List<QuestionPoint> QuestionPoints
    {
      get => this.questionPoints;
      set => this.questionPoints = value;
    }

    public List<EditedQuestionCode> QuestionsCodes
    {
      get => this.questionsCodes;
      set => this.questionsCodes = value;
    }

    public string UserName
    {
      get => this.userName;
      set => this.userName = value;
    }

    public ToysInfos ToysInfos
    {
      get => this.toysInfos;
      set => this.toysInfos = value;
    }
  }
}
