﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.UserProfileSaverAndLoader.ProfileSaverAndLoader
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.Championsships;
using PixBlocks.Server.DataModels.DataModels.DBModels;
using PixBlocks.Server.DataModels.DataModels.UserProfileInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.Tools;
using PixBlocks.Tools.DataStorageConfig;
using PixBlocks.TopPanel.Components.Basic;
using PixBlocks.UserMenagment.StaticEditedCodeMenager;
using PixBlocks.UserMenagment.StaticQuestionPointsMenagment;
using PixBlocks.UserMenagment.ToyShopMenager;
using System;
using System.Collections.Generic;
using System.IO;

namespace PixBlocks.UserMenagment.UserProfileSaverAndLoader
{
  internal class ProfileSaverAndLoader
  {
    private static string GetUserProfileNAme()
    {
      string currentUserName = UserMenager.GetCurrentUserName();
      string appUserDataPath = DataStorageParams.appUserDataPath;
      if (!Directory.Exists(appUserDataPath))
        Directory.CreateDirectory(appUserDataPath);
      return appUserDataPath + currentUserName + ".userprofile";
    }

    public static void LoadProfileForCurrentUser()
    {
      if (UserMenager.IsOffLineUser)
      {
        string userProfileName = ProfileSaverAndLoader.GetUserProfileNAme();
        if (File.Exists(userProfileName))
        {
          ProfileSaverAndLoader.LoadOffLineProfile(userProfileName);
        }
        else
        {
          QuestionsCodesManager.QuestionsCodes = new List<PixBlocks.UserMenagment.StaticEditedCodeMenager.EditedQuestionCode>();
          QuestionsPointsCounter.QuestionPoints = new List<QuestionPoint>();
          StaticToyManager.ToysInfos = (ToysInfos) null;
        }
      }
      else
        ProfileSaverAndLoader.LoadOnLineProfile();
    }

    public static void SaveProfileForCurrentUser()
    {
      if (UserMenager.IsOffLineUser)
      {
        ProfileSaverAndLoader.SaveOfflineProfile(ProfileSaverAndLoader.GetUserProfileNAme());
      }
      else
      {
        try
        {
          if (UserMenager.IsTeacherLogin)
            return;
          ProfileSaverAndLoader.SaveToyShopToServer();
        }
        catch
        {
          CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
        }
      }
    }

    public static void LoadOnLineProfile()
    {
      try
      {
        ServerApi serverApi = new ServerApi();
        int num = 177;
        if (CurrentUserInfo.CurrentUser.CountryId.HasValue)
        {
          num = CurrentUserInfo.CurrentUser.CountryId.Value;
        }
        else
        {
          if (UserMenager.LanguageKey == "PL")
            num = 177;
          if (UserMenager.LanguageKey == "EN")
            num = 235;
        }
        int countryId = num;
        AuthorizeData authorize = new AuthorizeData(CurrentUserInfo.CurrentUser);
        List<Championship> championshipsInCountry = serverApi.GetActiveChampionshipsInCountry(countryId, authorize);
        CurrentUserInfo.CurrenChampionship = championshipsInCountry.Count <= 0 ? (Championship) null : championshipsInCountry[0];
      }
      catch
      {
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
      }
      try
      {
        ProfileSaverAndLoader.LoadServerQuestionsEditedCodes();
      }
      catch
      {
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
      }
      try
      {
        ProfileSaverAndLoader.LoadServerQuestionPoints();
      }
      catch
      {
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
      }
      try
      {
        if (UserMenager.IsTeacherLogin)
          return;
        ProfileSaverAndLoader.LoadServerToyShopData();
      }
      catch
      {
        CustomMessageBox.Show(PixBlocks.Tools.TranslationsManager.TranslationsManager.TranslateUIID("serverError"));
      }
    }

    public static void LoadOffLineProfile(string path)
    {
      UserProfileData userProfileData = (UserProfileData) BinarySerializer.Deserialize(path);
      QuestionsCodesManager.QuestionsCodes = userProfileData.QuestionsCodes;
      QuestionsPointsCounter.QuestionPoints = userProfileData.QuestionPoints;
      UserMenager.SetUserName(userProfileData.UserName);
      StaticToyManager.ToysInfos = userProfileData.ToysInfos;
    }

    public static void LoadServerToyShopData()
    {
      GetToyShopDataResult userToysShopInfo = new ServerApi().GetUserToysShopInfo(CurrentUserInfo.CurrentUser, new AuthorizeData(CurrentUserInfo.CurrentUser));
      if (userToysShopInfo.IsToyShopExist)
        StaticToyManager.ToysInfos = (ToysInfos) XmlUtil.XmlTo(PixBlocks.Tools.StringCompressor.StringCompressor.DecompressString(userToysShopInfo.ToyShopData.ToyShopInfoBase64), new ToysInfos().GetType(), false);
      else
        StaticToyManager.ToysInfos = (ToysInfos) null;
    }

    public static void LoadServerQuestionPoints()
    {
      QuestionsPointsCounter.QuestionPoints = new List<QuestionPoint>();
      foreach (QuestionResult allQuestionsResult in new ServerApi().GetAllQuestionsResults(CurrentUserInfo.CurrentUser, new AuthorizeData(CurrentUserInfo.CurrentUser)))
        QuestionsPointsCounter.QuestionPoints.Add(new QuestionPoint(allQuestionsResult));
    }

    public static void LoadServerQuestionsEditedCodes()
    {
      QuestionsCodesManager.QuestionsCodes = new List<PixBlocks.UserMenagment.StaticEditedCodeMenager.EditedQuestionCode>();
      foreach (PixBlocks.Server.DataModels.DataModels.UserProfileInfo.EditedQuestionCode allQuestionsCode in new ServerApi().GetAllQuestionsCodes(CurrentUserInfo.CurrentUser, new AuthorizeData(CurrentUserInfo.CurrentUser)))
      {
        PixBlocks.UserMenagment.StaticEditedCodeMenager.EditedQuestionCode editedQuestionCode1 = new PixBlocks.UserMenagment.StaticEditedCodeMenager.EditedQuestionCode();
        PixBlocks.UserMenagment.StaticEditedCodeMenager.EditedQuestionCode editedQuestionCode2 = (PixBlocks.UserMenagment.StaticEditedCodeMenager.EditedQuestionCode) XmlUtil.XmlTo(PixBlocks.Tools.StringCompressor.StringCompressor.DecompressString(allQuestionsCode.QeditedQuesionCodeBase64), editedQuestionCode1.GetType(), false);
        editedQuestionCode2.CompressCodeAndBitmap();
        QuestionsCodesManager.QuestionsCodes.Add(editedQuestionCode2);
      }
    }

    public static void SaveOfflineProfile(string path)
    {
      BinarySerializer.Serialize(path, (object) new UserProfileData()
      {
        ToysInfos = StaticToyManager.ToysInfos,
        QuestionsCodes = QuestionsCodesManager.QuestionsCodes,
        QuestionPoints = QuestionsPointsCounter.QuestionPoints,
        UserName = UserMenager.GetCurrentUserName()
      });
      ServerApi serverApi = new ServerApi();
      try
      {
        SignInLog offlineLogoutLog = SignInLog.CreateOfflineLogoutLog();
        offlineLogoutLog.LoginDate = CurrentUserInfo.loginDate;
        offlineLogoutLog.UserId = new int?();
        serverApi.SaveUserSignOutLog(offlineLogoutLog);
      }
      catch
      {
      }
    }

    public static void SaveToyShopToServer()
    {
      string str = PixBlocks.Tools.StringCompressor.StringCompressor.CompressString(XmlUtil.ToXml((object) StaticToyManager.ToysInfos, false));
      ToyShopData toyShopData = new ToyShopData();
      toyShopData.CreationTime = new DateTime?(DateTime.Now);
      toyShopData.ToyShopInfoBase64 = str;
      toyShopData.UpdateTime = new DateTime?(DateTime.Now);
      toyShopData.UserID = CurrentUserInfo.CurrentUser.Id.Value;
      ServerApi serverApi = new ServerApi();
      serverApi.AddOrUpdateToyShopInfo(toyShopData, new AuthorizeData(CurrentUserInfo.CurrentUser));
      if (CurrentUserInfo.logoutThisAccount)
        return;
      try
      {
        SignInLog offlineLogoutLog = SignInLog.CreateOfflineLogoutLog();
        offlineLogoutLog.LoginDate = CurrentUserInfo.loginDate;
        offlineLogoutLog.UserId = CurrentUserInfo.CurrentUser.Id;
        serverApi.SaveUserSignOutLog(offlineLogoutLog);
        CurrentUserInfo.logoutThisAccount = true;
      }
      catch (Exception ex)
      {
      }
    }
  }
}
