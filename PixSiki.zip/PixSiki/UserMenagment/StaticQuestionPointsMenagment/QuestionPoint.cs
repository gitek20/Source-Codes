﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.StaticQuestionPointsMenagment.QuestionPoint
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels.UserProfileInfo;
using System;

namespace PixBlocks.UserMenagment.StaticQuestionPointsMenagment
{
  [Serializable]
  public class QuestionPoint
  {
    private string uniqueQuestionID;
    private int numberOfPoints;
    private bool isExamQuestion;
    private int? examID;

    public QuestionPoint()
    {
    }

    public string GetUniqueDictName() => this.isExamQuestion ? this.uniqueQuestionID + "_" + this.examID.ToString() : this.uniqueQuestionID;

    public bool IsEqualsToQuestion(Question question)
    {
      if (this.uniqueQuestionID != question.UniqueGuid || this.IsExamQuestion != question.IsExamQuestion)
        return false;
      if (question.IsExamQuestion)
      {
        int id = question.GetExam().Id;
        int? examId = this.examID;
        int valueOrDefault = examId.GetValueOrDefault();
        if (!(id == valueOrDefault & examId.HasValue))
          return false;
      }
      return true;
    }

    public QuestionPoint(Question question, int numberOfPoints)
    {
      this.uniqueQuestionID = question.UniqueGuid;
      this.isExamQuestion = question.IsExamQuestion;
      if (question.IsExamQuestion)
        this.examID = new int?(question.GetExam().Id);
      this.numberOfPoints = numberOfPoints;
    }

    public QuestionPoint(QuestionResult questionResult)
    {
      this.uniqueQuestionID = questionResult.QuestionGuid;
      this.isExamQuestion = questionResult.IsExamQuestion;
      this.examID = questionResult.ExamId;
      this.numberOfPoints = questionResult.Points;
    }

    public string UniqueQuestionID
    {
      get => this.uniqueQuestionID;
      set => this.uniqueQuestionID = value;
    }

    public int NumberOfPoints
    {
      get => this.numberOfPoints;
      set => this.numberOfPoints = value;
    }

    public bool IsExamQuestion
    {
      get => this.isExamQuestion;
      set => this.isExamQuestion = value;
    }

    public int? ExamID
    {
      get => this.examID;
      set => this.examID = value;
    }
  }
}
