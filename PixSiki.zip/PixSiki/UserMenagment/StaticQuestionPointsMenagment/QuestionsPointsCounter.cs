﻿// Decompiled with JetBrains decompiler
// Type: PixBlocks.UserMenagment.StaticQuestionPointsMenagment.QuestionsPointsCounter
// Assembly: PixBlocks, Version=629.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 01B4B8B8-CFB8-41BF-99A1-2407FBB5C27E
// Assembly location: C:\Program Files (x86)\PixBlocks\PixBlocks.exe

using PixBlocks.DataModels.Questions;
using PixBlocks.Server.DataModels.DataModels;
using PixBlocks.Server.DataModels.DataModels.UserProfileInfo;
using PixBlocks.ServerFasade.ServerAPI;
using PixBlocks.ServerFasade.UserManagment;
using PixBlocks.TopPanel.GlobalProgressBar;
using PixBlocks.UserMenagment.ToyShopMenager;
using System;
using System.Collections.Generic;

namespace PixBlocks.UserMenagment.StaticQuestionPointsMenagment
{
  internal class QuestionsPointsCounter
  {
    private static Dictionary<string, QuestionPoint> pointsDict = (Dictionary<string, QuestionPoint>) null;
    private static List<QuestionPoint> questionPoints = new List<QuestionPoint>();
    public static int GodModeAdditionalPoints = 0;

    public static List<QuestionPoint> QuestionPoints
    {
      get => QuestionsPointsCounter.questionPoints;
      set
      {
        QuestionsPointsCounter.questionPoints = value;
        QuestionsPointsCounter.pointsDict = (Dictionary<string, QuestionPoint>) null;
      }
    }

    private static void LoadDict()
    {
      if (QuestionsPointsCounter.pointsDict != null)
        return;
      QuestionsPointsCounter.pointsDict = new Dictionary<string, QuestionPoint>();
      foreach (QuestionPoint questionPoint in QuestionsPointsCounter.QuestionPoints)
      {
        if (!QuestionsPointsCounter.pointsDict.ContainsKey(questionPoint.GetUniqueDictName()))
          QuestionsPointsCounter.pointsDict.Add(questionPoint.GetUniqueDictName(), questionPoint);
      }
    }

    public static void LoadPointsFromFile()
    {
    }

    public static int CountPointsInQuestions(List<Question> questions)
    {
      int num = 0;
      foreach (Question question in questions)
        num += Math.Max(0, QuestionsPointsCounter.GetQuestionPoints(question));
      return num;
    }

    public static int GetPointsForCurrentUser()
    {
      int num = 6;
      foreach (QuestionPoint questionPoint in QuestionsPointsCounter.QuestionPoints)
        num += Math.Max(0, questionPoint.NumberOfPoints);
      return num - StaticToyManager.ToysInfos.GetTotalMoneyInRoom() + QuestionsPointsCounter.GodModeAdditionalPoints;
    }

    public static int GetQuestionPoints(Question question)
    {
      QuestionsPointsCounter.LoadDict();
      QuestionPoint questionPoint = (QuestionPoint) null;
      return QuestionsPointsCounter.pointsDict.TryGetValue(question.GetUniqueDictName(), out questionPoint) ? questionPoint.NumberOfPoints : 0;
    }

    public static event QuestionsPointsCounter.QuestionPointsModify questionPointsModifyEvent;

    public static void PointsWasChangedInShop()
    {
      if (QuestionsPointsCounter.questionPointsModifyEvent == null)
        return;
      QuestionsPointsCounter.questionPointsModifyEvent((QuestionPoint) null);
    }

    public static void SetQuestionPoints(Question question, int points)
    {
      if (UserMenager.IsTeacherLogin)
        return;
      QuestionsPointsCounter.LoadDict();
      QuestionPoint result = (QuestionPoint) null;
      if (QuestionsPointsCounter.pointsDict.TryGetValue(question.GetUniqueDictName(), out result))
      {
        if (result.NumberOfPoints == points)
          return;
        result.NumberOfPoints = points;
        if (QuestionsPointsCounter.questionPointsModifyEvent == null)
          return;
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          QuestionsPointsCounter.SavePointsToServer(result);
          QuestionsPointsCounter.questionPointsModifyEvent(result);
        }));
      }
      else
        GlobalProgressBarManager.RunFuncionAndProgressBar((Action) (() =>
        {
          QuestionPoint questionPoint = new QuestionPoint(question, points);
          QuestionsPointsCounter.SavePointsToServer(questionPoint);
          QuestionsPointsCounter.QuestionPoints.Add(questionPoint);
          QuestionsPointsCounter.pointsDict.Add(question.GetUniqueDictName(), questionPoint);
          QuestionsPointsCounter.questionPointsModifyEvent(questionPoint);
        }));
    }

    public static void SavePointsToServer(QuestionPoint questionPoint)
    {
      if (UserMenager.IsOffLineUser)
        return;
      new ServerApi().AddOrUpdateQuestionResult(new QuestionResult()
      {
        UserID = CurrentUserInfo.CurrentUser.Id.Value,
        UpdateTime = new DateTime?(DateTime.Now),
        CreationDate = new DateTime?(DateTime.Now),
        ExamId = questionPoint.ExamID,
        IsExamQuestion = questionPoint.IsExamQuestion,
        QuestionGuid = questionPoint.UniqueQuestionID,
        Points = questionPoint.NumberOfPoints
      }, new AuthorizeData(CurrentUserInfo.CurrentUser));
    }

    public delegate void QuestionPointsModify(QuestionPoint questionPoint);
  }
}
